﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Class_s.Outros;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Text.RegularExpressions;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConCategoria : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FrmCadCategoria frmCadastro;
        Ctrl_Categoria aCTRLCategorias; 
        Categoria oCategoria;
        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        public FrmConCategoria()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            aCTRLCategorias = new Ctrl_Categoria();
            CarregaLV();
        }
        public override void SetFrmCadastro(object obj)
        {
            if (obj is FrmCadCategoria)
            {
                frmCadastro = (FrmCadCategoria)obj;
            }
        }
        public virtual void ConhecaObj(object obj)
        {
            if (obj is Categoria) 
            {
                oCategoria = (Categoria)obj; 
            }
        }

        protected override void Incluir()
        {
            base.Incluir();
            aCTRLCategorias.Incluir(); 
            CarregaLV();
        }

        protected override void Alterar()
        {
            base.Alterar();
            int idCategoria = ObterIdSelecionado();
            if (idCategoria > 0)
            {
                Categoria Categoria = aCTRLCategorias.BuscarCategoriaPorId(idCategoria); 
                if (Categoria != null)
                {
                    aCTRLCategorias.Alterar(Categoria); 
                    CarregaLV();
                }
            }
        }

        public override void Excluir()
        {
            base.Excluir();
            int idCategoria = ObterIdSelecionado();
            if (idCategoria > 0)
            {
                Categoria Categoria = aCTRLCategorias.BuscarCategoriaPorId(idCategoria); 
                if (Categoria != null)
                {
                    aCTRLCategorias.Excluir(Categoria);
                    CarregaLV();
                }
            }
        }
        public virtual void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                Categoria Categoria = selectedItem.Tag as Categoria; 

                if (Categoria != null)
                {
                    aCTRLCategorias.Visualizar(Categoria); 
                }
            }
        }
        private void PreencherFichasListView(IEnumerable<Categoria> Categorias) 
        {
            LV_Con_Pai.Items.Clear();

            foreach (var Categoria in Categorias)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(Categoria.ID)); 
                item.SubItems.Add(Categoria.Nome);
                item.SubItems.Add(Categoria.DataCriacao.ToString());
                item.SubItems.Add(Categoria.DataUltimaAlteracao.ToString());
                item.Tag = Categoria; 
                LV_Con_Pai.Items.Add(item);
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            List<Categoria> Categorias = aCTRLCategorias.ListarCategoria(); 
            PreencherFichasListView(Categorias); 
        }

        public virtual void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCritérioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                
                var resultados = aCTRLCategorias.PesquisarCategoriaPorCriterio(criterioPesquisa, valorPesquisa);

                PreencherFichasListView(resultados); 
            }
        }

        public override void Atualizar()
        {
            base.Atualizar();
            CarregaLV();
        }

        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }
        private string ObterCritérioPesquisa()
        {
            if (RB_Codigo.Checked)
            {
                return "ID"; 
        
            }
            else if (RB_Categoria.Checked)
            {
                return "Categoria"; 
            }
            return string.Empty;
        
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
    }
}
