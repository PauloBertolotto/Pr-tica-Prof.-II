﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConPais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CH_Pais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DDI = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Sigla = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCadastro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(962, 21);
            this.btn_ConBuscar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(901, 668);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(973, 668);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(1045, 668);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Pais,
            this.CH_DDI,
            this.CH_Sigla,
            this.CH_DataCadastro,
            this.CH_DataUltAlt});
            this.LV_Con_Pai.Size = new System.Drawing.Size(1176, 611);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(1117, 21);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(9, 23);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txt_Codigo.Size = new System.Drawing.Size(946, 23);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1117, 668);
            // 
            // CH_Pais
            // 
            this.CH_Pais.Text = "País";
            this.CH_Pais.Width = 160;
            // 
            // CH_DDI
            // 
            this.CH_DDI.Text = "DDI";
            this.CH_DDI.Width = 70;
            // 
            // CH_Sigla
            // 
            this.CH_Sigla.Text = "Sigla";
            this.CH_Sigla.Width = 70;
            // 
            // CH_DataCadastro
            // 
            this.CH_DataCadastro.Text = "Data de Cadastro";
            this.CH_DataCadastro.Width = 150;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 150;
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(1036, 24);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(77, 22);
            this.CB_Inativos.TabIndex = 15;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            // 
            // FrmConPais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1211, 703);
            this.Controls.Add(this.CB_Inativos);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "FrmConPais";
            this.Text = "Consulta de País";
            this.Load += new System.EventHandler(this.FrmConPais_Load);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColumnHeader CH_Pais;
        private System.Windows.Forms.ColumnHeader CH_DDI;
        private System.Windows.Forms.ColumnHeader CH_Sigla;
        private System.Windows.Forms.ColumnHeader CH_DataCadastro;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
        private System.Windows.Forms.CheckBox CB_Inativos;
    }
}
