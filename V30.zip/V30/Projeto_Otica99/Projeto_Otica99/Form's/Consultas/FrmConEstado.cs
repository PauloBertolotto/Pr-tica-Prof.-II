﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConEstado : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        Estados oEstado;
        FrmCadEstado oCadEstado;
        Ctrl_Estados aCtrl_Estado;
        FrmCadEstado aFrmCadEstado;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        private string status = "A";
        public FrmConEstado()
        {
            InitializeComponent();

            oCadEstado = new FrmCadEstado();
            aCtrl_Estado = new Ctrl_Estados();
            oEstado = new Estados();

            CarregaLV();
        }
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadEstado = (FrmCadEstado)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Estado = (Ctrl_Estados)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadEstado.ConhecaObj(oEstado);
            oCadEstado.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            base.Alterar();
            int idEstado = ObterIdSelecionado();
            if (idEstado > 0)
            {
                Estados estado = aCtrl_Estado.BuscarEstadoPorId(idEstado);
                if (estado != null)
                {
                    
                    CarregaLV();
                }
            }
        }
        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Estado.Excluir(aux);
                }
                this.CarregaLV();
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            List<Estados> dados = aCtrl_Estado.ListarEstados(status);
            PreencherListView(dados);
        }

        private void LV_Con_Pai_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem linha = LV_Con_Pai.SelectedItems[0];

                oEstado.ID = Convert.ToInt16(linha.SubItems[0].Text);
                oEstado.Estado = linha.SubItems[1].Text;
                oEstado.UF = linha.SubItems[2].Text;
                oEstado.PaisID.ID = Convert.ToInt16(linha.SubItems[3].Text);
                oEstado.DataCriacao = Convert.ToDateTime(linha.SubItems[4]);
                oEstado.DataUltimaAlteracao = Convert.ToDateTime(linha.SubItems[5]);
            }
        }
        private string ObterCritérioPesquisa()
        {
            //if (cb_Codigo.Checked)
            //{
            //    return "ID";
            //}
            //else if (rbEstado.Checked)
            //{
            //    return "ESTADO";
            //}
            //else if (rbPais.Checked)
            //{
            //    return "PAIS";
            //}
            //else if (rbUF.Checked)
            //{
            //    return "UF";
            //}
            return string.Empty;
        }
        protected override void Buscar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCritérioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                var resultados = aCtrl_Estado.PesquisarEstadosPorCriterio(criterioPesquisa, valorPesquisa, status);

                // Use o método de preenchimento para atualizar a ListView
                PreencherListView(resultados);
            }
        }
        private void PreencherListView(IEnumerable<Estados> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var estado in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(estado.ID));
                item.SubItems.Add(estado.Estado);
                item.SubItems.Add(estado.UF);
                item.SubItems.Add(estado.PaisID.Pais); // Verificar se isso é o que realmente deseja mostrar
                item.SubItems.Add(estado.DataCriacao.ToString());
                item.SubItems.Add(estado.DataUltimaAlteracao.ToString());
                item.SubItems.Add(estado.Ativo == "I" ? "Inativo" : estado.Ativo == "A" ? "Ativo" : estado.Ativo);
                item.Tag = estado;
                LV_Con_Pai.Items.Add(item);
            }
        }
        public override void Atualizar()
        {
            CarregaLV();
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
    }
}
