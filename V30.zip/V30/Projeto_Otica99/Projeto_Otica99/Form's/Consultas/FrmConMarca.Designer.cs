﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConMarca
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RB_Codigo = new System.Windows.Forms.RadioButton();
            this.RB_Nome = new System.Windows.Forms.RadioButton();
            this.RB_Descricao = new System.Windows.Forms.RadioButton();
            this.CH_Nome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Descricao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCriacao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(1058, 21);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(915, 659);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(987, 659);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(1059, 659);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Nome,
            this.CH_Descricao,
            this.CH_DataCriacao,
            this.CH_DataUltAlt});
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 88);
            this.LV_Con_Pai.Size = new System.Drawing.Size(1190, 569);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(1131, 21);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Size = new System.Drawing.Size(1045, 23);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1131, 659);
            // 
            // RB_Codigo
            // 
            this.RB_Codigo.AutoSize = true;
            this.RB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.RB_Codigo.Location = new System.Drawing.Point(13, 53);
            this.RB_Codigo.Name = "RB_Codigo";
            this.RB_Codigo.Size = new System.Drawing.Size(74, 22);
            this.RB_Codigo.TabIndex = 10;
            this.RB_Codigo.TabStop = true;
            this.RB_Codigo.Text = "Código";
            this.RB_Codigo.UseVisualStyleBackColor = true;
            // 
            // RB_Nome
            // 
            this.RB_Nome.AutoSize = true;
            this.RB_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Nome.ForeColor = System.Drawing.Color.Gold;
            this.RB_Nome.Location = new System.Drawing.Point(93, 52);
            this.RB_Nome.Name = "RB_Nome";
            this.RB_Nome.Size = new System.Drawing.Size(67, 22);
            this.RB_Nome.TabIndex = 11;
            this.RB_Nome.TabStop = true;
            this.RB_Nome.Text = "Nome";
            this.RB_Nome.UseVisualStyleBackColor = true;
            // 
            // RB_Descricao
            // 
            this.RB_Descricao.AutoSize = true;
            this.RB_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Descricao.ForeColor = System.Drawing.Color.Gold;
            this.RB_Descricao.Location = new System.Drawing.Point(166, 53);
            this.RB_Descricao.Name = "RB_Descricao";
            this.RB_Descricao.Size = new System.Drawing.Size(94, 22);
            this.RB_Descricao.TabIndex = 12;
            this.RB_Descricao.TabStop = true;
            this.RB_Descricao.Text = "Descrição";
            this.RB_Descricao.UseVisualStyleBackColor = true;
            // 
            // CH_Nome
            // 
            this.CH_Nome.Text = "Nome";
            this.CH_Nome.Width = 150;
            // 
            // CH_Descricao
            // 
            this.CH_Descricao.Text = "Descrição";
            this.CH_Descricao.Width = 200;
            // 
            // CH_DataCriacao
            // 
            this.CH_DataCriacao.Text = "Data de Cadastro";
            this.CH_DataCriacao.Width = 155;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 155;
            // 
            // FrmConMarca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1207, 694);
            this.Controls.Add(this.RB_Descricao);
            this.Controls.Add(this.RB_Nome);
            this.Controls.Add(this.RB_Codigo);
            this.Name = "FrmConMarca";
            this.Text = "Consulta: Marcas";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.RB_Codigo, 0);
            this.Controls.SetChildIndex(this.RB_Nome, 0);
            this.Controls.SetChildIndex(this.RB_Descricao, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton RB_Codigo;
        private System.Windows.Forms.RadioButton RB_Nome;
        private System.Windows.Forms.RadioButton RB_Descricao;
        private System.Windows.Forms.ColumnHeader CH_Nome;
        private System.Windows.Forms.ColumnHeader CH_Descricao;
        private System.Windows.Forms.ColumnHeader CH_DataCriacao;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
    }
}
