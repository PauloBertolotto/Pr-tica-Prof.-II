﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConFormaPagamento : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FormaPagamento       aFormaPag;
        FrmCadFormaPag       oCadFormaPag;
        Ctrl_FormaPagamento  aCtrl_FormaPag;
        public int           IdSelecionado { get; private set; }
        public string        NomeSelecionado { get; private set; }
        public FrmConFormaPagamento()
        {
            InitializeComponent();
            aFormaPag      = new FormaPagamento();
            aCtrl_FormaPag = new Ctrl_FormaPagamento();
            CarregaLV();
        }
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadFormaPag = (FrmCadFormaPag)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_FormaPag = (Ctrl_FormaPagamento)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadFormaPag.ConhecaObj(aFormaPag);
            oCadFormaPag.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            string aux = oCadFormaPag.btn_Salvar.Text;
            oCadFormaPag.txt_Codigo.Enabled = false;
            oCadFormaPag.btn_Salvar.Text = "Alterar";
           
            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                // Preencha os campos ou propriedades da tela de destino com os dados do item selecionado
                oCadFormaPag.txt_Codigo.Text = itemSelecionado.SubItems[0].Text;
                oCadFormaPag.txt_FormaPag.Text = itemSelecionado.SubItems[1].Text;
                oCadFormaPag.CB_Status.Text = itemSelecionado.SubItems[2].Text;
                               
                // Exiba a tela de destino
                oCadFormaPag.ShowDialog();
                oCadFormaPag.btn_Salvar.Text = aux;
                oCadFormaPag.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_FormaPag.Excluir(aux);

                }
                this.CarregaLV();
            }
        }
        protected override void Buscar()
        {
            base.Buscar();
            string valorPesquisa = txt_Codigo.Text;

            if (!string.IsNullOrEmpty(valorPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                LV_Con_Pai.Items.Clear();
                var lista = aCtrl_FormaPag.Pesquisar(valorPesquisa);

                if (lista != null)
                {
                    foreach (var aFormaPag in lista)
                    {
                        ListViewItem item = new ListViewItem(Convert.ToString(aFormaPag.ID));
                        if (aFormaPag.StatusForma == "A")
                        {
                            item.SubItems.Add(aFormaPag.Forma);
                            item.SubItems.Add(aFormaPag.StatusForma);
                            item.SubItems.Add(Convert.ToString(aFormaPag.DataCriacao));
                            item.SubItems.Add(Convert.ToString(aFormaPag.DataUltimaAlteracao));


                            LV_Con_Pai.Items.Add(item);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Nenhum registro chamado " + txt_Codigo.Text);
                }
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            LV_Con_Pai.Items.Clear();
            if (aCtrl_FormaPag != null)
            {
                var lista = aCtrl_FormaPag.ListarFormasPag();
                foreach (var aFormaPag in lista)
                {
                                  
                    ListViewItem item = new ListViewItem(Convert.ToString(aFormaPag.ID));
                    if ((aFormaPag.StatusForma == "I" && CB_Inativos.Checked) || (aFormaPag.StatusForma == "A" && !CB_Inativos.Checked))
                    {
                        item.SubItems.Add(aFormaPag.Forma);
                        item.SubItems.Add(aFormaPag.StatusForma);                           
                        item.SubItems.Add(Convert.ToString(aFormaPag.DataCriacao));
                        item.SubItems.Add(Convert.ToString(aFormaPag.DataUltimaAlteracao));
        
                        LV_Con_Pai.Items.Add(item);
                    }
                    
                }
            }
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
    }
}
