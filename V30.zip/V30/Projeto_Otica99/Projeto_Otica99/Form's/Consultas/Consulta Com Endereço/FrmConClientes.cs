﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço
{
    public partial class FrmConClientes : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        DadosCadastro oCliente;
        FrmCadPFePJ   oCadCliente;
        Ctrl_Clientes aCtrl_Clientes;
        Ctrl_Cidades  aCtrl_Cidades;
        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        private string status = "A";
        public FrmConClientes()
        {
            InitializeComponent();
            oCliente       = new DadosCadastro();
            aCtrl_Clientes = new Ctrl_Clientes();
            aCtrl_Cidades  = new Ctrl_Cidades();
            CarregaLV();
        }
        public int id = 0;
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadCliente = (FrmCadPFePJ)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Clientes = (Ctrl_Clientes)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadCliente.ConhecaObj(oCliente);
            oCadCliente.lbl_Generica.Text = "Cliente";
            oCadCliente.ShowDialog();
            this.CarregaLV();
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
        protected override void Alterar()
        {
            string aux = oCadCliente.btn_Salvar.Text;      
            oCadCliente.btn_Salvar.Text   = "Alterar";
            oCadCliente.lbl_Generica.Text = "Cliente";
            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                oCadCliente.txt_Codigo.Text             = itemSelecionado.SubItems[0].Text;
                oCadCliente.txt_NomeOuNFantasia.Text    = itemSelecionado.SubItems[1].Text;
                oCadCliente.txt_SobrenomeOuRSocial.Text = itemSelecionado.SubItems[2].Text;
                if (itemSelecionado.SubItems[3].Text.Length < 18)
                {
                    oCadCliente.CB_Tipo.Text = "PF";
                    oCadCliente.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadCliente.CB_Tipo.Enabled   = false;
                }
                else
                {
                    oCadCliente.CB_Tipo.Text = "PJ";
                    oCadCliente.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadCliente.CB_Sexo.Text = null;
                    oCadCliente.CB_Tipo.Enabled   = false;
                }
                oCadCliente.mtb_RGeIE.Text        = itemSelecionado.SubItems[4].Text;
                oCadCliente.txt_Email.Text        = itemSelecionado.SubItems[5].Text;
                oCadCliente.txt_Telefone.Text     = itemSelecionado.SubItems[6].Text;
                oCadCliente.txt_Numero.Text       = itemSelecionado.SubItems[9].Text;
                oCadCliente.txt_Endereco.Text     = itemSelecionado.SubItems[7].Text;
                oCadCliente.txt_Complemento.Text  = itemSelecionado.SubItems[8].Text;
                oCadCliente.mtb_CEP.Text          = itemSelecionado.SubItems[11].Text;        
                oCadCliente.txt_Bairro.Text       = itemSelecionado.SubItems[10].Text;
                oCadCliente.txt_Cidade.Text       = itemSelecionado.SubItems[12].Text;
                oCadCliente.CB_Sexo.Text          = itemSelecionado.SubItems[14].Text;
                oCadCliente.txt_CodCidade.Text    = Convert.ToInt32(aCtrl_Clientes.BuscarIDCidade(oCadCliente.txt_Cidade.Text)).ToString();

                // Exiba a tela de destino
                oCadCliente.ShowDialog();
                oCadCliente.btn_Salvar.Text = aux;          
                oCadCliente.CB_Tipo.Enabled = true;
                oCadCliente.CB_Sexo.Enabled = true;
                oCadCliente.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            List<DadosCadastro> dados = aCtrl_Clientes.ListarClientes(status);
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<DadosCadastro> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var cliente in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(cliente.ID));
                string NomeOuNomeFantasia = string.IsNullOrWhiteSpace(cliente.NomeOuNomeFantasia) ? "Não Cadastrado" : cliente.NomeOuNomeFantasia;
                item.SubItems.Add(NomeOuNomeFantasia);

                string SobrenomeOuRSocial = string.IsNullOrWhiteSpace(cliente.SobrenomeOuRSocial) ? "Não Cadastrado" : cliente.SobrenomeOuRSocial;
                item.SubItems.Add(SobrenomeOuRSocial);

                string cnpj = string.IsNullOrWhiteSpace(cliente.CPFouCNPJ) ? "Não Cadastrado" : Verificacao.FormatarDocumento(cliente.CPFouCNPJ);
                item.SubItems.Add(cnpj);

                string RGouIE = string.IsNullOrWhiteSpace(cliente.RGouIE) ? "Não Cadastrado" : Verificacao.FormatarDocumento(cliente.RGouIE);
                item.SubItems.Add(RGouIE);

                item.SubItems.Add(cliente.Email);

                string telefone = string.IsNullOrEmpty(cliente.Telefone) ? "Não Cadastrado" : Verificacao.FormatarTelefone(cliente.Telefone);
                item.SubItems.Add(telefone);

                string endereco = string.IsNullOrEmpty(cliente.Endereco) ? "Não Cadastrado" : (cliente.Endereco);
                item.SubItems.Add(endereco);

                string complemento = string.IsNullOrEmpty(cliente.Complemento) ? "Não Cadastrado" : (cliente.Complemento);
                item.SubItems.Add(complemento);

                string numero = string.IsNullOrEmpty(cliente.Numero) ? "Não Cadastrado" : (cliente.Numero);
                item.SubItems.Add(numero);

                string bairro = string.IsNullOrEmpty(cliente.Bairro) ? "Não Cadastrado" : (cliente.Bairro);
                item.SubItems.Add(bairro);

                string cep = string.IsNullOrEmpty(cliente.CEP) ? "Não Cadastrado" : (cliente.CEP);
                item.SubItems.Add(cep);

                string cidade = string.IsNullOrWhiteSpace(aCtrl_Clientes.BuscarCidadePorId(cliente.CidadeID.ID)) ? "Não Cadastrado" : aCtrl_Clientes.BuscarCidadePorId(cliente.CidadeID.ID);
                item.SubItems.Add(cidade);

                string uf = string.IsNullOrWhiteSpace(aCtrl_Cidades.BuscarUFPorId(cliente.CidadeID.EstadoID.ID)) ? "Não Cadastrado" : aCtrl_Cidades.BuscarUFPorId(cliente.CidadeID.EstadoID.ID);
                item.SubItems.Add(uf);

                string sexo = string.IsNullOrEmpty(cliente.Sexo) ? "Não Cadastrado" : (cliente.Sexo);
                item.SubItems.Add(sexo);

                string datacad = string.IsNullOrEmpty(cliente.DataCriacao.ToString()) ? "Não Cadastrado" : (cliente.DataCriacao.ToString());
                item.SubItems.Add(datacad);

                string dataalt = string.IsNullOrEmpty(cliente.DataUltimaAlteracao.ToString()) ? "Não Cadastrado" : (cliente.DataUltimaAlteracao.ToString());
                item.SubItems.Add(dataalt);

                string condpag = string.IsNullOrEmpty(cliente.condicao_Pagamento.Condicao) ? "Não Cadastrado" : (cliente.condicao_Pagamento.Condicao);
                item.SubItems.Add(condpag);

                item.SubItems.Add(cliente.condicao_Pagamento.Condicao);

                item.Tag = cliente;
                LV_Con_Pai.Items.Add(item);
            }
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Clientes.Excluir(aux);

                }
                this.CarregaLV();
            }
        }
        //protected override void Buscar()
        //{
        //    base.Buscar();
        //    string valorPesquisa = txt_Codigo.Text;
        //
        //    if (!string.IsNullOrEmpty(valorPesquisa))
        //    {
        //        // Execute uma pesquisa na camada de controle com base no critério
        //        LV_Con_Pai.Items.Clear();
        //        var lista = aCtrl_Clientes.Pesquisar(valorPesquisa);
        //
        //        if (lista != null)
        //        {
        //            foreach (var oCliente in lista)
        //            {
        //                ListViewItem item = new ListViewItem(Convert.ToString(oCliente.ID));
        //                if (oCliente.Ativo == "A")
        //                {
        //                    item.SubItems.Add(oCliente.NomeOuNomeFantasia);
        //                    item.SubItems.Add(oCliente.SobrenomeOuRSocial);
        //                    item.SubItems.Add(oCliente.CPFouCNPJ);
        //                    item.SubItems.Add(oCliente.Email);
        //                    item.SubItems.Add(oCliente.Telefone);
        //                    item.SubItems.Add(oCliente.RGouIE);
        //                    item.SubItems.Add(Convert.ToString(aCtrl_Clientes.BuscarCidadePorId(oCliente.CidadeID)));
        //                    item.SubItems.Add(aCtrl_Clientes.BuscaUF(Convert.ToString(aCtrl_Clientes.BuscarCidadePorId(oCliente.CidadeID))));
        //                    item.SubItems.Add(oCliente.Endereco);
        //                    item.SubItems.Add(oCliente.Complemento);
        //                    item.SubItems.Add(oCliente.Numero);
        //                    item.SubItems.Add(oCliente.Bairro);
        //                    item.SubItems.Add(oCliente.CEP);
        //
        //                    item.SubItems.Add(Convert.ToString(oCliente.DataCriacao));
        //                    item.SubItems.Add(Convert.ToString(oCliente.DataUltimaAlteracao));
        //
        //
        //                    LV_Con_Pai.Items.Add(item);
        //                }
        //            }
        //        }
        //        else
        //        {
        //            // Caso não haja resultados, limpe a ListView ou mostre uma mensagem adequada
        //            // Exemplo: LV_Con_Pai.Items.Clear();
        //        }
        //    }
        //}
        public override void Atualizar()
        {
            CarregaLV();
        }
    }
}
