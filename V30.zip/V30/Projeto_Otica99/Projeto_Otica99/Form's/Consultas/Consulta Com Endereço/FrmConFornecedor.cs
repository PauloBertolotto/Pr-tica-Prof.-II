﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using System.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Projeto_Otica99.Class_s.Outros;
using System.Net.NetworkInformation;
using Projeto_Otica99.Class_s.DAO_s;
using System.Runtime.ConstrainedExecution;

namespace Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço
{
    public partial class FrmConFornecedor : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        DadosCadastro     oFornecedor;
        FrmCadPFePJ       oCadFornecedor;
        Ctrl_Fornecedores aCtrl_Fornecedor;
        Ctrl_Cidades      aCtrl_Cidades;
      

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        private string status = "A";

        public FrmConFornecedor()
        {
            InitializeComponent();
            oFornecedor      = new DadosCadastro();
            aCtrl_Fornecedor = new Ctrl_Fornecedores();
            aCtrl_Cidades    = new Ctrl_Cidades();
            oCadFornecedor   = new FrmCadPFePJ();
            CarregaLV();
        }
        public int id = 0;
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadFornecedor = (FrmCadPFePJ)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Fornecedor = (Ctrl_Fornecedores)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadFornecedor.ConhecaObj(oFornecedor);
            oCadFornecedor.lbl_Generica.Text = "Fornecedor";
            oCadFornecedor.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {             
            string aux                        = oCadFornecedor.btn_Salvar.Text;
            oCadFornecedor.txt_Codigo.Enabled = false;
            oCadFornecedor.btn_Salvar.Text    = "Alterar";
            oCadFornecedor.lbl_Generica.Text  = "Fornecedor";

            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                oCadFornecedor.txt_Codigo.Text = itemSelecionado.SubItems[0].Text;
                oCadFornecedor.txt_NomeOuNFantasia.Text = itemSelecionado.SubItems[1].Text;
                oCadFornecedor.txt_SobrenomeOuRSocial.Text = itemSelecionado.SubItems[2].Text;
                if (itemSelecionado.SubItems[3].Text.Length < 18)
                {
                    oCadFornecedor.CB_Tipo.Text = "PF";
                    oCadFornecedor.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFornecedor.CB_Tipo.Enabled = false;
                }
                else
                {
                    oCadFornecedor.CB_Tipo.Text = "PJ";
                    oCadFornecedor.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFornecedor.CB_Sexo.Text = null;
                    oCadFornecedor.CB_Tipo.Enabled = false;
                }
                oCadFornecedor.mtb_RGeIE.Text = itemSelecionado.SubItems[4].Text;
                oCadFornecedor.txt_Email.Text = itemSelecionado.SubItems[5].Text;
                oCadFornecedor.txt_Telefone.Text = itemSelecionado.SubItems[6].Text;
                oCadFornecedor.txt_Numero.Text = itemSelecionado.SubItems[9].Text;
                oCadFornecedor.txt_Endereco.Text = itemSelecionado.SubItems[7].Text;
                oCadFornecedor.txt_Complemento.Text = itemSelecionado.SubItems[8].Text;
                oCadFornecedor.mtb_CEP.Text = itemSelecionado.SubItems[11].Text;
                oCadFornecedor.txt_Bairro.Text = itemSelecionado.SubItems[10].Text;
                oCadFornecedor.txt_Cidade.Text = itemSelecionado.SubItems[12].Text;
                oCadFornecedor.CB_Sexo.Text = itemSelecionado.SubItems[14].Text;
                oCadFornecedor.txt_CodCidade.Text = Convert.ToInt32(aCtrl_Fornecedor.BuscarIDCidade(oCadFornecedor.txt_Cidade.Text)).ToString();

                // Exiba a tela de destino
                oCadFornecedor.ShowDialog();
                oCadFornecedor.btn_Salvar.Text = aux;
                oCadFornecedor.CB_Tipo.Enabled = true;
                oCadFornecedor.CB_Sexo.Enabled = true;
                oCadFornecedor.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
        protected override void Buscar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCritérioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                var resultados = aCtrl_Fornecedor.PesquisarFornecedoresPorCriterio(criterioPesquisa, valorPesquisa, status);

              
                PreencherListView(resultados);
            }
        }
        private string ObterCritérioPesquisa()
        {
            if (CB_Codigo.Checked)
            {
                return "ID";
            }
            else if (CB_NomeF.Checked)
            {
                return "NOME";
            }
            else if (CB_Cidade.Checked)
            {
                return "CIDADE";
            }
            else if (CB_CNPJ.Checked)
            {
                return "CNPJ";
            }
            else if (CB_Status.Checked)
            {
                return "STATUS";
            }

            return string.Empty; 
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Fornecedor.Excluir(aux);
                    
                }
                this.CarregaLV();
            }
        }
        
        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }

        public override void CarregaLV()
        {
            base.CarregaLV();
            List<DadosCadastro> dados = aCtrl_Fornecedor.ListarFornecedores(status);
            PreencherListView(dados);
        }

        private void PreencherListView(IEnumerable<DadosCadastro> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var fornecedor in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(fornecedor.ID));

                string nomeFantasia = string.IsNullOrWhiteSpace(fornecedor.NomeOuNomeFantasia) ? "Não Cadastrado" : fornecedor.NomeOuNomeFantasia;
                item.SubItems.Add(nomeFantasia);

                string razaoSocial = string.IsNullOrWhiteSpace(fornecedor.SobrenomeOuRSocial) ? "Não Cadastrado" : fornecedor.SobrenomeOuRSocial;
                item.SubItems.Add(razaoSocial);

                string cnpj = string.IsNullOrWhiteSpace(fornecedor.CPFouCNPJ) ? "Não Cadastrado" : Verificacao.FormatarDocumento(fornecedor.CPFouCNPJ);
                item.SubItems.Add(cnpj);

                string inscricaoEstadual = string.IsNullOrWhiteSpace(fornecedor.RGouIE) ? "Não Cadastrado" : Verificacao.FormatarDocumento(fornecedor.RGouIE);
                item.SubItems.Add(inscricaoEstadual);

                item.SubItems.Add(fornecedor.Email);

                string telefone = string.IsNullOrEmpty(fornecedor.Telefone) ? "Não Cadastrado" : Verificacao.FormatarTelefone(fornecedor.Telefone);
                item.SubItems.Add(telefone);

                string endereco = string.IsNullOrEmpty(fornecedor.Endereco) ? "Não Cadastrado" : (fornecedor.Endereco);
                item.SubItems.Add(endereco);

                string complemento = string.IsNullOrEmpty(fornecedor.Complemento) ? "Não Cadastrado" : (fornecedor.Complemento);
                item.SubItems.Add(complemento);

                string numero = string.IsNullOrEmpty(fornecedor.Numero) ? "Não Cadastrado" : (fornecedor.Numero);
                item.SubItems.Add(numero);

                string bairro = string.IsNullOrEmpty(fornecedor.Bairro) ? "Não Cadastrado" : (fornecedor.Bairro);
                item.SubItems.Add(bairro);

                string cep = string.IsNullOrEmpty(fornecedor.CEP) ? "Não Cadastrado" : (fornecedor.CEP);
                item.SubItems.Add(cep);

                string cidade = string.IsNullOrWhiteSpace(aCtrl_Fornecedor.BuscarCidadePorId(fornecedor.CidadeID.ID)) ? "Não Cadastrado" : aCtrl_Fornecedor.BuscarCidadePorId(fornecedor.CidadeID.ID);
                item.SubItems.Add(cidade); 

                string uf = string.IsNullOrWhiteSpace(aCtrl_Cidades.BuscarUFPorId(fornecedor.CidadeID.EstadoID.ID)) ? "Não Cadastrado" : aCtrl_Cidades.BuscarUFPorId(fornecedor.CidadeID.EstadoID.ID);
                item.SubItems.Add(uf);

                string sexo = string.IsNullOrEmpty(fornecedor.Sexo) ? "Não Cadastrado" : (fornecedor.Sexo);
                item.SubItems.Add(sexo);

                string datacad = string.IsNullOrEmpty(fornecedor.DataCriacao.ToString()) ? "Não Cadastrado" : (fornecedor.DataCriacao.ToString());
                item.SubItems.Add(datacad);

                string dataalt = string.IsNullOrEmpty(fornecedor.DataUltimaAlteracao.ToString()) ? "Não Cadastrado" : (fornecedor.DataUltimaAlteracao.ToString());
                item.SubItems.Add(dataalt);

                string condpag = string.IsNullOrEmpty(fornecedor.condicao_Pagamento.Condicao) ? "Não Cadastrado" : (fornecedor.condicao_Pagamento.Condicao);
                item.SubItems.Add(condpag);

                item.SubItems.Add(fornecedor.condicao_Pagamento.Condicao);

                item.Tag = fornecedor;
                LV_Con_Pai.Items.Add(item);
            }
        }
    }
}
