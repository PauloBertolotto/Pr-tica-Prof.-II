﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConCompra : Projeto_Otica99.FrmPai
    {
        FrmCadCompra frmCadCompras;
        Ctrl_Compras aCTRLCompras;
        Compras      aCompra;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }

        private bool Cancelada = false;

        public FrmConCompra()
        {
            InitializeComponent();
            aCTRLCompras = new Ctrl_Compras();
            Verificacao.DisableCopyPaste(this);
            CarregaLV();
        }

        public virtual void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmCadCompras = (FrmCadCompra)obj;
            }
        }
        public virtual void ConhecaObj(object obj)
        {
            aCompra = (Compras)obj;
        }
        public virtual void Incluir()
        {
            aCTRLCompras.Incluir();
            CarregaLV();
        }
        public virtual void Excluir()
        {
            int Numero     = ObterIdSelecionado(0); 
            int Modelo     = ObterIdSelecionado(1); 
            int Serie      = ObterIdSelecionado(2); 
            int Fornecedor = ObterIdSelecionado(3); 

            if (Fornecedor > 0)
            {
                Compras compra = aCTRLCompras.BuscarCompraPorChave(Numero, Modelo, Serie, Fornecedor);

                if (compra != null)
                {
                    Ctrl_ContasPagar aCTLConta = new Ctrl_ContasPagar();
                    var result = aCTLConta.VerificarExistenciaDeCompra(compra.NumNFC, compra.ModeloNFC, compra.SerieNFC, compra.Fornecedor.ID);
                    if (!result)
                    {
                        aCTRLCompras.CancelarNota(compra);
                        CarregaLV();
                    }
                    else
                    {
                        MessageBox.Show("Impossivel cancelar nota, pois a mesma já possui baixa");
                    }

                }
            }
        }
        private int ObterIdSelecionado(int posicao)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                return int.Parse(listView1.SelectedItems[0].SubItems[posicao].Text);
            }
            return 0;
        }
        public virtual void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                Compras compra = selectedItem.Tag as Compras;
                if (compra != null)
                {
                    aCTRLCompras.Visualizar(compra);
                    CarregaLV();
                }
            }
        }
        public virtual void CarregaLV()
        {
            List<Compras> dados = aCTRLCompras.ListarCompras(Cancelada);
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<Compras> dados)
        {
            listView1.Items.Clear();

            foreach (var compra in dados)
            {
                ListViewItem item = new ListViewItem(compra.NumNFC.ToString());
                item.SubItems.Add(compra.ModeloNFC.ToString());
                item.SubItems.Add(compra.SerieNFC.ToString());
                item.SubItems.Add(compra.Fornecedor.ID.ToString());
                item.SubItems.Add(compra.Fornecedor.NomeOuNomeFantasia);
                item.SubItems.Add(compra.Condicao.Condicao);
                item.SubItems.Add(compra.ValorTotal.ToString("C"));
                item.SubItems.Add(compra.ValorFrete.ToString("C"));
                item.SubItems.Add(compra.ValorSeguro.ToString("C"));
                item.SubItems.Add(compra.ValorOutrasDespesas.ToString("C"));
                item.SubItems.Add(compra.DataChegada.ToString());
                item.SubItems.Add(compra.DataEmissao.ToString());
                item.SubItems.Add(compra.DataCancelamento == DateTime.MinValue ? "Não Cancelada" : compra.DataCancelamento.ToString()); // Verifica se a data de cancelamento é MinValue
                item.SubItems.Add(compra.DataCriacao.ToString());
                item.SubItems.Add(compra.StatusCompra.ToString());
                item.Tag = compra;
                listView1.Items.Add(item);
            }
        }
        protected virtual void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (listView1.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = listView1.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
        protected virtual void Pesquisar()
        {
            // Obtém os parâmetros de filtragem
            DateTime? dataInicio = null;
            DateTime? dataFim = null;
            bool? cancelada = null;

            if (dtData1.Value.Date > DateTime.MinValue.Date)
            {
                dataInicio = dtData1.Value.Date;
            }

            if (dtData2.Value.Date > DateTime.MinValue.Date)
            {
                dataFim = dtData2.Value.Date;
            }

            if (CB_Canceladas.Checked)
            {
                cancelada = true;
            }

            if (string.IsNullOrEmpty(CB_Datas.Text)) // Verifica se o ComboBox de tipo de data está vazio
            {
                return;
            }

            // Chama o método de filtragem passando os parâmetros
            Filtrar(dataInicio, dataFim, cancelada, txt_Codigo.Text, CB_Datas.Text);
        }
        private void Filtrar(DateTime? dataInicio, DateTime? dataFim, bool? cancelada, string nomeFornecedor, string tipoData)
        {
            // Chama o método de listagem passando os parâmetros de filtragem
            List<Compras> compras = aCTRLCompras.ListarCompras(dataInicio, dataFim, cancelada, nomeFornecedor, tipoData);

            // Preenche o ListView com os resultados
            PreencherListView(compras);
        }

        private void CB_Canceladas_CheckedChanged(object sender, EventArgs e)
        {
            if (!CB_Canceladas.Checked)
            {
                btn_Excluir.Enabled = true;
                Cancelada = false;
                CarregaLV();
            }
            else
            {
                Cancelada = true;
                btn_Excluir.Enabled = false;
                CarregaLV();
            }
        }

        protected virtual void Alterar()
        {
            if (Convert.ToInt32(txt_CFornecedor.Text) > 0)
            {
                int codigo = Convert.ToInt32(txt_Numero.Text);
                int modelo = Convert.ToInt32(txt_Modelo.Text);
                int serie = Convert.ToInt32(txt_Serie.Text);
                int fornecedor = Convert.ToInt32(txt_CFornecedor.Text);

                List<Compras> dados = aCTRLCompras.BuscarListaCompraPorChave(codigo, modelo, serie, fornecedor);
                PreencherListView(dados);
            }
        }

        private void txt_Numero_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.' || e.KeyChar == ',')
            {
                e.Handled = true;
            }
        }

        private void btn_NovaVenda_Click(object sender, EventArgs e)
        {
            Incluir();
        }

        private void btn_BuscarDados_Click(object sender, EventArgs e)
        {
            using (FrmConFornecedor consultaFornecedor = new FrmConFornecedor())
            {
                consultaFornecedor.btn_Sair.Text = "Selecionar";
                consultaFornecedor.ShowDialog();

                int IdSelecionado = consultaFornecedor.IdSelecionado;
                string NomeSelecionado = consultaFornecedor.NomeSelecionado;

                txt_CFornecedor.Text = IdSelecionado.ToString();
            }
        }

        private void btn_CancelarV_Click(object sender, EventArgs e)
        {
            Excluir();
        }
    }
}
