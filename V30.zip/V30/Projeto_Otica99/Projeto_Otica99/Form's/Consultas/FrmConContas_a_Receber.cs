﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConContas_a_Receber : Projeto_Otica99.FrmPai
    {
        FrmCadContasReceber frmContaReceber;
        ContasReceber aContasReceber;
        private Dictionary<string, double> _colunasProporcao = new Dictionary<string, double>();
        Ctrl_ContasReceber aCTRLContaReceber;
        public FrmConContas_a_Receber()
        {
            InitializeComponent();
            this.Resize += FrmConContas_a_Receber_Resize;
            aCTRLContaReceber = new Ctrl_ContasReceber();
            Verificacao.DisableCopyPaste(this);
            DataGrid();
            CarregaLV();
        }
        public void ConhecaObj(object obj)
        {
            aContasReceber = (ContasReceber)obj;
        }
        public void CarregaLV()
        {
            string valor = CB_Status.Text;
            if (string.IsNullOrEmpty(valor))
                valor = "A RECEBER";
            List<ContasReceber> dados = aCTRLContaReceber.ListarContasReceber(valor);
            PreencherDataGridView(dados);
        }
        protected virtual void PreencherDataGridView(IEnumerable<ContasReceber> dados)
        {
            dgvContas.Rows.Clear();

            foreach (var conta in dados)
            {
                int rowIndex = dgvContas.Rows.Add();
                DataGridViewRow row = dgvContas.Rows[rowIndex];

                row.Cells["num_nfc"].Value = conta.NumNFC;
                row.Cells["modelo_nfc"].Value = conta.ModeloNFC;
                row.Cells["serie_nfc"].Value = conta.SerieNFC;
                row.Cells["num_parcela"].Value = conta.NumParcela;
                row.Cells["id_cliente"].Value = conta.Cliente.ID;
                row.Cells["cliente"].Value = conta.Cliente.NomeOuNomeFantasia;
                row.Cells["Forma_pagamento"].Value = conta.FormaPagamento.Forma;
                row.Cells["Data_emissao"].Value = conta.DataCriacao == DateTime.MinValue ? string.Empty : conta.DataCriacao.ToString("dd/MM/yyyy");
                row.Cells["data_vencimento"].Value = conta.DataVencimento == DateTime.MinValue ? string.Empty : conta.DataVencimento.ToString("dd/MM/yyyy");
                row.Cells["Valor"].Value = conta.Valor == 0 ? string.Empty : conta.Valor.ToString("C");
                row.Cells["data_baixa"].Value = conta.DataBaixa == DateTime.MinValue ? string.Empty : conta.DataBaixa.ToString("dd/MM/yyyy");
                row.Cells["Pagamento"].Value = conta.Pagamento == 0 ? string.Empty : conta.Pagamento.ToString("C");
                row.Cells["Juros"].Value = conta.Condicao.Taxa;
                row.Cells["Multa"].Value = conta.Condicao.Multa;
                row.Cells["Desconto"].Value = conta.Condicao.Desconto;
                row.Cells["situacao"].Value = conta.Situacao;
                row.Tag = conta;
            }

            AplicarFormatacao();
        }
        protected void AplicarFormatacao() 
        {
           
            foreach (DataGridViewRow row in dgvContas.Rows)
            {
               
                dgvContas.CurrentCell = null;

                
                string situacao = row.Cells["situacao"].Value as string;

                
                if (situacao == "PAGO")
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        cell.Style.BackColor = Color.LightGreen;
                        cell.Style.ForeColor = Color.Black;
                    }
                }
                else if (situacao == "CANCELADA")
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        cell.Style.BackColor = Color.Gray;
                        cell.Style.ForeColor = Color.Black;
                    }
                }
                else
                {
                    
                    if (row.Cells["data_vencimento"].Value != null && DateTime.TryParse(row.Cells["data_vencimento"].Value.ToString(), out DateTime dataVencimento))
                    {
                        TimeSpan diasParaVencimento = dataVencimento - DateTime.Now;

                        Color backColor;
                        Color foreColor;

                        if (diasParaVencimento.TotalDays < 0)
                        {
                            backColor = Color.DarkRed;
                            foreColor = Color.White;  
                        }
                        else if (diasParaVencimento.TotalDays <= 3)
                        {
                            backColor = Color.Orange; 
                            foreColor = Color.Black;  
                        }
                        else
                        {
                            backColor = Color.Yellow; 
                            foreColor = Color.Black;  
                        }

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            cell.Style.BackColor = backColor;
                            cell.Style.ForeColor = foreColor;
                        }
                    }
                }
            }
        }
        protected void DataGrid()
        {
          
            dgvContas.AutoGenerateColumns = false;
            dgvContas.Columns.Clear(); 
            dgvContas.Columns.AddRange(new DataGridViewTextBoxColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "num_nfc", HeaderText = "Nº NFC", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "modelo_nfc", HeaderText = "Modelo", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "serie_nfc", HeaderText = "Série", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "num_parcela", HeaderText = "Parcela", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "id_cliente", HeaderText = "Cód Cliente.", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "cliente", HeaderText = "Cliente", Width = 200 },
                new DataGridViewTextBoxColumn { Name = "Forma_pagamento", HeaderText = "Forma Pgt", Width = 155 },
                new DataGridViewTextBoxColumn { Name = "Data_emissao", HeaderText = "Data Emissão", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "data_vencimento", HeaderText = "Data Vencimento", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Valor", HeaderText = "Parcela VR (R$)", Width = 120 },
                new DataGridViewTextBoxColumn { Name = "data_baixa", HeaderText = "Data Baixa", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Pagamento", HeaderText = "Valor PG (R$)", Width = 120 },
                new DataGridViewTextBoxColumn { Name = "Juros", HeaderText = "Juros", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "Multa", HeaderText = "Multa", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "Desconto", HeaderText = "Desconto", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "situacao", HeaderText = "Status", Width = 110 },
            });

            dgvContas.RowTemplate.Height = 40;

            dgvContas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvContas.MultiSelect = false;
            CalcularProporcoesColunas(dgvContas);
        }
        public void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmContaReceber = (FrmCadContasReceber)obj;
            }
        }

        private void FrmConContas_a_Receber_Resize(object sender, EventArgs e)
        {
            if (this.Controls.OfType<DataGridView>().Any())
            {
                DataGridView dgv = this.Controls.OfType<DataGridView>().First();
                RedimensionarColunas(dgv);
            }
        }
        protected void RedimensionarColunas(DataGridView dgv)
        {
            double larguraTotal = dgv.Width;

            foreach (DataGridViewColumn coluna in dgv.Columns)
            {
                if (coluna.Visible && _colunasProporcao.ContainsKey(coluna.Name))
                {
                    coluna.Width = (int)(_colunasProporcao[coluna.Name] * larguraTotal);
                }
            }
        }
        protected void CalcularProporcoesColunas(DataGridView dgv)
        {
            _colunasProporcao.Clear();
            double larguraTotal = dgv.Width;

            foreach (DataGridViewColumn coluna in dgv.Columns)
            {
                if (coluna.Visible)
                {
                    _colunasProporcao[coluna.Name] = (double)coluna.Width / larguraTotal;
                }
            }
        }

        private void btn_BuscarDados_Click(object sender, EventArgs e)
        {
            int NumNFC = Convert.ToInt32(txt_Numero.Text);
            int ModeloNFC = Convert.ToInt32(txt_Modelo.Text);
            int SerieNFC = Convert.ToInt32(txt_Serie.Text);
            int ParcelaNFC = Convert.ToInt32(txt_NParcelas.Text);

            List<ContasReceber> dados = aCTRLContaReceber.BuscarContas(NumNFC, ModeloNFC, SerieNFC, ParcelaNFC);
            PreencherDataGridView(dados);
        }

        private void btn_BuscarFornecedor_Click(object sender, EventArgs e)
        {
            CarregaLV();
        }

        private void btn_BuscarData_Click(object sender, EventArgs e)
        {
            if (dtData1.Value > dtData2.Value)
            {
                MessageBox.Show("O periodo de busca não pode conter uma data inicial maior que a data final.");
            }
            else
                PesquisarContasReceber();
        }
        protected void PesquisarContasReceber()
        {
           
            DateTime? dataInicio = null;
            DateTime? dataFim = null;

            if (dtData1.Value.Date > DateTime.MinValue.Date)
            {
                dataInicio = dtData1.Value.Date;
            }

            if (dtData2.Value.Date > DateTime.MinValue.Date)
            {
                dataFim = dtData2.Value.Date;
            }
            if (string.IsNullOrEmpty(CB_Datas.Text)) 
            {
                return;
            }
        
            DateTime dataInicioValue = dataInicio ?? DateTime.MinValue;
            DateTime dataFimValue = dataFim ?? DateTime.MinValue;

            
            List<ContasReceber> contas = aCTRLContaReceber.ListarContasReceberComData(CB_Status.Text, dataInicioValue, dataFimValue, CB_Datas.Text);
            PreencherDataGridView(contas);
        }
        protected int ObterIdSelecionado(string columnName)
        {
            if (dgvContas.SelectedRows.Count > 0)
            {
                return int.Parse(dgvContas.SelectedRows[0].Cells[columnName].Value.ToString());
            }
            return 0;
        }
        protected string ObterNomeSelecionado(string columnName)
        {
            if (dgvContas.SelectedRows.Count > 0)
            {
                return dgvContas.SelectedRows[0].Cells[columnName].Value.ToString();
            }
            return string.Empty; 
        }

        private void btn_Pagar_Click(object sender, EventArgs e)
        {
            if (dgvContas.SelectedCells.Count > 0)
            {
                int numero = ObterIdSelecionado("num_nfc");
                int modelo = ObterIdSelecionado("modelo_nfc");
                int serie = ObterIdSelecionado("serie_nfc");
                int parcela = ObterIdSelecionado("num_parcela");
                string status = ObterNomeSelecionado("situacao");

                if (status != "CANCELADA")
                {
                    ContasReceber conta = aCTRLContaReceber.BuscarContasReceber(numero, modelo, serie, parcela);
                    if (conta != null)
                    {
                        aCTRLContaReceber.Alterar(conta);
                        CarregaLV();
                    }
                }
                else
                {
                    MessageBox.Show(
                        "A operação não pode ser realizada porque a nota fiscal selecionada foi cancelada.",
                        "Ação não permitida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
            }
        }
    }
}
