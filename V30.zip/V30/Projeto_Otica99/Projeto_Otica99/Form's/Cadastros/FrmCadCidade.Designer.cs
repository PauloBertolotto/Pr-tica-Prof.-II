﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadCidade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Cidade = new System.Windows.Forms.Label();
            this.lbl_DDD = new System.Windows.Forms.Label();
            this.lbl_CodEstado = new System.Windows.Forms.Label();
            this.lbl_Estado = new System.Windows.Forms.Label();
            this.txt_Cidade = new System.Windows.Forms.TextBox();
            this.txt_DDD = new System.Windows.Forms.TextBox();
            this.txt_CodEstado = new System.Windows.Forms.TextBox();
            this.txt_Estado = new System.Windows.Forms.TextBox();
            this.btn_Buscar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(158, 128);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(3, 3, 3, 3);
            // 
            // lbl_Código
            // 
            this.lbl_Código.Location = new System.Drawing.Point(6, 10);
            this.lbl_Código.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(9, 27);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(230, 128);
            this.btn_Sair.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            // 
            // lbl_Cidade
            // 
            this.lbl_Cidade.AutoSize = true;
            this.lbl_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cidade.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Cidade.Location = new System.Drawing.Point(109, 10);
            this.lbl_Cidade.Name = "lbl_Cidade";
            this.lbl_Cidade.Size = new System.Drawing.Size(51, 16);
            this.lbl_Cidade.TabIndex = 4;
            this.lbl_Cidade.Text = "Cidade";
            // 
            // lbl_DDD
            // 
            this.lbl_DDD.AutoSize = true;
            this.lbl_DDD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DDD.ForeColor = System.Drawing.Color.Gold;
            this.lbl_DDD.Location = new System.Drawing.Point(345, 10);
            this.lbl_DDD.Name = "lbl_DDD";
            this.lbl_DDD.Size = new System.Drawing.Size(37, 16);
            this.lbl_DDD.TabIndex = 5;
            this.lbl_DDD.Text = "DDD";
            // 
            // lbl_CodEstado
            // 
            this.lbl_CodEstado.AutoSize = true;
            this.lbl_CodEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodEstado.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodEstado.Location = new System.Drawing.Point(6, 72);
            this.lbl_CodEstado.Name = "lbl_CodEstado";
            this.lbl_CodEstado.Size = new System.Drawing.Size(97, 16);
            this.lbl_CodEstado.TabIndex = 6;
            this.lbl_CodEstado.Text = "Código Estado";
            // 
            // lbl_Estado
            // 
            this.lbl_Estado.AutoSize = true;
            this.lbl_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estado.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Estado.Location = new System.Drawing.Point(110, 72);
            this.lbl_Estado.Name = "lbl_Estado";
            this.lbl_Estado.Size = new System.Drawing.Size(50, 16);
            this.lbl_Estado.TabIndex = 7;
            this.lbl_Estado.Text = "Estado";
            // 
            // txt_Cidade
            // 
            this.txt_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cidade.Location = new System.Drawing.Point(112, 27);
            this.txt_Cidade.Name = "txt_Cidade";
            this.txt_Cidade.Size = new System.Drawing.Size(208, 22);
            this.txt_Cidade.TabIndex = 8;
            this.txt_Cidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_DDD
            // 
            this.txt_DDD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DDD.Location = new System.Drawing.Point(348, 27);
            this.txt_DDD.Name = "txt_DDD";
            this.txt_DDD.Size = new System.Drawing.Size(100, 22);
            this.txt_DDD.TabIndex = 9;
            this.txt_DDD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // txt_CodEstado
            // 
            this.txt_CodEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodEstado.Location = new System.Drawing.Point(9, 89);
            this.txt_CodEstado.Name = "txt_CodEstado";
            this.txt_CodEstado.Size = new System.Drawing.Size(76, 22);
            this.txt_CodEstado.TabIndex = 10;
            this.txt_CodEstado.Text = "0";
            this.txt_CodEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodEstado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // txt_Estado
            // 
            this.txt_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Estado.Location = new System.Drawing.Point(113, 89);
            this.txt_Estado.Name = "txt_Estado";
            this.txt_Estado.Size = new System.Drawing.Size(207, 22);
            this.txt_Estado.TabIndex = 11;
            // 
            // btn_Buscar
            // 
            this.btn_Buscar.BackColor = System.Drawing.Color.Gold;
            this.btn_Buscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Buscar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Buscar.Location = new System.Drawing.Point(348, 87);
            this.btn_Buscar.Name = "btn_Buscar";
            this.btn_Buscar.Size = new System.Drawing.Size(68, 26);
            this.btn_Buscar.TabIndex = 12;
            this.btn_Buscar.Text = "Buscar";
            this.btn_Buscar.UseVisualStyleBackColor = false;
            this.btn_Buscar.Click += new System.EventHandler(this.btn_Buscar_Click_1);
            // 
            // FrmCadCidade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(459, 165);
            this.Controls.Add(this.btn_Buscar);
            this.Controls.Add(this.txt_Estado);
            this.Controls.Add(this.txt_CodEstado);
            this.Controls.Add(this.txt_DDD);
            this.Controls.Add(this.txt_Cidade);
            this.Controls.Add(this.lbl_Estado);
            this.Controls.Add(this.lbl_CodEstado);
            this.Controls.Add(this.lbl_DDD);
            this.Controls.Add(this.lbl_Cidade);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FrmCadCidade";
            this.Text = "Cadastro de Cidade";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_Cidade, 0);
            this.Controls.SetChildIndex(this.lbl_DDD, 0);
            this.Controls.SetChildIndex(this.lbl_CodEstado, 0);
            this.Controls.SetChildIndex(this.lbl_Estado, 0);
            this.Controls.SetChildIndex(this.txt_Cidade, 0);
            this.Controls.SetChildIndex(this.txt_DDD, 0);
            this.Controls.SetChildIndex(this.txt_CodEstado, 0);
            this.Controls.SetChildIndex(this.txt_Estado, 0);
            this.Controls.SetChildIndex(this.btn_Buscar, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Cidade;
        private System.Windows.Forms.Label lbl_DDD;
        private System.Windows.Forms.Label lbl_CodEstado;
        private System.Windows.Forms.Label lbl_Estado;
        private System.Windows.Forms.Button btn_Buscar;
        public System.Windows.Forms.TextBox txt_Cidade;
        public System.Windows.Forms.TextBox txt_DDD;
        public System.Windows.Forms.TextBox txt_CodEstado;
        public System.Windows.Forms.TextBox txt_Estado;
    }
}
