﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System.Globalization;
using Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço;
using Projeto_Otica99.Form_s.Consultas;
using Projeto_Otica99.Form_s.Consultas.Consula_Pagamento;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadCompra : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {


        Ctrl_CondPagamento aCTRLcon;
        Ctrl_Produtos      aCTRLProdutos;
        Ctrl_Compras       aCTRLCompra;
        Ctrl_Fornecedores  aCTRLForn;
        bool               permiteExclusao;
        private bool       AutorizadoSalvar = false;
        Compras            aCompra;
        ItensCompra        oItemCompra;
        DadosCadastro      oFornecedor;
        CondicaoPagamento  aCondicao;
        CultureInfo        cultura = new CultureInfo("pt-BR");

        public FrmCadCompra()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            Instanciar();
        }
        private void Instanciar()
        {
            aCompra         = new Compras();
            oItemCompra     = new ItensCompra();
            aCTRLProdutos   = new Ctrl_Produtos();
            aCTRLCompra     = new Ctrl_Compras();
            aCTRLForn       = new Ctrl_Fornecedores();
            aCondicao       = new CondicaoPagamento();
            aCTRLcon        = new Ctrl_CondPagamento();
            oFornecedor     = new DadosCadastro();
            permiteExclusao = true;
            DataGrid();
        }
        protected override void LimparCampos()
        {
            dtChegada.Value = DateTime.Now;
            dtEmissao.Value = DateTime.Now;
            txtCodProduto.Clear();
            txtUND.Clear();
            txtQtd.Clear();
            txtCusto.Clear();
            txtDesconto.Clear();
            txtTotalItens.Clear();
            txtFrete.Text   = "0";
            txtSeguro.Text  = "0";
            txtOutras.Text  = "0";
            txtProduto.Clear();
        }
        protected virtual bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (dtChegada.Value == DateTime.MinValue || dtChegada.Value.Date > DateTime.Now.Date)
            {
                camposFaltantes.Add("Data de Chegada (não pode ser no futuro)");
            }

            if (dtEmissao.Value == DateTime.MinValue || dtEmissao.Value.Date > DateTime.Now.Date)
            {
                camposFaltantes.Add("Data de Emissão (não pode ser no futuro)");
            }

            if (string.IsNullOrWhiteSpace(txtCodProduto.Text))
            {
                camposFaltantes.Add("Código do Produto");
            }

            if (string.IsNullOrWhiteSpace(txtUND.Text))
            {
                camposFaltantes.Add("Unidade de Medida");
            }

            if (string.IsNullOrWhiteSpace(txtQtd.Text))
            {
                camposFaltantes.Add("Quantidade");
            }

            if (string.IsNullOrWhiteSpace(txtCusto.Text))
            {
                camposFaltantes.Add("Custo");
            }

            if (string.IsNullOrWhiteSpace(txtDesconto.Text))
            {
                camposFaltantes.Add("Desconto");
            }

            if (string.IsNullOrWhiteSpace(txtTotalItens.Text))
            {
                camposFaltantes.Add("Total de Itens");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos corretamente: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        public virtual void Verificar()
        {
            if (btn_Salvar.Text == "Salvar")
                Salvar();
            else if (btn_Salvar.Text == "Cancelar")
            {
                CancelarCompra();
            }
            else if (btn_Salvar.Text == "Emitir")
            {
            }
        }
        protected virtual void CancelarCompra()
        {
            string mensagem = "Tem certeza que deseja cancelar a Compra?";

            DialogResult resultado = MessageBox.Show(mensagem, $"Confirmação de Cancelamento", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    aCompra.NumNFC           = Convert.ToInt32(txtNumNFC.Value);
                    aCompra.SerieNFC         = Convert.ToInt32(txtSerieNFC.Value);
                    aCompra.ModeloNFC        = Convert.ToInt32(txtModeloNFC.Value);
                    aCompra.Fornecedor.ID    = Convert.ToInt32(txt_Codigo.Text);
                    aCompra.StatusCompra     = "CANCELADA";
                    aCompra.DataCancelamento = DateTime.Now;

                    aCTRLCompra.CancelarCompra(aCompra);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao Cancelar compra: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        public override void Salvar()
        {
            if (AutorizadoSalvar)
            {
                if (Dgv.Rows.Count > 0)
                {
                    CultureInfo cultura     = CultureInfo.InvariantCulture;
                    txtFrete_Leave(txtFrete, EventArgs.Empty);
                    Ctrl_Compras aCTLCompra            = new Ctrl_Compras();
                    List<ContasPagar> listaContasPagar = new List<ContasPagar>();
                    Compras Obj                        = new Compras();
                    Obj.Fornecedor                     = new DadosCadastro();
                    Obj.Condicao                       = new CondicaoPagamento();
                    Obj.Fornecedor.ID                  = Convert.ToInt32(txt_Codigo.Text);
                    Obj.Condicao.ID                    = int.Parse(txtCodCondicao.Text);
                    Obj.NumNFC                         = int.Parse(txtNumNFC.Text);
                    Obj.ModeloNFC                      = int.Parse(txtModeloNFC.Text);
                    Obj.SerieNFC                       = int.Parse(txtSerieNFC.Text);
                    Obj.ValorTotal                     = decimal.Parse(txtTotalNota.Text, cultura);
                    Obj.ValorFrete                     = string.IsNullOrEmpty(txtFrete.Text)  ? 0 : decimal.Parse(txtFrete.Text, cultura);
                    Obj.ValorSeguro                    = string.IsNullOrEmpty(txtSeguro.Text) ? 0 : decimal.Parse(txtSeguro.Text, cultura);
                    Obj.ValorOutrasDespesas            = string.IsNullOrEmpty(txtOutras.Text) ? 0 : decimal.Parse(txtOutras.Text, cultura);
                    Obj.DataChegada                    = DateTime.Parse(dtChegada.Text);
                    Obj.DataEmissao                    = DateTime.Parse(dtEmissao.Text);
                    Obj.DataCriacao                    = DateTime.Now;
                    Obj.StatusCompra                   = "ATIVO";
                    Obj.ItensCompra                    = ItensListView(Obj.NumNFC, Obj.ModeloNFC, Obj.SerieNFC, Obj.Fornecedor.ID);

                    foreach (ListViewItem item in lvParcelas.Items)
                    {
                        ContasPagar aContaPagar       = new ContasPagar();
                        aContaPagar.NumNFC            = Obj.NumNFC;
                        aContaPagar.ModeloNFC         = Obj.ModeloNFC;
                        aContaPagar.SerieNFC          = Obj.SerieNFC;
                        aContaPagar.NumParcela        = Convert.ToInt32(item.SubItems[0].Text);
                        aContaPagar.Fornecedor.ID     = Obj.Fornecedor.ID;
                        aContaPagar.Condicao.ID       = Obj.Condicao.ID;
                        aContaPagar.Valor             = Convert.ToDecimal(item.SubItems[5].Text);
                        aContaPagar.Situacao          = "A PAGAR";
                        aContaPagar.DataCriacao       = DateTime.Now;
                        aContaPagar.DataVencimento    = dtEmissao.Value.AddDays(Convert.ToInt32(item.SubItems[1].Text));
                        aContaPagar.DataUltAlteracao  = DateTime.Now;
                        aContaPagar.FormaPagamento.ID = Convert.ToInt32(item.SubItems[2].Text);
                        aContaPagar.Taxa              = aCondicao.Taxa;
                        aContaPagar.Desconto          = aCondicao.Desconto;
                        aContaPagar.Multa             = aCondicao.Multa;
                        //DataBaixa
                        listaContasPagar.Add(aContaPagar);
                    }

                    Obj.ContasPAgar = listaContasPagar;

                    bool result = aCTLCompra.AdicionarCompra(Obj);

                    if (!result)
                    {
                        MessageBox.Show("Erro ao salvar a compra.");
                    }
                    else
                    {
                        MessageBox.Show("Compra salva com sucesso!");
                    }
                    this.Close();
                }
                return;
            }
        }

        public List<ItensCompra> ItensListView(int Num_nfc, int Modelo_nfc, int Serie_nfc, int Id_fornecedor)
        {
            var vLista = new List<ItensCompra>();
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                ItensCompra ItensCompra      = new ItensCompra();
                ItensCompra.NumNFC           = Num_nfc;
                ItensCompra.ModeloNFC        = Modelo_nfc;
                ItensCompra.SerieNFC         = Serie_nfc;
                ItensCompra.Fornecedor.ID    = Id_fornecedor;
                ItensCompra.Produto          = aCTRLProdutos.BuscarProdutoPorId(Convert.ToInt32(vLinha.Cells["id_produto"].Value));
                ItensCompra.QtdProduto       = Convert.ToInt32(vLinha.Cells["qtd_entrada"].Value);
                ItensCompra.PrecoCusto       = Convert.ToDecimal(vLinha.Cells["custo_sugerido"].Value);
                ItensCompra.Desconto         = Convert.ToDecimal(vLinha.Cells["desconto"].Value);
                ItensCompra.PercentualCompra = Convert.ToDecimal(vLinha.Cells["percentual_compra"].Value);
                ItensCompra.MediaPonderada   = Convert.ToDecimal(vLinha.Cells["media_ponderada"].Value);
                ItensCompra.DataCriacao      = DateTime.Now;
                vLista.Add(ItensCompra);
            }
            return vLista;
        }
        public virtual void Popular(Compras aCompra)
        {
            permiteExclusao     = false;
            CultureInfo cultura = CultureInfo.InvariantCulture;
            txtNumNFC.Value     = aCompra.NumNFC;
            txtModeloNFC.Value  = aCompra.ModeloNFC;
            txtSerieNFC.Value   = aCompra.SerieNFC;
            txt_Codigo.Text     = aCompra.Fornecedor.ID.ToString();
            txtFornecedor.Text  = aCompra.Fornecedor.NomeOuNomeFantasia;
            dtChegada.Value     = aCompra.DataChegada;
            dtEmissao.Value     = aCompra.DataEmissao;
            txtCodCondicao.Text = aCompra.Condicao.ID.ToString();
            txtCondicao.Text    = aCompra.Condicao.Condicao;
            txtFrete.Text       = aCompra.ValorFrete.ToString("0.##", cultura);
            txtSeguro.Text      = aCompra.ValorSeguro.ToString("0.##", cultura);
            txtOutras.Text      = aCompra.ValorOutrasDespesas.ToString("0.##", cultura);
            txtTotalNota.Text   = aCompra.ValorTotal.ToString("0.##", cultura);

            int codigo          = Convert.ToInt32(txtNumNFC.Value);
            int modelo          = Convert.ToInt32(txtModeloNFC.Value);
            int serie           = Convert.ToInt32(txtSerieNFC.Value);
            int fornecedor      = Convert.ToInt32(txt_Codigo.Text);

            Ctrl_ItensCompra aCTRLItensCompra = new Ctrl_ItensCompra();
            List<ItensCompra> Itemcompra      = aCTRLItensCompra.BuscarItemCompraPorChave2(codigo, modelo, serie, fornecedor);

            PopularItens(Itemcompra);
            CarregaLV();
        }
        public void PopularItens(List<ItensCompra> List)
        {
            Dgv.Rows.Clear();
            foreach (ItensCompra Item in List)
            {
                Dgv.Rows.Add(
                    Item.Produto.ID,
                    Item.Produto.Nome,
                    Item.Produto.UnidadeMedida,
                    Item.QtdProduto,
                    Item.Produto.PrecoCusto,
                    Item.PrecoCusto,
                    Item.Desconto,
                    Item.PercentualCompra,
                    Item.TotalCusto,
                    Item.MediaPonderada);
            }
        }
        private void VerificarEExecutarAcao(int nNFC, int nModelo, int nSerie, int codForn)
        {
            var compraExiste = aCTRLCompra.VerificarSeCompraExiste(nNFC, nModelo, nSerie, codForn);

            if (compraExiste)
            {
                MessageBox.Show("Nota já cadastrada");
            }
            else
            {
                btnVerificar.Visible = false;
                txt_Codigo.Enabled = false;

            }
        }
        private void LimparFornecedor()
        {
            txtFornecedor.Clear();
            txt_Codigo.Clear();
        }
        private void CarregaLV()
        {
            int cod = Convert.ToInt32(txtCodCondicao.Text);
            Ctrl_Parcelas aCTLParcela = new Ctrl_Parcelas();
            List<Parcelas> dados = aCTLParcela.BuscarParcelasPorIDCondicao(cod);

            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<Parcelas> dados)
        {
            lvParcelas.Items.Clear();

            decimal custoTotalComAdicionais = CalcularCustoTotalComAdicionais();

            foreach (var parcela in dados)
            {
                ListViewItem item = new ListViewItem(parcela.NumParcela.ToString());
                item.SubItems.Add(parcela.DiasTotais.ToString());
                item.SubItems.Add(parcela.Forma.ID.ToString());
                item.SubItems.Add(parcela.Forma.Forma);
                item.SubItems.Add(parcela.Porcentagem.ToString());

                decimal valorParcela = (parcela.Porcentagem / 100) * custoTotalComAdicionais;
                item.SubItems.Add(valorParcela.ToString("F2"));

                item.Tag = parcela;
                lvParcelas.Items.Add(item);
            }
        }
        private decimal CalcularCustoTotalComAdicionais()
        {
            decimal total = CustoTotal();

            decimal frete = 0;
            decimal seguro = 0;
            decimal outrosCustos = 0;

            if (!string.IsNullOrEmpty(txtFrete.Text)) frete = Convert.ToDecimal(txtFrete.Text);
            if (!string.IsNullOrEmpty(txtSeguro.Text)) seguro = Convert.ToDecimal(txtSeguro.Text);
            if (!string.IsNullOrEmpty(txtOutras.Text)) outrosCustos = Convert.ToDecimal(txtOutras.Text);

            total += frete + seguro + outrosCustos;

            return total;
        }
        private void txtNumNFC_Leave(object sender, EventArgs e)
        {
            ValidarNota();
        }
        public void AdicionarItens()
        {

            if (decimal.TryParse(txtTotalItens.Text, out decimal total) && total <= 0)
            {
                MessageBox.Show("O total deve ser maior que 0 para adicionar um item.");
                return;
            }
            string idProduto = txtCodProduto.Text;
            if (ProdutoJaAdicionado(idProduto))
            {
                MessageBox.Show("Este produto já foi adicionado.");
                return;
            }

            Produtos Produtos  = aCTRLProdutos.BuscarProdutoPorId(Convert.ToInt32(txtCodProduto.Text));
            var NomeProduto    = txtProduto.Text;
            var IdProduto      = txtCodProduto.Text;
            var CustoSugerido  = txtCusto.Text;
            var Desconto       = txtDesconto.Text;
            var QtdEntrada     = txtQtd.Text;
            var QtdEstoque     = Produtos.QtdEstoque;
            var CustoAtual     = Produtos.PrecoCusto;
            var MediaPonderada = 0;
            var Percentual     = 0;

            Dgv.Rows.Add(
                Properties.Resources.Lixeira_x32,
                IdProduto,
                NomeProduto,
                QtdEstoque,
                QtdEntrada,
                CustoAtual,
                CustoSugerido,
                Desconto,
                Percentual,
                MediaPonderada
            );
            PercentualItem();
            NovoPrecoItens();
        }
        private bool ProdutoJaAdicionado(string idProduto)
        {
            foreach (DataGridViewRow row in Dgv.Rows)
            {
                if (row.Cells["id_produto"].Value != null && row.Cells["id_produto"].Value.ToString() == idProduto)
                {
                    return true;
                }
            }
            return false;
        }
        public void PercentualItem()
        {
            decimal Total = 0;
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                Total += Convert.ToInt32(vLinha.Cells["qtd_entrada"].Value);
            }
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                vLinha.Cells["percentual_compra"].Value = Math.Round(((Convert.ToDecimal(vLinha.Cells["qtd_entrada"].Value) / Total) * 100), 8);
            }
        }
        private void NovoPrecoItens()
        {
            decimal frete = 0;
            decimal seguro = 0;
            decimal outrosCustos = 0;

            decimal.TryParse(txtFrete.Text, out frete);
            decimal.TryParse(txtSeguro.Text, out seguro);
            decimal.TryParse(txtOutras.Text, out outrosCustos);

            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                if (vLinha != null)
                {
                    var Produto = aCTRLProdutos.BuscarProdutoPorId(Convert.ToInt32(vLinha.Cells["id_produto"].Value));
                    var CustoProdutoAtual = Produto.PrecoCusto;
                    var QtdEstoqueAtual = Produto.QtdEstoque;
                    var PercentualCompra = Convert.ToDecimal(vLinha.Cells["percentual_compra"].Value);

                    decimal CustoEntrada;
                    if (!decimal.TryParse(txtCusto.Text, out CustoEntrada))
                    {
                        CustoEntrada = 0;
                    }

                    var QtdEntradaEstoque = Convert.ToInt32(vLinha.Cells["qtd_entrada"].Value);
                    var Desconto = Convert.ToDecimal(vLinha.Cells["desconto"].Value);

                    // Calcula os rateios
                    var RatFrete = (PercentualCompra / 100) * frete;
                    var RatSeguro = (PercentualCompra / 100) * seguro;
                    var RatOutrosCustos = (PercentualCompra / 100) * outrosCustos;

                    var NovoCustoProduto = (RatFrete + RatSeguro + RatOutrosCustos + CustoEntrada) - Desconto;

                    var MediaPond = ((QtdEstoqueAtual * CustoProdutoAtual) + (QtdEntradaEstoque * NovoCustoProduto)) / (QtdEstoqueAtual + QtdEntradaEstoque);

                    vLinha.Cells["media_ponderada"].Value = Math.Round(MediaPond, 8);
                    vLinha.Cells["custo_sugerido"].Value = NovoCustoProduto;
                }
            }

        }
        private void txtQtd_Leave(object sender, EventArgs e)
        {

            try
            {             
              
                decimal qtd      = string.IsNullOrWhiteSpace(txtQtd.Text)      ? 0 : decimal.Parse(txtQtd.Text, cultura);
                decimal custo    = string.IsNullOrWhiteSpace(txtCusto.Text)    ? 0 : decimal.Parse(txtCusto.Text, cultura);
                decimal desconto = string.IsNullOrWhiteSpace(txtDesconto.Text) ? 0 : decimal.Parse(txtDesconto.Text, cultura);

                decimal total    = (qtd * custo) - (qtd * desconto);

                txtTotalItens.Text = total.ToString("0.00", cultura);
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, insira valores válidos.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void txt_Codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txt_Codigo_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null;
        }

        private void txtFrete_Leave(object sender, EventArgs e)
        {
            AtualizarTotalNota();
        }
       
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Codigo.Text))
                LimparFornecedor();
            else if (int.TryParse(txt_Codigo.Text, out int cod) && cod > 0)
            {


                oFornecedor = aCTRLForn.BuscarFornecedorPorId(cod);

                if (oFornecedor == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparFornecedor();
                }
                else if (oFornecedor.Ativo == "I")
                {
                    MessageBox.Show("O Fornecedor associado a este código está inativo.");
                    LimparFornecedor();
                }
                else
                {
                    txtFornecedor.Text = oFornecedor.NomeOuNomeFantasia;

                    int nNFC = (int)txtNumNFC.Value;
                    int nModelo = (int)txtModeloNFC.Value;
                    int nSerie = (int)txtSerieNFC.Value;
                    int codForn = Convert.ToInt32(txt_Codigo.Text);
                    VerificarEExecutarAcao(nNFC, nModelo, nSerie, codForn);

                }
            }
            else
            {
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparFornecedor();
            }
            this.AcceptButton = btn_Salvar;
        }    
        
        private void LimparText()
        {
            txtCodProduto.Clear();
            txtProduto.Clear();
            txtUND.Clear();
            txtQtd.Clear();
            txtCusto.Clear();
            txtDesconto.Clear();
            txtTotalItens.Clear();
        }
        
        private void DataGrid()
        {
            Dgv.RowHeadersVisible = false;
            Dgv.AutoGenerateColumns = false;
            Dgv.Columns.Clear();

            DataGridViewImageColumn deleteColumn = new DataGridViewImageColumn();
            deleteColumn.Name                    = "DeleteColumn";
            deleteColumn.HeaderText              = "Excluir";
            deleteColumn.Width                   = 80; 
            //deleteColumn.ImageLayout             = DataGridViewImageCellLayout.Zoom; 
            Dgv.Columns.Add(deleteColumn);

            // Adiciona as outras colunas do DataGridView
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "id_produto",        HeaderText = "ID", DataPropertyName              = "id_produto", Width = 60 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "produto",           HeaderText = "Produto", DataPropertyName         = "produto", Width = 400 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "und",               HeaderText = "UND", DataPropertyName             = "und", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "qtd_entrada",       HeaderText = "QTD Entrada", DataPropertyName     = "qtd_entrada", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "custo_atual",       HeaderText = "Custo Atual", DataPropertyName     = "custo_atual", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Custo_Sugerido",    HeaderText = "Preço Compra", DataPropertyName    = "Custo_Sugerido", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "desconto",          HeaderText = "Desconto", DataPropertyName        = "desconto", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "percentual_compra", HeaderText = "% Compra", DataPropertyName        = "percentual_compra", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "preco_total",       HeaderText = "Preço Total", DataPropertyName     = "preco_total", Width = 125 });
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "media_ponderada",   HeaderText = "Média Ponderada", DataPropertyName = "media_ponderada", Width = 125 });

            // Ajusta a altura das linhas para acomodar as imagens
            Dgv.RowTemplate.Height = 40; // Altura das linhas em pixels

            // Tornar a coluna "preco_total" invisível
            Dgv.Columns["preco_total"].Visible = false;

            // Calcula as proporções das coluna
            Dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Dgv.MultiSelect = false;
        }

        private void AtualizarTotalNota()
        {
            decimal custoItens = CustoTotal(); 

            // Adicionar valores de frete, seguro e outras despesas
            decimal frete  = string.IsNullOrEmpty(txtFrete.Text)  ? 0 : decimal.Parse(txtFrete.Text,  CultureInfo.InvariantCulture);
            decimal seguro = string.IsNullOrEmpty(txtSeguro.Text) ? 0 : decimal.Parse(txtSeguro.Text, CultureInfo.InvariantCulture);
            decimal outras = string.IsNullOrEmpty(txtOutras.Text) ? 0 : decimal.Parse(txtOutras.Text, CultureInfo.InvariantCulture);

            decimal totalNota = custoItens + frete + seguro + outras;

            // Atualizar o valor do txtTotalNota
            txtTotalNota.Text = totalNota.ToString("N2", CultureInfo.InvariantCulture);
        }
        
        private void LiberarCondicaoPagamento()
        {
            if (Dgv.Rows.Count > 0)
            {

                int cod                    = oFornecedor.condicao_Pagamento.ID;
                Ctrl_CondPagamento aCTLcon = new Ctrl_CondPagamento();
                CondicaoPagamento condicao = aCTLcon.BuscarCondicaoPagamentoPorId(cod);

                if (condicao != null)
                {
                    txtCodCondicao.Text = condicao.ID.ToString();
                    txtCondicao.Text    = condicao.Condicao;
                    CarregaLV();
                }
            }
            else
            {

                txtCodCondicao.Text = "";
                txtCondicao.Text    = "";
            }
        }
        private decimal CustoTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                total += Convert.ToDecimal(vLinha.Cells["qtd_entrada"].Value) * Convert.ToDecimal(vLinha.Cells["custo_sugerido"].Value);
            }
            return total;
        }
        private void txtCusto_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarValorKeyPressComVirgula((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtNumNFC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.' || e.KeyChar == ',')
            {
                e.Handled = true;
            }
        }

        private void txtFrete_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }

        private void btnVerificaData_Click(object sender, EventArgs e)
        {
            DateTime dataEmissao = dtEmissao.Value.Date;
            DateTime dataChegada = dtChegada.Value.Date;
            DateTime dataAtual   = DateTime.Now.Date;

            if (dataEmissao > dataAtual)
            {
                MessageBox.Show("A data de emissão de compra não pode ser no futuro. Apenas data de hoje ou anterior é permitida.",
                    "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dataChegada > dataAtual)
            {
                MessageBox.Show("A data de chegada não pode ser uma data futura.",
                    "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dataChegada < dataEmissao)
            {
                MessageBox.Show("A data de chegada deve ser maior ou igual à data de emissão. Não é possível que o produto chegue antes da emissão da nota.",
                    "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
          
        }
        
        
        private void Dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == Dgv.Columns["DeleteColumn"].Index && e.RowIndex >= 0 && permiteExclusao)
            {
                // Confirmação de exclusão
                var resultado = MessageBox.Show("Você tem certeza que deseja excluir este item?",
                    "Confirmação de Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    Dgv.Rows.RemoveAt(e.RowIndex);
                    txtTotalNota.Text = Convert.ToString(CustoTotal());
                }
            }
        }
       
        private void btnFinalizaCondicao_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodCondicao.Text) || string.IsNullOrEmpty(txtCondicao.Text))
            {
                MessageBox.Show("Nenhuma condição de pagamento encontrada.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (btnFinalizaCondicao.Text == "Finalizar")
            {
                LiberarFrete(false);
                btnFinalizaCondicao.Text    = "Liberar"; 
                btnFinalizaCondicao.Enabled = true; 
                txtTotalNota.Enabled        = true; 
                AtualizarTotalNota();
                LiberarCondicaoPagamento();
                AutorizadoSalvar            = true;
                btn_BuscaCondPag.Enabled    = false;
                txtCodCondicao.Enabled      = false;

                CarregaLV();
            }
            else if (btnFinalizaCondicao.Text == "Liberar")
            {
                LiberarFrete(true);
                btnFinalizaCondicao.Text    = "Finalizar";
                btnFinalizaCondicao.Enabled = true;
                AtualizarTotalNota();
                LiberarCondicaoPagamento();
                AutorizadoSalvar            = false;
                btn_BuscaCondPag.Enabled    = true;
                txtCodCondicao.Enabled      = true;
            }
        }
        private void LiberarFrete(bool valor)
        {
            txtFrete.Enabled = valor;
            txtOutras.Enabled = valor;
            txtSeguro.Enabled = valor;
        }

        private void btnBuscarFornecedor_Click(object sender, EventArgs e)
        {
            using (FrmConFornecedor frm = new FrmConFornecedor())
            {
                frm.btn_Sair.Text       = "Selecionar";
                frm.ShowDialog();

                int IdSelecionado       = frm.IdSelecionado;
                string NomeSelecionado  = frm.NomeSelecionado;

                txt_Codigo.Text         = IdSelecionado.ToString();
                txtFornecedor.Text      = NomeSelecionado;
            }
        }

        private void txtCodProduto_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodProduto.Text))
                LimparProdutos();
            else if (int.TryParse(txtCodProduto.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente
                Ctrl_Produtos aCTLprod = new Ctrl_Produtos();
                Produtos produto = aCTLprod.BuscarProdutoPorId(cod);

                if (produto == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparProdutos();
                }
                else
                {
                    txtProduto.Text = produto.Nome;
                    txtUND.Text = produto.QtdEstoque.ToString();

                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparProdutos();
            }
            this.AcceptButton = btn_Salvar;
        }
        private void LimparProdutos()
        {
            txtProduto.Clear();
            txtCodProduto.Clear();
        }

        public bool ValidarNota()
        {
            if (txtNumNFC.Value > 0 && txtModeloNFC.Value > 0 && txtSerieNFC.Value > 0 && Convert.ToInt32(txt_Codigo.Text) > 0)
            {
                var Obj = aCTRLCompra.BuscarCompraPorChave(Convert.ToInt32(txtNumNFC.Value), Convert.ToInt32(txtModeloNFC.Value),
                    Convert.ToInt32(txtSerieNFC.Value), Convert.ToInt32(Convert.ToInt32(txt_Codigo.Text)));
                if (Obj == null)
                {
                    MessageBox.Show("Nota ja cadastrada");
                    return false;
                }
                
                return true;
            }
            return false;
        }        
        private void btnBuscarProduto_Click(object sender, EventArgs e)
        {
            using (FrmConProdutos frm = new FrmConProdutos())
            {
                frm.btn_Sair.Text      = "Selecionar";
                frm.ShowDialog();

                int IdSelecionado      = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;
                string unidade         = frm.Und;

                txtCodProduto.Text     = IdSelecionado.ToString();
                txtProduto.Text        = NomeSelecionado;
                txtUND.Text            = unidade;
                txtCodProduto_Leave(txtCodProduto, EventArgs.Empty);

            }
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (VerificarCamposVazios())
            {
                AdicionarItens();
                LimparText();
                //txtTotalNota.Text = Convert.ToString(CustoTotal());
                btnFinaliza.Enabled = true;
            }
        }

        private void btnFinaliza_Click(object sender, EventArgs e)
        {
            if (btnFinaliza.Text == "Finalizar Compra")
            {
                LimparProdutos();               
                permiteExclusao = false;
                btnFinaliza.Text = "Liberar Produtos";
                txtCodCondicao.Text = aCondicao.ID.ToString();
                txtCondicao.Text = aCondicao.Condicao;

            }
            else
            {
                LimparProdutos();               
                Dgv.ReadOnly = false;
                permiteExclusao = true;
                lvParcelas.Items.Clear();
                txtFrete.Text = "0";
                txtOutras.Text = "0";
                txtSeguro.Text = "0";
                btnFinaliza.Text = "Finalizar Compra";
            }
            AtualizarTotalNota();
        }

        private void btn_BuscaCondPag_Click(object sender, EventArgs e)
        {
            using (FrmConCondPagamento frm = new FrmConCondPagamento())
            {
                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txtCodCondicao.Text = IdSelecionado.ToString();
                txtCondicao.Text = NomeSelecionado;
                aCondicao = aCTRLcon.BuscarCondicaoPagamentoPorId(IdSelecionado);
                lvParcelas.Items.Clear();
            }
        }

        private void txtQtd_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtDesconto_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarValorKeyPressComVirgula((System.Windows.Forms.TextBox)sender, e);
        }

        private void LimparCondicao()
        {
            txtCondicao.Clear();
            txtCodCondicao.Clear();
        }

        private void txtCodCondicao_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodCondicao.Text))
                LimparCondicao();
            else if (int.TryParse(txtCodCondicao.Text, out int cod) && cod > 0)
            {

                aCondicao = aCTRLcon.BuscarCondicaoPagamentoPorId(cod);

                if (aCondicao == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparCondicao();
                }
                else
                {
                    txtCondicao.Text = aCondicao.Condicao;
                }
            }
            else
            {

                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparCondicao();
            }
            lvParcelas.Items.Clear();
            this.AcceptButton = btn_Salvar;
        }

        private void txtSeguro_Leave(object sender, EventArgs e)
        {
            AtualizarTotalNota();
        }

        private void txtOutras_Leave(object sender, EventArgs e)
        {
            AtualizarTotalNota();
        }

        private void txtCodCondicao_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null;
        }

        private void txtCodCondicao_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }
    }
}
