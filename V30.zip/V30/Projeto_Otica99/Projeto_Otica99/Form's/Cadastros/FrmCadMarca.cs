﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;
using System.Data.SqlClient;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadMarca : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Marca aMarca;
        Ctrl_Marca aCTRLMarca;
        public FrmCadMarca()
        {
            InitializeComponent();
            aMarca = new Marca();
            aCTRLMarca = new Ctrl_Marca();
            Verificacao.DisableCopyPaste(this);
        }
        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Marca marca)
            {
                aMarca = marca;
                CarregarEdit();
            }
        }
        public override void BloquearEdit()
        {
            base.BloquearEdit();
            txt_Codigo.Enabled = false;
            txtMarca.Enabled = false;
            txtDescricao.Enabled = false;
        }
        public override void DesbloquearEdit()
        {
            base.DesbloquearEdit();
            txt_Codigo.Enabled = true;
            txtMarca.Enabled = true;
            txtDescricao.Enabled = true;
        }
        public override void CarregarEdit()
        {
            base.CarregarEdit();
            txt_Codigo.Text = aMarca.ID.ToString();
            txtMarca.Text = aMarca.Nome;
            txtDescricao.Text = aMarca.Descricao;
        }

        public virtual void Verificar()
        {
            if (btn_Salvar.Text == "SALVAR" || btn_Salvar.Text == "ALTERAR")
            {
                Salvar();
            }
            else if (btn_Salvar.Text == "EXCLUIR")
            {
                ConfirmarExclusaoMarca();
            }
        }

        public override void Salvar()
        {
            if (string.IsNullOrWhiteSpace(txtMarca.Text))
            {
                MessageBox.Show("Campo Marca não pode estar vazio.");
                txtMarca.Focus();
                return;
            }

            try
            {

                aMarca.Nome = txtMarca.Text;
                aMarca.Descricao = txtDescricao.Text;

                if (aMarca.ID == 0) // Produto de patrimônios
                {
                    aMarca.DataCriacao = DateTime.Now;
                    aCTRLMarca.AdicionarMarca(aMarca);
                }
                else
                {
                    aMarca.DataUltimaAlteracao = DateTime.Now;
                    aCTRLMarca.AtualizarMarca(aMarca);
                }

                Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar os dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void ConfirmarExclusaoMarca()
        {
            DialogResult result = MessageBox.Show("Tem certeza que deseja excluir esta Produto?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ExcluirMarca();
            }
        }


        private void ExcluirMarca()
        {
            if (aMarca != null)
            {
                try
                {

                    aCTRLMarca.ExcluirMarca(aMarca.ID);
                    Close();
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547)
                    {
                        MessageBox.Show("Não é possível excluir a Marca devido a outros registros estarem vinculados a esta Produto.");
                    }
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir a Marca. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }
    }
}
