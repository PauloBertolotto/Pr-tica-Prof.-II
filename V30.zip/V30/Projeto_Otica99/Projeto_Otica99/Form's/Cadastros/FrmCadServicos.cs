﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;
using System.Data.SqlClient;
using System.Globalization;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadServicos : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Servicos oServico = new Servicos();
        Ctrl_Servicos aCTRLServicos;

        public FrmCadServicos()
        {
            InitializeComponent();
            aCTRLServicos = new Ctrl_Servicos();
            Verificacao.DisableCopyPaste(this);
        }

        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Servicos servico)
            {
                oServico = servico;
                CarregarEdit();
            }
        }

        protected override void LimparCampos()
        {
            txt_Codigo.Clear();
            txt_Descricao.Clear();
            CB_Status.SelectedIndex = 0;
            txt_Valor.Clear();
        }

        public override void BloquearEdit()
        {
            base.BloquearEdit();
            txt_Descricao.Enabled = false;
            CB_Status.Enabled = false;
            txt_Valor.Enabled = false;
        }

        public override void DesbloquearEdit()
        {
            base.DesbloquearEdit();
            txt_Descricao.Enabled = true;
            CB_Status.Enabled = true;
            txt_Valor.Enabled = true;
        }

        public override void CarregarEdit()
        {
            base.CarregarEdit();
            txt_Codigo.Text = oServico.ID.ToString();
            txt_Descricao.Text = oServico.Descricao;
            CB_Status.Text = oServico.Status == "I" ? "Inativo" : oServico.Status == "A" ? "Ativo" : oServico.Status;
            txt_Valor.Text = oServico.Valor.ToString();
        }

        public virtual void Verificar()
        {
            if (btn_Salvar.Text == "SALVAR" || btn_Salvar.Text == "ALTERAR")
                Salvar();
            else if (btn_Salvar.Text == "EXCLUIR")
            {
                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este serviço?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    ExcluirServico();
                }
            }
        }

        private void ExcluirServico()
        {
            if (oServico != null)
            {
                try
                {
                    var result = aCTRLServicos.ExcluirServico(oServico.ID);
                    if (result)
                        Close();
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir o serviço. Detalhes: " + result);
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547)
                    {
                        MessageBox.Show("Não é possível excluir o serviço devido a outros registros estarem vinculados a este serviço.");
                    }
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir o serviço. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }

        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txt_Descricao.Text))
            {
                camposFaltantes.Add("Descrição");
            }
            if (string.IsNullOrWhiteSpace(CB_Status.Text))
            {
                camposFaltantes.Add("Status");
            }
           
            if (string.IsNullOrWhiteSpace(txt_Valor.Text))
                camposFaltantes.Add("Valor");
            else
            {
                if (!decimal.TryParse(txt_Valor.Text, out decimal valor) || valor <= 0)
                    camposFaltantes.Add("Valor (deve ser um número maior que zero)");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        public override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                CultureInfo cultura = CultureInfo.InvariantCulture; 
                oServico.Descricao = txt_Descricao.Text;
                oServico.Status = CB_Status.Text[0].ToString();
                oServico.Valor = decimal.Parse(txt_Valor.Text, cultura);

                if (oServico.ID == 0)
                {
                    oServico.DataCriacao = DateTime.Now;
                    var result = aCTRLServicos.AdicionarServico(oServico);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    oServico.DataUltimaAlteracao = DateTime.Now;
                    var result = aCTRLServicos.AtualizarServico(oServico);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }

                return;
            }
        }

        private void txt_Valor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
          
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
          
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }
    }
}
