﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificar = new System.Windows.Forms.Button();
            this.Nome = new System.Windows.Forms.Label();
            this.txtNumNFC = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.txtModeloNFC = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSerieNFC = new System.Windows.Forms.NumericUpDown();
            this.clForn = new System.Windows.Forms.Label();
            this.txtFornecedor = new System.Windows.Forms.TextBox();
            this.btnBuscarFornecedor = new System.Windows.Forms.Button();
            this.btnVerificaData = new System.Windows.Forms.Button();
            this.dtEmissao = new System.Windows.Forms.DateTimePicker();
            this.dtChegada = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.txtTotalItens = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtUND = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCusto = new System.Windows.Forms.TextBox();
            this.txtDesconto = new System.Windows.Forms.TextBox();
            this.txtQtd = new System.Windows.Forms.TextBox();
            this.btnBuscarProduto = new System.Windows.Forms.Button();
            this.txtCodProduto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtProduto = new System.Windows.Forms.TextBox();
            this.btnFinaliza = new System.Windows.Forms.Button();
            this.Dgv = new System.Windows.Forms.DataGridView();
            this.btnFinalizaCondicao = new System.Windows.Forms.Button();
            this.txtTotalNota = new System.Windows.Forms.TextBox();
            this.txtFrete = new System.Windows.Forms.TextBox();
            this.txtSeguro = new System.Windows.Forms.TextBox();
            this.txtOutras = new System.Windows.Forms.TextBox();
            this.lbTotalNota = new System.Windows.Forms.Label();
            this.lbOutras = new System.Windows.Forms.Label();
            this.lbSeguro = new System.Windows.Forms.Label();
            this.lbFrete = new System.Windows.Forms.Label();
            this.lbCondicaoPg = new System.Windows.Forms.Label();
            this.txtCondicao = new System.Windows.Forms.TextBox();
            this.lbCodigoCondicao = new System.Windows.Forms.Label();
            this.txtCodCondicao = new System.Windows.Forms.TextBox();
            this.lvParcelas = new System.Windows.Forms.ListView();
            this.clParcelas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDias = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clIdForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPercentTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPreco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_BuscaCondPag = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumNFC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModeloNFC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerieNFC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(1036, 518);
            // 
            // lbl_Código
            // 
            this.lbl_Código.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.Location = new System.Drawing.Point(260, 15);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(263, 35);
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            this.txt_Codigo.Enter += new System.EventHandler(this.txt_Codigo_Enter);
            this.txt_Codigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Codigo_KeyPress);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1108, 518);
            // 
            // btnVerificar
            // 
            this.btnVerificar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnVerificar.BackColor = System.Drawing.Color.Gold;
            this.btnVerificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnVerificar.Location = new System.Drawing.Point(449, 6);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(4);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(95, 24);
            this.btnVerificar.TabIndex = 111;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // Nome
            // 
            this.Nome.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Nome.AutoSize = true;
            this.Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nome.ForeColor = System.Drawing.Color.Gold;
            this.Nome.Location = new System.Drawing.Point(8, 15);
            this.Nome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(60, 18);
            this.Nome.TabIndex = 114;
            this.Nome.Text = "Nº Nota";
            // 
            // txtNumNFC
            // 
            this.txtNumNFC.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtNumNFC.BackColor = System.Drawing.Color.White;
            this.txtNumNFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumNFC.Location = new System.Drawing.Point(11, 35);
            this.txtNumNFC.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumNFC.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtNumNFC.Name = "txtNumNFC";
            this.txtNumNFC.Size = new System.Drawing.Size(74, 26);
            this.txtNumNFC.TabIndex = 107;
            this.txtNumNFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNumNFC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumNFC_KeyPress);
            this.txtNumNFC.Leave += new System.EventHandler(this.txtNumNFC_Leave);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(87, 15);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 18);
            this.label3.TabIndex = 115;
            this.label3.Text = "Modelo Nota";
            // 
            // txtModeloNFC
            // 
            this.txtModeloNFC.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtModeloNFC.BackColor = System.Drawing.Color.White;
            this.txtModeloNFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModeloNFC.Location = new System.Drawing.Point(89, 35);
            this.txtModeloNFC.Margin = new System.Windows.Forms.Padding(2);
            this.txtModeloNFC.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtModeloNFC.Name = "txtModeloNFC";
            this.txtModeloNFC.Size = new System.Drawing.Size(92, 26);
            this.txtModeloNFC.TabIndex = 108;
            this.txtModeloNFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(183, 15);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 18);
            this.label4.TabIndex = 116;
            this.label4.Text = "Serie";
            // 
            // txtSerieNFC
            // 
            this.txtSerieNFC.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSerieNFC.BackColor = System.Drawing.Color.White;
            this.txtSerieNFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerieNFC.Location = new System.Drawing.Point(185, 35);
            this.txtSerieNFC.Margin = new System.Windows.Forms.Padding(2);
            this.txtSerieNFC.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtSerieNFC.Name = "txtSerieNFC";
            this.txtSerieNFC.Size = new System.Drawing.Size(74, 26);
            this.txtSerieNFC.TabIndex = 109;
            this.txtSerieNFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // clForn
            // 
            this.clForn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clForn.AutoSize = true;
            this.clForn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clForn.ForeColor = System.Drawing.Color.Gold;
            this.clForn.Location = new System.Drawing.Point(343, 15);
            this.clForn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.clForn.Name = "clForn";
            this.clForn.Size = new System.Drawing.Size(85, 18);
            this.clForn.TabIndex = 113;
            this.clForn.Text = "Fornecedor";
            // 
            // txtFornecedor
            // 
            this.txtFornecedor.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFornecedor.Location = new System.Drawing.Point(346, 34);
            this.txtFornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.txtFornecedor.MaxLength = 100;
            this.txtFornecedor.Name = "txtFornecedor";
            this.txtFornecedor.ReadOnly = true;
            this.txtFornecedor.Size = new System.Drawing.Size(198, 26);
            this.txtFornecedor.TabIndex = 110;
            // 
            // btnBuscarFornecedor
            // 
            this.btnBuscarFornecedor.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnBuscarFornecedor.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarFornecedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarFornecedor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarFornecedor.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnBuscarFornecedor.Location = new System.Drawing.Point(552, 34);
            this.btnBuscarFornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarFornecedor.Name = "btnBuscarFornecedor";
            this.btnBuscarFornecedor.Size = new System.Drawing.Size(82, 24);
            this.btnBuscarFornecedor.TabIndex = 112;
            this.btnBuscarFornecedor.Text = "Buscar";
            this.btnBuscarFornecedor.UseVisualStyleBackColor = false;
            this.btnBuscarFornecedor.Click += new System.EventHandler(this.btnBuscarFornecedor_Click);
            // 
            // btnVerificaData
            // 
            this.btnVerificaData.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnVerificaData.BackColor = System.Drawing.Color.Gold;
            this.btnVerificaData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerificaData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerificaData.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificaData.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnVerificaData.Location = new System.Drawing.Point(1081, 34);
            this.btnVerificaData.Margin = new System.Windows.Forms.Padding(4);
            this.btnVerificaData.Name = "btnVerificaData";
            this.btnVerificaData.Size = new System.Drawing.Size(95, 24);
            this.btnVerificaData.TabIndex = 121;
            this.btnVerificaData.Text = "Verificar";
            this.btnVerificaData.UseVisualStyleBackColor = false;
            this.btnVerificaData.Click += new System.EventHandler(this.btnVerificaData_Click);
            // 
            // dtEmissao
            // 
            this.dtEmissao.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dtEmissao.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtEmissao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtEmissao.Location = new System.Drawing.Point(889, 33);
            this.dtEmissao.Name = "dtEmissao";
            this.dtEmissao.Size = new System.Drawing.Size(190, 27);
            this.dtEmissao.TabIndex = 118;
            // 
            // dtChegada
            // 
            this.dtChegada.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dtChegada.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtChegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtChegada.Location = new System.Drawing.Point(693, 33);
            this.dtChegada.Name = "dtChegada";
            this.dtChegada.Size = new System.Drawing.Size(190, 27);
            this.dtChegada.TabIndex = 117;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(690, 12);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 18);
            this.label8.TabIndex = 120;
            this.label8.Text = "Data Chegada";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(885, 12);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 18);
            this.label7.TabIndex = 119;
            this.label7.Text = "Data Emissão";
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAdicionar.BackColor = System.Drawing.Color.Gold;
            this.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdicionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnAdicionar.Location = new System.Drawing.Point(825, 92);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(101, 24);
            this.btnAdicionar.TabIndex = 134;
            this.btnAdicionar.Text = "Adicionar";
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Gold;
            this.label21.Location = new System.Drawing.Point(699, 67);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 18);
            this.label21.TabIndex = 141;
            this.label21.Text = "Total";
            // 
            // txtTotalItens
            // 
            this.txtTotalItens.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtTotalItens.BackColor = System.Drawing.Color.White;
            this.txtTotalItens.Enabled = false;
            this.txtTotalItens.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalItens.Location = new System.Drawing.Point(702, 91);
            this.txtTotalItens.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalItens.Name = "txtTotalItens";
            this.txtTotalItens.ReadOnly = true;
            this.txtTotalItens.Size = new System.Drawing.Size(114, 26);
            this.txtTotalItens.TabIndex = 133;
            this.txtTotalItens.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Gold;
            this.label20.Location = new System.Drawing.Point(414, 68);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 18);
            this.label20.TabIndex = 140;
            this.label20.Text = "UND E.";
            // 
            // txtUND
            // 
            this.txtUND.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtUND.Enabled = false;
            this.txtUND.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUND.Location = new System.Drawing.Point(416, 91);
            this.txtUND.Margin = new System.Windows.Forms.Padding(2);
            this.txtUND.Name = "txtUND";
            this.txtUND.Size = new System.Drawing.Size(56, 26);
            this.txtUND.TabIndex = 129;
            this.txtUND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Gold;
            this.label18.Location = new System.Drawing.Point(613, 70);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 18);
            this.label18.TabIndex = 139;
            this.label18.Text = "Desconto";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Gold;
            this.label17.Location = new System.Drawing.Point(529, 68);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 18);
            this.label17.TabIndex = 138;
            this.label17.Text = "Custo";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gold;
            this.label16.Location = new System.Drawing.Point(475, 68);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 18);
            this.label16.TabIndex = 137;
            this.label16.Text = "Qntd";
            // 
            // txtCusto
            // 
            this.txtCusto.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCusto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCusto.Location = new System.Drawing.Point(530, 91);
            this.txtCusto.Margin = new System.Windows.Forms.Padding(2);
            this.txtCusto.Name = "txtCusto";
            this.txtCusto.Size = new System.Drawing.Size(81, 26);
            this.txtCusto.TabIndex = 131;
            this.txtCusto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCusto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCusto_KeyPress);
            this.txtCusto.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // txtDesconto
            // 
            this.txtDesconto.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesconto.Location = new System.Drawing.Point(615, 91);
            this.txtDesconto.Margin = new System.Windows.Forms.Padding(2);
            this.txtDesconto.Name = "txtDesconto";
            this.txtDesconto.Size = new System.Drawing.Size(83, 26);
            this.txtDesconto.TabIndex = 132;
            this.txtDesconto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDesconto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesconto_KeyPress);
            this.txtDesconto.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // txtQtd
            // 
            this.txtQtd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtQtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtd.Location = new System.Drawing.Point(476, 91);
            this.txtQtd.Margin = new System.Windows.Forms.Padding(2);
            this.txtQtd.Name = "txtQtd";
            this.txtQtd.Size = new System.Drawing.Size(50, 26);
            this.txtQtd.TabIndex = 130;
            this.txtQtd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQtd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQtd_KeyPress);
            this.txtQtd.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // btnBuscarProduto
            // 
            this.btnBuscarProduto.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnBuscarProduto.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarProduto.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnBuscarProduto.Location = new System.Drawing.Point(314, 92);
            this.btnBuscarProduto.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarProduto.Name = "btnBuscarProduto";
            this.btnBuscarProduto.Size = new System.Drawing.Size(82, 24);
            this.btnBuscarProduto.TabIndex = 128;
            this.btnBuscarProduto.Text = "Buscar";
            this.btnBuscarProduto.UseVisualStyleBackColor = false;
            this.btnBuscarProduto.Click += new System.EventHandler(this.btnBuscarProduto_Click);
            // 
            // txtCodProduto
            // 
            this.txtCodProduto.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCodProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodProduto.Location = new System.Drawing.Point(13, 92);
            this.txtCodProduto.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodProduto.MaxLength = 100;
            this.txtCodProduto.Name = "txtCodProduto";
            this.txtCodProduto.Size = new System.Drawing.Size(91, 26);
            this.txtCodProduto.TabIndex = 126;
            this.txtCodProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodProduto.Leave += new System.EventHandler(this.txtCodProduto_Leave);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(11, 70);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 18);
            this.label5.TabIndex = 136;
            this.label5.Text = "Cód Produto";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(120, 70);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 135;
            this.label6.Text = "Produto";
            // 
            // txtProduto
            // 
            this.txtProduto.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProduto.Location = new System.Drawing.Point(112, 92);
            this.txtProduto.Margin = new System.Windows.Forms.Padding(4);
            this.txtProduto.MaxLength = 100;
            this.txtProduto.Name = "txtProduto";
            this.txtProduto.ReadOnly = true;
            this.txtProduto.Size = new System.Drawing.Size(194, 26);
            this.txtProduto.TabIndex = 127;
            // 
            // btnFinaliza
            // 
            this.btnFinaliza.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnFinaliza.BackColor = System.Drawing.Color.Gold;
            this.btnFinaliza.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinaliza.Enabled = false;
            this.btnFinaliza.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFinaliza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinaliza.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnFinaliza.Location = new System.Drawing.Point(1036, 93);
            this.btnFinaliza.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinaliza.Name = "btnFinaliza";
            this.btnFinaliza.Size = new System.Drawing.Size(140, 26);
            this.btnFinaliza.TabIndex = 802;
            this.btnFinaliza.Text = "Finalizar Compra";
            this.btnFinaliza.UseVisualStyleBackColor = false;
            this.btnFinaliza.Click += new System.EventHandler(this.btnFinaliza_Click);
            // 
            // Dgv
            // 
            this.Dgv.AllowUserToAddRows = false;
            this.Dgv.AllowUserToDeleteRows = false;
            this.Dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Dgv.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.Dgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.Dgv.Location = new System.Drawing.Point(11, 125);
            this.Dgv.Margin = new System.Windows.Forms.Padding(2);
            this.Dgv.Name = "Dgv";
            this.Dgv.ReadOnly = true;
            this.Dgv.RowHeadersWidth = 51;
            this.Dgv.RowTemplate.Height = 24;
            this.Dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv.Size = new System.Drawing.Size(1165, 212);
            this.Dgv.TabIndex = 803;
            this.Dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv_CellContentClick);
            // 
            // btnFinalizaCondicao
            // 
            this.btnFinalizaCondicao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnFinalizaCondicao.BackColor = System.Drawing.Color.Gold;
            this.btnFinalizaCondicao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizaCondicao.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFinalizaCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizaCondicao.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnFinalizaCondicao.Location = new System.Drawing.Point(757, 378);
            this.btnFinalizaCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinalizaCondicao.Name = "btnFinalizaCondicao";
            this.btnFinalizaCondicao.Size = new System.Drawing.Size(85, 29);
            this.btnFinalizaCondicao.TabIndex = 816;
            this.btnFinalizaCondicao.Text = "Finalizar";
            this.btnFinalizaCondicao.UseVisualStyleBackColor = false;
            this.btnFinalizaCondicao.Click += new System.EventHandler(this.btnFinalizaCondicao_Click);
            // 
            // txtTotalNota
            // 
            this.txtTotalNota.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTotalNota.BackColor = System.Drawing.Color.White;
            this.txtTotalNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalNota.Location = new System.Drawing.Point(1081, 372);
            this.txtTotalNota.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalNota.MaxLength = 10;
            this.txtTotalNota.Name = "txtTotalNota";
            this.txtTotalNota.ReadOnly = true;
            this.txtTotalNota.Size = new System.Drawing.Size(94, 26);
            this.txtTotalNota.TabIndex = 815;
            this.txtTotalNota.Text = "0";
            this.txtTotalNota.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFrete
            // 
            this.txtFrete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtFrete.BackColor = System.Drawing.Color.White;
            this.txtFrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFrete.Location = new System.Drawing.Point(427, 379);
            this.txtFrete.Margin = new System.Windows.Forms.Padding(2);
            this.txtFrete.MaxLength = 10;
            this.txtFrete.Name = "txtFrete";
            this.txtFrete.Size = new System.Drawing.Size(94, 26);
            this.txtFrete.TabIndex = 814;
            this.txtFrete.Text = "0";
            this.txtFrete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFrete.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress);
            this.txtFrete.Leave += new System.EventHandler(this.txtFrete_Leave);
            // 
            // txtSeguro
            // 
            this.txtSeguro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtSeguro.BackColor = System.Drawing.Color.White;
            this.txtSeguro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeguro.Location = new System.Drawing.Point(529, 379);
            this.txtSeguro.Margin = new System.Windows.Forms.Padding(2);
            this.txtSeguro.MaxLength = 10;
            this.txtSeguro.Name = "txtSeguro";
            this.txtSeguro.Size = new System.Drawing.Size(94, 26);
            this.txtSeguro.TabIndex = 813;
            this.txtSeguro.Text = "0";
            this.txtSeguro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSeguro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress);
            this.txtSeguro.Leave += new System.EventHandler(this.txtSeguro_Leave);
            // 
            // txtOutras
            // 
            this.txtOutras.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtOutras.BackColor = System.Drawing.Color.White;
            this.txtOutras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutras.Location = new System.Drawing.Point(627, 379);
            this.txtOutras.Margin = new System.Windows.Forms.Padding(2);
            this.txtOutras.MaxLength = 10;
            this.txtOutras.Name = "txtOutras";
            this.txtOutras.Size = new System.Drawing.Size(124, 26);
            this.txtOutras.TabIndex = 812;
            this.txtOutras.Text = "0";
            this.txtOutras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOutras.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress);
            this.txtOutras.Leave += new System.EventHandler(this.txtOutras_Leave);
            // 
            // lbTotalNota
            // 
            this.lbTotalNota.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTotalNota.AutoSize = true;
            this.lbTotalNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalNota.ForeColor = System.Drawing.Color.Gold;
            this.lbTotalNota.Location = new System.Drawing.Point(1078, 352);
            this.lbTotalNota.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTotalNota.Name = "lbTotalNota";
            this.lbTotalNota.Size = new System.Drawing.Size(77, 18);
            this.lbTotalNota.TabIndex = 811;
            this.lbTotalNota.Text = "Total Nota";
            // 
            // lbOutras
            // 
            this.lbOutras.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbOutras.AutoSize = true;
            this.lbOutras.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOutras.ForeColor = System.Drawing.Color.Gold;
            this.lbOutras.Location = new System.Drawing.Point(627, 360);
            this.lbOutras.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbOutras.Name = "lbOutras";
            this.lbOutras.Size = new System.Drawing.Size(124, 18);
            this.lbOutras.TabIndex = 810;
            this.lbOutras.Text = "Outras Despesas";
            // 
            // lbSeguro
            // 
            this.lbSeguro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbSeguro.AutoSize = true;
            this.lbSeguro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSeguro.ForeColor = System.Drawing.Color.Gold;
            this.lbSeguro.Location = new System.Drawing.Point(523, 359);
            this.lbSeguro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbSeguro.Name = "lbSeguro";
            this.lbSeguro.Size = new System.Drawing.Size(100, 18);
            this.lbSeguro.TabIndex = 809;
            this.lbSeguro.Text = "Custo Seguro";
            // 
            // lbFrete
            // 
            this.lbFrete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbFrete.AutoSize = true;
            this.lbFrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFrete.ForeColor = System.Drawing.Color.Gold;
            this.lbFrete.Location = new System.Drawing.Point(424, 359);
            this.lbFrete.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbFrete.Name = "lbFrete";
            this.lbFrete.Size = new System.Drawing.Size(86, 18);
            this.lbFrete.TabIndex = 808;
            this.lbFrete.Text = "Custo Frete";
            // 
            // lbCondicaoPg
            // 
            this.lbCondicaoPg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbCondicaoPg.AutoSize = true;
            this.lbCondicaoPg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCondicaoPg.ForeColor = System.Drawing.Color.Gold;
            this.lbCondicaoPg.Location = new System.Drawing.Point(76, 358);
            this.lbCondicaoPg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbCondicaoPg.Name = "lbCondicaoPg";
            this.lbCondicaoPg.Size = new System.Drawing.Size(172, 18);
            this.lbCondicaoPg.TabIndex = 807;
            this.lbCondicaoPg.Text = "Condição de Pagamento";
            // 
            // txtCondicao
            // 
            this.txtCondicao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCondicao.Enabled = false;
            this.txtCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCondicao.Location = new System.Drawing.Point(79, 379);
            this.txtCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.txtCondicao.MaxLength = 100;
            this.txtCondicao.Name = "txtCondicao";
            this.txtCondicao.ReadOnly = true;
            this.txtCondicao.Size = new System.Drawing.Size(252, 26);
            this.txtCondicao.TabIndex = 805;
            // 
            // lbCodigoCondicao
            // 
            this.lbCodigoCondicao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbCodigoCondicao.AutoSize = true;
            this.lbCodigoCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCodigoCondicao.ForeColor = System.Drawing.Color.Gold;
            this.lbCodigoCondicao.Location = new System.Drawing.Point(8, 358);
            this.lbCodigoCondicao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbCodigoCondicao.Name = "lbCodigoCondicao";
            this.lbCodigoCondicao.Size = new System.Drawing.Size(56, 18);
            this.lbCodigoCondicao.TabIndex = 806;
            this.lbCodigoCondicao.Text = "Código";
            // 
            // txtCodCondicao
            // 
            this.txtCodCondicao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCodCondicao.Enabled = false;
            this.txtCodCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCondicao.Location = new System.Drawing.Point(11, 379);
            this.txtCodCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodCondicao.MaxLength = 100;
            this.txtCodCondicao.Name = "txtCodCondicao";
            this.txtCodCondicao.ReadOnly = true;
            this.txtCodCondicao.Size = new System.Drawing.Size(62, 26);
            this.txtCodCondicao.TabIndex = 804;
            this.txtCodCondicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodCondicao.Enter += new System.EventHandler(this.txtCodCondicao_Enter);
            this.txtCodCondicao.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCondicao_KeyPress);
            this.txtCodCondicao.Leave += new System.EventHandler(this.txtCodCondicao_Leave);
            // 
            // lvParcelas
            // 
            this.lvParcelas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lvParcelas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clParcelas,
            this.clDias,
            this.clIdForma,
            this.clForma,
            this.clPercentTotal,
            this.clPreco});
            this.lvParcelas.FullRowSelect = true;
            this.lvParcelas.GridLines = true;
            this.lvParcelas.HideSelection = false;
            this.lvParcelas.Location = new System.Drawing.Point(11, 414);
            this.lvParcelas.Margin = new System.Windows.Forms.Padding(4);
            this.lvParcelas.Name = "lvParcelas";
            this.lvParcelas.Size = new System.Drawing.Size(949, 130);
            this.lvParcelas.TabIndex = 817;
            this.lvParcelas.UseCompatibleStateImageBehavior = false;
            this.lvParcelas.View = System.Windows.Forms.View.Details;
            // 
            // clParcelas
            // 
            this.clParcelas.Text = "Nº";
            this.clParcelas.Width = 40;
            // 
            // clDias
            // 
            this.clDias.Text = "Dias";
            this.clDias.Width = 100;
            // 
            // clIdForma
            // 
            this.clIdForma.Text = "ID.F";
            // 
            // clForma
            // 
            this.clForma.Text = "Forma PG";
            this.clForma.Width = 475;
            // 
            // clPercentTotal
            // 
            this.clPercentTotal.Text = "%  sob Total";
            this.clPercentTotal.Width = 120;
            // 
            // clPreco
            // 
            this.clPreco.Text = "Valor da parcela";
            this.clPreco.Width = 150;
            // 
            // btn_BuscaCondPag
            // 
            this.btn_BuscaCondPag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_BuscaCondPag.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscaCondPag.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscaCondPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscaCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscaCondPag.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscaCondPag.Location = new System.Drawing.Point(339, 379);
            this.btn_BuscaCondPag.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscaCondPag.Name = "btn_BuscaCondPag";
            this.btn_BuscaCondPag.Size = new System.Drawing.Size(82, 27);
            this.btn_BuscaCondPag.TabIndex = 818;
            this.btn_BuscaCondPag.Text = "Buscar";
            this.btn_BuscaCondPag.UseVisualStyleBackColor = false;
            this.btn_BuscaCondPag.Click += new System.EventHandler(this.btn_BuscaCondPag_Click);
            // 
            // FrmCadCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1187, 555);
            this.Controls.Add(this.btn_BuscaCondPag);
            this.Controls.Add(this.lvParcelas);
            this.Controls.Add(this.btnFinalizaCondicao);
            this.Controls.Add(this.txtTotalNota);
            this.Controls.Add(this.txtFrete);
            this.Controls.Add(this.txtSeguro);
            this.Controls.Add(this.txtOutras);
            this.Controls.Add(this.lbTotalNota);
            this.Controls.Add(this.lbOutras);
            this.Controls.Add(this.lbSeguro);
            this.Controls.Add(this.lbFrete);
            this.Controls.Add(this.lbCondicaoPg);
            this.Controls.Add(this.txtCondicao);
            this.Controls.Add(this.lbCodigoCondicao);
            this.Controls.Add(this.txtCodCondicao);
            this.Controls.Add(this.Dgv);
            this.Controls.Add(this.btnFinaliza);
            this.Controls.Add(this.btnAdicionar);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtTotalItens);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtUND);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtCusto);
            this.Controls.Add(this.txtDesconto);
            this.Controls.Add(this.txtQtd);
            this.Controls.Add(this.btnBuscarProduto);
            this.Controls.Add(this.txtCodProduto);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtProduto);
            this.Controls.Add(this.btnVerificaData);
            this.Controls.Add(this.dtEmissao);
            this.Controls.Add(this.dtChegada);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.txtNumNFC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtModeloNFC);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSerieNFC);
            this.Controls.Add(this.clForn);
            this.Controls.Add(this.txtFornecedor);
            this.Controls.Add(this.btnBuscarFornecedor);
            this.Name = "FrmCadCompra";
            this.Text = "Cadastro: Compras";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.btnBuscarFornecedor, 0);
            this.Controls.SetChildIndex(this.txtFornecedor, 0);
            this.Controls.SetChildIndex(this.clForn, 0);
            this.Controls.SetChildIndex(this.txtSerieNFC, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.txtModeloNFC, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txtNumNFC, 0);
            this.Controls.SetChildIndex(this.Nome, 0);
            this.Controls.SetChildIndex(this.btnVerificar, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.dtChegada, 0);
            this.Controls.SetChildIndex(this.dtEmissao, 0);
            this.Controls.SetChildIndex(this.btnVerificaData, 0);
            this.Controls.SetChildIndex(this.txtProduto, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txtCodProduto, 0);
            this.Controls.SetChildIndex(this.btnBuscarProduto, 0);
            this.Controls.SetChildIndex(this.txtQtd, 0);
            this.Controls.SetChildIndex(this.txtDesconto, 0);
            this.Controls.SetChildIndex(this.txtCusto, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.label18, 0);
            this.Controls.SetChildIndex(this.txtUND, 0);
            this.Controls.SetChildIndex(this.label20, 0);
            this.Controls.SetChildIndex(this.txtTotalItens, 0);
            this.Controls.SetChildIndex(this.label21, 0);
            this.Controls.SetChildIndex(this.btnAdicionar, 0);
            this.Controls.SetChildIndex(this.btnFinaliza, 0);
            this.Controls.SetChildIndex(this.Dgv, 0);
            this.Controls.SetChildIndex(this.txtCodCondicao, 0);
            this.Controls.SetChildIndex(this.lbCodigoCondicao, 0);
            this.Controls.SetChildIndex(this.txtCondicao, 0);
            this.Controls.SetChildIndex(this.lbCondicaoPg, 0);
            this.Controls.SetChildIndex(this.lbFrete, 0);
            this.Controls.SetChildIndex(this.lbSeguro, 0);
            this.Controls.SetChildIndex(this.lbOutras, 0);
            this.Controls.SetChildIndex(this.lbTotalNota, 0);
            this.Controls.SetChildIndex(this.txtOutras, 0);
            this.Controls.SetChildIndex(this.txtSeguro, 0);
            this.Controls.SetChildIndex(this.txtFrete, 0);
            this.Controls.SetChildIndex(this.txtTotalNota, 0);
            this.Controls.SetChildIndex(this.btnFinalizaCondicao, 0);
            this.Controls.SetChildIndex(this.lvParcelas, 0);
            this.Controls.SetChildIndex(this.btn_BuscaCondPag, 0);
            ((System.ComponentModel.ISupportInitialize)(this.txtNumNFC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModeloNFC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerieNFC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Button btnVerificar;
        protected System.Windows.Forms.Label Nome;
        protected System.Windows.Forms.NumericUpDown txtNumNFC;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.NumericUpDown txtModeloNFC;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.NumericUpDown txtSerieNFC;
        protected System.Windows.Forms.Label clForn;
        protected System.Windows.Forms.TextBox txtFornecedor;
        protected System.Windows.Forms.Button btnBuscarFornecedor;
        protected System.Windows.Forms.Button btnVerificaData;
        protected System.Windows.Forms.DateTimePicker dtEmissao;
        protected System.Windows.Forms.DateTimePicker dtChegada;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.Button btnAdicionar;
        protected System.Windows.Forms.Label label21;
        protected System.Windows.Forms.TextBox txtTotalItens;
        protected System.Windows.Forms.Label label20;
        protected System.Windows.Forms.TextBox txtUND;
        protected System.Windows.Forms.Label label18;
        protected System.Windows.Forms.Label label17;
        protected System.Windows.Forms.Label label16;
        protected System.Windows.Forms.TextBox txtCusto;
        protected System.Windows.Forms.TextBox txtDesconto;
        protected System.Windows.Forms.TextBox txtQtd;
        protected System.Windows.Forms.Button btnBuscarProduto;
        protected System.Windows.Forms.TextBox txtCodProduto;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.TextBox txtProduto;
        protected System.Windows.Forms.Button btnFinaliza;
        public System.Windows.Forms.DataGridView Dgv;
        protected System.Windows.Forms.Button btnFinalizaCondicao;
        private System.Windows.Forms.TextBox txtTotalNota;
        private System.Windows.Forms.TextBox txtFrete;
        private System.Windows.Forms.TextBox txtSeguro;
        private System.Windows.Forms.TextBox txtOutras;
        protected System.Windows.Forms.Label lbTotalNota;
        protected System.Windows.Forms.Label lbOutras;
        protected System.Windows.Forms.Label lbSeguro;
        protected System.Windows.Forms.Label lbFrete;
        protected System.Windows.Forms.Label lbCondicaoPg;
        protected System.Windows.Forms.TextBox txtCondicao;
        protected System.Windows.Forms.Label lbCodigoCondicao;
        protected System.Windows.Forms.TextBox txtCodCondicao;
        protected System.Windows.Forms.ListView lvParcelas;
        private System.Windows.Forms.ColumnHeader clParcelas;
        private System.Windows.Forms.ColumnHeader clDias;
        private System.Windows.Forms.ColumnHeader clIdForma;
        private System.Windows.Forms.ColumnHeader clForma;
        private System.Windows.Forms.ColumnHeader clPercentTotal;
        private System.Windows.Forms.ColumnHeader clPreco;
        protected System.Windows.Forms.Button btn_BuscaCondPag;
    }
}
