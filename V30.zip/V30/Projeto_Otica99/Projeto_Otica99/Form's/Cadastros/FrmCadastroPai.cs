﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadastroPai : Projeto_Otica99.FrmPai
    {
        public FrmCadastroPai()
        {
            InitializeComponent();
        }
        public virtual void ConhecaObj(object obj)
        {

        }
        public virtual void CarregarEdit()
        {
            this.txt_Codigo.Text = txt_Codigo.Text.ToString();
        }
        protected virtual void AlterarEdit()
        {
        
        }
        protected virtual void LimparCampos()
        {
            this.txt_Codigo.Clear();
        }
        public virtual void DesbloquearEdit()
        {
            this.txt_Codigo.Enabled = true;
        }
        public virtual void BloquearEdit()
        {
            this.txt_Codigo.Enabled = false;
        }
        public virtual void Salvar()
        {
            
        }        

        public override void Sair()
        {

            LimparCampos();
            base.Sair();
        }
        private void btn_Salvar_Click(object sender, EventArgs e)
        {

            Salvar();           
        }
    }
}
