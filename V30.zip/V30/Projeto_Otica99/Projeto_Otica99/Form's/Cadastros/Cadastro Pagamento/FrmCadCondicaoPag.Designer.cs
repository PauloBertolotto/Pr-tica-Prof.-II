﻿namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento
{
    partial class FrmCadCondicaoPag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.clmParcela = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmForma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmPagamento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmPercentagemTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblDataUltAlt = new System.Windows.Forms.Label();
            this.txt_DataUltAlteracao = new System.Windows.Forms.TextBox();
            this.btn_Buscar = new System.Windows.Forms.Button();
            this.lblFormaPagamento = new System.Windows.Forms.Label();
            this.txt_FormaPagamento = new System.Windows.Forms.TextBox();
            this.lblCodForma = new System.Windows.Forms.Label();
            this.txt_CodForma = new System.Windows.Forms.TextBox();
            this.lblDesconto = new System.Windows.Forms.Label();
            this.txt_Desconto = new System.Windows.Forms.TextBox();
            this.lblMulta = new System.Windows.Forms.Label();
            this.txt_Multa = new System.Windows.Forms.TextBox();
            this.btn_Adicionar = new System.Windows.Forms.Button();
            this.lbl_PercentagemTotal = new System.Windows.Forms.Label();
            this.txt_PercentagemTotal = new System.Windows.Forms.TextBox();
            this.lbl_Porcentagem = new System.Windows.Forms.Label();
            this.txt_Percentagem = new System.Windows.Forms.TextBox();
            this.lbl_Dias = new System.Windows.Forms.Label();
            this.txt_Dias = new System.Windows.Forms.TextBox();
            this.lbl_Parcelas = new System.Windows.Forms.Label();
            this.txt_Parcelas = new System.Windows.Forms.TextBox();
            this.lbl_Condicao = new System.Windows.Forms.Label();
            this.txt_Condicao = new System.Windows.Forms.TextBox();
            this.lblDataCadastro = new System.Windows.Forms.Label();
            this.txt_DataCadastro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Taxa = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(704, 496);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(12, 31);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(800, 496);
            this.btn_Sair.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            this.dg1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmParcela,
            this.clmDias,
            this.clmForma,
            this.clmPagamento,
            this.clmPercentagemTotal});
            this.dg1.Location = new System.Drawing.Point(12, 118);
            this.dg1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dg1.Name = "dg1";
            this.dg1.ReadOnly = true;
            this.dg1.RowHeadersWidth = 51;
            this.dg1.RowTemplate.Height = 24;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.Size = new System.Drawing.Size(879, 354);
            this.dg1.TabIndex = 228;
            // 
            // clmParcela
            // 
            this.clmParcela.HeaderText = "N° Parcela";
            this.clmParcela.MinimumWidth = 6;
            this.clmParcela.Name = "clmParcela";
            this.clmParcela.ReadOnly = true;
            this.clmParcela.Width = 125;
            // 
            // clmDias
            // 
            this.clmDias.HeaderText = "Dias";
            this.clmDias.MinimumWidth = 6;
            this.clmDias.Name = "clmDias";
            this.clmDias.ReadOnly = true;
            this.clmDias.Width = 125;
            // 
            // clmForma
            // 
            this.clmForma.HeaderText = "ID Forma";
            this.clmForma.MinimumWidth = 6;
            this.clmForma.Name = "clmForma";
            this.clmForma.ReadOnly = true;
            this.clmForma.Width = 125;
            // 
            // clmPagamento
            // 
            this.clmPagamento.HeaderText = "Forma de Pagamento";
            this.clmPagamento.MinimumWidth = 6;
            this.clmPagamento.Name = "clmPagamento";
            this.clmPagamento.ReadOnly = true;
            this.clmPagamento.Width = 150;
            // 
            // clmPercentagemTotal
            // 
            this.clmPercentagemTotal.HeaderText = "% Sob Total";
            this.clmPercentagemTotal.MinimumWidth = 6;
            this.clmPercentagemTotal.Name = "clmPercentagemTotal";
            this.clmPercentagemTotal.ReadOnly = true;
            this.clmPercentagemTotal.Width = 125;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.Gold;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnExcluir.Location = new System.Drawing.Point(607, 496);
            this.btnExcluir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(91, 32);
            this.btnExcluir.TabIndex = 227;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Gold;
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnLimpar.Location = new System.Drawing.Point(509, 496);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(91, 32);
            this.btnLimpar.TabIndex = 226;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblDataUltAlt
            // 
            this.lblDataUltAlt.AutoSize = true;
            this.lblDataUltAlt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataUltAlt.ForeColor = System.Drawing.Color.Gold;
            this.lblDataUltAlt.Location = new System.Drawing.Point(152, 475);
            this.lblDataUltAlt.Name = "lblDataUltAlt";
            this.lblDataUltAlt.Size = new System.Drawing.Size(141, 22);
            this.lblDataUltAlt.TabIndex = 225;
            this.lblDataUltAlt.Text = "Última Alteração";
            // 
            // txt_DataUltAlteracao
            // 
            this.txt_DataUltAlteracao.Enabled = false;
            this.txt_DataUltAlteracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DataUltAlteracao.Location = new System.Drawing.Point(156, 498);
            this.txt_DataUltAlteracao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_DataUltAlteracao.Name = "txt_DataUltAlteracao";
            this.txt_DataUltAlteracao.Size = new System.Drawing.Size(143, 27);
            this.txt_DataUltAlteracao.TabIndex = 224;
            // 
            // btn_Buscar
            // 
            this.btn_Buscar.BackColor = System.Drawing.Color.Gold;
            this.btn_Buscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Buscar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Buscar.Location = new System.Drawing.Point(580, 81);
            this.btn_Buscar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Buscar.Name = "btn_Buscar";
            this.btn_Buscar.Size = new System.Drawing.Size(91, 32);
            this.btn_Buscar.TabIndex = 223;
            this.btn_Buscar.Text = "Buscar";
            this.btn_Buscar.UseVisualStyleBackColor = false;
            this.btn_Buscar.Click += new System.EventHandler(this.btn_Buscar_Click);
            // 
            // lblFormaPagamento
            // 
            this.lblFormaPagamento.AutoSize = true;
            this.lblFormaPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormaPagamento.ForeColor = System.Drawing.Color.Gold;
            this.lblFormaPagamento.Location = new System.Drawing.Point(393, 62);
            this.lblFormaPagamento.Name = "lblFormaPagamento";
            this.lblFormaPagamento.Size = new System.Drawing.Size(180, 22);
            this.lblFormaPagamento.TabIndex = 222;
            this.lblFormaPagamento.Text = "Forma de pagamento";
            // 
            // txt_FormaPagamento
            // 
            this.txt_FormaPagamento.Enabled = false;
            this.txt_FormaPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaPagamento.Location = new System.Drawing.Point(397, 84);
            this.txt_FormaPagamento.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_FormaPagamento.Name = "txt_FormaPagamento";
            this.txt_FormaPagamento.Size = new System.Drawing.Size(176, 27);
            this.txt_FormaPagamento.TabIndex = 221;
            // 
            // lblCodForma
            // 
            this.lblCodForma.AutoSize = true;
            this.lblCodForma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodForma.ForeColor = System.Drawing.Color.Gold;
            this.lblCodForma.Location = new System.Drawing.Point(324, 62);
            this.lblCodForma.Name = "lblCodForma";
            this.lblCodForma.Size = new System.Drawing.Size(67, 22);
            this.lblCodForma.TabIndex = 220;
            this.lblCodForma.Text = "Código";
            // 
            // txt_CodForma
            // 
            this.txt_CodForma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodForma.Location = new System.Drawing.Point(328, 84);
            this.txt_CodForma.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_CodForma.Name = "txt_CodForma";
            this.txt_CodForma.Size = new System.Drawing.Size(63, 27);
            this.txt_CodForma.TabIndex = 219;
            this.txt_CodForma.Text = "0";
            this.txt_CodForma.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblDesconto
            // 
            this.lblDesconto.AutoSize = true;
            this.lblDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesconto.ForeColor = System.Drawing.Color.Gold;
            this.lblDesconto.Location = new System.Drawing.Point(221, 62);
            this.lblDesconto.Name = "lblDesconto";
            this.lblDesconto.Size = new System.Drawing.Size(86, 22);
            this.lblDesconto.TabIndex = 218;
            this.lblDesconto.Text = "Desconto";
            // 
            // txt_Desconto
            // 
            this.txt_Desconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Desconto.Location = new System.Drawing.Point(225, 84);
            this.txt_Desconto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Desconto.Name = "txt_Desconto";
            this.txt_Desconto.Size = new System.Drawing.Size(97, 27);
            this.txt_Desconto.TabIndex = 217;
            this.txt_Desconto.Text = "0";
            this.txt_Desconto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMulta
            // 
            this.lblMulta.AutoSize = true;
            this.lblMulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMulta.ForeColor = System.Drawing.Color.Gold;
            this.lblMulta.Location = new System.Drawing.Point(117, 62);
            this.lblMulta.Name = "lblMulta";
            this.lblMulta.Size = new System.Drawing.Size(53, 22);
            this.lblMulta.TabIndex = 216;
            this.lblMulta.Text = "Multa";
            // 
            // txt_Multa
            // 
            this.txt_Multa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Multa.Location = new System.Drawing.Point(123, 84);
            this.txt_Multa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Multa.Name = "txt_Multa";
            this.txt_Multa.Size = new System.Drawing.Size(97, 27);
            this.txt_Multa.TabIndex = 215;
            this.txt_Multa.Text = "0";
            this.txt_Multa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_Adicionar
            // 
            this.btn_Adicionar.BackColor = System.Drawing.Color.Gold;
            this.btn_Adicionar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Adicionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Adicionar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Adicionar.Location = new System.Drawing.Point(619, 28);
            this.btn_Adicionar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Adicionar.Name = "btn_Adicionar";
            this.btn_Adicionar.Size = new System.Drawing.Size(111, 32);
            this.btn_Adicionar.TabIndex = 214;
            this.btn_Adicionar.Text = "Adicionar";
            this.btn_Adicionar.UseVisualStyleBackColor = false;
            this.btn_Adicionar.Click += new System.EventHandler(this.btn_Adicionar_Click);
            // 
            // lbl_PercentagemTotal
            // 
            this.lbl_PercentagemTotal.AutoSize = true;
            this.lbl_PercentagemTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PercentagemTotal.ForeColor = System.Drawing.Color.Gold;
            this.lbl_PercentagemTotal.Location = new System.Drawing.Point(541, 7);
            this.lbl_PercentagemTotal.Name = "lbl_PercentagemTotal";
            this.lbl_PercentagemTotal.Size = new System.Drawing.Size(72, 22);
            this.lbl_PercentagemTotal.TabIndex = 213;
            this.lbl_PercentagemTotal.Text = "% Total";
            // 
            // txt_PercentagemTotal
            // 
            this.txt_PercentagemTotal.Enabled = false;
            this.txt_PercentagemTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PercentagemTotal.Location = new System.Drawing.Point(545, 31);
            this.txt_PercentagemTotal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_PercentagemTotal.Name = "txt_PercentagemTotal";
            this.txt_PercentagemTotal.Size = new System.Drawing.Size(57, 27);
            this.txt_PercentagemTotal.TabIndex = 212;
            this.txt_PercentagemTotal.Text = "0";
            this.txt_PercentagemTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_Porcentagem
            // 
            this.lbl_Porcentagem.AutoSize = true;
            this.lbl_Porcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Porcentagem.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Porcentagem.Location = new System.Drawing.Point(475, 7);
            this.lbl_Porcentagem.Name = "lbl_Porcentagem";
            this.lbl_Porcentagem.Size = new System.Drawing.Size(26, 22);
            this.lbl_Porcentagem.TabIndex = 211;
            this.lbl_Porcentagem.Text = "%";
            // 
            // txt_Percentagem
            // 
            this.txt_Percentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Percentagem.Location = new System.Drawing.Point(479, 31);
            this.txt_Percentagem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Percentagem.Name = "txt_Percentagem";
            this.txt_Percentagem.Size = new System.Drawing.Size(57, 27);
            this.txt_Percentagem.TabIndex = 210;
            this.txt_Percentagem.Text = "0";
            this.txt_Percentagem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_Dias
            // 
            this.lbl_Dias.AutoSize = true;
            this.lbl_Dias.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dias.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Dias.Location = new System.Drawing.Point(409, 7);
            this.lbl_Dias.Name = "lbl_Dias";
            this.lbl_Dias.Size = new System.Drawing.Size(46, 22);
            this.lbl_Dias.TabIndex = 209;
            this.lbl_Dias.Text = "Dias";
            // 
            // txt_Dias
            // 
            this.txt_Dias.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Dias.Location = new System.Drawing.Point(413, 31);
            this.txt_Dias.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Dias.Name = "txt_Dias";
            this.txt_Dias.Size = new System.Drawing.Size(57, 27);
            this.txt_Dias.TabIndex = 208;
            this.txt_Dias.Text = "30";
            this.txt_Dias.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_Parcelas
            // 
            this.lbl_Parcelas.AutoSize = true;
            this.lbl_Parcelas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Parcelas.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Parcelas.Location = new System.Drawing.Point(327, 7);
            this.lbl_Parcelas.Name = "lbl_Parcelas";
            this.lbl_Parcelas.Size = new System.Drawing.Size(80, 22);
            this.lbl_Parcelas.TabIndex = 207;
            this.lbl_Parcelas.Text = "Parcelas";
            // 
            // txt_Parcelas
            // 
            this.txt_Parcelas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Parcelas.Location = new System.Drawing.Point(331, 31);
            this.txt_Parcelas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Parcelas.Name = "txt_Parcelas";
            this.txt_Parcelas.Size = new System.Drawing.Size(76, 27);
            this.txt_Parcelas.TabIndex = 206;
            this.txt_Parcelas.Text = "1";
            this.txt_Parcelas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_Condicao
            // 
            this.lbl_Condicao.AutoSize = true;
            this.lbl_Condicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Condicao.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Condicao.Location = new System.Drawing.Point(115, 7);
            this.lbl_Condicao.Name = "lbl_Condicao";
            this.lbl_Condicao.Size = new System.Drawing.Size(207, 22);
            this.lbl_Condicao.TabIndex = 205;
            this.lbl_Condicao.Text = "Condição de Pagamento";
            // 
            // txt_Condicao
            // 
            this.txt_Condicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Condicao.Location = new System.Drawing.Point(119, 31);
            this.txt_Condicao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Condicao.Name = "txt_Condicao";
            this.txt_Condicao.Size = new System.Drawing.Size(203, 27);
            this.txt_Condicao.TabIndex = 204;
            // 
            // lblDataCadastro
            // 
            this.lblDataCadastro.AutoSize = true;
            this.lblDataCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataCadastro.ForeColor = System.Drawing.Color.Gold;
            this.lblDataCadastro.Location = new System.Drawing.Point(12, 475);
            this.lblDataCadastro.Name = "lblDataCadastro";
            this.lblDataCadastro.Size = new System.Drawing.Size(126, 22);
            this.lblDataCadastro.TabIndex = 231;
            this.lblDataCadastro.Text = "Data Cadastro";
            // 
            // txt_DataCadastro
            // 
            this.txt_DataCadastro.Enabled = false;
            this.txt_DataCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DataCadastro.Location = new System.Drawing.Point(16, 498);
            this.txt_DataCadastro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_DataCadastro.Name = "txt_DataCadastro";
            this.txt_DataCadastro.Size = new System.Drawing.Size(133, 27);
            this.txt_DataCadastro.TabIndex = 230;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(13, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 22);
            this.label1.TabIndex = 233;
            this.label1.Text = "Taxa";
            // 
            // txt_Taxa
            // 
            this.txt_Taxa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Taxa.Location = new System.Drawing.Point(19, 84);
            this.txt_Taxa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Taxa.Name = "txt_Taxa";
            this.txt_Taxa.Size = new System.Drawing.Size(97, 27);
            this.txt_Taxa.TabIndex = 232;
            this.txt_Taxa.Text = "0";
            this.txt_Taxa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FrmCadCondicaoPag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(909, 545);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Taxa);
            this.Controls.Add(this.lblDataCadastro);
            this.Controls.Add(this.txt_DataCadastro);
            this.Controls.Add(this.dg1);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblDataUltAlt);
            this.Controls.Add(this.txt_DataUltAlteracao);
            this.Controls.Add(this.btn_Buscar);
            this.Controls.Add(this.lblFormaPagamento);
            this.Controls.Add(this.txt_FormaPagamento);
            this.Controls.Add(this.lblCodForma);
            this.Controls.Add(this.txt_CodForma);
            this.Controls.Add(this.lblDesconto);
            this.Controls.Add(this.txt_Desconto);
            this.Controls.Add(this.lblMulta);
            this.Controls.Add(this.txt_Multa);
            this.Controls.Add(this.btn_Adicionar);
            this.Controls.Add(this.lbl_PercentagemTotal);
            this.Controls.Add(this.txt_PercentagemTotal);
            this.Controls.Add(this.lbl_Porcentagem);
            this.Controls.Add(this.txt_Percentagem);
            this.Controls.Add(this.lbl_Dias);
            this.Controls.Add(this.txt_Dias);
            this.Controls.Add(this.lbl_Parcelas);
            this.Controls.Add(this.txt_Parcelas);
            this.Controls.Add(this.lbl_Condicao);
            this.Controls.Add(this.txt_Condicao);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmCadCondicaoPag";
            this.Text = "Cadastro de Condição de Pagamento";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.txt_Condicao, 0);
            this.Controls.SetChildIndex(this.lbl_Condicao, 0);
            this.Controls.SetChildIndex(this.txt_Parcelas, 0);
            this.Controls.SetChildIndex(this.lbl_Parcelas, 0);
            this.Controls.SetChildIndex(this.txt_Dias, 0);
            this.Controls.SetChildIndex(this.lbl_Dias, 0);
            this.Controls.SetChildIndex(this.txt_Percentagem, 0);
            this.Controls.SetChildIndex(this.lbl_Porcentagem, 0);
            this.Controls.SetChildIndex(this.txt_PercentagemTotal, 0);
            this.Controls.SetChildIndex(this.lbl_PercentagemTotal, 0);
            this.Controls.SetChildIndex(this.btn_Adicionar, 0);
            this.Controls.SetChildIndex(this.txt_Multa, 0);
            this.Controls.SetChildIndex(this.lblMulta, 0);
            this.Controls.SetChildIndex(this.txt_Desconto, 0);
            this.Controls.SetChildIndex(this.lblDesconto, 0);
            this.Controls.SetChildIndex(this.txt_CodForma, 0);
            this.Controls.SetChildIndex(this.lblCodForma, 0);
            this.Controls.SetChildIndex(this.txt_FormaPagamento, 0);
            this.Controls.SetChildIndex(this.lblFormaPagamento, 0);
            this.Controls.SetChildIndex(this.btn_Buscar, 0);
            this.Controls.SetChildIndex(this.txt_DataUltAlteracao, 0);
            this.Controls.SetChildIndex(this.lblDataUltAlt, 0);
            this.Controls.SetChildIndex(this.btnLimpar, 0);
            this.Controls.SetChildIndex(this.btnExcluir, 0);
            this.Controls.SetChildIndex(this.dg1, 0);
            this.Controls.SetChildIndex(this.txt_DataCadastro, 0);
            this.Controls.SetChildIndex(this.lblDataCadastro, 0);
            this.Controls.SetChildIndex(this.txt_Taxa, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmParcela;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDias;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmForma;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmPagamento;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmPercentagemTotal;
        public System.Windows.Forms.Button btnExcluir;
        public System.Windows.Forms.Button btnLimpar;
        public System.Windows.Forms.Label lblFormaPagamento;
        public System.Windows.Forms.Label lblCodForma;
        public System.Windows.Forms.Label lblDesconto;
        public System.Windows.Forms.Label lblMulta;
        public System.Windows.Forms.Button btn_Adicionar;
        public System.Windows.Forms.Label lbl_PercentagemTotal;
        public System.Windows.Forms.TextBox txt_PercentagemTotal;
        public System.Windows.Forms.Label lbl_Porcentagem;
        public System.Windows.Forms.TextBox txt_Percentagem;
        public System.Windows.Forms.Label lbl_Dias;
        public System.Windows.Forms.TextBox txt_Dias;
        public System.Windows.Forms.Label lbl_Parcelas;
        public System.Windows.Forms.TextBox txt_Parcelas;
        public System.Windows.Forms.Label lbl_Condicao;
        public System.Windows.Forms.TextBox txt_Condicao;
        public System.Windows.Forms.Button btn_Buscar;
        public System.Windows.Forms.TextBox txt_FormaPagamento;
        public System.Windows.Forms.TextBox txt_CodForma;
        public System.Windows.Forms.TextBox txt_Desconto;
        public System.Windows.Forms.TextBox txt_Multa;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txt_Taxa;
        public System.Windows.Forms.Label lblDataUltAlt;
        public System.Windows.Forms.TextBox txt_DataUltAlteracao;
        public System.Windows.Forms.Label lblDataCadastro;
        public System.Windows.Forms.TextBox txt_DataCadastro;
    }
}
