﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento
{
    public partial class FrmCadFormaPag : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        FormaPagamento       aFormaPag;
        Ctrl_FormaPagamento  aCtrlFormaPag;
        public FrmCadFormaPag()
        {
            InitializeComponent();
            aFormaPag     = new FormaPagamento();
            aCtrlFormaPag = new Ctrl_FormaPagamento();
        }
        private void Letras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }
        
        public override void ConhecaObj(object obj)
        {
            this.aFormaPag = (FormaPagamento)obj;         
        }      
        public override void CarregarEdit()
        {
            this.txt_Codigo.Text   = txt_Codigo.ToString();

            this.CB_Status.Text    = CB_Status.ToString();
            this.txt_FormaPag.Text = txt_FormaPag.ToString();
            
        }
        protected override void LimparCampos()
        {
            this.txt_Codigo.Text         = "0";
            this.CB_Status.SelectedIndex = -1;
            this.txt_FormaPag.Clear();
        }
        public override void DesbloquearEdit()
        {
            this.CB_Status.Enabled    = true;
            this.txt_FormaPag.Enabled = true;
        }
        public override void BloquearEdit()
        {
            this.CB_Status.Enabled    = false;
            this.txt_FormaPag.Enabled = false;
        }
        public bool CamposPreenchidos()
        {
            bool ok = false;
            if (string.IsNullOrEmpty(txt_FormaPag.Text) ||
                string.IsNullOrEmpty(CB_Status.Text)             
                )
            {
                MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                ok = true;
            }

            return ok;
        }
        public override void Salvar()
        {
            string Salvo_FormaPagamento;
            string msg = "O Cadastro " + txt_FormaPag.Text + " foi realizado com o sucesso!";

            if(CamposPreenchidos())
            {

                aFormaPag.ID = Convert.ToInt16(txt_Codigo.Text);

                aFormaPag.StatusForma = CB_Status.Text;
                aFormaPag.Forma       = txt_FormaPag.Text;           

                Salvo_FormaPagamento = aCtrlFormaPag.Salvar(aFormaPag);

                if (btn_Salvar.Text == "Alterar")
                {
                    aFormaPag.DataUltimaAlteracao = DateTime.Now;
                    msg = "o Cadastro de Forma de Pagamento foi Alterado com sucesso!";
                }

                LimparCampos();
                this.txt_Codigo.Text = "0";
                MessageBox.Show(msg);
                Close();
            }
        }
    }
}
