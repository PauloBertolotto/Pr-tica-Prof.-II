﻿namespace Projeto_Otica99
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.PanelMenu = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Consultas = new System.Windows.Forms.Button();
            this.btn_Pagamento = new System.Windows.Forms.Button();
            this.btn_Vendas = new System.Windows.Forms.Button();
            this.btn_Cidades = new System.Windows.Forms.Button();
            this.btn_Fornecedores = new System.Windows.Forms.Button();
            this.btn_Estados = new System.Windows.Forms.Button();
            this.btn_Paises = new System.Windows.Forms.Button();
            this.PanelConsultas = new System.Windows.Forms.Panel();
            this.btn_Categoria = new System.Windows.Forms.Button();
            this.btn_Marca = new System.Windows.Forms.Button();
            this.btn_Produtos = new System.Windows.Forms.Button();
            this.btn_Funcionarios = new System.Windows.Forms.Button();
            this.btn_Clientes = new System.Windows.Forms.Button();
            this.Panel_Pag = new System.Windows.Forms.Panel();
            this.btn_Compra = new System.Windows.Forms.Button();
            this.btn_ContasReceber = new System.Windows.Forms.Button();
            this.btn_Venda = new System.Windows.Forms.Button();
            this.btn_CondPag = new System.Windows.Forms.Button();
            this.btn_ContasPagar = new System.Windows.Forms.Button();
            this.btn_FormaPag = new System.Windows.Forms.Button();
            this.PanelMenu.SuspendLayout();
            this.PanelConsultas.SuspendLayout();
            this.Panel_Pag.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelMenu
            // 
            this.PanelMenu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PanelMenu.BackColor = System.Drawing.Color.MidnightBlue;
            this.PanelMenu.Controls.Add(this.panel2);
            this.PanelMenu.Controls.Add(this.btn_Consultas);
            this.PanelMenu.Controls.Add(this.btn_Pagamento);
            this.PanelMenu.Controls.Add(this.btn_Vendas);
            this.PanelMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PanelMenu.Location = new System.Drawing.Point(1, 0);
            this.PanelMenu.Name = "PanelMenu";
            this.PanelMenu.Size = new System.Drawing.Size(1783, 37);
            this.PanelMenu.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::Projeto_Otica99.Properties.Resources.Logo1;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Location = new System.Drawing.Point(-1, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(41, 37);
            this.panel2.TabIndex = 16;
            // 
            // btn_Consultas
            // 
            this.btn_Consultas.BackColor = System.Drawing.Color.Gold;
            this.btn_Consultas.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Consultas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Consultas.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Consultas.Location = new System.Drawing.Point(46, 3);
            this.btn_Consultas.Name = "btn_Consultas";
            this.btn_Consultas.Size = new System.Drawing.Size(90, 29);
            this.btn_Consultas.TabIndex = 0;
            this.btn_Consultas.Text = "Consultas";
            this.btn_Consultas.UseVisualStyleBackColor = false;
            this.btn_Consultas.Click += new System.EventHandler(this.btn_Consultas_Click);
            // 
            // btn_Pagamento
            // 
            this.btn_Pagamento.BackColor = System.Drawing.Color.Gold;
            this.btn_Pagamento.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Pagamento.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Pagamento.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Pagamento.Location = new System.Drawing.Point(142, 3);
            this.btn_Pagamento.Name = "btn_Pagamento";
            this.btn_Pagamento.Size = new System.Drawing.Size(100, 29);
            this.btn_Pagamento.TabIndex = 1;
            this.btn_Pagamento.Text = "Pagamento";
            this.btn_Pagamento.UseVisualStyleBackColor = false;
            this.btn_Pagamento.Click += new System.EventHandler(this.btn_Contas_Click);
            // 
            // btn_Vendas
            // 
            this.btn_Vendas.BackColor = System.Drawing.Color.Gold;
            this.btn_Vendas.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Vendas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Vendas.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Vendas.Location = new System.Drawing.Point(248, 3);
            this.btn_Vendas.Name = "btn_Vendas";
            this.btn_Vendas.Size = new System.Drawing.Size(90, 29);
            this.btn_Vendas.TabIndex = 2;
            this.btn_Vendas.Text = "Vendas";
            this.btn_Vendas.UseVisualStyleBackColor = false;
            // 
            // btn_Cidades
            // 
            this.btn_Cidades.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Cidades.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Cidades.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Cidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cidades.ForeColor = System.Drawing.Color.Gold;
            this.btn_Cidades.Location = new System.Drawing.Point(3, 109);
            this.btn_Cidades.Name = "btn_Cidades";
            this.btn_Cidades.Size = new System.Drawing.Size(186, 47);
            this.btn_Cidades.TabIndex = 12;
            this.btn_Cidades.Text = "Cidades";
            this.btn_Cidades.UseVisualStyleBackColor = false;
            this.btn_Cidades.Visible = false;
            this.btn_Cidades.Click += new System.EventHandler(this.btn_Cidades_Click);
            // 
            // btn_Fornecedores
            // 
            this.btn_Fornecedores.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Fornecedores.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Fornecedores.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Fornecedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fornecedores.ForeColor = System.Drawing.Color.Gold;
            this.btn_Fornecedores.Location = new System.Drawing.Point(3, 268);
            this.btn_Fornecedores.Name = "btn_Fornecedores";
            this.btn_Fornecedores.Size = new System.Drawing.Size(186, 47);
            this.btn_Fornecedores.TabIndex = 13;
            this.btn_Fornecedores.Text = "Fornecedores";
            this.btn_Fornecedores.UseVisualStyleBackColor = false;
            this.btn_Fornecedores.Visible = false;
            this.btn_Fornecedores.Click += new System.EventHandler(this.btn_Fornecedores_Click);
            // 
            // btn_Estados
            // 
            this.btn_Estados.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Estados.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Estados.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Estados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Estados.ForeColor = System.Drawing.Color.Gold;
            this.btn_Estados.Location = new System.Drawing.Point(3, 56);
            this.btn_Estados.Name = "btn_Estados";
            this.btn_Estados.Size = new System.Drawing.Size(186, 47);
            this.btn_Estados.TabIndex = 11;
            this.btn_Estados.Text = "Estados";
            this.btn_Estados.UseVisualStyleBackColor = false;
            this.btn_Estados.Visible = false;
            this.btn_Estados.Click += new System.EventHandler(this.btn_Estados_Click);
            // 
            // btn_Paises
            // 
            this.btn_Paises.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Paises.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Paises.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Paises.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Paises.ForeColor = System.Drawing.Color.Gold;
            this.btn_Paises.Location = new System.Drawing.Point(3, 3);
            this.btn_Paises.Name = "btn_Paises";
            this.btn_Paises.Size = new System.Drawing.Size(186, 47);
            this.btn_Paises.TabIndex = 10;
            this.btn_Paises.Text = "Paises";
            this.btn_Paises.UseVisualStyleBackColor = false;
            this.btn_Paises.Visible = false;
            this.btn_Paises.Click += new System.EventHandler(this.btn_Paises_Click);
            // 
            // PanelConsultas
            // 
            this.PanelConsultas.BackColor = System.Drawing.Color.Transparent;
            this.PanelConsultas.Controls.Add(this.btn_Categoria);
            this.PanelConsultas.Controls.Add(this.btn_Marca);
            this.PanelConsultas.Controls.Add(this.btn_Produtos);
            this.PanelConsultas.Controls.Add(this.btn_Funcionarios);
            this.PanelConsultas.Controls.Add(this.btn_Clientes);
            this.PanelConsultas.Controls.Add(this.btn_Paises);
            this.PanelConsultas.Controls.Add(this.btn_Estados);
            this.PanelConsultas.Controls.Add(this.btn_Cidades);
            this.PanelConsultas.Controls.Add(this.btn_Fornecedores);
            this.PanelConsultas.Location = new System.Drawing.Point(12, 43);
            this.PanelConsultas.Name = "PanelConsultas";
            this.PanelConsultas.Size = new System.Drawing.Size(386, 376);
            this.PanelConsultas.TabIndex = 16;
            this.PanelConsultas.Visible = false;
            // 
            // btn_Categoria
            // 
            this.btn_Categoria.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Categoria.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Categoria.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Categoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Categoria.ForeColor = System.Drawing.Color.Gold;
            this.btn_Categoria.Location = new System.Drawing.Point(195, 56);
            this.btn_Categoria.Name = "btn_Categoria";
            this.btn_Categoria.Size = new System.Drawing.Size(186, 47);
            this.btn_Categoria.TabIndex = 22;
            this.btn_Categoria.Text = "Categorias";
            this.btn_Categoria.UseVisualStyleBackColor = false;
            this.btn_Categoria.Visible = false;
            this.btn_Categoria.Click += new System.EventHandler(this.btn_Categoria_Click);
            // 
            // btn_Marca
            // 
            this.btn_Marca.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Marca.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Marca.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Marca.ForeColor = System.Drawing.Color.Gold;
            this.btn_Marca.Location = new System.Drawing.Point(195, 3);
            this.btn_Marca.Name = "btn_Marca";
            this.btn_Marca.Size = new System.Drawing.Size(186, 47);
            this.btn_Marca.TabIndex = 17;
            this.btn_Marca.Text = "Marcas";
            this.btn_Marca.UseVisualStyleBackColor = false;
            this.btn_Marca.Visible = false;
            this.btn_Marca.Click += new System.EventHandler(this.btn_Marca_Click);
            // 
            // btn_Produtos
            // 
            this.btn_Produtos.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Produtos.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Produtos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Produtos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Produtos.ForeColor = System.Drawing.Color.Gold;
            this.btn_Produtos.Location = new System.Drawing.Point(3, 321);
            this.btn_Produtos.Name = "btn_Produtos";
            this.btn_Produtos.Size = new System.Drawing.Size(186, 47);
            this.btn_Produtos.TabIndex = 16;
            this.btn_Produtos.Text = "Produtos";
            this.btn_Produtos.UseVisualStyleBackColor = false;
            this.btn_Produtos.Visible = false;
            this.btn_Produtos.Click += new System.EventHandler(this.btn_Produtos_Click);
            // 
            // btn_Funcionarios
            // 
            this.btn_Funcionarios.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Funcionarios.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Funcionarios.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Funcionarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Funcionarios.ForeColor = System.Drawing.Color.Gold;
            this.btn_Funcionarios.Location = new System.Drawing.Point(3, 215);
            this.btn_Funcionarios.Name = "btn_Funcionarios";
            this.btn_Funcionarios.Size = new System.Drawing.Size(186, 47);
            this.btn_Funcionarios.TabIndex = 15;
            this.btn_Funcionarios.Text = "Funcionários";
            this.btn_Funcionarios.UseVisualStyleBackColor = false;
            this.btn_Funcionarios.Visible = false;
            this.btn_Funcionarios.Click += new System.EventHandler(this.btn_Funcionarios_Click);
            // 
            // btn_Clientes
            // 
            this.btn_Clientes.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Clientes.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Clientes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clientes.ForeColor = System.Drawing.Color.Gold;
            this.btn_Clientes.Location = new System.Drawing.Point(3, 162);
            this.btn_Clientes.Name = "btn_Clientes";
            this.btn_Clientes.Size = new System.Drawing.Size(186, 47);
            this.btn_Clientes.TabIndex = 14;
            this.btn_Clientes.Text = "Clientes";
            this.btn_Clientes.UseVisualStyleBackColor = false;
            this.btn_Clientes.Visible = false;
            this.btn_Clientes.Click += new System.EventHandler(this.btn_Clientes_Click);
            // 
            // Panel_Pag
            // 
            this.Panel_Pag.BackColor = System.Drawing.Color.Transparent;
            this.Panel_Pag.Controls.Add(this.btn_Compra);
            this.Panel_Pag.Controls.Add(this.btn_ContasReceber);
            this.Panel_Pag.Controls.Add(this.btn_Venda);
            this.Panel_Pag.Controls.Add(this.btn_CondPag);
            this.Panel_Pag.Controls.Add(this.btn_ContasPagar);
            this.Panel_Pag.Controls.Add(this.btn_FormaPag);
            this.Panel_Pag.Location = new System.Drawing.Point(404, 43);
            this.Panel_Pag.Name = "Panel_Pag";
            this.Panel_Pag.Size = new System.Drawing.Size(199, 376);
            this.Panel_Pag.TabIndex = 17;
            this.Panel_Pag.Visible = false;
            // 
            // btn_Compra
            // 
            this.btn_Compra.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Compra.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Compra.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Compra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Compra.ForeColor = System.Drawing.Color.Gold;
            this.btn_Compra.Location = new System.Drawing.Point(3, 271);
            this.btn_Compra.Name = "btn_Compra";
            this.btn_Compra.Size = new System.Drawing.Size(186, 47);
            this.btn_Compra.TabIndex = 21;
            this.btn_Compra.Text = "Compra";
            this.btn_Compra.UseVisualStyleBackColor = false;
            this.btn_Compra.Click += new System.EventHandler(this.btn_Compra_Click);
            // 
            // btn_ContasReceber
            // 
            this.btn_ContasReceber.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_ContasReceber.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_ContasReceber.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_ContasReceber.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ContasReceber.ForeColor = System.Drawing.Color.Gold;
            this.btn_ContasReceber.Location = new System.Drawing.Point(3, 162);
            this.btn_ContasReceber.Name = "btn_ContasReceber";
            this.btn_ContasReceber.Size = new System.Drawing.Size(186, 47);
            this.btn_ContasReceber.TabIndex = 19;
            this.btn_ContasReceber.Text = "Contas a Receber";
            this.btn_ContasReceber.UseVisualStyleBackColor = false;
            this.btn_ContasReceber.Visible = false;
            this.btn_ContasReceber.Click += new System.EventHandler(this.btn_ContasReceber_Click);
            // 
            // btn_Venda
            // 
            this.btn_Venda.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_Venda.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_Venda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Venda.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Venda.ForeColor = System.Drawing.Color.Gold;
            this.btn_Venda.Location = new System.Drawing.Point(3, 215);
            this.btn_Venda.Name = "btn_Venda";
            this.btn_Venda.Size = new System.Drawing.Size(186, 47);
            this.btn_Venda.TabIndex = 20;
            this.btn_Venda.Text = "Venda";
            this.btn_Venda.UseVisualStyleBackColor = false;
            this.btn_Venda.Click += new System.EventHandler(this.btn_Venda_Click);
            // 
            // btn_CondPag
            // 
            this.btn_CondPag.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_CondPag.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_CondPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_CondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CondPag.ForeColor = System.Drawing.Color.Gold;
            this.btn_CondPag.Location = new System.Drawing.Point(3, 3);
            this.btn_CondPag.Name = "btn_CondPag";
            this.btn_CondPag.Size = new System.Drawing.Size(186, 47);
            this.btn_CondPag.TabIndex = 10;
            this.btn_CondPag.Text = "Condição de Pagamento";
            this.btn_CondPag.UseVisualStyleBackColor = false;
            this.btn_CondPag.Visible = false;
            this.btn_CondPag.Click += new System.EventHandler(this.btn_CondPag_Click);
            // 
            // btn_ContasPagar
            // 
            this.btn_ContasPagar.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_ContasPagar.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_ContasPagar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_ContasPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ContasPagar.ForeColor = System.Drawing.Color.Gold;
            this.btn_ContasPagar.Location = new System.Drawing.Point(3, 109);
            this.btn_ContasPagar.Name = "btn_ContasPagar";
            this.btn_ContasPagar.Size = new System.Drawing.Size(186, 47);
            this.btn_ContasPagar.TabIndex = 18;
            this.btn_ContasPagar.Text = "Contas a Pagar";
            this.btn_ContasPagar.UseVisualStyleBackColor = false;
            this.btn_ContasPagar.Visible = false;
            this.btn_ContasPagar.Click += new System.EventHandler(this.btn_ContasPagar_Click);
            // 
            // btn_FormaPag
            // 
            this.btn_FormaPag.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn_FormaPag.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_FormaPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_FormaPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FormaPag.ForeColor = System.Drawing.Color.Gold;
            this.btn_FormaPag.Location = new System.Drawing.Point(3, 56);
            this.btn_FormaPag.Name = "btn_FormaPag";
            this.btn_FormaPag.Size = new System.Drawing.Size(186, 47);
            this.btn_FormaPag.TabIndex = 11;
            this.btn_FormaPag.Text = "Forma de Pagamento";
            this.btn_FormaPag.UseVisualStyleBackColor = false;
            this.btn_FormaPag.Visible = false;
            this.btn_FormaPag.Click += new System.EventHandler(this.btn_FormaPag_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1203, 701);
            this.Controls.Add(this.Panel_Pag);
            this.Controls.Add(this.PanelConsultas);
            this.Controls.Add(this.PanelMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Principal_KeyDown);
            this.PanelMenu.ResumeLayout(false);
            this.PanelConsultas.ResumeLayout(false);
            this.Panel_Pag.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel PanelMenu;
        private System.Windows.Forms.Button btn_Vendas;
        private System.Windows.Forms.Button btn_Pagamento;
        private System.Windows.Forms.Button btn_Consultas;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_Cidades;
        private System.Windows.Forms.Button btn_Fornecedores;
        private System.Windows.Forms.Button btn_Estados;
        private System.Windows.Forms.Button btn_Paises;
        private System.Windows.Forms.Panel PanelConsultas;
        private System.Windows.Forms.Button btn_Funcionarios;
        private System.Windows.Forms.Button btn_Clientes;
        private System.Windows.Forms.Button btn_Produtos;
        private System.Windows.Forms.Panel Panel_Pag;
        private System.Windows.Forms.Button btn_CondPag;
        private System.Windows.Forms.Button btn_FormaPag;
        private System.Windows.Forms.Button btn_ContasPagar;
        private System.Windows.Forms.Button btn_ContasReceber;
        private System.Windows.Forms.Button btn_Venda;
        private System.Windows.Forms.Button btn_Compra;
        private System.Windows.Forms.Button btn_Categoria;
        private System.Windows.Forms.Button btn_Marca;
    }
}

