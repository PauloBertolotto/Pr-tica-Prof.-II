﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Venda_e_Compra
{
    public class FormaPagamento : Pai
    {
        private string _statusForma;
        private string _forma;

        public FormaPagamento() 
        {
            _statusForma = "";
            _forma       = "";
        }
        public FormaPagamento(int id, string statusForma, string forma, DateTime dataCriacao, DateTime dataUltAlteracao) : base(id, dataCriacao, dataUltAlteracao)
        {
            _statusForma = statusForma;
            _forma = forma;
        }
        public string StatusForma
        {
            get => _statusForma;
            set => _statusForma = value;
        }

        public string Forma
        {
            get => _forma;
            set => _forma = value;
        }
    }
}
