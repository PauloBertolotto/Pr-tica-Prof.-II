﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_ItensVenda
    {
        private DAO_ItensVenda itensVendaDAL = new DAO_ItensVenda();

        public bool AdicionarItemVenda(ItensVenda itemVenda)
        {
            return itensVendaDAL.AdicionarItemVenda(itemVenda);
        }
        public ItensVenda BuscarItemVendaPorChave(int numNF, int modeloNF, int serieNF, int idCliente, int idProduto, string tipoItem)
        {
            return itensVendaDAL.BuscarItemVendaPorChave(numNF, modeloNF, serieNF, idCliente, idProduto, tipoItem);
        }
        public List<ItensVenda> BuscarItensVendaPorChave2(int numNF, int modeloNF, int serieNF)
        {
            return itensVendaDAL.BuscarItensVendaPorChave2(numNF, modeloNF, serieNF);
        }
        public List<ItensVenda> ListarItensVenda()
        {
            return itensVendaDAL.ListarItensVenda();
        }
    }
}
