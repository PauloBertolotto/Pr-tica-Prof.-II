﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_FormaPagamento : Controller
    {

        DAO_FormaPagamento aDAO_FormaPag;       
        public Ctrl_FormaPagamento()
        {
            aDAO_FormaPag = new DAO_FormaPagamento();
        }
        public override string Salvar(object obj)
        {
            return aDAO_FormaPag.Salvar(obj);
        }
        public override string Excluir(string item)
        {
            return aDAO_FormaPag.Excluir(item);
        }
        public List<FormaPagamento> Pesquisar(string nome)
        {
            return aDAO_FormaPag.Pesquisar(nome);
        }
        public List<FormaPagamento> ListarFormasPag()
        {
            return aDAO_FormaPag.ListarFormasPag();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_FormaPag.CarregaObj(obj);
        }
        public FormaPagamento BuscarFormaPagamentoPorId(int id)
        {
            return aDAO_FormaPag.BuscarFormaPagamentoPorId(id);
        }

    }
}
