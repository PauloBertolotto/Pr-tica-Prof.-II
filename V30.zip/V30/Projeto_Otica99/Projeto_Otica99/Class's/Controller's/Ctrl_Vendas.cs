﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Vendas
    {
        private DAO_Vendas vendasDAL = new DAO_Vendas();

        public bool AdicionarVenda(Vendas venda)
        {
            return vendasDAL.AdicionarVenda(venda);
        }

        public bool CancelarVenda(Vendas venda)
        {
            return vendasDAL.CancelarVenda(venda);
        }

        public Vendas BuscarVendaPorChave(int numNF, int modeloNF, int serieNF, int idCliente)
        {
            return vendasDAL.BuscarVendaPorChave(numNF, modeloNF, serieNF, idCliente);
        }

        public bool VerificarSeVendaExiste(int numNF, int modeloNF, int serieNF, int idCliente)
        {
            try
            {
                return vendasDAL.ExisteVendaPorChave(numNF, modeloNF, serieNF, idCliente);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }
        }

        public List<Vendas> BuscarListaVendaPorChave(int numNF, int modeloNF, int serieNF)
        {
            return vendasDAL.BuscarListaVendasPorChave(numNF, modeloNF, serieNF);
        }

        public List<Vendas> ListarVendas(bool? statusCancelada)
        {
            return vendasDAL.ListarVendas(statusCancelada);
        }

        public List<Vendas> ListarVendas(DateTime? dataInicio, DateTime? dataFim, bool? cancelada, string nomeCliente, string tipoData)
        {
            return vendasDAL.ListarVendas(dataInicio, dataFim, cancelada, nomeCliente, tipoData);
        }

        public int BuscarNFE(string tipo)
        {
            return vendasDAL.BuscarNFe(tipo);
        }
        public void Incluir()
        {
            FrmCadVendas frmCadastroVenda = new FrmCadVendas();
            frmCadastroVenda.Text = "Realizar nova venda";
            frmCadastroVenda.BuscarNFE();
            frmCadastroVenda.ShowDialog();
        }

        public void Visualizar(Vendas venda)
        {
            if (venda != null)
            {
                FrmCadVendas frmCadastroVenda = new FrmCadVendas();
                frmCadastroVenda.Text = "Consultar uma Venda";
                frmCadastroVenda.Popular(venda);
                frmCadastroVenda.DesabilitarBotoes();
                frmCadastroVenda.ShowDialog();
            }
        }

        public void CancelarNota(Vendas venda)
        {
            if (venda != null)
            {
                FrmCadVendas frm = new FrmCadVendas();
                frm.Text = "Cancelar Nota";
                if (venda.DataCancelamento != null)
                {
                    frm.btn_Salvar.Text = "CANCELAR";
                }
                frm.btn_FCond.Enabled = false;
                frm.Popular(venda);
                frm.ShowDialog();
            }
        }
    }
}
