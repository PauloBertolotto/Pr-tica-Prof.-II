﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento;
using Projeto_Otica99.Form_s.Consultas.Consula_Pagamento;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_CondPagamento : Controller
    {
        private CondicaoPagamento CondicaoPagamento = new CondicaoPagamento();

        private DAO_CondPagamento condicaoPagamentoDAO = new DAO_CondPagamento();

        public bool AdicionarCondicaoPagamento(CondicaoPagamento condicao)
        {
            CondicaoPagamento = condicao;
            return condicaoPagamentoDAO.Salvar(CondicaoPagamento);
        }
        public bool AlterarCondicaoPagamento(CondicaoPagamento condicao)
        {
            CondicaoPagamento = condicao;
            return condicaoPagamentoDAO.Alterar(CondicaoPagamento);
        }
        public bool AtivarOuDesativarCondicaoPagamento(CondicaoPagamento condicao)
        {
            return condicaoPagamentoDAO.AtivarOuDesativarCondicaoPagamento(condicao);
        }

        public bool Excluir(int condicaoPagamentoId)
        {
            return condicaoPagamentoDAO.ExcluirCondicaoPagamento(condicaoPagamentoId);
        }
        public CondicaoPagamento BuscarCondicaoPagamentoPorId(int id)
        {
            return condicaoPagamentoDAO.BuscarCondicaoPagamentoPorId(id);
        }
        public List<CondicaoPagamento> ListarCondicoesPagamento(string status)
        {
            return condicaoPagamentoDAO.ListarCondicoesPagamento(status);
        }
        public List<CondicaoPagamento> PesquisarCondicaoPorCriterio(string valorPesquisa, string status)
        {
            List<CondicaoPagamento> Encontrados = condicaoPagamentoDAO.PesquisarCondicaoPorCriterio(valorPesquisa, status);
            return Encontrados;
        }

        public int ObterProximoIdCondicaoPagamento()
        {
            return condicaoPagamentoDAO.ObterProximoIdCondicaoPagamento();
        }
        public void Incluir()
        {
            FrmCadCondicaoPag frm = new FrmCadCondicaoPag();
            frm.Text = "Incluir Condição de Pagamento";
            frm.btnLimpar.Visible = true;
            frm.btnExcluir.Visible = true;
            frm.DefinirProximoIdCondicaoPagamento();
            
            frm.ShowDialog();
        }
        
    }
}
