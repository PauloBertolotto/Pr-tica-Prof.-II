﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento;
using Projeto_Otica99.Form_s.Consultas;
using Projeto_Otica99.Form_s.Consultas.Consula_Pagamento;
using Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Outros
{
    internal class Interfaces
    {

        FrmCadPais             oCadPais;  
        FrmConPais             aConPais;
                               
        FrmCadEstado           oCadEstado;
        FrmConEstado           aConEstado;
                               
        FrmCadCidade           oCadCidade;
        FrmConCidade           aConCidade;
                               
        FrmCadPFePJ            oCadCliente;
        FrmConClientes         aConCliente;
                               
        FrmCadPFePJ            oCadFuncionario;
        FrmConFuncionarios     aConFuncionario;
                               
        FrmCadPFePJ            oCadFornecedor;
        FrmConFornecedor       aConFornecedor;
                               
        FrmCadFormaPag         oCadFormaPag;
        FrmConFormaPagamento   aConFormaPag;
                               
        FrmCadCondicaoPag      oCadCondPag;
        FrmConCondPagamento    aConCondicaoPag;
                               
        FrmCadContasPagar      oCadContasPagar;
        FrmConContas_a_Pagar   aConContasPagar;

        FrmCadContasReceber    oCadContasReceber;
        FrmConContas_a_Receber aConContasReceber;

        FrmCadCategoria        oCadCategoria;
        FrmConCategoria        aConCategoria;

        FrmCadMarca            oCadMarca;
        FrmConMarca            aConMarca;

        FrmCadProdutos         oCadProduto;
        FrmConProdutos         aConProduto;

        FrmCadCompra           oCadCompra;
        FrmConCompra           aConCompra;

        FrmCadVendas           oCadVenda;
        FrmConVendas           aConVendas;
                             
        public Interfaces()
        {
            oCadPais          = new FrmCadPais();
            aConPais          = new FrmConPais();
                              
            oCadEstado        = new FrmCadEstado();
            aConEstado        = new FrmConEstado();
                              
            oCadCidade        = new FrmCadCidade();
            aConCidade        = new FrmConCidade();
                              
            oCadCliente       = new FrmCadPFePJ();
            aConCliente       = new FrmConClientes();
                              
            oCadFuncionario   = new FrmCadPFePJ();
            aConFuncionario   = new FrmConFuncionarios();
                              
            oCadFornecedor    = new FrmCadPFePJ();
            aConFornecedor    = new FrmConFornecedor();
                              
            oCadFormaPag      = new FrmCadFormaPag();
            aConFormaPag      = new FrmConFormaPagamento();
                              
            oCadCondPag       = new FrmCadCondicaoPag();
            aConCondicaoPag   = new FrmConCondPagamento();
                              
            oCadContasPagar   = new FrmCadContasPagar();
            aConContasPagar   = new FrmConContas_a_Pagar();

            oCadContasReceber = new FrmCadContasReceber();
            aConContasReceber = new FrmConContas_a_Receber();

            oCadCategoria     = new FrmCadCategoria();
            aConCategoria     = new FrmConCategoria();

            oCadMarca         = new FrmCadMarca();
            aConMarca         = new FrmConMarca();

            oCadProduto       = new FrmCadProdutos();
            aConProduto       = new FrmConProdutos();

            oCadCompra        = new FrmCadCompra();
            aConCompra        = new FrmConCompra();

            oCadVenda         = new FrmCadVendas();
            aConVendas        = new FrmConVendas();

            aConPais.SetFrmCadastro(oCadPais);

            aConEstado.SetFrmCadastro(oCadEstado);

            aConCidade.SetFrmCadastro(oCadCidade);

            aConFornecedor.SetFrmCadastro(oCadFornecedor);

            aConFuncionario.SetFrmCadastro(oCadFuncionario);

            aConCliente.SetFrmCadastro(oCadCliente);

            aConFormaPag.SetFrmCadastro(oCadFormaPag);

            aConCondicaoPag.SetFrmCadastro(oCadCondPag);

            oCadEstado.SetConsultaPaises(aConPais);

            oCadCidade.SetConsultaEstado(aConEstado);

            oCadFornecedor.SetConsultaCidade(aConCidade);

            aConCompra.SetFrmCadastro(oCadCompra);

            aConVendas.SetFrmCadastro(oCadVenda);
        }
        public void PecaPais(Paises oPais, Ctrl_Paises aCtrlPais)
        {
            aConPais.ConhecaObj(oCadPais, aCtrlPais);
            aConPais.ShowDialog();
        }
        public void PecaEstado(Estados oEstado, Ctrl_Estados aCtrlEstados)
        {
            aConEstado.ConhecaObj(oCadEstado, aCtrlEstados);
            aConEstado.ShowDialog();
        }
        public void PecaCidade(Cidades aCidade, Ctrl_Cidades aCtrlCidades)
        {
            aConCidade.ConhecaObj(oCadCidade, aCtrlCidades);
            aConCidade.ShowDialog();
        }
        public void PecaCliente(DadosCadastro oCliente, Ctrl_Clientes aCtrlCliente)
        {
            aConCliente.ConhecaObj(oCliente, aCtrlCliente);
            aConCliente.ShowDialog();
        }
        public void PecaFuncionario(DadosCadastro oFuncionario, Ctrl_Funcionarios aCtrlFuncionario)
        {
            aConFuncionario.ConhecaObj(oFuncionario, aCtrlFuncionario);
            aConFuncionario.ShowDialog();
        }
        public void PecaFornecedor(DadosCadastro oFornecedor, Ctrl_Fornecedores aCtrlFornecedor)
        {
            aConFornecedor.ConhecaObj(oCadFornecedor, aCtrlFornecedor);
            aConFornecedor.ShowDialog();
        }
        public void PecaFormaPag(FormaPagamento aFormaPag, Ctrl_FormaPagamento aCtrlFormaPag)
        {
            aConFormaPag.ConhecaObj(oCadFormaPag, aCtrlFormaPag);
            aConFormaPag.ShowDialog();
        }
        public void PecaCondPag(CondicaoPagamento aCondPag, Ctrl_CondPagamento aCtrlCondPagamento)
        {
            aConCondicaoPag.ConhecaObj(aCondPag, aCtrlCondPagamento);
            aConCondicaoPag.ShowDialog();
        }
        public void PecaContasPagar(ContasPagar aContaPagar)
        {
            aConContasPagar.ConhecaObj(aContaPagar);
            aConContasPagar.ShowDialog();
        }
        public void PecaContasReceber(ContasReceber aContaReceber)
        {
            aConContasReceber.ConhecaObj(aContaReceber);
            aConContasReceber.ShowDialog();
        }
        public void PecaCategoria(Categoria aCategoria)
        {
            aConCategoria.ConhecaObj(aCategoria); 
            aConCategoria.ShowDialog();
        }
        public void PecaMarca(Marca aMarca) 
        { 
            aConMarca.ConhecaObj(aMarca);
            aConMarca.ShowDialog();
        }
        public void PecaProduto(Produtos oProduto)
        {
            aConProduto.ConhecaObj(oProduto);
            aConProduto.ShowDialog();
        }
        public void PecaCompras(Compras aCompras)
        {
            aConCompra.ConhecaObj(aCompras); 
            aConCompra.ShowDialog();
        }
        public void PecaVendas(Vendas aVenda)
        {
            aConVendas.ConhecaObj(aVenda);
            aConVendas.ShowDialog();
        }
    }
}
