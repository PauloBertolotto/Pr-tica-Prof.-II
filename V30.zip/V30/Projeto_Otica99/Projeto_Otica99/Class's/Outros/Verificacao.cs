﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.Outros
{
    internal class Verificacao
    {
        public void HandleException(string message, Exception ex)
        {
            Console.WriteLine($"{message}: {ex.Message}");

            // Exibir uma mensagem de erro para o usuário (você pode usar um MessageBox ou uma caixa de diálogo)
            MessageBox.Show($"Ocorreu um erro: {message}\nDetalhes do erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }    

        public bool IsTelefone(string telefone)
        {
            // Utilizamos uma expressão regular que aceita os formatos mencionados
            Regex Rgx = new Regex(@"^(?:(?:\+|00)\d{2}|0)?\d{2,5}\d{4,8}$");

            bool ok = Rgx.IsMatch(telefone);
            if (ok == true)
            {
                return ok;
            }
            else
            {
                //MessageBox.Show("Telefone Inválido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ok;
            }
        }
        public bool IsEmail(string strEmail)
        {
            string strModelo = "^([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (System.Text.RegularExpressions.Regex.IsMatch(strEmail, strModelo))
            {
                return true;
            }
            else
            {
                MessageBox.Show("Email Inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }
        }
        public bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;
            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;
            tempCnpj = cnpj.Substring(0, 12);
            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            bool ok = cnpj.EndsWith(digito);
            if (ok == true)
            {
                return ok;
            }
            //else
            //{
            //    MessageBox.Show("CNPJ Inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //
            //    return ok;
            //}
            return ok;
        }
        public static string FormatarCep(string cep)
        {
            if (cep.Length == 8)
            {
                return string.Format("{0:00000-000}", long.Parse(cep));
            }
            return cep;
        }
        public bool IsCpf(string cpf)
        {
            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            string tempCpf;
            string digito;
            int soma;
            int resto;
            cpf = cpf.Trim();
            cpf = cpf.Replace(".", "").Replace("-", "");
            if (cpf.Length != 11)
                return false;
            tempCpf = cpf.Substring(0, 9);
            soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];
            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCpf = tempCpf + digito;
            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];
            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cpf.EndsWith(digito);
        }

        public bool IsCep(string cep)
        {
            string pattern = @"^\d{5}-\d{3}$";
            
            bool ok = Regex.IsMatch(cep, pattern);
            if (ok == true)
            {
                return ok;
            }
            else
            {
                MessageBox.Show("CEP Inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ok;
            }
        }

        public bool IsForeignKeyViolation(SqlException ex)
        {
            foreach (SqlError error in ex.Errors)
            {
                if (error.Number == 547)
                {
                    // Número de erro 547 é comum para violações de chave estrangeira no SQL Server
                    return true;
                }
            }
            return false;
        }

        public static void DisableCopyPaste(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is TextBox textBox)
                {
                    textBox.KeyDown += BloquearKeyDowControlC;
                    textBox.ContextMenu = new ContextMenu(); // Remove o menu de contexto padrão
                }

                // Verifica recursivamente em todos os controles filhos
                if (control.HasChildren)
                {
                    DisableCopyPaste(control);
                }
            }
        }
        public static void BloquearKeyDowControlC(object sender, KeyEventArgs e)
        {
            // Desabilita Ctrl+C, Ctrl+X e Ctrl+V
            if (e.Control && (e.KeyCode == Keys.C || e.KeyCode == Keys.X || e.KeyCode == Keys.V))
            {
                e.SuppressKeyPress = true;
            }
        }

        public static string FormatarDocumento(string documento)
        {
            // Remova todos os caracteres não numéricos
            string documentoLimpo = new string(documento.Where(char.IsDigit).ToArray());


            if (documentoLimpo.Length == 11) // CPF
            {
                return string.Format("{0:000\\.000\\.000\\-00}", long.Parse(documentoLimpo));
            }
            else if (documentoLimpo.Length == 14) // CNPJ
            {
                return string.Format("{0:00\\.000\\.000\\/0000\\-00}", long.Parse(documentoLimpo));
            }
            return documento; // Retorna o documento original se não for CPF nem CNPJ
        }

        public static string FormatarTelefone(string telefone)
        {
            // Remove espaços em branco e traços
            telefone = telefone.Replace(" ", "").Replace("-", "");

            try
            {
                if (telefone.Length == 11)
                {
                    return string.Format("({0}) {1}-{2}",
                        telefone.Substring(0, 2),
                        telefone.Substring(2, 5),
                        telefone.Substring(7, 4));
                }
                else if (telefone.Length == 10)
                {
                    return string.Format("({0}) {1}-{2}",
                        telefone.Substring(0, 2),
                        telefone.Substring(2, 4),
                        telefone.Substring(6, 4));
                }
                else if (telefone.Length == 9)
                {
                    return string.Format("{0}-{1}",
                        telefone.Substring(0, 5),
                        telefone.Substring(5, 4));
                }
                else if (telefone.Length == 8)
                {
                    return string.Format("{0}-{1}",
                        telefone.Substring(0, 4),
                        telefone.Substring(4, 4));
                }
            }
            catch (FormatException)
            {
                return "Formato inválido";
            }
            catch (Exception ex)
            {
                return "Erro ao formatar: " + ex.Message;
            }

            return telefone;
        }
        public static void ValidarNomes(object sender, KeyPressEventArgs e) // Validar nomes
        {
            TextBox textBox = (TextBox)sender;

            // Bloqueia qualquer modificação com Ctrl
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
            // Verificar se o caractere é uma letra, controle (como Backspace) ou espaço único
            if (char.IsLetter(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == ' ')
            {
                // Impedir mais de um espaço consecutivo
                if (e.KeyChar == ' ' && (textBox.Text.Length == 0 || textBox.Text.EndsWith(" ")))
                {
                    e.Handled = true;
                }
                // Impedir que o primeiro caractere seja um espaço
                else if (e.KeyChar == ' ' && textBox.Text.Length == 0)
                {
                    e.Handled = true;
                }
            }
            else
            {
                // Bloquear todos os outros caracteres (caracteres especiais, dígitos, etc.)
                e.Handled = true;
            }
        }
        public static void ValidarValorKeyPress(TextBox textBox, KeyPressEventArgs e) // validar numeros inteiros.
        {
            // Bloqueia qualquer modificação com Ctrl
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }

            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != Convert.ToChar(Keys.Back);
        }
        public static void ValidarValorKeyPressComVirgula(TextBox textBox, KeyPressEventArgs e)
        {
            // Bloqueia qualquer modificação com Ctrl
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
                return;
            }

            // Permite dígitos, Backspace e vírgula
            if (char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back))
            {
                e.Handled = false;
            }
            // Permite vírgula apenas se ainda não houver uma vírgula no texto
            else if (e.KeyChar == ',' && !textBox.Text.Contains(","))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
    
}
