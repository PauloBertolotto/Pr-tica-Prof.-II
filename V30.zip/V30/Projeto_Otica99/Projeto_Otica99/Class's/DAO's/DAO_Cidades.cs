﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Cidades : DAO
    {
        DB oDB;
        Verificacao verificacao;
        public DAO_Cidades()
        {
            oDB = new DB();
            verificacao = new Verificacao();
        }
        public override string CarregaObj(object obj)
        {
            Cidades aCidade = (Cidades)obj;
            string ok = "";
        
            try
            {
                string sql = "select * from Cidade where ID_Cidade = '" + Convert.ToString(aCidade.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    aCidade.ID                  = Convert.ToInt32(dr.GetValue(0));
                    aCidade.Cidade              = dr.GetString(1);
                    aCidade.DDD                 = dr.GetString(2);
                    aCidade.EstadoID.ID         = Convert.ToInt32(dr.GetValue(3));
                    aCidade.Ativo               = dr.GetString(4);
                    aCidade.DataCriacao         = dr.GetDateTime(5);
                    aCidade.DataUltimaAlteracao = dr.GetDateTime(6);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {
        
            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            Cidades aCidade = (Cidades)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Cidade (Nome, DDD, EstadoID, Ativo, DataEntrada, DataUltimaAlteracao) " + 
                "VALUES (@Nome, @DDD, @EstadoID, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (aCidade.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Cidade SET NOME = @Nome, DDD = @DDD, ESTADOID = @EstadoID, Ativo = @Ativo, DataUltimaAlteracao = @DataUltimaAlteracao WHERE ID_Cidade = @ID";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (aCidade.ID != 0)
            {
                cnn.Parameters.AddWithValue("@Id",              aCidade.ID);
            }
            cnn.Parameters.AddWithValue("@Nome",                aCidade.Cidade);
            cnn.Parameters.AddWithValue("@DDD",                 aCidade.DDD);
            cnn.Parameters.AddWithValue("@EstadoID",            aCidade.EstadoID);
            cnn.Parameters.AddWithValue("@Ativo",               aCidade.Ativo);
            cnn.Parameters.AddWithValue("@DataEntrada",         aCidade.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", aCidade.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();
            cnn.Connection.Close();
            return ok;
        }

        public override string Excluir(string item)
        {
            string ok = "";
        
            try
            {
                string sql = "UPDATE Cidade SET Ativo = 'I' WHERE ID_Cidade = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {
        
            }
            return ok;
        }

        public List<Cidades> PesquisarCidadesPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Cidades> cidadesEncontradas = new List<Cidades>();

            try
            {
                string query = string.Empty;
                List<SqlParameter> parametros = new List<SqlParameter>();

                // Construir a consulta com base no critério de pesquisa
                string condicao = string.Empty;
                if (criterio == "ID")
                {
                    condicao = "ID_Cidade LIKE @ValorPesquisa";
                }
                else if (criterio == "DDD")
                {
                    condicao = "DDD LIKE @ValorPesquisa";
                }
                else if (criterio == "ESTADO")
                {
                    condicao = "e.nome LIKE @ValorPesquisa";
                    query = "SELECT c.* FROM Cidade c JOIN Estado e ON c.ID_Estado = e.EstadoID";
                }
                else if (criterio == "PAIS")
                {
                    condicao = "p.nome LIKE @ValorPesquisa";
                    query = "SELECT c.* FROM Cidade c JOIN Estado e ON c.ID_Estado = e.EstadoID JOIN Pais p ON e.ID_Pais = p.ID_Pais";
                }
                else if (criterio == "CIDADE")
                {
                    condicao = "nome LIKE @ValorPesquisa";
                }

                // Adicionar filtro de status à condição
                condicao += " AND Ativo = @Status";
                parametros.Add(new SqlParameter("@Status", status));

                if (!string.IsNullOrEmpty(condicao))
                {
                    if (!string.IsNullOrEmpty(query))
                    {
                        query += " WHERE " + condicao;
                    }
                    else
                    {
                        query = "SELECT * FROM Cidade WHERE " + condicao;
                    }
                    parametros.Add(new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%"));
                }

                // Executar a consulta e preencher a lista de cidades encontradas
                DataTable dataTable = oDB.ExecutarConsulta(query, parametros.ToArray());

                foreach (DataRow row in dataTable.Rows)
                {
                    Cidades cidade = CreateCidadeFromDataRow(row);
                    cidadesEncontradas.Add(cidade);
                }
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar cidades", ex);
                return null;
            }

            return cidadesEncontradas;
        }


        public List<Cidades> ListarCidades(string status)
        {
            try
            {
                string sql = "SELECT * FROM Cidade";
                List<SqlParameter> parametros = new List<SqlParameter>();

                // Verifica se o parâmetro de status foi fornecido e adiciona a cláusula WHERE, se necessário
                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE Ativo = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateCidadesListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao listar cidades", ex);
                return new List<Cidades>();
            }
        }
        private List<Cidades> CreateCidadesListFromDataTable(DataTable dataTable)
        {
            List<Cidades> cidades = new List<Cidades>();
            foreach (DataRow row in dataTable.Rows)
            {
                cidades.Add(CreateCidadeFromDataRow(row));
            }
            return cidades;
        }
        public string BuscarEstadoPorId(int id)
        {
        
            string ok = "";
            try
            {
                string sql = "select Nome from Estado where ID_Estado = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {
        
            }
            return ok;
        }
        public string BuscarUFPorId(int id)
        {

            string ok = "";
            try
            {
                string sql = "select UF from Estado where ID_Estado = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public int BuscarIDEstado(string nome)
        {
            int IDPais = 0;
            try
            {
                string sql = "select ID_Estado from Estado where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDPais = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {
        
            }
            if (IDPais == 0)
            {
                MessageBox.Show("Estado não encontrado!");
            }
            return IDPais;
        }
        public Cidades BuscarCidadePorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Cidade WHERE ID_Cidade = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateCidadeFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar cidade por ID", ex);
                return null;
            }
        }
        private Cidades CreateCidadeFromDataRow(DataRow row)
        {
            Ctrl_Estados aCTRLEstados = new Ctrl_Estados();
            Estados estado = aCTRLEstados.BuscarEstadoPorId(Convert.ToInt32(row["EstadoID"]));

            return new Cidades
            {
                ID = Convert.ToInt32(row["ID_Cidade"]),
                Cidade = row["nome"].ToString(),
                DDD = row["DDD"].ToString(),
                EstadoID = estado,
                DataCriacao = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["DataUltimaAlteracao"]),
                Ativo = row["Ativo"].ToString()
            };
        }

    }
}
