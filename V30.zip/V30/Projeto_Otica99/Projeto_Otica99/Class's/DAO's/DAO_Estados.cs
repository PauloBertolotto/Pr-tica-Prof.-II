﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Estados : DAO
    {
        DB          oDB;
        Verificacao verificacao;
        Ctrl_Paises aCTRLPaises;
        public DAO_Estados() 
        { 
            oDB  = new DB();
            verificacao = new Verificacao();
            aCTRLPaises = new Ctrl_Paises();
        }
        //public override string CarregaObj(object obj)
        //{
        //    Estados oEstado = (Estados)obj;
        //    string ok = "";
        //
        //    try
        //    {
        //        string sql = "select * from Estado where ID_Estado = '" + Convert.ToString(oEstado.ID) + "'";
        //        SqlCommand cnn = new SqlCommand();
        //        cnn.Connection = DB.Abrir();
        //        cnn.CommandType = System.Data.CommandType.Text;
        //        cnn.CommandText = sql;
        //        cnn.ExecuteNonQuery();
        //        var dr = cnn.ExecuteReader();
        //        while (dr.Read())
        //        {
        //            oEstado.ID                  = Convert.ToInt32(dr.GetValue(0));
        //            oEstado.Estado              = dr.GetString(1);
        //            oEstado.UF                  = dr.GetString(2);
        //            oEstado.PaisID.ID           = Convert.ToInt32(dr.GetValue(3));
        //            oEstado.Ativo               = dr.GetString(4);
        //            oEstado.DataCriacao         = dr.GetDateTime(5);
        //            oEstado.DataUltimaAlteracao = dr.GetDateTime(6);
        //        }
        //        cnn.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        ok = "Erro";
        //    }
        //    finally
        //    {
        //
        //    }
        //    return ok;
        //}
        public override string Salvar(object obj)
        {
            Estados oEstado = (Estados)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Estado (Nome, UF, PaisID, Ativo, DataEntrada, DataUltimaAlteracao) " +
             "VALUES (@Nome, @UF, @PaisID, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oEstado.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Estado SET NOME = @Nome, UF = @UF, PAISID = @PaisID, Ativo = @Ativo, DataUltimaAlteracao = @DataUltimaAlteracao WHERE ID_Estado = @ID";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oEstado.ID != 0)
            {
                cnn.Parameters.AddWithValue("@Id",              oEstado.ID);
            }
            cnn.Parameters.AddWithValue("@Nome",                oEstado.Estado);
            cnn.Parameters.AddWithValue("@UF",                  oEstado.UF);
            cnn.Parameters.AddWithValue("@PaisID",              oEstado.PaisID);
            cnn.Parameters.AddWithValue("@Ativo",               oEstado.Ativo);
            cnn.Parameters.AddWithValue("@DataEntrada",         oEstado.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", oEstado.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();
            cnn.Connection.Close();
            return ok;
        }
        public override string Excluir(string item)
        {
            string ok = "";

            try
            {
                string sql = "UPDATE Estado SET Ativo = 'I' WHERE ID_Estado = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }

        public List<Estados> PesquisarEstadosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Estados> estadosEncontrados = new List<Estados>();

            try
            {
                string query = string.Empty;
                SqlParameter parametro = new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%");

                // Verificando o critério de pesquisa
                if (criterio == "ID")
                {
                    query = "SELECT * FROM Estado WHERE ID_Estado LIKE @ValorPesquisa";
                }
                else if (criterio == "UF")
                {
                    query = "SELECT * FROM Estado WHERE uf LIKE @ValorPesquisa";
                }
                else if (criterio == "PAIS")
                {
                    query = "SELECT e.* FROM Estado e JOIN Pais p ON e.ID_Pais = p.PaisID WHERE p.nome LIKE @ValorPesquisa";
                }
                else if (criterio == "ESTADO")
                {
                    query = "SELECT * FROM Estado WHERE nome LIKE @ValorPesquisa";
                }

                // Adicionar filtro de status, se fornecido
                if (!string.IsNullOrEmpty(status))
                {
                    if (!string.IsNullOrEmpty(query))
                    {
                        query += " AND Ativo = @Status";
                    }
                    else
                    {
                        query = "SELECT * FROM Estado WHERE Ativo = @Status";
                    }
                }

                // Executar a consulta e preencher a lista de estados encontrados
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro, new SqlParameter("@Status", status) });

                foreach (DataRow row in dataTable.Rows)
                {
                    Estados estado = CreateEstadoFromDataRow(row);
                    estadosEncontrados.Add(estado);
                }
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar estados", ex);
                return null;
            }

            return estadosEncontrados;
        }


        public List<Estados> ListarEstados(string status)
        {
            try
            {
                string sql = "SELECT * FROM Estado";
                List<SqlParameter> parametros = new List<SqlParameter>();

                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE Ativo = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateEstadosListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao listar estados", ex);
                return new List<Estados>();
            }
        }
        private List<Estados> CreateEstadosListFromDataTable(DataTable dataTable)
        {
            List<Estados> estados = new List<Estados>();
            foreach (DataRow row in dataTable.Rows)
            {
                estados.Add(CreateEstadoFromDataRow(row));
            }
            return estados;
        }
        public string BuscarPaisPorId(int id)
        {
            
            string ok = "";
            try
            {
                string sql = "select Nome from Pais where ID_Pais = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {                  
                    ok = dr.GetString(0);                 
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public int BuscarIDPais(string nome)
        {
            int IDPais = 0;
            try
            {
                string sql = "select ID_Pais from Pais where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDPais = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {

            }
            if (IDPais == 0)
            {
                MessageBox.Show("País não encontrado!");
            }
            return IDPais;
        }
        public Estados BuscarEstadoPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Estado WHERE ID_Estado = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateEstadoFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar estado por ID", ex);
                return null;
            }
        }
        private Estados CreateEstadoFromDataRow(DataRow row)
        {
            Paises pais = aCTRLPaises.BuscarPaisPorId(Convert.ToInt32(row["PaisID"]));

            return new Estados
            {
                ID = Convert.ToInt32(row["ID_Estado"]),
                Estado = row["nome"].ToString(),
                UF = row["uf"].ToString(),
                PaisID = pais,
                DataCriacao = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["DataUltimaAlteracao"]),
                Ativo = row["Ativo"].ToString()
            };
        }
    }

}
