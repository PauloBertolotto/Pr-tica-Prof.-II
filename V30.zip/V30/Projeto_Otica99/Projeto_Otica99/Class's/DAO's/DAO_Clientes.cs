﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Clientes : DAO
    {
        DB oDB;
        Verificacao verificaco;
        public DAO_Clientes()
        {
            oDB = new DB();
            verificaco = new Verificacao();
        }
        public override string CarregaObj(object obj)
        {
            DadosCadastro oCliente = (DadosCadastro)obj;
            string ok = "";

            try
            {
                string sql = "select * from Cliente where ID_Cliente = '" + Convert.ToString(oCliente.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    oCliente.ID = Convert.ToInt32(dr.GetValue(0));
                    oCliente.CidadeID.ID = Convert.ToInt32(dr.GetValue(1));
                    oCliente.condicao_Pagamento.ID = Convert.ToInt32(dr.GetValue(2));
                    oCliente.NomeOuNomeFantasia = dr.GetString(3);
                    oCliente.SobrenomeOuRSocial = dr.GetString(4);
                    oCliente.Endereco = dr.GetString(5);
                    oCliente.Complemento = dr.GetString(6);
                    oCliente.Numero = dr.GetString(7);
                    oCliente.Bairro = dr.GetString(8);
                    oCliente.CEP = dr.GetString(9);
                    oCliente.Telefone = dr.GetString(10);
                    oCliente.Email = dr.GetString(11);
                    oCliente.CPFouCNPJ = dr.GetString(12);
                    oCliente.RGouIE = dr.GetString(13);
                    oCliente.Sexo = dr.GetString(14);
                    oCliente.Ativo = dr.GetString(15);

                    oCliente.DataCriacao = dr.GetDateTime(16);
                    oCliente.DataUltimaAlteracao = dr.GetDateTime(17);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            DadosCadastro oCliente = (DadosCadastro)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Cliente (CidadeID, id_condicao_pagamento, NomeOuNomeFantasia, SobrenomeOuRSocial, Endereco, Complemento, Numero, Bairro, CEP, Telefone, Email, CPFouCNPJ, RGouIE, Sexo, Ativo, DataEntrada, DataUltimaAlteracao) " +
        "VALUES (@CidadeID, @id_condicao_pagamento, @NomeOuNomeFantasia, @SobrenomeOuRSocial, @Endereco, @Complemento, @Numero, @Bairro, @CEP, @Telefone, @Email, @CPFouCNPJ, @RGouIE, @Sexo, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oCliente.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Cliente SET CidadeID = @CidadeID, NomeOuNomeFantasia = @NomeOuNomeFantasia, SobrenomeOuRSocial = @SobrenomeOuRSocial, Endereco = @Endereco, Complemento = @Complemento, Numero = @Numero, Bairro = @Bairro, CEP = @CEP, Telefone = @Telefone, Email = @Email, CPFouCNPJ = @CPFouCNPJ,RGouIE =@RGouIE ,Sexo = @Sexo ,Ativo =@Ativo ,DataUltimaAlteracao=@DataUltimaAlteracao WHERE ID_Cliente =@ID_Cliente";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oCliente.ID != 0)
            {
                cnn.Parameters.AddWithValue("@ID_Cliente", oCliente.ID);
            }
            cnn.Parameters.AddWithValue("@CidadeID", oCliente.CidadeID.ID);
            cnn.Parameters.AddWithValue("@id_condicao_pagamento", oCliente.condicao_Pagamento.ID);
            cnn.Parameters.AddWithValue("@NomeOuNomeFantasia", oCliente.NomeOuNomeFantasia);
            cnn.Parameters.AddWithValue("@SobrenomeOuRSocial", oCliente.SobrenomeOuRSocial);
            cnn.Parameters.AddWithValue("@Endereco", oCliente.Endereco);
            cnn.Parameters.AddWithValue("@Complemento", oCliente.Complemento);
            cnn.Parameters.AddWithValue("@Numero", oCliente.Numero);
            cnn.Parameters.AddWithValue("@Bairro", oCliente.Bairro);
            cnn.Parameters.AddWithValue("@CEP", oCliente.CEP);
            cnn.Parameters.AddWithValue("@Telefone", oCliente.Telefone);
            cnn.Parameters.AddWithValue("@Email", oCliente.Email);
            cnn.Parameters.AddWithValue("@CPFouCNPJ", oCliente.CPFouCNPJ);
            cnn.Parameters.AddWithValue("@RGouIE", oCliente.RGouIE);
            cnn.Parameters.AddWithValue("@Sexo", oCliente.Sexo);
            cnn.Parameters.AddWithValue("@Ativo", oCliente.Ativo);


            cnn.Parameters.AddWithValue("@DataEntrada", oCliente.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", oCliente.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();

            cnn.Connection.Close();

            return ok;
        }
        public override string Excluir(string item)
        {
            string ok = "";

            try
            {
                string sql = "UPDATE Cliente SET Ativo = 'I' WHERE ID_Cliente = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        //public List<DadosCadastro> Pesquisar(string nome)
        //{
        //    List<DadosCadastro> lista = new List<DadosCadastro>();
        //    SqlCommand cnn = new SqlCommand();
        //    cnn.Connection = DB.Abrir();
        //    cnn.CommandType = System.Data.CommandType.Text;
        //
        //    cnn.CommandText = "select * from Cliente where SobrenomeOuRSocial = '" + nome + "'";
        //    var dr = cnn.ExecuteReader();
        //    while (dr.Read())
        //    {
        //        lista.Add(new DadosCadastro(
        //        Convert.ToInt32(dr.GetValue(0)), //ID
        //        Convert.ToInt32(dr.GetValue(1)), //HistoricoID
        //        Convert.ToInt32(dr.GetValue(2)), //CidadeID
        //
        //        dr.GetString(3),                 // NomeOuNFantasia
        //        dr.GetString(4),                 // SobrenomeOURSocial
        //        dr.GetString(5),                 // Endereço
        //        dr.GetString(6),                 // Complemento
        //        dr.GetString(7),                 // Numero
        //        dr.GetString(8),                 // Bairro
        //        dr.GetString(9),                 // CEP
        //        dr.GetString(10),                // Telefone
        //        dr.GetString(11),                // Email
        //        dr.GetString(12),                // CPFouCNPJ
        //        dr.GetString(13),                // RGouIE
        //        dr.GetString(15),                // Sexo 
        //        dr.GetString(14),                // Ativo                       
        //
        //        dr.GetDateTime(16),
        //        dr.GetDateTime(17)
        //        ));
        //    }
        //    return lista;
        //}

        public List<DadosCadastro> ListarClientes(string status)
        {
            try
            {
                string sql = "SELECT * FROM Cliente";
                List<SqlParameter> parametros = new List<SqlParameter>();

                // Verifica se o parâmetro de status foi fornecido e adiciona a cláusula WHERE, se necessário
                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE Ativo = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateClientesListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificaco.HandleException("Erro ao listar clientes", ex);
                return new List<DadosCadastro>();
            }
        }

        private List<DadosCadastro> CreateClientesListFromDataTable(DataTable dataTable)
        {
            List<DadosCadastro> clientes = new List<DadosCadastro>();
            // Para cada linha no DataTable, crie um objeto Clientes e adicione à lista de clientes
            foreach (DataRow row in dataTable.Rows)
            {
                clientes.Add(CreateClienteFromDataRow(row));
            }
            return clientes;
        }
        public DadosCadastro BuscarClientePorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Cliente WHERE ID_Cliente = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateClienteFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                // Trate exceções genéricas, se aplicável
                verificaco.HandleException("Erro ao buscar cliente por ID", ex);
                return null;
            }
        }
        private DadosCadastro CreateClienteFromDataRow(DataRow row)
        {
            Ctrl_CondPagamento aCtrl_Cond = new Ctrl_CondPagamento();
            var condicao = aCtrl_Cond.BuscarCondicaoPagamentoPorId(Convert.ToInt32(row["id_condicao_pagamento"]));
            return new DadosCadastro
            {
                ID = Convert.ToInt32(row["ID_Cliente"]),
                NomeOuNomeFantasia = row["NomeOuNomeFantasia"].ToString(),
                SobrenomeOuRSocial = row["SobrenomeOuRSocial"].ToString(),
                Sexo = row["sexo"].ToString(),
                //Apelido = row["apelido"].ToString(),
                RGouIE = row["RGouIE"].ToString(),
                CPFouCNPJ = row["CPFouCNPJ"].ToString(),
                Email = row["email"].ToString(),
                Telefone = row["telefone"].ToString(),
                CEP = row["cep"].ToString(),
                Endereco = row["endereco"].ToString(),
                Numero = row["numero"].ToString(),
                Complemento = row["complemento"].ToString(),
                Bairro = row["bairro"].ToString(),
                CidadeID = new Cidades { ID = Convert.ToInt32(row["CidadeID"]) }, // Supondo que você tenha um método para buscar a cidade pelo ID
                //DataNasc = Convert.ToDateTime(row["data_nasc"]),
                DataCriacao = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["DataUltimaAlteracao"]),
                condicao_Pagamento = condicao,
            };
        }
        public int BuscarIDCidade(string nome)
        {
            int IDCidade = 0;
            try
            {
                string sql = "select ID_Cidade from Cidade where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDCidade = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {

            }
            if (IDCidade == 0)
            {
                MessageBox.Show("Cidade não encontrada!");
            }
            return IDCidade;
        }
        public string BuscarCidadePorId(int id)
        {

            string ok = "";
            try
            {
                string sql = "select Nome from Cidade where ID_Cidade = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public string BuscaUF(string cidade)
        {
            string uf = "";
            try
            {
                string sql = "SELECT e.UF FROM [dbo].[Cidade] c JOIN [dbo].[Estado] e ON c.EstadoID = e.ID_Estado WHERE c.Nome = @NomeCidade";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = DB.Abrir();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@NomeCidade", cidade);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    uf = dr.GetString(0);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                uf = "Erro";
            }
            return uf;
        }
        public DadosCadastro BuscarClientePorCPFouCNPJ2(string documento)
        {

            try
            {
                string query = "SELECT * FROM Cliente WHERE cpf = @Documento OR rg = @Documento";
                SqlParameter parametro = new SqlParameter("@Documento", documento);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateClienteFromDataRow(row);
                }

                return null; // Retorna null se não encontrar o cliente
            }
            catch (Exception ex)
            {
                // Trate exceções genéricas, se aplicável
                verificaco.HandleException("Erro ao buscar cliente por documento", ex);
                return null;
            }
        }
    }
}
