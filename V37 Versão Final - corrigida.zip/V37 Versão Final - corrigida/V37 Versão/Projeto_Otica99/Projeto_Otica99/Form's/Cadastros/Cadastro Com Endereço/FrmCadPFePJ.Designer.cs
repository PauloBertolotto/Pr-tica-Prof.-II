﻿namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço
{
    partial class FrmCadPFePJ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_NomeOuRSocial = new System.Windows.Forms.TextBox();
            this.txt_SobrenomeOuNFantasia = new System.Windows.Forms.TextBox();
            this.lbl_CNPJeCPF = new System.Windows.Forms.Label();
            this.lbl_NomeOuRSocial = new System.Windows.Forms.Label();
            this.lbl_SobrenomeOuNFantasia = new System.Windows.Forms.Label();
            this.txt_Telefone = new System.Windows.Forms.MaskedTextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.lbl_Telefone = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_RGeIE = new System.Windows.Forms.Label();
            this.mtb_CPFeCNPJ = new System.Windows.Forms.MaskedTextBox();
            this.mtb_RGeIE = new System.Windows.Forms.MaskedTextBox();
            this.CB_Sexo = new System.Windows.Forms.ComboBox();
            this.lbl_Sexo = new System.Windows.Forms.Label();
            this.lbl_TelaCadastroDe = new System.Windows.Forms.Label();
            this.lbl_Generica = new System.Windows.Forms.Label();
            this.lbl_CodPagamento = new System.Windows.Forms.Label();
            this.txt_CodCondicaoPag = new System.Windows.Forms.TextBox();
            this.txt_CondPag = new System.Windows.Forms.TextBox();
            this.lbl_CondPag = new System.Windows.Forms.Label();
            this.btn_BuscarCondPag = new System.Windows.Forms.Button();
            this.lbl_DataNasc = new System.Windows.Forms.Label();
            this.txt_DataNasc = new System.Windows.Forms.MaskedTextBox();
            this.txt_Cargo = new System.Windows.Forms.TextBox();
            this.txt_CodCargo = new System.Windows.Forms.TextBox();
            this.lbl_Cargo = new System.Windows.Forms.Label();
            this.lbl_CodCargo = new System.Windows.Forms.Label();
            this.btn_Cargo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CEP
            // 
            this.lbl_CEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CEP.Location = new System.Drawing.Point(658, 91);
            this.lbl_CEP.Size = new System.Drawing.Size(48, 24);
            // 
            // lbl_Endereco
            // 
            this.lbl_Endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Endereco.Location = new System.Drawing.Point(6, 91);
            this.lbl_Endereco.Size = new System.Drawing.Size(94, 24);
            // 
            // lbl_Bairro
            // 
            this.lbl_Bairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bairro.Location = new System.Drawing.Point(554, 91);
            this.lbl_Bairro.Size = new System.Drawing.Size(59, 24);
            // 
            // lbl_Numero
            // 
            this.lbl_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Numero.Location = new System.Drawing.Point(478, 91);
            this.lbl_Numero.Size = new System.Drawing.Size(79, 24);
            // 
            // lbl_Cidade
            // 
            this.lbl_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cidade.Location = new System.Drawing.Point(92, 147);
            this.lbl_Cidade.Size = new System.Drawing.Size(70, 24);
            // 
            // lbl_CodCidade
            // 
            this.lbl_CodCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodCidade.Location = new System.Drawing.Point(6, 147);
            this.lbl_CodCidade.Size = new System.Drawing.Size(71, 24);
            // 
            // mtb_CEP
            // 
            this.mtb_CEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_CEP.Location = new System.Drawing.Point(658, 118);
            this.mtb_CEP.Size = new System.Drawing.Size(100, 26);
            this.mtb_CEP.TabIndex = 8;
            this.mtb_CEP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // txt_Endereco
            // 
            this.txt_Endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Endereco.Location = new System.Drawing.Point(11, 118);
            this.txt_Endereco.Size = new System.Drawing.Size(255, 26);
            this.txt_Endereco.TabIndex = 4;
            this.txt_Endereco.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_Bairro
            // 
            this.txt_Bairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Bairro.Location = new System.Drawing.Point(558, 118);
            this.txt_Bairro.Size = new System.Drawing.Size(92, 26);
            this.txt_Bairro.TabIndex = 7;
            this.txt_Bairro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_Numero
            // 
            this.txt_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero.Location = new System.Drawing.Point(478, 118);
            this.txt_Numero.Size = new System.Drawing.Size(74, 26);
            this.txt_Numero.TabIndex = 6;
            // 
            // txt_Cidade
            // 
            this.txt_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cidade.Location = new System.Drawing.Point(92, 174);
            this.txt_Cidade.Size = new System.Drawing.Size(219, 26);
            // 
            // txt_CodCidade
            // 
            this.txt_CodCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCidade.Location = new System.Drawing.Point(11, 174);
            this.txt_CodCidade.Size = new System.Drawing.Size(76, 26);
            this.txt_CodCidade.TabIndex = 9;
            // 
            // btn_BuscarPorCidade
            // 
            this.btn_BuscarPorCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarPorCidade.Location = new System.Drawing.Point(317, 173);
            this.btn_BuscarPorCidade.Size = new System.Drawing.Size(84, 27);
            this.btn_BuscarPorCidade.TabIndex = 10;
            // 
            // lbl_Complemento
            // 
            this.lbl_Complemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complemento.Location = new System.Drawing.Point(272, 91);
            this.lbl_Complemento.Size = new System.Drawing.Size(129, 24);
            // 
            // txt_Complemento
            // 
            this.txt_Complemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Complemento.Location = new System.Drawing.Point(272, 118);
            this.txt_Complemento.Size = new System.Drawing.Size(200, 26);
            this.txt_Complemento.TabIndex = 5;
            this.txt_Complemento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // CB_Tipo
            // 
            this.CB_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Tipo.ItemHeight = 20;
            this.CB_Tipo.Items.AddRange(new object[] {
            "PF",
            "PJ",
            "Estrangeiro"});
            this.CB_Tipo.Location = new System.Drawing.Point(91, 62);
            this.CB_Tipo.Size = new System.Drawing.Size(114, 28);
            this.CB_Tipo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(88, 37);
            this.label1.Size = new System.Drawing.Size(36, 24);
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Salvar.Location = new System.Drawing.Point(584, 300);
            this.btn_Salvar.Size = new System.Drawing.Size(84, 27);
            this.btn_Salvar.TabIndex = 16;
            // 
            // lbl_Código
            // 
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.Location = new System.Drawing.Point(6, 37);
            this.lbl_Código.Size = new System.Drawing.Size(71, 24);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(11, 63);
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sair.Location = new System.Drawing.Point(674, 300);
            this.btn_Sair.Size = new System.Drawing.Size(84, 27);
            this.btn_Sair.TabIndex = 17;
            // 
            // txt_NomeOuRSocial
            // 
            this.txt_NomeOuRSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NomeOuRSocial.Location = new System.Drawing.Point(210, 63);
            this.txt_NomeOuRSocial.MaxLength = 30;
            this.txt_NomeOuRSocial.Name = "txt_NomeOuRSocial";
            this.txt_NomeOuRSocial.Size = new System.Drawing.Size(243, 26);
            this.txt_NomeOuRSocial.TabIndex = 2;
            this.txt_NomeOuRSocial.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_SobrenomeOuNFantasia
            // 
            this.txt_SobrenomeOuNFantasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SobrenomeOuNFantasia.Location = new System.Drawing.Point(459, 63);
            this.txt_SobrenomeOuNFantasia.MaxLength = 50;
            this.txt_SobrenomeOuNFantasia.Name = "txt_SobrenomeOuNFantasia";
            this.txt_SobrenomeOuNFantasia.Size = new System.Drawing.Size(299, 26);
            this.txt_SobrenomeOuNFantasia.TabIndex = 3;
            this.txt_SobrenomeOuNFantasia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // lbl_CNPJeCPF
            // 
            this.lbl_CNPJeCPF.AutoSize = true;
            this.lbl_CNPJeCPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CNPJeCPF.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CNPJeCPF.Location = new System.Drawing.Point(7, 204);
            this.lbl_CNPJeCPF.Name = "lbl_CNPJeCPF";
            this.lbl_CNPJeCPF.Size = new System.Drawing.Size(47, 24);
            this.lbl_CNPJeCPF.TabIndex = 31;
            this.lbl_CNPJeCPF.Text = "CPF";
            // 
            // lbl_NomeOuRSocial
            // 
            this.lbl_NomeOuRSocial.AutoSize = true;
            this.lbl_NomeOuRSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NomeOuRSocial.ForeColor = System.Drawing.Color.Gold;
            this.lbl_NomeOuRSocial.Location = new System.Drawing.Point(207, 37);
            this.lbl_NomeOuRSocial.Name = "lbl_NomeOuRSocial";
            this.lbl_NomeOuRSocial.Size = new System.Drawing.Size(62, 24);
            this.lbl_NomeOuRSocial.TabIndex = 22;
            this.lbl_NomeOuRSocial.Text = "Nome";
            // 
            // lbl_SobrenomeOuNFantasia
            // 
            this.lbl_SobrenomeOuNFantasia.AutoSize = true;
            this.lbl_SobrenomeOuNFantasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SobrenomeOuNFantasia.ForeColor = System.Drawing.Color.Gold;
            this.lbl_SobrenomeOuNFantasia.Location = new System.Drawing.Point(456, 37);
            this.lbl_SobrenomeOuNFantasia.Name = "lbl_SobrenomeOuNFantasia";
            this.lbl_SobrenomeOuNFantasia.Size = new System.Drawing.Size(110, 24);
            this.lbl_SobrenomeOuNFantasia.TabIndex = 24;
            this.lbl_SobrenomeOuNFantasia.Text = "Sobrenome";
            // 
            // txt_Telefone
            // 
            this.txt_Telefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Telefone.Location = new System.Drawing.Point(408, 174);
            this.txt_Telefone.Mask = "00000-0000";
            this.txt_Telefone.Name = "txt_Telefone";
            this.txt_Telefone.Size = new System.Drawing.Size(110, 26);
            this.txt_Telefone.TabIndex = 11;
            // 
            // txt_Email
            // 
            this.txt_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Email.Location = new System.Drawing.Point(524, 174);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(234, 26);
            this.txt_Email.TabIndex = 12;
            // 
            // lbl_Telefone
            // 
            this.lbl_Telefone.AutoSize = true;
            this.lbl_Telefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Telefone.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Telefone.Location = new System.Drawing.Point(410, 147);
            this.lbl_Telefone.Name = "lbl_Telefone";
            this.lbl_Telefone.Size = new System.Drawing.Size(85, 24);
            this.lbl_Telefone.TabIndex = 29;
            this.lbl_Telefone.Text = "Telefone";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Email.Location = new System.Drawing.Point(526, 147);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(63, 24);
            this.lbl_Email.TabIndex = 28;
            this.lbl_Email.Text = "E-mail";
            // 
            // lbl_RGeIE
            // 
            this.lbl_RGeIE.AutoSize = true;
            this.lbl_RGeIE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RGeIE.ForeColor = System.Drawing.Color.Gold;
            this.lbl_RGeIE.Location = new System.Drawing.Point(141, 204);
            this.lbl_RGeIE.Name = "lbl_RGeIE";
            this.lbl_RGeIE.Size = new System.Drawing.Size(37, 24);
            this.lbl_RGeIE.TabIndex = 30;
            this.lbl_RGeIE.Text = "RG";
            // 
            // mtb_CPFeCNPJ
            // 
            this.mtb_CPFeCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_CPFeCNPJ.Location = new System.Drawing.Point(11, 231);
            this.mtb_CPFeCNPJ.Name = "mtb_CPFeCNPJ";
            this.mtb_CPFeCNPJ.Size = new System.Drawing.Size(126, 26);
            this.mtb_CPFeCNPJ.TabIndex = 13;
            this.mtb_CPFeCNPJ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            this.mtb_CPFeCNPJ.Leave += new System.EventHandler(this.mtb_CPFeCNPJ_Leave);
            // 
            // mtb_RGeIE
            // 
            this.mtb_RGeIE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_RGeIE.Location = new System.Drawing.Point(143, 231);
            this.mtb_RGeIE.Name = "mtb_RGeIE";
            this.mtb_RGeIE.Size = new System.Drawing.Size(123, 26);
            this.mtb_RGeIE.TabIndex = 14;
            this.mtb_RGeIE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // CB_Sexo
            // 
            this.CB_Sexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Sexo.FormattingEnabled = true;
            this.CB_Sexo.Items.AddRange(new object[] {
            "M",
            "F",
            "O"});
            this.CB_Sexo.Location = new System.Drawing.Point(272, 229);
            this.CB_Sexo.Name = "CB_Sexo";
            this.CB_Sexo.Size = new System.Drawing.Size(78, 28);
            this.CB_Sexo.TabIndex = 15;
            // 
            // lbl_Sexo
            // 
            this.lbl_Sexo.AutoSize = true;
            this.lbl_Sexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sexo.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Sexo.Location = new System.Drawing.Point(270, 203);
            this.lbl_Sexo.Name = "lbl_Sexo";
            this.lbl_Sexo.Size = new System.Drawing.Size(54, 24);
            this.lbl_Sexo.TabIndex = 36;
            this.lbl_Sexo.Text = "Sexo";
            // 
            // lbl_TelaCadastroDe
            // 
            this.lbl_TelaCadastroDe.AutoSize = true;
            this.lbl_TelaCadastroDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TelaCadastroDe.ForeColor = System.Drawing.Color.Gold;
            this.lbl_TelaCadastroDe.Location = new System.Drawing.Point(7, 5);
            this.lbl_TelaCadastroDe.Name = "lbl_TelaCadastroDe";
            this.lbl_TelaCadastroDe.Size = new System.Drawing.Size(111, 24);
            this.lbl_TelaCadastroDe.TabIndex = 37;
            this.lbl_TelaCadastroDe.Text = "Cadastro de";
            // 
            // lbl_Generica
            // 
            this.lbl_Generica.AutoSize = true;
            this.lbl_Generica.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Generica.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Generica.Location = new System.Drawing.Point(119, 5);
            this.lbl_Generica.Name = "lbl_Generica";
            this.lbl_Generica.Size = new System.Drawing.Size(88, 24);
            this.lbl_Generica.TabIndex = 38;
            this.lbl_Generica.Text = "Genérico";
            // 
            // lbl_CodPagamento
            // 
            this.lbl_CodPagamento.AutoSize = true;
            this.lbl_CodPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodPagamento.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodPagamento.Location = new System.Drawing.Point(359, 204);
            this.lbl_CodPagamento.Name = "lbl_CodPagamento";
            this.lbl_CodPagamento.Size = new System.Drawing.Size(71, 24);
            this.lbl_CodPagamento.TabIndex = 40;
            this.lbl_CodPagamento.Text = "Código";
            // 
            // txt_CodCondicaoPag
            // 
            this.txt_CodCondicaoPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCondicaoPag.Location = new System.Drawing.Point(356, 231);
            this.txt_CodCondicaoPag.Name = "txt_CodCondicaoPag";
            this.txt_CodCondicaoPag.Size = new System.Drawing.Size(82, 26);
            this.txt_CodCondicaoPag.TabIndex = 41;
            this.txt_CodCondicaoPag.Text = "0";
            this.txt_CodCondicaoPag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodCondicaoPag.Leave += new System.EventHandler(this.txt_CodCondicaoPag_Leave);
            // 
            // txt_CondPag
            // 
            this.txt_CondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CondPag.Location = new System.Drawing.Point(445, 231);
            this.txt_CondPag.Name = "txt_CondPag";
            this.txt_CondPag.Size = new System.Drawing.Size(313, 26);
            this.txt_CondPag.TabIndex = 42;
            // 
            // lbl_CondPag
            // 
            this.lbl_CondPag.AutoSize = true;
            this.lbl_CondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CondPag.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CondPag.Location = new System.Drawing.Point(441, 204);
            this.lbl_CondPag.Name = "lbl_CondPag";
            this.lbl_CondPag.Size = new System.Drawing.Size(219, 24);
            this.lbl_CondPag.TabIndex = 43;
            this.lbl_CondPag.Text = "Condição de Pagamento";
            // 
            // btn_BuscarCondPag
            // 
            this.btn_BuscarCondPag.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarCondPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarCondPag.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarCondPag.Location = new System.Drawing.Point(674, 263);
            this.btn_BuscarCondPag.Name = "btn_BuscarCondPag";
            this.btn_BuscarCondPag.Size = new System.Drawing.Size(84, 27);
            this.btn_BuscarCondPag.TabIndex = 44;
            this.btn_BuscarCondPag.Text = "Buscar";
            this.btn_BuscarCondPag.UseVisualStyleBackColor = false;
            this.btn_BuscarCondPag.Click += new System.EventHandler(this.btn_BuscarCondPag_Click);
            // 
            // lbl_DataNasc
            // 
            this.lbl_DataNasc.AutoSize = true;
            this.lbl_DataNasc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DataNasc.ForeColor = System.Drawing.Color.Gold;
            this.lbl_DataNasc.Location = new System.Drawing.Point(6, 263);
            this.lbl_DataNasc.Name = "lbl_DataNasc";
            this.lbl_DataNasc.Size = new System.Drawing.Size(179, 24);
            this.lbl_DataNasc.TabIndex = 45;
            this.lbl_DataNasc.Text = "Data de Nascimento";
            this.lbl_DataNasc.Visible = false;
            // 
            // txt_DataNasc
            // 
            this.txt_DataNasc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DataNasc.Location = new System.Drawing.Point(11, 290);
            this.txt_DataNasc.Name = "txt_DataNasc";
            this.txt_DataNasc.Size = new System.Drawing.Size(174, 26);
            this.txt_DataNasc.TabIndex = 47;
            this.txt_DataNasc.Visible = false;
            this.txt_DataNasc.Leave += new System.EventHandler(this.txt_DataNasc_Leave);
            // 
            // txt_Cargo
            // 
            this.txt_Cargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cargo.Location = new System.Drawing.Point(280, 290);
            this.txt_Cargo.Name = "txt_Cargo";
            this.txt_Cargo.Size = new System.Drawing.Size(158, 26);
            this.txt_Cargo.TabIndex = 49;
            this.txt_Cargo.Visible = false;
            // 
            // txt_CodCargo
            // 
            this.txt_CodCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCargo.Location = new System.Drawing.Point(191, 290);
            this.txt_CodCargo.Name = "txt_CodCargo";
            this.txt_CodCargo.Size = new System.Drawing.Size(82, 26);
            this.txt_CodCargo.TabIndex = 48;
            this.txt_CodCargo.Text = "0";
            this.txt_CodCargo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodCargo.Visible = false;
            // 
            // lbl_Cargo
            // 
            this.lbl_Cargo.AutoSize = true;
            this.lbl_Cargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cargo.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Cargo.Location = new System.Drawing.Point(272, 263);
            this.lbl_Cargo.Name = "lbl_Cargo";
            this.lbl_Cargo.Size = new System.Drawing.Size(61, 24);
            this.lbl_Cargo.TabIndex = 51;
            this.lbl_Cargo.Text = "Cargo";
            this.lbl_Cargo.Visible = false;
            // 
            // lbl_CodCargo
            // 
            this.lbl_CodCargo.AutoSize = true;
            this.lbl_CodCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodCargo.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodCargo.Location = new System.Drawing.Point(187, 263);
            this.lbl_CodCargo.Name = "lbl_CodCargo";
            this.lbl_CodCargo.Size = new System.Drawing.Size(71, 24);
            this.lbl_CodCargo.TabIndex = 50;
            this.lbl_CodCargo.Text = "Código";
            this.lbl_CodCargo.Visible = false;
            // 
            // btn_Cargo
            // 
            this.btn_Cargo.BackColor = System.Drawing.Color.Gold;
            this.btn_Cargo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Cargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cargo.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Cargo.Location = new System.Drawing.Point(444, 289);
            this.btn_Cargo.Name = "btn_Cargo";
            this.btn_Cargo.Size = new System.Drawing.Size(84, 27);
            this.btn_Cargo.TabIndex = 52;
            this.btn_Cargo.Text = "Buscar";
            this.btn_Cargo.UseVisualStyleBackColor = false;
            this.btn_Cargo.Visible = false;
            this.btn_Cargo.Click += new System.EventHandler(this.btn_Cargo_Click);
            // 
            // FrmCadPFePJ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(769, 338);
            this.Controls.Add(this.btn_Cargo);
            this.Controls.Add(this.lbl_Cargo);
            this.Controls.Add(this.lbl_CodCargo);
            this.Controls.Add(this.txt_Cargo);
            this.Controls.Add(this.txt_CodCargo);
            this.Controls.Add(this.txt_DataNasc);
            this.Controls.Add(this.lbl_DataNasc);
            this.Controls.Add(this.btn_BuscarCondPag);
            this.Controls.Add(this.txt_CondPag);
            this.Controls.Add(this.lbl_CondPag);
            this.Controls.Add(this.txt_CodCondicaoPag);
            this.Controls.Add(this.lbl_CodPagamento);
            this.Controls.Add(this.lbl_Generica);
            this.Controls.Add(this.lbl_TelaCadastroDe);
            this.Controls.Add(this.lbl_Sexo);
            this.Controls.Add(this.CB_Sexo);
            this.Controls.Add(this.mtb_RGeIE);
            this.Controls.Add(this.mtb_CPFeCNPJ);
            this.Controls.Add(this.lbl_CNPJeCPF);
            this.Controls.Add(this.lbl_RGeIE);
            this.Controls.Add(this.txt_Telefone);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.lbl_Telefone);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.txt_SobrenomeOuNFantasia);
            this.Controls.Add(this.lbl_SobrenomeOuNFantasia);
            this.Controls.Add(this.txt_NomeOuRSocial);
            this.Controls.Add(this.lbl_NomeOuRSocial);
            this.Name = "FrmCadPFePJ";
            this.Text = "Cadastro de Pessoa Física e jurídica";
            this.Load += new System.EventHandler(this.FrmCadPFePJ_Load);
            this.Controls.SetChildIndex(this.lbl_NomeOuRSocial, 0);
            this.Controls.SetChildIndex(this.txt_NomeOuRSocial, 0);
            this.Controls.SetChildIndex(this.lbl_SobrenomeOuNFantasia, 0);
            this.Controls.SetChildIndex(this.txt_SobrenomeOuNFantasia, 0);
            this.Controls.SetChildIndex(this.lbl_Email, 0);
            this.Controls.SetChildIndex(this.lbl_Telefone, 0);
            this.Controls.SetChildIndex(this.txt_Email, 0);
            this.Controls.SetChildIndex(this.txt_Telefone, 0);
            this.Controls.SetChildIndex(this.lbl_RGeIE, 0);
            this.Controls.SetChildIndex(this.lbl_CNPJeCPF, 0);
            this.Controls.SetChildIndex(this.mtb_CPFeCNPJ, 0);
            this.Controls.SetChildIndex(this.mtb_RGeIE, 0);
            this.Controls.SetChildIndex(this.CB_Sexo, 0);
            this.Controls.SetChildIndex(this.lbl_Sexo, 0);
            this.Controls.SetChildIndex(this.lbl_TelaCadastroDe, 0);
            this.Controls.SetChildIndex(this.lbl_Generica, 0);
            this.Controls.SetChildIndex(this.lbl_CodPagamento, 0);
            this.Controls.SetChildIndex(this.txt_CodCondicaoPag, 0);
            this.Controls.SetChildIndex(this.lbl_CondPag, 0);
            this.Controls.SetChildIndex(this.txt_CondPag, 0);
            this.Controls.SetChildIndex(this.btn_BuscarCondPag, 0);
            this.Controls.SetChildIndex(this.lbl_DataNasc, 0);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_CEP, 0);
            this.Controls.SetChildIndex(this.lbl_Endereco, 0);
            this.Controls.SetChildIndex(this.lbl_Bairro, 0);
            this.Controls.SetChildIndex(this.lbl_Numero, 0);
            this.Controls.SetChildIndex(this.lbl_Cidade, 0);
            this.Controls.SetChildIndex(this.lbl_CodCidade, 0);
            this.Controls.SetChildIndex(this.mtb_CEP, 0);
            this.Controls.SetChildIndex(this.txt_Endereco, 0);
            this.Controls.SetChildIndex(this.txt_Bairro, 0);
            this.Controls.SetChildIndex(this.txt_Numero, 0);
            this.Controls.SetChildIndex(this.txt_Cidade, 0);
            this.Controls.SetChildIndex(this.txt_CodCidade, 0);
            this.Controls.SetChildIndex(this.btn_BuscarPorCidade, 0);
            this.Controls.SetChildIndex(this.lbl_Complemento, 0);
            this.Controls.SetChildIndex(this.txt_Complemento, 0);
            this.Controls.SetChildIndex(this.CB_Tipo, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.txt_DataNasc, 0);
            this.Controls.SetChildIndex(this.txt_CodCargo, 0);
            this.Controls.SetChildIndex(this.txt_Cargo, 0);
            this.Controls.SetChildIndex(this.lbl_CodCargo, 0);
            this.Controls.SetChildIndex(this.lbl_Cargo, 0);
            this.Controls.SetChildIndex(this.btn_Cargo, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.MaskedTextBox txt_Telefone;
        public System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label lbl_Telefone;
        private System.Windows.Forms.Label lbl_Email;
        protected System.Windows.Forms.Label lbl_RGeIE;
        protected System.Windows.Forms.Label lbl_CNPJeCPF;
        protected System.Windows.Forms.Label lbl_Sexo;
        public System.Windows.Forms.Label lbl_NomeOuRSocial;
        public System.Windows.Forms.Label lbl_SobrenomeOuNFantasia;
        public System.Windows.Forms.MaskedTextBox mtb_CPFeCNPJ;
        public System.Windows.Forms.MaskedTextBox mtb_RGeIE;
        public System.Windows.Forms.ComboBox CB_Sexo;
        public System.Windows.Forms.TextBox txt_SobrenomeOuNFantasia;
        public System.Windows.Forms.TextBox txt_NomeOuRSocial;
        private System.Windows.Forms.Label lbl_TelaCadastroDe;
        public System.Windows.Forms.Label lbl_Generica;
        public System.Windows.Forms.TextBox txt_CodCondicaoPag;
        public System.Windows.Forms.TextBox txt_CondPag;
        private System.Windows.Forms.Button btn_BuscarCondPag;
        public System.Windows.Forms.Label lbl_CodPagamento;
        public System.Windows.Forms.Label lbl_CondPag;
        protected System.Windows.Forms.Label lbl_DataNasc;
        public System.Windows.Forms.MaskedTextBox txt_DataNasc;
        public System.Windows.Forms.TextBox txt_Cargo;
        public System.Windows.Forms.TextBox txt_CodCargo;
        public System.Windows.Forms.Label lbl_Cargo;
        public System.Windows.Forms.Label lbl_CodCargo;
        private System.Windows.Forms.Button btn_Cargo;
    }
}
