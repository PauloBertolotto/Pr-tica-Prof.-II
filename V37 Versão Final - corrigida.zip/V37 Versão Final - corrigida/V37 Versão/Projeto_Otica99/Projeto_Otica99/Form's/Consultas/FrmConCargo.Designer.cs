﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConCargo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CH_Cargo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCadastro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.CB_Codigo = new System.Windows.Forms.CheckBox();
            this.CB_Cargo = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_ConBuscar.Location = new System.Drawing.Point(387, 24);
            this.btn_ConBuscar.Click += new System.EventHandler(this.btn_ConBuscar_Click);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(514, 594);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(586, 594);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(658, 594);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)));
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Cargo,
            this.CH_DataCadastro,
            this.CH_DataUltAlt,
            this.CH_Status});
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 56);
            this.LV_Con_Pai.Size = new System.Drawing.Size(789, 533);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(716, 24);
            this.btn_Att.Size = new System.Drawing.Size(82, 27);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_Codigo.Size = new System.Drawing.Size(373, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(730, 594);
            // 
            // CH_Cargo
            // 
            this.CH_Cargo.Text = "Cargo";
            this.CH_Cargo.Width = 150;
            // 
            // CH_DataCadastro
            // 
            this.CH_DataCadastro.Text = "Data de Cadastro";
            this.CH_DataCadastro.Width = 200;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alterção";
            this.CH_DataUltAlt.Width = 200;
            // 
            // CH_Status
            // 
            this.CH_Status.Text = "Status";
            this.CH_Status.Width = 100;
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(627, 27);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(83, 24);
            this.CB_Inativos.TabIndex = 10;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            // 
            // CB_Codigo
            // 
            this.CB_Codigo.AutoSize = true;
            this.CB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.CB_Codigo.Location = new System.Drawing.Point(460, 26);
            this.CB_Codigo.Name = "CB_Codigo";
            this.CB_Codigo.Size = new System.Drawing.Size(78, 24);
            this.CB_Codigo.TabIndex = 11;
            this.CB_Codigo.Text = "Código";
            this.CB_Codigo.UseVisualStyleBackColor = true;
            // 
            // CB_Cargo
            // 
            this.CB_Cargo.AutoSize = true;
            this.CB_Cargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Cargo.ForeColor = System.Drawing.Color.Gold;
            this.CB_Cargo.Location = new System.Drawing.Point(544, 26);
            this.CB_Cargo.Name = "CB_Cargo";
            this.CB_Cargo.Size = new System.Drawing.Size(71, 24);
            this.CB_Cargo.TabIndex = 12;
            this.CB_Cargo.Text = "Cargo";
            this.CB_Cargo.UseVisualStyleBackColor = true;
            // 
            // FrmConCargo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(806, 627);
            this.Controls.Add(this.CB_Cargo);
            this.Controls.Add(this.CB_Codigo);
            this.Controls.Add(this.CB_Inativos);
            this.Name = "FrmConCargo";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.Controls.SetChildIndex(this.CB_Codigo, 0);
            this.Controls.SetChildIndex(this.CB_Cargo, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColumnHeader CH_Cargo;
        private System.Windows.Forms.ColumnHeader CH_DataCadastro;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
        private System.Windows.Forms.ColumnHeader CH_Status;
        private System.Windows.Forms.CheckBox CB_Inativos;
        private System.Windows.Forms.CheckBox CB_Codigo;
        private System.Windows.Forms.CheckBox CB_Cargo;
    }
}
