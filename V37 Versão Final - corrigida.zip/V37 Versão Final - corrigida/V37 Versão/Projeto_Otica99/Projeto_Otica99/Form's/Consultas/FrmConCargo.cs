﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Class_s.Outros;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConCargo : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FrmCadCargo   frmCadCargo;
        Cargos        oCargo;
        Ctrl_Cargos   aCtrl_Cargos;
        public int    IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        string status = "A";

        public FrmConCargo()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            aCtrl_Cargos = new Ctrl_Cargos();
        }
        public override void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmCadCargo = (FrmCadCargo)obj;
            }
        }
        public void ConhecaObj(object obj)
        {
            oCargo = (Cargos)obj;
        }
        protected override void Incluir()
        {
            base.Incluir();
            aCtrl_Cargos.Incluir();
            CarregaLV();
        }

        protected override void Alterar()
        {
            base.Alterar();
            int idCargo = ObterIdSelecionado();
            if (idCargo > 0)
            {
                Cargos cargo = aCtrl_Cargos.BuscarCargoPorId(idCargo);
                if (cargo != null)
                {
                    aCtrl_Cargos.Alterar(cargo);
                    CarregaLV();
                }
            }
        }

        public override void Excluir()
        {
            base.Excluir();
            int idCargo = ObterIdSelecionado();
            if (idCargo > 0)
            {
                Cargos cargo = aCtrl_Cargos.BuscarCargoPorId(idCargo);
                if (cargo != null)
                {
                    aCtrl_Cargos.Excluir(cargo);
                    CarregaLV();
                }
            }
        }

        public void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                Cargos cargo = selectedItem.Tag as Cargos;
                if (cargo != null)
                {
                    aCtrl_Cargos.Visualizar(cargo);
                    CarregaLV();
                }
            }
        }

        public override void CarregaLV()
        {
            base.CarregaLV();
            List<Cargos> dados = aCtrl_Cargos.ListarCargos(status);
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<Cargos> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var cargo in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(cargo.ID));
                item.SubItems.Add(cargo.Cargo);
                item.SubItems.Add(cargo.DataCriacao.ToString());
                item.SubItems.Add(cargo.DataUltimaAlteracao.ToString());
                item.SubItems.Add(cargo.StatusCargo == "I" ? "Inativo" : cargo.StatusCargo == "A" ? "Ativo" : cargo.StatusCargo);
                item.Tag = cargo;
                LV_Con_Pai.Items.Add(item);
            }
        }

        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }

        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
        private string ObterCritérioPesquisa()
        {
            if (CB_Codigo.Checked)
            {
                return "ID";
            }
            else if (CB_Cargo.Checked)
            {
                return "CARGO";
            }

            return string.Empty;
        }
        protected void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCritérioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                var resultados = aCtrl_Cargos.PesquisarCargosPorCriterio(criterioPesquisa, valorPesquisa, status);
                PreencherListView(resultados);
            }
        }

        private void cbInativos_CheckedChanged(object sender, EventArgs e)
        {
            if (CB_Inativos.Checked)
                status = "I";
            else
                status = "A";
            CarregaLV();
        }

        private void btn_ConBuscar_Click(object sender, EventArgs e)
        {
            Pesquisar();
        }
    }
}
