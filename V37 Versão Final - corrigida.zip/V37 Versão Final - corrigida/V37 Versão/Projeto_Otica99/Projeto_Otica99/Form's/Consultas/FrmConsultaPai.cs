﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConsultaPai : Projeto_Otica99.FrmPai
    {
        public FrmConsultaPai()
        {
            InitializeComponent();

        }
        public virtual void SetFrmCadastro(object obj)
        {

        }
        public virtual void ConhecaObj(object obj, object ctrl)
        {

        }
        protected virtual void Incluir()
        {

        }
        protected virtual void Alterar()
        {

        }
        public virtual void Excluir()
        {
           
        }
        public virtual void CarregaLV()
        {

        }
        protected virtual void Buscar()
        {

        }
        public virtual void Atualizar()
        {
            CarregaLV();
        }

        private void btn_ConBuscar_Click(object sender, EventArgs e)
        {
            Buscar();
        }

        private void btn_Con_Incluir_Click(object sender, EventArgs e)
        {
            Incluir();
        }

        private void btn_Con_Alterar_Click(object sender, EventArgs e)
        {
            Alterar();
        }

        private void btn_Con_Excluir_Click(object sender, EventArgs e)
        {
            Excluir();
        }

        private void btn_Att_Click(object sender, EventArgs e)
        {
            Atualizar();
            txt_Codigo.Clear();
        }
    }
}
