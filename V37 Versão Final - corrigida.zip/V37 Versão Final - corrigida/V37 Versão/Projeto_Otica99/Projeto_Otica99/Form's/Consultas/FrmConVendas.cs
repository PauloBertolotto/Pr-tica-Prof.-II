﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConVendas : Projeto_Otica99.FrmPai
    {
        FrmCadVendas frmCadVendas;
        Ctrl_Vendas aCTRLVendas;
        Vendas aVenda;
        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        private bool Cancelada = false; 
        public FrmConVendas()
        {
            InitializeComponent();
            aCTRLVendas = new Ctrl_Vendas();
            Verificacao.DisableCopyPaste(this);
            CarregaLV();
        }
        public virtual void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmCadVendas = (FrmCadVendas)obj;
            }
        }
        public virtual void ConhecaObj(object obj)
        {
            aVenda = (Vendas)obj;
        }
        protected virtual void Incluir()
        {
            aCTRLVendas.Incluir();
            CarregaLV();
        }
        public virtual void Excluir()
        {
            int Numero  = ObterIdSelecionado(0); // Obtém o número
            int Modelo  = ObterIdSelecionado(1); // Obtém o modelo
            int Serie   = ObterIdSelecionado(2); // Obtém a série
            int Cliente = ObterIdSelecionado(3); // Obtém o ID do cliente

            // Verifica se o ID do cliente é maior que 0
            if (Cliente > 0)
            {
                // Busca a venda com base nos IDs obtidos
                Vendas venda = aCTRLVendas.BuscarVendaPorChave(Numero, Modelo, Serie, Cliente);

                // Verifica se a venda foi encontrada
                if (venda != null)
                {
                    // Cancela a nota da venda encontrada
                    aCTRLVendas.CancelarNota(venda);
                    CarregaLV();
                }
            }
        }
        private int ObterIdSelecionado(int posicao)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                return int.Parse(listView1.SelectedItems[0].SubItems[posicao].Text);
            }
            return 0;
        }
        public virtual void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                Vendas venda = selectedItem.Tag as Vendas;
                if (venda != null)
                {
                    aCTRLVendas.Visualizar(venda);
                    CarregaLV();
                }
            }
        }
        public virtual void CarregaLV()
        {
            List<Vendas> dados = aCTRLVendas.ListarVendas(Cancelada);
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<Vendas> dados)
        {
            listView1.Items.Clear();

            foreach (var venda in dados)
            {
                ListViewItem item = new ListViewItem(venda.NumNfv.ToString());
                item.SubItems.Add(venda.ModeloNfv.ToString());
                item.SubItems.Add(venda.SerieNfv.ToString());
                item.SubItems.Add(venda.Cliente.ID.ToString());
                item.SubItems.Add(venda.Cliente.NomeOuRSocial);
                item.SubItems.Add(venda.CondicaoPagamento.Condicao);
                item.SubItems.Add(venda.ValorTotal.ToString("C"));
                item.SubItems.Add(venda.ValorFrete.ToString("C"));
                item.SubItems.Add(venda.ValorSeguro.ToString("C"));
                item.SubItems.Add(venda.ValorOutrasDespesas.ToString("C"));
                item.SubItems.Add(venda.DataSaida.ToString());
                item.SubItems.Add(venda.DataEmissao.ToString());
                item.SubItems.Add(venda.DataCancelamento == DateTime.MinValue ? "Não Cancelada" : venda.DataCancelamento.ToString()); // Verifica se a data de cancelamento é MinValue
                item.SubItems.Add(venda.DataCriacao.ToString());

                item.Tag = venda;
                listView1.Items.Add(item);
            }
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (listView1.SelectedItems.Count > 0)
                {
                    IdSelecionado   = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = listView1.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
        protected virtual void Pesquisar()
        {
            // Obtém os parâmetros de filtragem
            DateTime? dataInicio = null;
            DateTime? dataFim = null;
            bool? cancelada = null;

            if (dtData1.Value.Date > DateTime.MinValue.Date)
            {
                dataInicio = dtData1.Value.Date;
            }

            if (dtData2.Value.Date > DateTime.MinValue.Date)
            {
                dataFim = dtData2.Value.Date;
            }

            if (CB_Canceladas.Checked)
            {
                cancelada = true;
            }

            if (string.IsNullOrEmpty(CB_Datas.Text)) // Verifica se o ComboBox de tipo de data está vazio
            {
                return;
            }

            // Chama o método de filtragem passando os parâmetros
            Filtrar(dataInicio, dataFim, cancelada, txt_Codigo.Text, CB_Datas.Text);
        }
        private void Filtrar(DateTime? dataInicio, DateTime? dataFim, bool? cancelada, string nomeCliente, string tipoData)
        {
            // Chama o método de listagem passando os parâmetros de filtragem
            List<Vendas> vendas = aCTRLVendas.ListarVendas(dataInicio, dataFim, cancelada, nomeCliente, tipoData);

            // Preenche o ListView com os resultados
            PreencherListView(vendas);
        }

        private void CB_Canceladas_CheckedChanged(object sender, EventArgs e)
        {
            if (!CB_Canceladas.Checked)
            {
                btn_Excluir.Enabled = true;
                Cancelada = false;
                CarregaLV();
            }
            else
            {
                Cancelada = true;
                btn_Excluir.Enabled = false;
                CarregaLV();
            }
        }
        public virtual void Alterar()
        {
            if (Convert.ToInt32(txt_Numero.Text) >= 0 && txt_Serie.TextAlign >= 0 && txt_Modelo.TextAlign >= 0)
            {
                int codigo = Convert.ToInt32(txt_Numero.Text);
                int modelo = Convert.ToInt32(txt_Modelo.Text);
                int serie  = Convert.ToInt32(txt_Serie.Text);

                List<Vendas> dados = aCTRLVendas.BuscarListaVendaPorChave(codigo, modelo, serie);
                PreencherListView(dados);
            }
        }

        private void btn_NovaVenda_Click(object sender, EventArgs e)
        {
            Incluir();
        }

        private void btn_CancelarV_Click(object sender, EventArgs e)
        {
            Excluir();
        }

        private void FrmConVendas_Load(object sender, EventArgs e)
        {

        }
    }
}
