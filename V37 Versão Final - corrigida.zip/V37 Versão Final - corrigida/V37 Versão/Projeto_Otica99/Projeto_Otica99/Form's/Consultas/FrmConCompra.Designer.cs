﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BuscarDados = new System.Windows.Forms.Button();
            this.txt_Serie = new System.Windows.Forms.TextBox();
            this.txt_Modelo = new System.Windows.Forms.TextBox();
            this.txt_Numero = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CB_Canceladas = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.CB_Datas = new System.Windows.Forms.ComboBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.CH_Codigo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Modelo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Serie = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_CodF = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Forn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Cond = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Total = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Frete = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Seguro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Outras = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataChegada = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataEm = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCancelar = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_NovaVenda = new System.Windows.Forms.Button();
            this.btn_CancelarV = new System.Windows.Forms.Button();
            this.btn_BuscarData = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.dtData2 = new System.Windows.Forms.DateTimePicker();
            this.dtData1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_CFornecedor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Código
            // 
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.Location = new System.Drawing.Point(5, 0);
            this.lbl_Código.Size = new System.Drawing.Size(71, 24);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sair.Location = new System.Drawing.Point(1133, 667);
            // 
            // btn_BuscarDados
            // 
            this.btn_BuscarDados.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarDados.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarDados.Location = new System.Drawing.Point(468, 26);
            this.btn_BuscarDados.Name = "btn_BuscarDados";
            this.btn_BuscarDados.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarDados.TabIndex = 611;
            this.btn_BuscarDados.Text = "Buscar";
            this.btn_BuscarDados.UseVisualStyleBackColor = false;
            this.btn_BuscarDados.Click += new System.EventHandler(this.btn_BuscarDados_Click);
            // 
            // txt_Serie
            // 
            this.txt_Serie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Serie.Location = new System.Drawing.Point(252, 26);
            this.txt_Serie.Name = "txt_Serie";
            this.txt_Serie.Size = new System.Drawing.Size(75, 26);
            this.txt_Serie.TabIndex = 610;
            this.txt_Serie.Text = "0";
            this.txt_Serie.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Serie.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Numero_KeyPress);
            // 
            // txt_Modelo
            // 
            this.txt_Modelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Modelo.Location = new System.Drawing.Point(171, 26);
            this.txt_Modelo.Name = "txt_Modelo";
            this.txt_Modelo.Size = new System.Drawing.Size(75, 26);
            this.txt_Modelo.TabIndex = 609;
            this.txt_Modelo.Text = "0";
            this.txt_Modelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Modelo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Numero_KeyPress);
            // 
            // txt_Numero
            // 
            this.txt_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero.Location = new System.Drawing.Point(90, 26);
            this.txt_Numero.Name = "txt_Numero";
            this.txt_Numero.Size = new System.Drawing.Size(75, 26);
            this.txt_Numero.TabIndex = 608;
            this.txt_Numero.Text = "0";
            this.txt_Numero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Numero.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Numero_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(248, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 24);
            this.label3.TabIndex = 607;
            this.label3.Text = "Série";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(167, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 24);
            this.label2.TabIndex = 606;
            this.label2.Text = "Modelo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(86, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 24);
            this.label1.TabIndex = 605;
            this.label1.Text = "Número";
            // 
            // CB_Canceladas
            // 
            this.CB_Canceladas.AutoSize = true;
            this.CB_Canceladas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Canceladas.ForeColor = System.Drawing.Color.Gold;
            this.CB_Canceladas.Location = new System.Drawing.Point(612, 26);
            this.CB_Canceladas.Name = "CB_Canceladas";
            this.CB_Canceladas.Size = new System.Drawing.Size(112, 24);
            this.CB_Canceladas.TabIndex = 604;
            this.CB_Canceladas.Text = "Canceladas";
            this.CB_Canceladas.UseVisualStyleBackColor = true;
            this.CB_Canceladas.CheckedChanged += new System.EventHandler(this.CB_Canceladas_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(6, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 24);
            this.label8.TabIndex = 603;
            this.label8.Text = "Tipo de Data";
            // 
            // CB_Datas
            // 
            this.CB_Datas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Datas.FormattingEnabled = true;
            this.CB_Datas.Items.AddRange(new object[] {
            "EMISSAO",
            "VENCIMENTO",
            "BAIXA"});
            this.CB_Datas.Location = new System.Drawing.Point(9, 79);
            this.CB_Datas.Name = "CB_Datas";
            this.CB_Datas.Size = new System.Drawing.Size(114, 28);
            this.CB_Datas.TabIndex = 602;
            // 
            // listView1
            // 
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Codigo,
            this.CH_Modelo,
            this.CH_Serie,
            this.CH_CodF,
            this.CH_Forn,
            this.CH_Cond,
            this.CH_Total,
            this.CH_Frete,
            this.CH_Seguro,
            this.CH_Outras,
            this.CH_DataChegada,
            this.CH_DataEm,
            this.CH_DataCancelar,
            this.CH_DataC,
            this.CH_Status});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(9, 113);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1192, 547);
            this.listView1.TabIndex = 620;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // CH_Codigo
            // 
            this.CH_Codigo.Text = "Código";
            this.CH_Codigo.Width = 100;
            // 
            // CH_Modelo
            // 
            this.CH_Modelo.Text = "Modelo";
            this.CH_Modelo.Width = 100;
            // 
            // CH_Serie
            // 
            this.CH_Serie.Text = "Série";
            this.CH_Serie.Width = 80;
            // 
            // CH_CodF
            // 
            this.CH_CodF.Text = "C. Fornecedor";
            this.CH_CodF.Width = 100;
            // 
            // CH_Forn
            // 
            this.CH_Forn.Text = "Fornecedor";
            this.CH_Forn.Width = 150;
            // 
            // CH_Cond
            // 
            this.CH_Cond.Text = "Condição de Pagamento";
            this.CH_Cond.Width = 220;
            // 
            // CH_Total
            // 
            this.CH_Total.Text = "Total";
            this.CH_Total.Width = 120;
            // 
            // CH_Frete
            // 
            this.CH_Frete.Text = "Frete";
            this.CH_Frete.Width = 120;
            // 
            // CH_Seguro
            // 
            this.CH_Seguro.Text = "Seguro";
            this.CH_Seguro.Width = 120;
            // 
            // CH_Outras
            // 
            this.CH_Outras.Text = "Outras";
            this.CH_Outras.Width = 120;
            // 
            // CH_DataChegada
            // 
            this.CH_DataChegada.Text = "Data de Chegada";
            this.CH_DataChegada.Width = 155;
            // 
            // CH_DataEm
            // 
            this.CH_DataEm.Text = "Emissão";
            this.CH_DataEm.Width = 155;
            // 
            // CH_DataCancelar
            // 
            this.CH_DataCancelar.Text = "Cancelada";
            this.CH_DataCancelar.Width = 155;
            // 
            // CH_DataC
            // 
            this.CH_DataC.Text = "Data da Compra";
            this.CH_DataC.Width = 155;
            // 
            // CH_Status
            // 
            this.CH_Status.Text = "Status";
            this.CH_Status.Width = 100;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Excluir.BackColor = System.Drawing.Color.Gold;
            this.btn_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Excluir.Location = new System.Drawing.Point(9, 667);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(100, 27);
            this.btn_Excluir.TabIndex = 619;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = false;
            // 
            // btn_NovaVenda
            // 
            this.btn_NovaVenda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_NovaVenda.BackColor = System.Drawing.Color.Gold;
            this.btn_NovaVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_NovaVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NovaVenda.Location = new System.Drawing.Point(810, 666);
            this.btn_NovaVenda.Name = "btn_NovaVenda";
            this.btn_NovaVenda.Size = new System.Drawing.Size(162, 28);
            this.btn_NovaVenda.TabIndex = 618;
            this.btn_NovaVenda.Text = "Nova Compra";
            this.btn_NovaVenda.UseVisualStyleBackColor = false;
            this.btn_NovaVenda.Click += new System.EventHandler(this.btn_NovaVenda_Click);
            // 
            // btn_CancelarV
            // 
            this.btn_CancelarV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_CancelarV.BackColor = System.Drawing.Color.Gold;
            this.btn_CancelarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_CancelarV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarV.Location = new System.Drawing.Point(978, 667);
            this.btn_CancelarV.Name = "btn_CancelarV";
            this.btn_CancelarV.Size = new System.Drawing.Size(150, 27);
            this.btn_CancelarV.TabIndex = 617;
            this.btn_CancelarV.Text = "Cancelar Compra";
            this.btn_CancelarV.UseVisualStyleBackColor = false;
            this.btn_CancelarV.Click += new System.EventHandler(this.btn_CancelarV_Click);
            // 
            // btn_BuscarData
            // 
            this.btn_BuscarData.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarData.Location = new System.Drawing.Point(819, 78);
            this.btn_BuscarData.Name = "btn_BuscarData";
            this.btn_BuscarData.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarData.TabIndex = 616;
            this.btn_BuscarData.Text = "Buscar";
            this.btn_BuscarData.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(528, 83);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 20);
            this.label7.TabIndex = 615;
            this.label7.Text = "até";
            // 
            // dtData2
            // 
            this.dtData2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtData2.Location = new System.Drawing.Point(560, 81);
            this.dtData2.Name = "dtData2";
            this.dtData2.Size = new System.Drawing.Size(253, 26);
            this.dtData2.TabIndex = 614;
            // 
            // dtData1
            // 
            this.dtData1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtData1.Location = new System.Drawing.Point(271, 81);
            this.dtData1.Name = "dtData1";
            this.dtData1.Size = new System.Drawing.Size(251, 26);
            this.dtData1.TabIndex = 613;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(127, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 20);
            this.label6.TabIndex = 612;
            this.label6.Text = "Período de Busca:";
            // 
            // txt_CFornecedor
            // 
            this.txt_CFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CFornecedor.Location = new System.Drawing.Point(333, 26);
            this.txt_CFornecedor.Name = "txt_CFornecedor";
            this.txt_CFornecedor.Size = new System.Drawing.Size(129, 26);
            this.txt_CFornecedor.TabIndex = 622;
            this.txt_CFornecedor.Text = "0";
            this.txt_CFornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CFornecedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Numero_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(329, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 24);
            this.label4.TabIndex = 621;
            this.label4.Text = "C. Fornecedor";
            // 
            // FrmConCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1212, 700);
            this.Controls.Add(this.txt_CFornecedor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.btn_NovaVenda);
            this.Controls.Add(this.btn_CancelarV);
            this.Controls.Add(this.btn_BuscarData);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtData2);
            this.Controls.Add(this.dtData1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_BuscarDados);
            this.Controls.Add(this.txt_Serie);
            this.Controls.Add(this.txt_Modelo);
            this.Controls.Add(this.txt_Numero);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CB_Canceladas);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CB_Datas);
            this.Name = "FrmConCompra";
            this.Text = "Consulta: Compra";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.CB_Datas, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.CB_Canceladas, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txt_Numero, 0);
            this.Controls.SetChildIndex(this.txt_Modelo, 0);
            this.Controls.SetChildIndex(this.txt_Serie, 0);
            this.Controls.SetChildIndex(this.btn_BuscarDados, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.dtData1, 0);
            this.Controls.SetChildIndex(this.dtData2, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.btn_BuscarData, 0);
            this.Controls.SetChildIndex(this.btn_CancelarV, 0);
            this.Controls.SetChildIndex(this.btn_NovaVenda, 0);
            this.Controls.SetChildIndex(this.btn_Excluir, 0);
            this.Controls.SetChildIndex(this.listView1, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.txt_CFornecedor, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_BuscarDados;
        private System.Windows.Forms.TextBox txt_Serie;
        private System.Windows.Forms.TextBox txt_Modelo;
        private System.Windows.Forms.TextBox txt_Numero;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox CB_Canceladas;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CB_Datas;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_NovaVenda;
        private System.Windows.Forms.Button btn_CancelarV;
        private System.Windows.Forms.Button btn_BuscarData;
        private System.Windows.Forms.Label label7;
        protected System.Windows.Forms.DateTimePicker dtData2;
        protected System.Windows.Forms.DateTimePicker dtData1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_CFornecedor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ColumnHeader CH_Codigo;
        private System.Windows.Forms.ColumnHeader CH_Modelo;
        private System.Windows.Forms.ColumnHeader CH_Serie;
        private System.Windows.Forms.ColumnHeader CH_CodF;
        private System.Windows.Forms.ColumnHeader CH_Forn;
        private System.Windows.Forms.ColumnHeader CH_Cond;
        private System.Windows.Forms.ColumnHeader CH_Total;
        private System.Windows.Forms.ColumnHeader CH_Frete;
        private System.Windows.Forms.ColumnHeader CH_Seguro;
        private System.Windows.Forms.ColumnHeader CH_Outras;
        private System.Windows.Forms.ColumnHeader CH_DataChegada;
        private System.Windows.Forms.ColumnHeader CH_DataEm;
        private System.Windows.Forms.ColumnHeader CH_DataCancelar;
        private System.Windows.Forms.ColumnHeader CH_DataC;
        private System.Windows.Forms.ColumnHeader CH_Status;
    }
}
