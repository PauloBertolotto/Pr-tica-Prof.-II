﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RB_Codigo = new System.Windows.Forms.RadioButton();
            this.RB_Categoria = new System.Windows.Forms.RadioButton();
            this.CH_Nome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCadastro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(1065, 21);
            this.btn_ConBuscar.Click += new System.EventHandler(this.btn_ConBuscar_Click);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(922, 668);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(994, 668);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(1066, 668);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Nome,
            this.CH_DataCadastro,
            this.CH_DataUltAlt});
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 83);
            this.LV_Con_Pai.Size = new System.Drawing.Size(1197, 583);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(1138, 21);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Size = new System.Drawing.Size(1052, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1138, 668);
            // 
            // RB_Codigo
            // 
            this.RB_Codigo.AutoSize = true;
            this.RB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.RB_Codigo.Location = new System.Drawing.Point(9, 52);
            this.RB_Codigo.Name = "RB_Codigo";
            this.RB_Codigo.Size = new System.Drawing.Size(74, 22);
            this.RB_Codigo.TabIndex = 10;
            this.RB_Codigo.TabStop = true;
            this.RB_Codigo.Text = "Código";
            this.RB_Codigo.UseVisualStyleBackColor = true;
            // 
            // RB_Categoria
            // 
            this.RB_Categoria.AutoSize = true;
            this.RB_Categoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Categoria.ForeColor = System.Drawing.Color.Gold;
            this.RB_Categoria.Location = new System.Drawing.Point(89, 52);
            this.RB_Categoria.Name = "RB_Categoria";
            this.RB_Categoria.Size = new System.Drawing.Size(90, 22);
            this.RB_Categoria.TabIndex = 11;
            this.RB_Categoria.TabStop = true;
            this.RB_Categoria.Text = "Categoria";
            this.RB_Categoria.UseVisualStyleBackColor = true;
            // 
            // CH_Nome
            // 
            this.CH_Nome.Text = "Nome";
            this.CH_Nome.Width = 200;
            // 
            // CH_DataCadastro
            // 
            this.CH_DataCadastro.Text = "Data de Cadastro";
            this.CH_DataCadastro.Width = 155;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 155;
            // 
            // FrmConCategoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1214, 703);
            this.Controls.Add(this.RB_Categoria);
            this.Controls.Add(this.RB_Codigo);
            this.Name = "FrmConCategoria";
            this.Text = "Consulta: Categoria";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.RB_Codigo, 0);
            this.Controls.SetChildIndex(this.RB_Categoria, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton RB_Codigo;
        private System.Windows.Forms.RadioButton RB_Categoria;
        private System.Windows.Forms.ColumnHeader CH_Nome;
        private System.Windows.Forms.ColumnHeader CH_DataCadastro;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
    }
}
