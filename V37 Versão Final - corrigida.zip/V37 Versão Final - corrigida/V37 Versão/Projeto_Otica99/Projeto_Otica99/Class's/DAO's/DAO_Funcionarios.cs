﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Funcionarios : DAO
    {
        DB oDB;
        Verificacao verificacao;
        Ctrl_Cidades aCTRLCidades;
        Ctrl_Cargos aCTRLCargos;
        public DAO_Funcionarios()
        {
            oDB = new DB();
            verificacao = new Verificacao();
            aCTRLCidades = new Ctrl_Cidades();
            aCTRLCargos = new Ctrl_Cargos();
        }
        public override string CarregaObj(object obj)
        {
            DadosCadastro2 oFuncionario = (DadosCadastro2)obj;
            string ok = "";

            try
            {
                string sql = "select * from Funcionario where ID_Funcionario = '" + Convert.ToString(oFuncionario.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    oFuncionario.ID                      = Convert.ToInt32(dr.GetValue(0));
                    oFuncionario.CidadeID.ID             = Convert.ToInt32(dr.GetValue(1));

                    oFuncionario.NomeOuRSocial           = dr.GetString(2);
                    oFuncionario.SobrenomeOuNomeFantasia = dr.GetString(3);
                    oFuncionario.Endereco                = dr.GetString(4);
                    oFuncionario.Complemento             = dr.GetString(5);
                    oFuncionario.Numero                  = dr.GetString(6);
                    oFuncionario.Bairro                  = dr.GetString(7);
                    oFuncionario.CEP                     = dr.GetString(8);
                    oFuncionario.Telefone                = dr.GetString(9);
                    oFuncionario.Email                   = dr.GetString(10);
                    oFuncionario.CPFouCNPJ               = dr.GetString(11);
                    oFuncionario.RGouIE                  = dr.GetString(12);
                    oFuncionario.Sexo                    = dr.GetString(13);
                    oFuncionario.DataNasc                = dr.GetString(14);
                    oFuncionario.CargoID.ID              = Convert.ToInt32(dr.GetString(15));
                    oFuncionario.Ativo                   = dr.GetString(16);

                    oFuncionario.DataCriacao             = dr.GetDateTime(17);
                    oFuncionario.DataUltimaAlteracao     = dr.GetDateTime(18);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            DadosCadastro2 oFuncionario = (DadosCadastro2)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Funcionario (CidadeID, NomeOuRSocial, SobrenomeOuNomeFantasia, Endereco, Complemento, Numero, Bairro, CEP, Telefone, Email, CPFouCNPJ, RGouIE, Sexo, DataNasc, CargoID, Ativo, DataEntrada, DataUltimaAlteracao) " +
        "VALUES (@CidadeID, @NomeOuRSocial, @SobrenomeOuNomeFantasia, @Endereco, @Complemento, @Numero, @Bairro, @CEP, @Telefone, @Email, @CPFouCNPJ, @RGouIE, @Sexo, @DataNasc, @CargoID, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oFuncionario.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Funcionario SET  CidadeID = @CidadeID, NomeOuRSocial = @NomeOuRSocial, SobrenomeOuNomeFantasia = @SobrenomeOuNomeFantasia, Endereco = @Endereco, Complemento = @Complemento, Numero = @Numero, Bairro = @Bairro, CEP = @CEP, Telefone = @Telefone, Email = @Email, CPFouCNPJ = @CPFouCNPJ,RGouIE =@RGouIE ,Sexo = @Sexo, DataNasc = @DataNasc, CargoID = @CargoID ,Ativo =@Ativo ,DataUltimaAlteracao=@DataUltimaAlteracao WHERE ID_Funcionario =@ID_Funcionario";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oFuncionario.ID != 0)
            {
                cnn.Parameters.AddWithValue("@ID_Funcionario",       oFuncionario.ID);
            }                                                        
            cnn.Parameters.AddWithValue("@CidadeID",                 oFuncionario.CidadeID.ID);
            cnn.Parameters.AddWithValue("@NomeOuRSocial",            oFuncionario.NomeOuRSocial);
            cnn.Parameters.AddWithValue("@SobrenomeOuNomeFantasia",  oFuncionario.SobrenomeOuNomeFantasia);
            cnn.Parameters.AddWithValue("@Endereco",                 oFuncionario.Endereco);
            cnn.Parameters.AddWithValue("@Complemento",              oFuncionario.Complemento);
            cnn.Parameters.AddWithValue("@Numero",                   oFuncionario.Numero);
            cnn.Parameters.AddWithValue("@Bairro",                   oFuncionario.Bairro);
            cnn.Parameters.AddWithValue("@CEP",                      oFuncionario.CEP);
            cnn.Parameters.AddWithValue("@Telefone",                 oFuncionario.Telefone);
            cnn.Parameters.AddWithValue("@Email",                    oFuncionario.Email);
            cnn.Parameters.AddWithValue("@CPFouCNPJ",                oFuncionario.CPFouCNPJ);
            cnn.Parameters.AddWithValue("@RGouIE",                   oFuncionario.RGouIE);
            cnn.Parameters.AddWithValue("@Sexo",                     oFuncionario.Sexo);
            cnn.Parameters.AddWithValue("@DataNasc",                 oFuncionario.DataNasc);
            cnn.Parameters.AddWithValue("@CargoID",                  oFuncionario.CargoID.ID);
            cnn.Parameters.AddWithValue("@Ativo",                    oFuncionario.Ativo);
                                                                     
                                                                     
            cnn.Parameters.AddWithValue("@DataEntrada",              oFuncionario.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao",      oFuncionario.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();

            cnn.Connection.Close();

            return ok;
        }
        public override string Excluir(string item)
        {
            string ok = "";

            try
            {
                string sql = "UPDATE Funcionario SET Ativo = 'I' WHERE ID_Funcionario = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public List<DadosCadastro2> PesquisarFuncionariosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<DadosCadastro2> funcionariosEncontrados = new List<DadosCadastro2>();

            try
            {
                string query = string.Empty;
                SqlParameter parametro = new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%");

                // Verificando o critério de pesquisa
                if (criterio == "ID")
                {
                    query = "SELECT * FROM Funcionario WHERE ID_Funcionario LIKE @ValorPesquisa";
                }
                else if (criterio == "NOME")
                {
                    query = "SELECT * FROM Funcionario WHERE NomeOuRSocial LIKE @ValorPesquisa";
                }
                else if (criterio == "RG")
                {
                    query = "SELECT * FROM Funcionario WHERE RGouIE LIKE @ValorPesquisa";
                }
                else if (criterio == "CPF")
                {
                    query = "SELECT * FROM Funcionario WHERE CPFouCNPJ LIKE @ValorPesquisa";
                }
                //else if (criterio == "CIDADE")
                //{
                //    query = "SELECT c.* FROM Funcionario c JOIN Cidade cid ON c.ID_Cidade = cid.id_cidade WHERE cid.nome LIKE @ValorPesquisa";
                //}

                // Adicionar filtro de status, se fornecido
                if (!string.IsNullOrEmpty(status))
                {
                    if (!string.IsNullOrEmpty(query))
                    {
                        query += " AND Ativo = @Status";
                    }
                    else
                    {
                        query = "SELECT * FROM Funcionario WHERE Ativo = @Status AND nome LIKE @ValorPesquisa";
                    }
                }

                // Executar a consulta e preencher a lista de funcionários encontrados
                DataTable dataTable;
                if (!string.IsNullOrEmpty(query))
                {
                    dataTable = oDB.ExecutarConsulta(query, new[] { parametro, new SqlParameter("@Status", status) });
                }
                else
                {
                    dataTable = oDB.ExecutarConsulta("SELECT * FROM Funcionario WHERE nome LIKE @ValorPesquisa", new[] { parametro });
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    DadosCadastro2 funcionario = CreateFuncionarioFromDataRow(row);
                    funcionariosEncontrados.Add(funcionario);
                }
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar funcionários", ex);
                return null;
            }

            return funcionariosEncontrados;
        }
        private DadosCadastro2 CreateFuncionarioFromDataRow(DataRow row)
        {
            return new DadosCadastro2
            {
                ID = Convert.ToInt32(row["ID_Funcionario"]),
                CidadeID = aCTRLCidades.BuscarCidadePorId(Convert.ToInt32(row["CidadeID"])),
                NomeOuRSocial = row["NomeOuRSocial"].ToString(),
                SobrenomeOuNomeFantasia = row["SobrenomeOuNomeFantasia"].ToString(),
                Endereco = row["Endereco"].ToString(),
                Complemento = row["Complemento"].ToString(),
                Numero = row["Numero"].ToString(),
                Bairro = row["Bairro"].ToString(),
                CEP = row["CEP"].ToString(),
                Telefone = row["Telefone"].ToString(),
                Email = row["Email"].ToString(),
                CPFouCNPJ = row["CPFouCNPJ"].ToString(),
                RGouIE = row["RGouIE"].ToString(),
                Sexo = row["Sexo"].ToString(),
                DataNasc = row["DataNasc"].ToString(),
                CargoID = aCTRLCargos.BuscarCargoPorId(Convert.ToInt32(row["CargoID"])),
                Ativo = row["Ativo"].ToString(),
                DataCriacao = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["DataUltimaAlteracao"])
            };
        }

        private List<DadosCadastro2> CreateFornecedoresListFromDataTable(DataTable dataTable)
        {
            List<DadosCadastro2> fornecedores = new List<DadosCadastro2>();
            // Para cada linha no DataTable, crie um objeto Fornecedores e adicione à lista de fornecedores
            foreach (DataRow row in dataTable.Rows)
            {
                fornecedores.Add(CreateFornecedorFromDataRow(row));
            }
            return fornecedores;
        }
        public List<DadosCadastro2> ListarFuncionarios(string status)
        {
            try
            {
                string sql = "SELECT * FROM Funcionario";
                List<SqlParameter> parametros = new List<SqlParameter>();

                // Verifica se o parâmetro de status foi fornecido e adiciona a cláusula WHERE, se necessário
                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE Ativo = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateFornecedoresListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                // Trate exceções genéricas, se aplicável
                verificacao.HandleException("Erro ao listar fornecedores", ex);
                return new List<DadosCadastro2>();
            }
        }
        private DadosCadastro2 CreateFornecedorFromDataRow(DataRow row)
        {          
            return new DadosCadastro2
            {
                ID                      = Convert.ToInt32(row["ID_Funcionario"]),
                Ativo                   = row["Ativo"].ToString(),
                NomeOuRSocial           = row["NomeOuRSocial"].ToString(),
                SobrenomeOuNomeFantasia = row["SobrenomeOuNomeFantasia"].ToString(),
                Sexo                    = row["sexo"].ToString(),
                RGouIE                  = row["RGouIE"].ToString(),
                CPFouCNPJ               = row["CPFouCNPJ"].ToString(),
                Email                   = row["Email"].ToString(),
                Telefone                = row["Telefone"].ToString(),
                CEP                     = row["cep"].ToString(),
                Endereco                = row["endereco"].ToString(),
                Numero                  = row["Numero"].ToString(),
                Complemento             = row["complemento"].ToString(),
                Bairro                  = row["bairro"].ToString(),
                CidadeID                = aCTRLCidades.BuscarCidadePorId(Convert.ToInt32(row["CidadeID"])), // Supondo que você tenha um método para buscar a cidade pelo ID
                DataNasc                = row["DataNasc"].ToString(),
                CargoID                 = aCTRLCargos.BuscarCargoPorId(Convert.ToInt32(row["CargoID"])),
                DataCriacao             = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao     = Convert.ToDateTime(row["DataUltimaAlteracao"]),

            };
        }
        public int BuscarIDCidade(string nome)
        {
            int IDCidade = 0;
            try
            {
                string sql      = "select ID_Cidade from Cidade where Nome = @Nome";
                SqlCommand cnn  = new SqlCommand();
                cnn.Connection  = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDCidade = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {

            }
            if (IDCidade == 0)
            {
                MessageBox.Show("Cidade não encontrada!");
            }
            return IDCidade;
        }
        public string BuscarCidadePorId(int id)
        {

            string ok = "";
            try
            {
                string sql      = "select Nome from Cidade where ID_Cidade = " + id + "";
                SqlCommand cnn  = new SqlCommand();
                cnn.Connection  = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr          = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public string BuscaUF(string cidade)
        {
            string uf = "";
            try
            {
                string sql      = "SELECT e.UF FROM [dbo].[Cidade] c JOIN [dbo].[Estado] e ON c.EstadoID = e.ID_Estado WHERE c.Nome = @NomeCidade";
                SqlCommand cmd  = new SqlCommand();
                cmd.Connection  = DB.Abrir();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@NomeCidade", cidade);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    uf = dr.GetString(0);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                uf = "Erro";
            }
            return uf;
        }
    }
}
