﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;

namespace Projeto_Otica99.Class_s.DAO_s
{

    internal class DAO_CondPagamento : DAO
    {
        DB oDB;
        Verificacao aVerificacao;
        public DAO_CondPagamento()
        {
            this.oDB = new DB();
            aVerificacao = new Verificacao();
        }
        public bool Salvar(CondicaoPagamento obj)
        {
            bool status = false;
            string sqlInsert = @"INSERT INTO Condicao_Pagamento (ID_Condicao, Parcelas, Condicao, Taxa, Multa, Desconto, Status_Condicao, data_criacao, data_ult_alteracao)
                         VALUES(@ID_Condicao, @parcelas, @condicao, @taxa, @multa, @desconto, @Status_Condicao, @data_criacao, @data_ult_alteracao)";
            string LastID = "SELECT ISNULL(MAX(ID_Condicao), 0) FROM Condicao_Pagamento";
          

            try
            {
                using (SqlConnection connection = oDB.Abrir2())
                {
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Obter o próximo ID
                            int proximoID = Convert.ToInt32(oDB.ExecutarComandoScalar(LastID, null)) + 1;
                            obj.ID = proximoID;

                            // Configurar parâmetros
                            SqlParameter[] parametros = new SqlParameter[]
                            {
                                new SqlParameter("@ID_Condicao", obj.ID),
                                new SqlParameter("@parcelas", obj.Parcelas),
                                new SqlParameter("@condicao", obj.Condicao),
                                new SqlParameter("@taxa", obj.Taxa),
                                new SqlParameter("@multa", obj.Multa),
                                new SqlParameter("@desconto", obj.Desconto),
                                new SqlParameter("@data_criacao", obj.DataCriacao),
                                new SqlParameter("@data_ult_alteracao", obj.DataUltimaAlteracao),
                                new SqlParameter("@Status_Condicao", obj.Status)
                            };

                            // Executar comando de inserção
                            oDB.ExecutarComando(sqlInsert, parametros);

                            // Salvar parcelas associadas
                            foreach (Parcelas parcela in obj.uParcelas)
                            {
                                if (parcela != null)
                                {
                                    Ctrl_Parcelas aCTLParcelas = new Ctrl_Parcelas();
                                    parcela.ID = proximoID; // Definir o ID da condição de pagamento
                                    status = aCTLParcelas.SalvarParcelas(parcela);
                                    if (!status)
                                    {
                                        transaction.Rollback();
                                        MessageBox.Show("Aconteceu um erro ao salvar as parcelas.");
                                        return false;
                                    }
                                }
                            }

                            transaction.Commit();
                            status = true;
                            MessageBox.Show("Condição de pagamento cadastrada com sucesso!");
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Erro ao salvar a condição de pagamento: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
            }

            return status;
        }
        public bool Alterar(CondicaoPagamento obj)
        {
            bool status = false;
            string sqlInsert = "UPDATE Condicao_Pagamento SET Parcelas = @Parcelas, Condicao = @Condicao, Taxa = @Taxa, Multa = @Multa, Data_ult_alteracao = @Data_ult_alteracao WHERE ID_Condicao = @ID_Condicao";


            try
            {
                using (SqlConnection connection = oDB.Abrir2())
                {
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            //int proximoID = Convert.ToInt32(oDB.ExecutarComandoScalar(LastID, null)) + 1;
                            //obj.ID = proximoID;
                            // Configurar parâmetros
                            SqlParameter[] parametros = new SqlParameter[]
                            {
                                new SqlParameter("@ID_Condicao", obj.ID),
                                new SqlParameter("@parcelas", obj.Parcelas),
                                new SqlParameter("@condicao", obj.Condicao),
                                new SqlParameter("@taxa", obj.Taxa),
                                new SqlParameter("@multa", obj.Multa),
                                new SqlParameter("@desconto", obj.Desconto),
                                new SqlParameter("@data_criacao", obj.DataCriacao),
                                new SqlParameter("@data_ult_alteracao", obj.DataUltimaAlteracao),
                                new SqlParameter("@Status_Condicao", obj.Status)
                            };

                            // Executar comando de inserção
                            oDB.ExecutarComando(sqlInsert, parametros);

                            // Salvar parcelas associadas
                            //foreach (Parcelas parcela in obj.uParcelas)
                            //{
                            //    if (parcela != null)
                            //    {
                            //        Ctrl_Parcelas aCTLParcelas = new Ctrl_Parcelas();
                            //        parcela.ID = proximoID; 
                            //        status = aCTLParcelas.SalvarParcelas(parcela);
                            //        if (!status)
                            //        {
                            //            transaction.Rollback();
                            //            MessageBox.Show("Aconteceu um erro ao salvar as parcelas.");
                            //            return false;
                            //        }
                            //    }
                            //}

                            transaction.Commit();
                            status = true;
                            MessageBox.Show("Condição de pagamento cadastrada com sucesso!");
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Erro ao salvar a condição de pagamento: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
            }

            return status;
        }
        public bool ExcluirCondicaoPagamento(int condicaoPagamentoId)
        {
            try
            {
                string sql = "DELETE FROM Condicao_Pagamento WHERE ID_Condicao = @Id";
                SqlParameter parametro = new SqlParameter("@Id", condicaoPagamentoId);
                oDB.ExecutarComando(sql, new[] { parametro });
                return true;
            }
            catch (Exception ex)
            {
                aVerificacao.HandleException("Erro ao excluir condição de pagamento", ex);
                return false;
            }
        }

        public bool AtivarOuDesativarCondicaoPagamento(CondicaoPagamento condicao)
        {
            try
            {
                string sql = "UPDATE Condicao_Pagamento SET status_condicao = @Status WHERE ID_Condicao = @Id";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Status", condicao.Status),
                    new SqlParameter("@Id", condicao.ID)
                };

                oDB.ExecutarComando(sql, parametros);
                return true;
            }
            catch (Exception ex)
            {
                aVerificacao.HandleException("Erro ao ativar ou desativar condição de pagamento", ex);
                return false;
            }
        }

        public CondicaoPagamento BuscarCondicaoPagamentoPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Condicao_Pagamento WHERE ID_Condicao = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateCondicaoPagamentoFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                aVerificacao.HandleException("Erro ao buscar condição de pagamento por ID", ex);
                return null;
            }
        }

        public List<CondicaoPagamento> ListarCondicoesPagamento(string status)
        {
            try
            {
                string sql = "SELECT * FROM Condicao_Pagamento";
                List<SqlParameter> parametros = new List<SqlParameter>();

                // Verifica se o parâmetro de status foi fornecido e adiciona a cláusula WHERE, se necessário
                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE status_condicao = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateCondicoesPagamentoListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                aVerificacao.HandleException("Erro ao listar condições de pagamento", ex);
                return new List<CondicaoPagamento>();
            }
        }


        private CondicaoPagamento CreateCondicaoPagamentoFromDataRow(DataRow row)
        {
            return new CondicaoPagamento
            {
                ID = Convert.ToInt32(row["ID_Condicao"]),
                Condicao = row["Condicao"].ToString(),
                Parcelas = Convert.ToInt32(row["Parcelas"]),
                Taxa = Convert.ToDecimal(row["Taxa"]),
                Multa = Convert.ToDecimal(row["Multa"]),
                Desconto = Convert.ToDecimal(row["Desconto"]),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["data_ult_alteracao"]),
                Status = row["Status_Condicao"].ToString()
            };
        }

        private List<CondicaoPagamento> CreateCondicoesPagamentoListFromDataTable(DataTable dataTable)
        {
            List<CondicaoPagamento> condicoesPagamento = new List<CondicaoPagamento>();
            foreach (DataRow row in dataTable.Rows)
            {
                condicoesPagamento.Add(CreateCondicaoPagamentoFromDataRow(row));
            }
            return condicoesPagamento;
        }

        public int ObterProximoIdCondicaoPagamento()
        {
            try
            {
                string sql = "SELECT ISNULL(MAX(id_condicao), 0) FROM Condicao_Pagamento";
                int ultimoId = (int)oDB.ExecutarComandoScalar(sql, null);
                return ultimoId + 1;
            }
            catch (Exception ex)
            {
                aVerificacao.HandleException("Erro ao obter o próximo ID de condição de pagamento", ex);
                return 1; // Retorna 1 se houver um erro
            }
        }

        public List<CondicaoPagamento> PesquisarCondicaoPorCriterio(string valorPesquisa, string status)
        {
            List<CondicaoPagamento> condicoesEncontradas = new List<CondicaoPagamento>();

            try
            {
                string query = string.Empty;
                List<SqlParameter> parametros = new List<SqlParameter>();

                query = "SELECT * FROM Condicao_Pagamento WHERE condicao LIKE @ValorPesquisa AND Status_Condicao = @Status";
                parametros.Add(new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%"));

                // Adiciona o parâmetro de status à lista de parâmetros
                parametros.Add(new SqlParameter("@Status", status));

                // Executar a consulta e preencher a lista de condições de pagamento encontradas
                DataTable dataTable = oDB.ExecutarConsulta(query, parametros.ToArray());

                foreach (DataRow row in dataTable.Rows)
                {
                    CondicaoPagamento condicaoPagamento = CreateCondicaoPagamentoFromDataRow(row);
                    condicoesEncontradas.Add(condicaoPagamento);
                }
            }
            catch (Exception ex)
            {
                aVerificacao.HandleException("Erro ao buscar condições de pagamento", ex);
                return null;
            }

            return condicoesEncontradas;
        }
    }
}
