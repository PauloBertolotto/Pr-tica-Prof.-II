﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_ContasPagar
    {
        DAO_ContasPagar contasPagarDAO = new DAO_ContasPagar();
        public string AdicionarContaPagar(ContasPagar contaPagar)
        {
            return contasPagarDAO.AdicionarContaPagar(contaPagar);
        }

        public string AtualizarContaPagar(ContasPagar contaPagar)
        {
            return contasPagarDAO.AtualizarContaPagar(contaPagar);
        }
        public string Quitar(ContasPagar contaPagar)
        {
            return contasPagarDAO.Quitar(contaPagar);
        }
        public bool CancelarParcela(ContasPagar contaPagar)
        {
            return contasPagarDAO.CancelarParcela(contaPagar);
        }
        public bool ExcluirContaPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor, int numParcela)
        {
            return contasPagarDAO.ExcluirContaPagar(numNFC, modeloNFC, serieNFC, numFornecedor, numParcela);
        }

        public ContasPagar BuscarContaPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor, int numParcela)
        {
            return contasPagarDAO.BuscarContaPagar(numNFC, modeloNFC, serieNFC, numFornecedor, numParcela);
        }
        public List<ContasPagar> BuscarContasPorNomeFornecedor(string nome)
        {
            return contasPagarDAO.BuscarContasPorNomeFornecedor(nome);
        }
        public List<ContasPagar> BuscarContas(int numNFC, int modeloNFC, int serieNFC, int numFornecedor, int ParcelaNFC)
        {
            return contasPagarDAO.BuscarContas(numNFC, modeloNFC, serieNFC, numFornecedor, ParcelaNFC);
        }
        public bool VerificarExistenciaDeCompra(int numNFC, int modeloNFC, int serieNFC, int numFornecedor)
        {
            return contasPagarDAO.VerificarExistenciaDeNota(numNFC, modeloNFC, serieNFC, numFornecedor);
        }

        public string VerificarContasAPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor)
        {
            List<ContasPagar> contasVerificadas = contasPagarDAO.ListarContasAPagarPorNumero(numNFC, modeloNFC, serieNFC, numFornecedor);

            foreach (ContasPagar conta in contasVerificadas)
            {
                if (conta.Situacao != "PAGO")
                {
                    return "NOT";
                }
            }
            return "OK";
        }
        public List<ContasPagar> VerificarListaContasAPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor)
        {
           
            List<ContasPagar> contasVerificadas = contasPagarDAO.ListarContasAPagarPorNumero(numNFC, modeloNFC, serieNFC, numFornecedor);

         
            List<ContasPagar> contasNaoPagas = new List<ContasPagar>();

        
            foreach (ContasPagar conta in contasVerificadas)
            {
               
                if (conta.Situacao != "PAGO")
                {
                    contasNaoPagas.Add(conta);
                }
            }
           
            return contasNaoPagas;
        }


        public List<ContasPagar> ListarContasPagar(string status)
        {
            return contasPagarDAO.ListarContasPagar(status);
        }
        public List<ContasPagar> ListarContasPagarComData(string status, DateTime DataInicio, DateTime DataFim, string TipoData)
        {
            return contasPagarDAO.ListarContasPagarComData(status, DataInicio, DataFim, TipoData);
        }
        public List<ContasPagar> ListarTodasContasPagar()
        {
            return contasPagarDAO.ListarTodasContasPagar();
        }
        public void Incluir()
        {
            FrmCadContasPagar frmCadastroContasPagar = new FrmCadContasPagar();
            frmCadastroContasPagar.Text = "Contas a Pagar";
            frmCadastroContasPagar.ShowDialog();
        }

        public void Alterar(ContasPagar contaPagar)
        {
            if (contaPagar != null)
            {
                FrmCadContasPagar frmCadastroContasPagar = new FrmCadContasPagar();
                frmCadastroContasPagar.ConhecaObj(contaPagar);
                frmCadastroContasPagar.Text = "Contas a Pagar";
                frmCadastroContasPagar.CarregarEdit();
                frmCadastroContasPagar.ShowDialog();
            }

        }
        public void AlterarData(ContasPagar contaPagar)
        {
            if (contaPagar != null)
            {
                FrmCadContasPagar frmCadastroContasPagar = new FrmCadContasPagar();
                frmCadastroContasPagar.ConhecaObj(contaPagar);
                frmCadastroContasPagar.Text = "Contas a Pagar";
                frmCadastroContasPagar.btn_Salvar.Text = "ALTERAR VENCIMENTO";
                frmCadastroContasPagar.BloquearEdit();
                frmCadastroContasPagar.dtVencimento.Enabled = true;
                frmCadastroContasPagar.CarregarEdit();
                frmCadastroContasPagar.ShowDialog();
            }

        }

        public void Excluir(ContasPagar contaPagar)
        {
            
        }

        public void Visualizar(ContasPagar contaPagar)
        {
            if (contaPagar != null)
            {
                FrmCadContasPagar frmCadastroContasPagar = new FrmCadContasPagar();
                frmCadastroContasPagar.ConhecaObj(contaPagar);
                frmCadastroContasPagar.Text = "Contas a Pagar";
                frmCadastroContasPagar.CarregarEdit();
                frmCadastroContasPagar.BloquearEdit();
                frmCadastroContasPagar.ShowDialog();
            }
        }
    }
}
