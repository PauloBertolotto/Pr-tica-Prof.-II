﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Servicos
    {
        private DAO_Servicos servicosDAL = new DAO_Servicos();

        public string AdicionarServico(Servicos servico)
        {
            return servicosDAL.AdicionarServico(servico);
        }

        public string AtualizarServico(Servicos servico)
        {
            return servicosDAL.AtualizarServico(servico);
        }

        public bool ExcluirServico(int servicoId)
        {
            return servicosDAL.ExcluirServico(servicoId);
        }

        public Servicos BuscarServicoPorId(int id)
        {
            return servicosDAL.BuscarServicoPorId(id);
        }

        public List<Servicos> ListarServicos(string status)
        {
            return servicosDAL.ListarServicos(status);
        }

        public List<Servicos> PesquisarServicosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Servicos> encontrados = servicosDAL.PesquisarServicosPorCriterio(criterio, valorPesquisa, status);
            return encontrados;
        }

        public void Incluir()
        {
            FrmCadServicos frmCadastroServicos = new FrmCadServicos();
            frmCadastroServicos.Text = "Incluir Serviço";
            frmCadastroServicos.CB_Status.Text = "Ativo";
            frmCadastroServicos.CB_Status.Enabled = false;          
            frmCadastroServicos.ShowDialog();
        }

        public void Alterar(Servicos servico)
        {
            if (servico != null)
            {
                FrmCadServicos frmCadastroServicos = new FrmCadServicos();
                frmCadastroServicos.ConhecaObj(servico);
                frmCadastroServicos.Text = "Alterar Serviço";
                frmCadastroServicos.btn_Salvar.Text = "Alterar";              
                frmCadastroServicos.CarregarEdit();               
                frmCadastroServicos.ShowDialog();
            }
        }

        public void Excluir(Servicos servico)
        {
            if (servico != null)
            {
                FrmCadServicos frmCadastroServicos = new FrmCadServicos();
                frmCadastroServicos.ConhecaObj(servico);
                frmCadastroServicos.Text = "Excluir Serviço";
                frmCadastroServicos.btn_Salvar.Text = "Excluir";
                frmCadastroServicos.CarregarEdit();
                frmCadastroServicos.BloquearEdit();
                frmCadastroServicos.ShowDialog();
            }
        }

        public void Visualizar(Servicos servico)
        {
            if (servico != null)
            {
                FrmCadServicos frmCadastroServicos = new FrmCadServicos();
                frmCadastroServicos.ConhecaObj(servico);
                frmCadastroServicos.Text = "Consultar Serviço";
                frmCadastroServicos.CarregarEdit();
                frmCadastroServicos.BloquearEdit();
                frmCadastroServicos.btn_Salvar.Enabled = false;
                frmCadastroServicos.ShowDialog();
            }
        }
    }
}
