﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_ContasReceber : Controller
    {
        private DAO_ContasReceber aDAO_contasReceber = new DAO_ContasReceber();

        public string AdicionarContaReceber(ContasReceber contaReceber)
        {
            return aDAO_contasReceber.AdicionarContaReceber(contaReceber);
        }

        public string AtualizarContaReceber(ContasReceber contaReceber)
        {
            return aDAO_contasReceber.AtualizarContaReceber(contaReceber);
        }

        public string Quitar(ContasReceber contaReceber)
        {
            return aDAO_contasReceber.Quitar(contaReceber);
        }

        public bool CancelarParcela(ContasReceber contaReceber)
        {
            return aDAO_contasReceber.CancelarParcela(contaReceber);
        }
        public List<ContasReceber> ListarContasReceber(string status)
        {
            return aDAO_contasReceber.ListarContasReceber(status);
        }
        public List<ContasReceber> BuscarContas(int numNFC, int modeloNFC, int serieNFC, int ParcelaNFC)
        {
            return aDAO_contasReceber.BuscarContas(numNFC, modeloNFC, serieNFC, ParcelaNFC);
        }
        public ContasReceber BuscarContasReceber(int numNFC, int modeloNFC, int serieNFC, int ParcelaNFC)
        {
            return aDAO_contasReceber.BuscarContaReceber(numNFC, modeloNFC, serieNFC, ParcelaNFC);
        }
        public List<ContasReceber> ListarContasReceberComData(string status, DateTime DataInicio, DateTime DataFim, string TipoData)
        {
            return aDAO_contasReceber.ListarContasReceberComData(status, DataInicio, DataFim, TipoData);
        }
        public void Incluir()
        {
            FrmCadContasReceber frmCadastroContasReceber = new FrmCadContasReceber();
            frmCadastroContasReceber.Text = "Contas a Receber";
            frmCadastroContasReceber.ShowDialog();
        }

        public void Alterar(ContasReceber contaReceber)
        {
            if (contaReceber != null)
            {
                FrmCadContasReceber frmCadastroContasReceber = new FrmCadContasReceber();
                frmCadastroContasReceber.ConhecaObj(contaReceber);
                frmCadastroContasReceber.Text = "Contas a Receber";
                frmCadastroContasReceber.CarregarEdit();
                frmCadastroContasReceber.ShowDialog();
            }
        }

        public void Excluir(ContasReceber contaReceber)
        {
            // Implemente a lógica para abrir o formulário de exclusão de contas a receber
        }

        public void Visualizar(ContasReceber contaReceber)
        {
            if (contaReceber != null)
            {
                FrmCadContasReceber frmCadastroContasReceber = new FrmCadContasReceber();
                frmCadastroContasReceber.ConhecaObj(contaReceber);
                frmCadastroContasReceber.Text = "Contas a Receber";
                frmCadastroContasReceber.CarregarEdit();
                frmCadastroContasReceber.BloquearEdit();
                frmCadastroContasReceber.ShowDialog();
            }
        }
    }
}
