﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99
{
    public partial class FrmPai : Form
    {
        public FrmPai()
        {
            InitializeComponent();
        }
        public virtual void Sair()
        {
            Close();
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            Sair();
        }

        private void FrmPai_Load(object sender, EventArgs e)
        {


        }

        private void FrmPai_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                // Feche o formulário
                this.Close();
            }
        }
    }
}
