﻿using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    public class ContasReceber : Pai
    {
        protected int _numNFC;
        protected int _modeloNFC;
        protected int _serieNFC;
        protected int _numParcela;
        protected DadosCadastro _cliente;
        protected CondicaoPagamento _condicao;
        protected decimal _valor;
        protected string _situacao;
        protected DateTime _dataBaixa;
        protected DateTime _dataVencimento;
        protected DateTime _dataCriacao;
        protected DateTime _dataUltAlteracao;
        protected decimal _pagamento;
        protected FormaPagamento _formaPagamento;

        public ContasReceber()
        {
            _numNFC = 0;
            _modeloNFC = 0;
            _serieNFC = 0;
            _numParcela = 0;
            _cliente = new DadosCadastro();
            _condicao = new CondicaoPagamento();
            _valor = 0m;
            _situacao = "";
            _dataBaixa = DateTime.Now;
            _dataVencimento = DateTime.Now;
            _dataCriacao = DateTime.Now;
            _dataUltAlteracao = DateTime.Now;
            _pagamento = 0m;
            _formaPagamento = new FormaPagamento();
        }

        public ContasReceber(FormaPagamento forma, decimal pagamento, int numNFC, int modeloNFC, int serieNFC, int numParcela, DadosCadastro cliente, CondicaoPagamento condicao, decimal valor, string situacao, DateTime dataBaixa, DateTime dataVencimento, DateTime dataCriacao, DateTime dataUltAlteracao)
        {
            _numNFC = numNFC;
            _modeloNFC = modeloNFC;
            _serieNFC = serieNFC;
            _numParcela = numParcela;
            _cliente = cliente;
            _condicao = condicao;
            _valor = valor;
            _situacao = situacao;
            _dataBaixa = dataBaixa;
            _dataVencimento = dataVencimento;
            _dataCriacao = dataCriacao;
            _dataUltAlteracao = dataUltAlteracao;
            _pagamento = pagamento;
            _formaPagamento = forma;
        }

        public decimal Pagamento
        {
            get => _pagamento;
            set => _pagamento = value;
        }
        public int NumNFC
        {
            get => _numNFC;
            set => _numNFC = value;
        }

        public int ModeloNFC
        {
            get => _modeloNFC;
            set => _modeloNFC = value;
        }

        public int SerieNFC
        {
            get => _serieNFC;
            set => _serieNFC = value;
        }

        public int NumParcela
        {
            get => _numParcela;
            set => _numParcela = value;
        }

        public DadosCadastro Cliente
        {
            get => _cliente;
            set => _cliente = value;
        }

        public FormaPagamento FormaPagamento
        {
            get => _formaPagamento;
            set => _formaPagamento = value;
        }
        public CondicaoPagamento Condicao
        {
            get => _condicao;
            set => _condicao = value;
        }

        public decimal Valor
        {
            get => _valor;
            set => _valor = value;
        }

        public string Situacao
        {
            get => _situacao;
            set => _situacao = value;
        }

        public DateTime DataBaixa
        {
            get => _dataBaixa;
            set => _dataBaixa = value;
        }

        public DateTime DataVencimento
        {
            get => _dataVencimento;
            set => _dataVencimento = value;
        }

        public DateTime DataUltAlteracao
        {
            get => _dataUltAlteracao;
            set => _dataUltAlteracao = value;
        }
    }
}
