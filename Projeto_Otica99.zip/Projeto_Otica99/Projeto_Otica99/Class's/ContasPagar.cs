﻿using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    public class ContasPagar  
    {
        private int _numNFC;
        private int _modeloNFC;
        private int _serieNFC;
        private int _numParcela;
        private DadosCadastro _fornecedor;
        private CondicaoPagamento _condicao;
        private decimal _valor;
        private string _situacao;
        private DateTime _dataBaixa;
        private DateTime _dataVencimento;
        private DateTime _dataCriacao;
        private DateTime _dataUltAlteracao;
        private decimal _pagamento;
        private FormaPagamento _formaPagamento;

        public ContasPagar()
        {
            _numNFC = 0;
            _modeloNFC = 0;
            _serieNFC = 0;
            _numParcela = 0;
            _fornecedor = new DadosCadastro();
            _condicao = new CondicaoPagamento();
            _valor = 0m;
            _situacao = "";
            _dataBaixa = DateTime.Now;
            _dataVencimento = DateTime.Now;
            _dataCriacao = DateTime.Now;
            _dataUltAlteracao = DateTime.Now;
            _pagamento = 0m;
            _formaPagamento = new FormaPagamento();
        }

        public ContasPagar(FormaPagamento forma, decimal pagamento, int numNFC, int modeloNFC, int serieNFC, int numParcela, DadosCadastro fornecedor, CondicaoPagamento condicao, decimal valor, string situacao, DateTime dataBaixa, DateTime dataVencimento, DateTime dataCriacao, DateTime dataUltAlteracao)
        {
            _numNFC = numNFC;
            _modeloNFC = modeloNFC;
            _serieNFC = serieNFC;
            _numParcela = numParcela;
            _fornecedor = fornecedor;
            _condicao = condicao;
            _valor = valor;
            _situacao = situacao;
            _dataBaixa = dataBaixa;
            _dataVencimento = dataVencimento;
            _dataCriacao = dataCriacao;
            _dataUltAlteracao = dataUltAlteracao;
            _pagamento = pagamento;
            _formaPagamento = forma;
        }

        public decimal Pagamento
        {
            get => _pagamento;
            set => _pagamento = value;
        }
        public int NumNFC
        {
            get => _numNFC;
            set => _numNFC = value;
        }

        public int ModeloNFC
        {
            get => _modeloNFC;
            set => _modeloNFC = value;
        }

        public int SerieNFC
        {
            get => _serieNFC;
            set => _serieNFC = value;
        }

        public int NumParcela
        {
            get => _numParcela;
            set => _numParcela = value;
        }

        public DadosCadastro Fornecedor
        {
            get => _fornecedor;
            set => _fornecedor = value;
        }

        public FormaPagamento FormaPagamento
        {
            get => _formaPagamento;
            set => _formaPagamento = value;
        }
        public CondicaoPagamento Condicao
        {
            get => _condicao;
            set => _condicao = value;
        }

        public decimal Valor
        {
            get => _valor;
            set => _valor = value;
        }

        public string Situacao
        {
            get => _situacao;
            set => _situacao = value;
        }

        public DateTime DataBaixa
        {
            get => _dataBaixa;
            set => _dataBaixa = value;
        }

        public DateTime DataVencimento
        {
            get => _dataVencimento;
            set => _dataVencimento = value;
        }

        public DateTime DataCriacao
        {
            get => _dataCriacao;
            set => _dataCriacao = value;
        }

        public DateTime DataUltAlteracao
        {
            get => _dataUltAlteracao;
            set => _dataUltAlteracao = value;
        }
    }
}
