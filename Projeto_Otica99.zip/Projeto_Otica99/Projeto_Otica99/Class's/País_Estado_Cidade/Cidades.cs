﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    internal class Cidades : Pai
    {
        protected string _cidade;
        protected string _ddd;
        protected int    _estadoID;
        protected string _ativo;
        public Cidades() : base()
        {
            ID        = 0;
            _cidade   = "";
            _ddd      = "";
            _estadoID = 0;
            _ativo    = "";
        }
        public Cidades(int id, string cidade, string ddd, int estadoID, string ativo, DateTime dataultAlteracao, DateTime dataCriacao) : base(id, dataCriacao, dataultAlteracao)
        {
            this.ID  = id;
            Cidade   = cidade;
            DDD      = ddd;
            EstadoID = estadoID;
            Ativo    = ativo;
        }
        public string Cidade
        {
            get => _cidade;
            set => _cidade = value;
        }

        public string DDD
        {
            get => _ddd;
            set => _ddd = value;
        }

        public int EstadoID
        {
            get => _estadoID;
            set => _estadoID = value;
        }
        public string Ativo
        {
            get => _ativo;
            set => _ativo = value;
        }
    }
}
