﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_ItensCompra
    {
        private DAO_ItensCompra aDAO_Itens = new DAO_ItensCompra();
        private ItensCompra item = new ItensCompra();


        public bool AdicionarItemCompra(ItensCompra itemCompra)
        {
            return aDAO_Itens.AdicionarItemCompra(itemCompra);
        }

        public ItensCompra BuscarItemCompraPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor, int idProduto)
        {
            return aDAO_Itens.BuscarItemCompraPorChave(numNFC, modeloNFC, serieNFC, idFornecedor, idProduto);
        }

        public List<ItensCompra> BuscarItemCompraPorChave2(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            return aDAO_Itens.BuscarItemCompraPorChave2(numNFC, modeloNFC, serieNFC, idFornecedor);
        }

        public List<ItensCompra> ListarItensCompra()
        {
            return aDAO_Itens.ListarItensCompra();
        }
    }
}
