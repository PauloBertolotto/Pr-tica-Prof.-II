﻿using Projeto_Otica99.Class_s.DAO_s;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Fornecedores : Controller
    {
        
        DAO_Fornecedores aDAO_Fornecedores;
        public Ctrl_Fornecedores() 
        {          
            aDAO_Fornecedores = new DAO_Fornecedores();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_Fornecedores.CarregaObj(obj);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Fornecedores.Salvar(obj);
        }
        
        public int BuscarIDCidade(string nome)
        {
            return aDAO_Fornecedores.BuscarIDCidade(nome);
        }
        public string BuscarCidadePorId(int id)
        {
            return aDAO_Fornecedores.BuscarCidadePorId(id);
        }

        //public List<DadosCadastro> ListarFornecedores()
        //{
        //    return aDAO_Fornecedores.ListarFornecedores();
        //}

        public DadosCadastro BuscarFornecedorPorNome(string nome)
        {
            return aDAO_Fornecedores.BuscarFornecedorPorNome(nome);
        }

        public override string Excluir(string item)
        {
            return aDAO_Fornecedores.Excluir(item);
        }
        public string BuscaUF(string cidade)
        {
            return aDAO_Fornecedores.BuscaUF(cidade);
        }
        //public List<DadosCadastro> Pesquisar(string nome)
        //{
        //    return aDAO_Fornecedores.Pesquisar(nome);
        //}
        public DadosCadastro BuscarFornecedorPorId(int id)
        {
            return aDAO_Fornecedores.BuscarFornecedorPorId(id);
        }
    }
}
