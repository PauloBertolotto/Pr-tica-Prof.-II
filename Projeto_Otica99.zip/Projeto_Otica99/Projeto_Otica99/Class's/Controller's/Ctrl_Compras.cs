﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Compras
    {
        private DAO_Compras comprasDAO = new DAO_Compras();


        public bool AdicionarCompra(Compras compra)
        {
            return comprasDAO.AdicionarCompra(compra);
        }
        public bool CancelarCompra(Compras aCompra)
        {
            return comprasDAO.CancelarCompra(aCompra);
        }
        public string BaixaCompra(Compras aCompra)
        {
            return comprasDAO.BaixaCompra(aCompra);
        }
        public Compras BuscarCompraPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            return comprasDAO.BuscarCompraPorChave(numNFC, modeloNFC, serieNFC, idFornecedor);
        }
        public bool VerificarSeCompraExiste(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            try
            {
                return comprasDAO.ExisteCompraPorChave(numNFC, modeloNFC, serieNFC, idFornecedor);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }
        }
        public List<Compras> BuscarListaCompraPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            return comprasDAO.BuscarListaComprasPorChave(numNFC, modeloNFC, serieNFC, idFornecedor);
        }
        public List<Compras> ListarCompras(bool? statusCancelada)
        {
            return comprasDAO.ListarCompras(statusCancelada);
        }

        public List<Compras> ListarComprasPorFornecedor(int codFornecedor)
        {
            // filtrar, se a compra vier com status_compra = FINALIZADO então não entra no escopo de retorno .
            return comprasDAO.ListarComprasPorFornecedor(codFornecedor);
        }

        public List<Compras> ListarCompras(DateTime? dataInicio, DateTime? dataFim, bool? Cancelada, string Fornecedor, string cbDatas)
        {
            return comprasDAO.ListarCompras(dataInicio, dataFim, Cancelada, Fornecedor, cbDatas);
        }
        public void Incluir()
        {
            FrmCadCompra frmCadastroCompra = new FrmCadCompra();
            frmCadastroCompra.Text = "Incluir Compra";
            frmCadastroCompra.ShowDialog();
        }

        public void Visualizar(Compras compra)
        {
            if (compra != null)
            {
                FrmCadCompra frmCadastroCompra = new FrmCadCompra();
                frmCadastroCompra.ConhecaObj(compra);
                frmCadastroCompra.Text = "Consultar Compra";
                //frmCadastroCompra.GbChave.Enabled = false;
                //frmCadastroCompra.Popular(compra);
                frmCadastroCompra.BloquearEdit();
                frmCadastroCompra.btn_Salvar.Enabled = false;
                frmCadastroCompra.ShowDialog();
            }
        }
        public void CancelarNota(Compras compra)
        {
            if (compra != null)
            {
                FrmCadCompra frm = new FrmCadCompra();
                frm.ConhecaObj(compra);
                frm.Text = "Cancelar Nota";

                if (compra.DataCancelamento != null)
                    frm.btn_Salvar.Text = "CANCELAR";
                //frm.GbChave.Enabled = false;
                //frm.Popular(compra);
                frm.BloquearEdit();
                frm.ShowDialog();
            }
        }
    }
}
