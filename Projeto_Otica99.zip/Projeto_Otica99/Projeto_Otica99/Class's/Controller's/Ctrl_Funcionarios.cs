﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Funcionarios : Controller
    {
        DAO_Funcionarios aDAO_Funcionarios;
        public Ctrl_Funcionarios() 
        {
            aDAO_Funcionarios = new DAO_Funcionarios();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_Funcionarios.CarregaObj(obj);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Funcionarios.Salvar(obj);
        }

        public int BuscarIDCidade(string nome)
        {
            return aDAO_Funcionarios.BuscarIDCidade(nome);
        }
        public string BuscarCidadePorId(int id)
        {
            return aDAO_Funcionarios.BuscarCidadePorId(id);
        }

        //public List<DadosCadastro> ListarFuncionarios()
        //{
        //    return aDAO_Funcionarios.ListarFuncionarios();
        //}

        public virtual string Excluir(string item)
        {
            return aDAO_Funcionarios.Excluir(item);
        }
        public string BuscaUF(string cidade)
        {
            return aDAO_Funcionarios.BuscaUF(cidade);
        }
        //public List<DadosCadastro> Pesquisar(string nome)
        //{
        //    return aDAO_Funcionarios.Pesquisar(nome);
        //}
    }
}
