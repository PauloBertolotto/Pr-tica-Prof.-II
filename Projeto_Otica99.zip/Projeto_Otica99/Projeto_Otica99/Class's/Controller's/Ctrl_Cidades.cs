﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Cidades : Controller
    {
        DAO_Cidades aDAO_Cidades;
        public Ctrl_Cidades()
        {
            aDAO_Cidades = new DAO_Cidades();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_Cidades.CarregaObj(obj);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Cidades.Salvar(obj);
        }
        public override string Excluir(string item)
        {
            return aDAO_Cidades.Excluir(item);
        }
        public List<Cidades> Pesquisar(string nome)
        {
            return aDAO_Cidades.Pesquisar(nome);
        }
        public List<Cidades> ListarCidades()
        {
            return aDAO_Cidades.ListarCidades();
        }
        public string BuscarEstadoPorId(int id)
        {
            return aDAO_Cidades.BuscarEstadoPorId(id);
        }
        public int BuscarIDEstado(string nome)
        {
            return aDAO_Cidades.BuscarIDEstado(nome);
        }
    }
}
