﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Funcionarios : DAO
    {
        DB oDB;
        public DAO_Funcionarios()
        {
            oDB = new DB();
        }
        public override string CarregaObj(object obj)
        {
            DadosCadastro oFuncionario = (DadosCadastro)obj;
            string ok = "";

            try
            {
                string sql = "select * from Funcionario where ID_Funcionario = '" + Convert.ToString(oFuncionario.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    oFuncionario.ID = Convert.ToInt32(dr.GetValue(0));
                    oFuncionario.HistoricoID = Convert.ToInt32(dr.GetValue(1));
                    oFuncionario.CidadeID = Convert.ToInt32(dr.GetValue(2));

                    oFuncionario.NomeOuNomeFantasia = dr.GetString(3);
                    oFuncionario.SobrenomeOuRSocial = dr.GetString(4);
                    oFuncionario.Endereco = dr.GetString(5);
                    oFuncionario.Complemento = dr.GetString(6);
                    oFuncionario.Numero = dr.GetString(7);
                    oFuncionario.Bairro = dr.GetString(8);
                    oFuncionario.CEP = dr.GetString(9);
                    oFuncionario.Telefone = dr.GetString(10);
                    oFuncionario.Email = dr.GetString(11);
                    oFuncionario.CPFouCNPJ = dr.GetString(12);
                    oFuncionario.RGouIE = dr.GetString(13);
                    oFuncionario.Sexo = dr.GetString(14);
                    oFuncionario.Ativo = dr.GetString(15);

                    oFuncionario.DataCriacao = dr.GetDateTime(16);
                    oFuncionario.DataUltimaAlteracao = dr.GetDateTime(17);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            DadosCadastro oFuncionario = (DadosCadastro)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Funcionario (HistoricoID, CidadeID, NomeOuNomeFantasia, SobrenomeOuRSocial, Endereco, Complemento, Numero, Bairro, CEP, Telefone, Email, CPFouCNPJ, RGouIE, Sexo, Ativo, DataEntrada, DataUltimaAlteracao) " +
        "VALUES (@HistoricoID, @CidadeID, @NomeOuNomeFantasia, @SobrenomeOuRSocial, @Endereco, @Complemento, @Numero, @Bairro, @CEP, @Telefone, @Email, @CPFouCNPJ, @RGouIE, @Sexo, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oFuncionario.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Funcionario SET HistoricoID = @HistoricoID, CidadeID = @CidadeID, NomeOuNomeFantasia = @NomeOuNomeFantasia, SobrenomeOuRSocial = @SobrenomeOuRSocial, Endereco = @Endereco, Complemento = @Complemento, Numero = @Numero, Bairro = @Bairro, CEP = @CEP, Telefone = @Telefone, Email = @Email, CPFouCNPJ = @CPFouCNPJ,RGouIE =@RGouIE ,Sexo = @Sexo ,Ativo =@Ativo ,DataUltimaAlteracao=@DataUltimaAlteracao WHERE ID_Funcionario =@ID_Funcionario";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oFuncionario.ID != 0)
            {
                cnn.Parameters.AddWithValue("@ID_Funcionario", oFuncionario.ID);
            }
            cnn.Parameters.AddWithValue("@HistoricoID", oFuncionario.HistoricoID);
            cnn.Parameters.AddWithValue("@CidadeID", oFuncionario.CidadeID);
            cnn.Parameters.AddWithValue("@NomeOuNomeFantasia", oFuncionario.NomeOuNomeFantasia);
            cnn.Parameters.AddWithValue("@SobrenomeOuRSocial", oFuncionario.SobrenomeOuRSocial);
            cnn.Parameters.AddWithValue("@Endereco", oFuncionario.Endereco);
            cnn.Parameters.AddWithValue("@Complemento", oFuncionario.Complemento);
            cnn.Parameters.AddWithValue("@Numero", oFuncionario.Numero);
            cnn.Parameters.AddWithValue("@Bairro", oFuncionario.Bairro);
            cnn.Parameters.AddWithValue("@CEP", oFuncionario.CEP);
            cnn.Parameters.AddWithValue("@Telefone", oFuncionario.Telefone);
            cnn.Parameters.AddWithValue("@Email", oFuncionario.Email);
            cnn.Parameters.AddWithValue("@CPFouCNPJ", oFuncionario.CPFouCNPJ);
            cnn.Parameters.AddWithValue("@RGouIE", oFuncionario.RGouIE);
            cnn.Parameters.AddWithValue("@Sexo", oFuncionario.Sexo);
            cnn.Parameters.AddWithValue("@Ativo", oFuncionario.Ativo);


            cnn.Parameters.AddWithValue("@DataEntrada", oFuncionario.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", oFuncionario.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();

            cnn.Connection.Close();

            return ok;
        }
        public override string Excluir(string item)
        {
            string ok = "";

            try
            {
                string sql = "UPDATE Funcionario SET Ativo = 'I' WHERE ID_Funcionario = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        //public List<DadosCadastro> Pesquisar(string nome)
        //{
        //    List<DadosCadastro> lista = new List<DadosCadastro>();
        //    SqlCommand cnn = new SqlCommand();
        //    cnn.Connection = DB.Abrir();
        //    cnn.CommandType = System.Data.CommandType.Text;
        //
        //    cnn.CommandText = "select * from Funcionario where SobrenomeOuRSocial = '" + nome + "'";
        //    var dr = cnn.ExecuteReader();
        //    while (dr.Read())
        //    {
        //        lista.Add(new DadosCadastro(
        //        Convert.ToInt32(dr.GetValue(0)), //ID
        //        Convert.ToInt32(dr.GetValue(1)), //HistoricoID
        //        Convert.ToInt32(dr.GetValue(2)), //CidadeID
        //
        //        dr.GetString(3),                 // NomeOuNFantasia
        //        dr.GetString(4),                 // SobrenomeOURSocial
        //        dr.GetString(5),                 // Endereço
        //        dr.GetString(6),                 // Complemento
        //        dr.GetString(7),                 // Numero
        //        dr.GetString(8),                 // Bairro
        //        dr.GetString(9),                 // CEP
        //        dr.GetString(10),                // Telefone
        //        dr.GetString(11),                // Email
        //        dr.GetString(12),                // CPFouCNPJ
        //        dr.GetString(13),                // RGouIE
        //        dr.GetString(15),                // Sexo 
        //        dr.GetString(14),                // Ativo                       
        //
        //        dr.GetDateTime(16),
        //        dr.GetDateTime(17)
        //        ));
        //    }
        //    return lista;
        //}

        //public List<DadosCadastro> ListarFuncionarios()
        //{
        //    List<DadosCadastro> lista = new List<DadosCadastro>();
        //    SqlCommand cnn = new SqlCommand();
        //    cnn.Connection = DB.Abrir();
        //    cnn.CommandType = System.Data.CommandType.Text;
        //
        //    cnn.CommandText = "Select * from Funcionario";
        //    var dr = cnn.ExecuteReader();
        //    while (dr.Read())
        //    {
        //        lista.Add(new DadosCadastro(
        //        Convert.ToInt32(dr.GetValue(0)), //ID
        //        Convert.ToInt32(dr.GetValue(1)), //HistoricoID
        //        Convert.ToInt32(dr.GetValue(2)), //CidadeID
        //
        //        dr.GetString(3),                 // NomeOuNFantasia
        //        dr.GetString(4),                 // SobrenomeOURSocial
        //        dr.GetString(5),                 // Endereço
        //        dr.GetString(6),                 // Complemento
        //        dr.GetString(7),                 // Numero
        //        dr.GetString(8),                 // Bairro
        //        dr.GetString(9),                 // CEP
        //        dr.GetString(10),                // Telefone
        //        dr.GetString(11),                // Email
        //        dr.GetString(12),                // CPFouCNPJ
        //        dr.GetString(13),                // RGouIE
        //        dr.GetString(15),                // Sexo 
        //        dr.GetString(14),                // Ativo                       
        //
        //        dr.GetDateTime(16),
        //        dr.GetDateTime(17)
        //        ));
        //    }
        //    return lista;
        //}

        public int BuscarIDCidade(string nome)
        {
            int IDCidade = 0;
            try
            {
                string sql = "select ID_Cidade from Cidade where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDCidade = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {

            }
            if (IDCidade == 0)
            {
                MessageBox.Show("Cidade não encontrada!");
            }
            return IDCidade;
        }
        public string BuscarCidadePorId(int id)
        {

            string ok = "";
            try
            {
                string sql = "select Nome from Cidade where ID_Cidade = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public string BuscaUF(string cidade)
        {
            string uf = "";
            try
            {
                string sql = "SELECT e.UF FROM [dbo].[Cidade] c JOIN [dbo].[Estado] e ON c.EstadoID = e.ID_Estado WHERE c.Nome = @NomeCidade";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = DB.Abrir();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@NomeCidade", cidade);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    uf = dr.GetString(0);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                uf = "Erro";
            }
            return uf;
        }
    }
}
