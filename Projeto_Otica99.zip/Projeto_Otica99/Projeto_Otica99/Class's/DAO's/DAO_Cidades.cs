﻿using Projeto_Otica99.Class_s.Controller_s;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Cidades : DAO
    {
        DB oDB;
        
        public DAO_Cidades()
        {
            oDB = new DB();
        }
        public override string CarregaObj(object obj)
        {
            Cidades aCidade = (Cidades)obj;
            string ok = "";
        
            try
            {
                string sql = "select * from Cidade where ID_Cidade = '" + Convert.ToString(aCidade.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    aCidade.ID                  = Convert.ToInt32(dr.GetValue(0));
                    aCidade.Cidade              = dr.GetString(1);
                    aCidade.DDD                 = dr.GetString(2);
                    aCidade.EstadoID            = Convert.ToInt32(dr.GetValue(3));
                    aCidade.Ativo               = dr.GetString(4);
                    aCidade.DataCriacao         = dr.GetDateTime(5);
                    aCidade.DataUltimaAlteracao = dr.GetDateTime(6);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {
        
            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            Cidades aCidade = (Cidades)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Cidade (Nome, DDD, EstadoID, Ativo, DataEntrada, DataUltimaAlteracao) " + 
                "VALUES (@Nome, @DDD, @EstadoID, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (aCidade.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Cidade SET NOME = @Nome, DDD = @DDD, ESTADOID = @EstadoID, Ativo = @Ativo, DataUltimaAlteracao = @DataUltimaAlteracao WHERE ID_Cidade = @ID";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (aCidade.ID != 0)
            {
                cnn.Parameters.AddWithValue("@Id",              aCidade.ID);
            }
            cnn.Parameters.AddWithValue("@Nome",                aCidade.Cidade);
            cnn.Parameters.AddWithValue("@DDD",                 aCidade.DDD);
            cnn.Parameters.AddWithValue("@EstadoID",            aCidade.EstadoID);
            cnn.Parameters.AddWithValue("@Ativo",               aCidade.Ativo);
            cnn.Parameters.AddWithValue("@DataEntrada",         aCidade.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", aCidade.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();
            cnn.Connection.Close();
            return ok;
        }

        public override string Excluir(string item)
        {
            string ok = "";
        
            try
            {
                string sql = "UPDATE Cidade SET Ativo = 'I' WHERE ID_Cidade = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {
        
            }
            return ok;
        }
        
        public List<Cidades> Pesquisar(string nome)
        {
            List<Cidades> lista = new List<Cidades>();
            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandType = System.Data.CommandType.Text;
        
            cnn.CommandText = "select * from Cidade where Nome = '" + nome + "'";
            var dr = cnn.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new Cidades(
                Convert.ToInt32(dr.GetValue(0)),
                dr.GetString(1),
                dr.GetString(2),
                Convert.ToInt32(dr.GetValue(3)),
                dr.GetString(4),
                dr.GetDateTime(5),
                dr.GetDateTime(6)
            ));
            }
            return lista;
        }
        
        
        public List<Cidades> ListarCidades()
        {
            List<Cidades> lista = new List<Cidades>();
            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandType = System.Data.CommandType.Text;
        
            cnn.CommandText = "Select * from Cidade";
            var dr = cnn.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new Cidades(
                    Convert.ToInt32(dr.GetValue(0)),
                    dr.GetString(1),
                    dr.GetString(2),
                    Convert.ToInt32(dr.GetValue(3)),
                    dr.GetString(4),
                    dr.GetDateTime(5),
                    dr.GetDateTime(6)
                    ));
            }
            return lista;
        }
        public string BuscarEstadoPorId(int id)
        {
        
            string ok = "";
            try
            {
                string sql = "select Nome from Estado where ID_Estado = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {
        
            }
            return ok;
        }
        public int BuscarIDEstado(string nome)
        {
            int IDPais = 0;
            try
            {
                string sql = "select ID_Estado from Estado where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDPais = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {
        
            }
            if (IDPais == 0)
            {
                MessageBox.Show("Estado não encontrado!");
            }
            return IDPais;
        }


}
}
