﻿using Projeto_Otica99.Class_s.Controller_s;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_ItensVenda
    {
        private DB banco = new DB();

        public bool AdicionarItemVenda(ItensVenda itemVenda)
        {
            try
            {
                string sql = "INSERT INTO tb_itens_vendas (num_nfv, modelo_nfv, serie_nfv, id_cliente, id_item, tipo_item, qtd_item, preco_unitario, total_item, desconto, data_criacao) " +
                             "VALUES (@NumNFV, @ModeloNFV, @SerieNFV, @IdCliente, @IdItem, @TipoItem, @QtdItem, @PrecoUnitario, @TotalItem, @Desconto, @DataCriacao)";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFV", itemVenda.NumNfv),
                    new SqlParameter("@ModeloNFV", itemVenda.ModeloNfv),
                    new SqlParameter("@SerieNFV", itemVenda.SerieNfv),
                    new SqlParameter("@IdCliente", itemVenda.Cliente.ID),
                    new SqlParameter("@IdItem", itemVenda.IdItem),
                    new SqlParameter("@TipoItem", itemVenda.TipoItem),
                    new SqlParameter("@QtdItem", itemVenda.QtdItem),
                    new SqlParameter("@PrecoUnitario", itemVenda.PrecoUnitario),
                    new SqlParameter("@TotalItem", itemVenda.TotalItem),
                    new SqlParameter("@Desconto", (object)itemVenda.Desconto ?? DBNull.Value), // Tratando valor nulo
                    new SqlParameter("@DataCriacao", itemVenda.DataCriacao)
                };
                var retorno = banco.ExecutarComandostr(sql, parametros);
                if (retorno == "OK")
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public List<ItensVenda> BuscarItensVendaPorChave2(int numNFV, int modeloNFV, int serieNFV)
        {
            try
            {
                string sql = "SELECT * FROM tb_itens_vendas WHERE num_nfv = @NumNFV AND modelo_nfv = @ModeloNFV AND serie_nfv = @SerieNFV ";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFV", numNFV),
                    new SqlParameter("@ModeloNFV", modeloNFV),
                    new SqlParameter("@SerieNFV", serieNFV)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                List<ItensVenda> itensVenda = new List<ItensVenda>();
                foreach (DataRow row in dataTable.Rows)
                {
                    itensVenda.Add(CreateItemVendaFromDataRow(row));
                }

                return itensVenda;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<ItensVenda>();
            }
        }

        public ItensVenda BuscarItemVendaPorChave(int numNFV, int modeloNFV, int serieNFV, int idCliente, int idItem, string tipoItem)
        {
            try
            {
                string sql = "SELECT * FROM tb_itens_vendas WHERE num_nfv = @NumNFV AND modelo_nfv = @ModeloNFV AND serie_nfv = @SerieNFV AND id_cliente = @IdCliente AND id_item = @IdItem AND tipo_item = @TipoItem";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFV", numNFV),
                    new SqlParameter("@ModeloNFV", modeloNFV),
                    new SqlParameter("@SerieNFV", serieNFV),
                    new SqlParameter("@IdCliente", idCliente),
                    new SqlParameter("@IdItem", idItem),
                    new SqlParameter("@TipoItem", tipoItem)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateItemVendaFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public List<ItensVenda> ListarItensVenda()
        {
            try
            {
                string sql = "SELECT * FROM tb_itens_vendas";
                DataTable dataTable = banco.ExecutarConsulta(sql, null);
                return CreateItensVendaListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<ItensVenda>();
            }
        }
        private ItensVenda CreateItemVendaFromDataRow(DataRow row)
        {
            if (row == null)
            {
                throw new ArgumentNullException(nameof(row), "O DataRow não pode ser null.");
            }

            Ctrl_Produtos aCTLProdutos = new Ctrl_Produtos();
            Produtos produto = null;
            if (row["tipo_item"].ToString().Trim().ToUpper() == "P")
            {
                produto = aCTLProdutos.BuscarProdutoPorId(Convert.ToInt32(row["id_item"]));
                if (produto == null)
                {
                    throw new NullReferenceException("Produto não encontrado.");
                }
            }

            Ctrl_Servicos aCTLServico = new Ctrl_Servicos();
            Servicos servico = null;
            if (row["tipo_item"].ToString().Trim().ToUpper() == "S")
            {
                servico = aCTLServico.BuscarServicoPorId(Convert.ToInt32(row["id_item"]));
                if (servico == null)
                {
                    throw new NullReferenceException("Serviço não encontrado.");
                }
            }

            Ctrl_Clientes aCTLCliente = new Ctrl_Clientes();
            DadosCadastro cliente = aCTLCliente.BuscarClientePorId(Convert.ToInt32(row["id_cliente"]));
            if (cliente == null)
            {
                throw new NullReferenceException("Cliente não encontrado.");
            }

            ItensVenda itemVenda = new ItensVenda
            {
                NumNfv = Convert.ToInt32(row["num_nfv"]),
                ModeloNfv = Convert.ToInt32(row["modelo_nfv"]),
                SerieNfv = Convert.ToInt32(row["serie_nfv"]),
                Cliente = cliente,
                IdItem = Convert.ToInt32(row["id_item"]),
                TipoItem = row["tipo_item"].ToString().Trim(),
                QtdItem = Convert.ToInt32(row["qtd_item"]),
                PrecoUnitario = Convert.ToDecimal(row["preco_unitario"]),
                TotalItem = Convert.ToDecimal(row["total_item"]),
                Desconto = row["desconto"] != DBNull.Value ? Convert.ToDecimal(row["desconto"]) : (decimal?)null,
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                Descricao = string.Empty  // Inicializa com uma string vazia
            };

            
            if (row["tipo_item"].ToString().Trim().ToUpper() == "P")
            {
                itemVenda.Descricao = produto.Nome.ToString(); 
            }
            else if (row["tipo_item"].ToString().Trim().ToUpper() == "S")
            {
                itemVenda.Descricao = servico.Descricao.ToString(); 
            }

            return itemVenda;
        }

        private List<ItensVenda> CreateItensVendaListFromDataTable(DataTable dataTable)
        {
            List<ItensVenda> itensVenda = new List<ItensVenda>();
            foreach (DataRow row in dataTable.Rows)
            {
                itensVenda.Add(CreateItemVendaFromDataRow(row));
            }
            return itensVenda;
        }
    }
}
