﻿using Projeto_Otica99.Class_s.Controller_s;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_ItensCompra
    {
        private DB banco = new DB();


        public bool AdicionarItemCompra(ItensCompra itemCompra)
        {
            try
            {
                string sql = "INSERT INTO Itens_compras (num_nfc, modelo_nfc, serie_nfc, id_fornecedor, id_produto, qtd_produto, preco_custo, total_custo, percentual_compra, media_ponderada, data_criacao, Desconto) " +
                             "VALUES (@NumNFC, @ModeloNFC, @SerieNFC, @IdFornecedor, @IdProduto, @QtdProduto, @PrecoCusto, @TotalCusto, @PercentualCompra, @MediaPonderada, @DataCriacao, @Desconto)";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFC", itemCompra.NumNFC),
                    new SqlParameter("@ModeloNFC", itemCompra.ModeloNFC),
                    new SqlParameter("@SerieNFC", itemCompra.SerieNFC),
                    new SqlParameter("@IdFornecedor", itemCompra.Fornecedor.ID),
                    new SqlParameter("@IdProduto", itemCompra.Produto.ID),
                    new SqlParameter("@QtdProduto", itemCompra.QtdProduto),
                    new SqlParameter("@PrecoCusto", itemCompra.PrecoCusto),
                    new SqlParameter("@TotalCusto", itemCompra.TotalCusto),
                    new SqlParameter("@PercentualCompra", itemCompra.PercentualCompra),
                    new SqlParameter("@MediaPonderada", itemCompra.MediaPonderada),
                    new SqlParameter("@DataCriacao", itemCompra.DataCriacao),
                    new SqlParameter("@Desconto", itemCompra.Desconto)
                };
                banco.ExecutarComando(sql, parametros);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<ItensCompra> BuscarItemCompraPorChave2(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            try
            {
                string sql = "SELECT * FROM Itens_compras WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFC", numNFC),
                    new SqlParameter("@ModeloNFC", modeloNFC),
                    new SqlParameter("@SerieNFC", serieNFC),
                    new SqlParameter("@IdFornecedor", idFornecedor)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                List<ItensCompra> itensCompra = new List<ItensCompra>();
                foreach (DataRow row in dataTable.Rows)
                {
                    itensCompra.Add(CreateItemCompraFromDataRow(row));
                }

                return itensCompra;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<ItensCompra>();
            }
        }


        public ItensCompra BuscarItemCompraPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor, int idProduto)
        {
            try
            {
                string sql = "SELECT * FROM Itens_compras WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor AND id_produto = @IdProduto";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFC", numNFC),
                    new SqlParameter("@ModeloNFC", modeloNFC),
                    new SqlParameter("@SerieNFC", serieNFC),
                    new SqlParameter("@IdFornecedor", idFornecedor),
                    new SqlParameter("@IdProduto", idProduto)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateItemCompraFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public List<ItensCompra> ListarItensCompra()
        {
            try
            {
                string sql = "SELECT * FROM Itens_compras";
                DataTable dataTable = banco.ExecutarConsulta(sql, null);
                return CreateItensCompraListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<ItensCompra>();
            }
        }

        private ItensCompra CreateItemCompraFromDataRow(DataRow row)
        {
            Ctrl_Fornecedores aCTLFornecedores = new Ctrl_Fornecedores();
            Ctrl_Produtos aCTLProdutos = new Ctrl_Produtos();
            DadosCadastro fornecedor = aCTLFornecedores.BuscarFornecedorPorId(Convert.ToInt32(row["id_fornecedor"]));
            Produtos produto = aCTLProdutos.BuscarProdutoPorId(Convert.ToInt32(row["id_produto"]));
            return new ItensCompra
            {
                NumNFC = Convert.ToInt32(row["num_nfc"]),
                ModeloNFC = Convert.ToInt32(row["modelo_nfc"]),
                SerieNFC = Convert.ToInt32(row["serie_nfc"]),
                Fornecedor = fornecedor,
                Produto = produto,
                QtdProduto = Convert.ToInt32(row["qtd_produto"]),
                PrecoCusto = Convert.ToDecimal(row["preco_custo"]),
                TotalCusto = Convert.ToDecimal(row["total_custo"]),
                PercentualCompra = Convert.ToDecimal(row["percentual_compra"]),
                MediaPonderada = Convert.ToDecimal(row["media_ponderada"]),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                Desconto = Convert.ToDecimal(row["desconto"]),
            };
        }

        private List<ItensCompra> CreateItensCompraListFromDataTable(DataTable dataTable)
        {
            List<ItensCompra> itensCompra = new List<ItensCompra>();
            foreach (DataRow row in dataTable.Rows)
            {
                itensCompra.Add(CreateItemCompraFromDataRow(row));
            }
            return itensCompra;
        }
    }
}
