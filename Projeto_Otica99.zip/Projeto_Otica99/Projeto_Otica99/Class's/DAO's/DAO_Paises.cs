﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Paises : DAO
    {
        DB oDB;
        public DAO_Paises()
        {
            oDB = new DB();
        }
        public override string CarregaObj(object obj)
        {
            Paises oPais = (Paises)obj;
            string ok = "";

            try
            {
                string sql = "select * from Pais where ID_Pais = '" + Convert.ToString(oPais.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    oPais.ID                  = Convert.ToInt32(dr.GetValue(0));
                    oPais.Pais                = dr.GetString(1);
                    oPais.Ddi                 = dr.GetString(2);
                    oPais.Sigla               = dr.GetString(3);
                    oPais.Ativo               = dr.GetString(4);
                    oPais.DataCriacao         = dr.GetDateTime(5);
                    oPais.DataUltimaAlteracao = dr.GetDateTime(6);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            Paises oPais = (Paises)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Pais (Nome, DDI, Sigla, Ativo, DataEntrada, DataUltimaAlteracao) " +
             "VALUES (@Nome, @DDI, @Sigla, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oPais.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Pais SET NOME = @Nome, DDI = @Ddi, Sigla = @Sigla, Ativo = @Ativo, DataUltimaAlteracao = @DataUltimaAlteracao WHERE ID_Pais = @ID";                
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oPais.ID != 0)
            {
                cnn.Parameters.AddWithValue("@Id", oPais.ID);
            }          
            cnn.Parameters.AddWithValue("@Nome", oPais.Pais);
            cnn.Parameters.AddWithValue("@DDI", oPais.Ddi);
            cnn.Parameters.AddWithValue("@Sigla", oPais.Sigla);
            cnn.Parameters.AddWithValue("@Ativo", oPais.Ativo);
            cnn.Parameters.AddWithValue("@DataEntrada", oPais.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", oPais.DataUltimaAlteracao);          
            
            cnn.ExecuteNonQuery();
            cnn.Connection.Close();
            return ok;
        }
        public override string Excluir(string item)
        {  
            string ok = "";

            try
            {
                string sql = "UPDATE Pais SET Ativo = 'I' WHERE ID_Pais = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();          
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }      

        public List<Paises> Pesquisar(string nome)
        {
            List<Paises> lista = new List<Paises>();
            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandType = System.Data.CommandType.Text;

            cnn.CommandText = "select * from Pais where Nome = '" + nome + "'";
            var dr = cnn.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new Paises(Convert.ToInt32(dr.GetValue(0)),
                    dr.GetString(1),
                    dr.GetString(2),
                    dr.GetString(3),
                    dr.GetString(4),
                    dr.GetDateTime(5),
                    dr.GetDateTime(6)
                    ));
            }
            return lista;
        }
        public List<Paises> ListarPaises()
        {
            List<Paises> lista = new List<Paises>();
            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandType = System.Data.CommandType.Text;

            cnn.CommandText = "Select * from Pais";
            var dr = cnn.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new Paises(Convert.ToInt32(dr.GetValue(0)),
                    dr.GetString(1),
                    dr.GetString(2),
                    dr.GetString(3),
                    dr.GetString(4),
                    dr.GetDateTime(5),
                    dr.GetDateTime(6)
                    ));
            }
            return lista;
        }
        public Paises BuscarPaisPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Pais WHERE id_pais = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });
        
                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreatePaisFromDataRow(row);
                }
        
                return null;
            }
            catch (Exception ex)
            {
                oDB.HandleException("Erro ao buscar país por ID", ex);
                return null;
            }
        }
        private Paises CreatePaisFromDataRow(DataRow row)
        {
            return new Paises
            {
                ID = Convert.ToInt32(row["id_pais"]),
                Pais = row["nome"].ToString(),
                Sigla = row["sigla"].ToString(),
                Ddi = row["DDI"].ToString(),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["data_ult_alteracao"])
            };
        }
    }
}
