﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Compras
    {
        private DB banco = new DB();

        public bool AdicionarCompra(Compras compra)
        {
            bool status = false;
            using (SqlConnection connection = banco.Abrir2())
            {
                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Inserir a compra
                        string sqlCompra = "INSERT INTO Compras (status_compra, num_nfc, modelo_nfc, serie_nfc, id_fornecedor, id_condicao, valor_total, valor_frete, valor_seguro, valor_outras_despesas, data_chegada, data_emissao, data_criacao) " +
                                           "VALUES (@status_compra, @NumNFC, @ModeloNFC, @SerieNFC, @IdFornecedor, @IdCondicao, @ValorTotal, @ValorFrete, @ValorSeguro, @ValorOutrasDespesas, @DataChegada, @DataEmissao, @DataCriacao)";
                        SqlParameter[] parametrosCompra =
                        {
                            new SqlParameter("@NumNFC", compra.NumNFC),
                            new SqlParameter("@ModeloNFC", compra.ModeloNFC),
                            new SqlParameter("@SerieNFC", compra.SerieNFC),
                            new SqlParameter("@IdFornecedor", compra.Fornecedor.ID),
                            new SqlParameter("@IdCondicao", compra.Condicao.ID),
                            new SqlParameter("@ValorTotal", compra.ValorTotal),
                            new SqlParameter("@ValorFrete", compra.ValorFrete),
                            new SqlParameter("@ValorSeguro", compra.ValorSeguro),
                            new SqlParameter("@ValorOutrasDespesas", compra.ValorOutrasDespesas),
                            new SqlParameter("@DataChegada", compra.DataChegada),
                            new SqlParameter("@DataEmissao", compra.DataEmissao),
                            new SqlParameter("@DataCriacao", compra.DataCriacao),
                            new SqlParameter("@status_compra", compra.StatusCompra)
                        };
                        banco.ExecutarComando(sqlCompra, parametrosCompra);

                        // Inserir os itens da compra e atualizar o estoque
                        foreach (ItensCompra itemCompra in compra.ItensCompra)
                        {
                            if (itemCompra != null)
                            {
                                // Adicionar item de compra
                                Ctrl_ItensCompra aCTLItensCompra = new Ctrl_ItensCompra();
                                itemCompra.NumNFC = compra.NumNFC;
                                itemCompra.SerieNFC = compra.SerieNFC;
                                itemCompra.ModeloNFC = compra.ModeloNFC;
                                itemCompra.Fornecedor.ID = compra.Fornecedor.ID;
                                status = aCTLItensCompra.AdicionarItemCompra(itemCompra);
                                if (!status)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("Aconteceu um erro ao salvar os itens da compra.");
                                    return false;
                                }

                                // Atualizar estoque do produto
                                Ctrl_Produtos CTLProduto = new Ctrl_Produtos();
                                Produtos produto = CTLProduto.BuscarProdutoPorId(itemCompra.Produto.ID);
                                int estoqueantigo = produto.QtdEstoque;
                                produto.ID = itemCompra.Produto.ID;
                                produto.PrecoCusto = itemCompra.MediaPonderada;
                                produto.QtdEstoque = estoqueantigo + itemCompra.QtdProduto;
                                status = CTLProduto.AtualizarEstoque(produto);
                                if (!status)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("Aconteceu um erro ao atualizar o estoque do produto.");
                                    return false;
                                }
                            }
                        }

                        // Inserir as contas a pagar
                        Ctrl_ContasPagar aCTRLContasPagar = new Ctrl_ContasPagar();
                        foreach (ContasPagar contaPagar in compra.ContasPAgar)
                        {
                            var status2 = aCTRLContasPagar.AdicionarContaPagar(contaPagar);
                            if (status2 != "OK")
                            {
                                transaction.Rollback();
                                MessageBox.Show("Aconteceu um erro ao salvar as contas a pagar.");
                                return false;
                            }
                        }

                        transaction.Commit();
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }
            return status;
        }

        public bool AdicionarCompra2(Compras compra)
        {
            bool status = false;
            using (SqlConnection connection = banco.Abrir2())
            {
                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Inserir a compra
                        string sql = "INSERT INTO tb_compras (status_compra, num_nfc, modelo_nfc, serie_nfc, id_fornecedor, id_condicao, valor_total, valor_frete, valor_seguro, valor_outras_despesas, data_chegada, data_emissao, data_criacao) " +
                                     "VALUES (@status_compra, @NumNFC, @ModeloNFC, @SerieNFC, @IdFornecedor, @IdCondicao, @ValorTotal, @ValorFrete, @ValorSeguro, @ValorOutrasDespesas, @DataChegada, @DataEmissao, @DataCriacao)";
                        SqlParameter[] parametros =
                        {
                            new SqlParameter("@NumNFC", compra.NumNFC),
                            new SqlParameter("@ModeloNFC", compra.ModeloNFC),
                            new SqlParameter("@SerieNFC", compra.SerieNFC),
                            new SqlParameter("@IdFornecedor", compra.Fornecedor.ID),
                            new SqlParameter("@IdCondicao", compra.Condicao.ID),
                            new SqlParameter("@ValorTotal", compra.ValorTotal),
                            new SqlParameter("@ValorFrete", compra.ValorFrete),
                            new SqlParameter("@ValorSeguro", compra.ValorSeguro),
                            new SqlParameter("@ValorOutrasDespesas", compra.ValorOutrasDespesas),
                            new SqlParameter("@DataChegada", compra.DataChegada),
                            new SqlParameter("@DataEmissao", compra.DataEmissao),
                            new SqlParameter("@DataCriacao", compra.DataCriacao),
                            new SqlParameter("@status_compra", compra.StatusCompra)
                        };
                        banco.ExecutarComando(sql, parametros);

                        // Inserir os itens da compra e atualizar o estoque
                        foreach (ItensCompra itemCompra in compra.ItensCompra)
                        {
                            if (itemCompra != null)
                            {
                                // Adicionar item de compra
                                Ctrl_ItensCompra aCTLItensCompra = new Ctrl_ItensCompra();
                                itemCompra.NumNFC = compra.NumNFC;
                                itemCompra.SerieNFC = compra.SerieNFC;
                                itemCompra.ModeloNFC = compra.ModeloNFC;
                                itemCompra.Fornecedor.ID = compra.Fornecedor.ID;
                                status = aCTLItensCompra.AdicionarItemCompra(itemCompra);
                                if (!status)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("Aconteceu um erro ao salvar os itens da compra.");
                                    return false;
                                }

                                // Atualizar estoque do produto
                                Ctrl_Produtos CTLProduto = new Ctrl_Produtos();
                                Produtos produto = CTLProduto.BuscarProdutoPorId(itemCompra.Produto.ID);
                                int estoqueantigo = produto.QtdEstoque;
                                produto.ID = itemCompra.Produto.ID;
                                produto.PrecoCusto = itemCompra.MediaPonderada;
                                produto.QtdEstoque = estoqueantigo + itemCompra.QtdProduto;
                                status = CTLProduto.AtualizarEstoque(produto);
                                if (!status)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("Aconteceu um erro ao atualizar o estoque do produto.");
                                    return false;
                                }
                            }
                        }

                        transaction.Commit();
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }
            return status;
        }
        public string BaixaCompra(Compras compra)
        {
            try
            {
                string sql = "UPDATE tb_compras SET status_compra = @Status WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                SqlParameter[] parametros =
                {
                     new SqlParameter("@Status", compra.StatusCompra),
                     new SqlParameter("@NumNFC", compra.NumNFC),
                     new SqlParameter("@ModeloNFC", compra.ModeloNFC),
                     new SqlParameter("@SerieNFC", compra.SerieNFC),
                     new SqlParameter("@IdFornecedor", compra.Fornecedor.ID),
                };
                banco.ExecutarComando(sql, parametros);

                // Se a execução chegou até aqui, significa que a operação foi bem-sucedida
                return "OK";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Compras> BuscarListaComprasPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            try
            {
                string sql = "SELECT * FROM tb_compras WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFC", numNFC),
                    new SqlParameter("@ModeloNFC", modeloNFC),
                    new SqlParameter("@SerieNFC", serieNFC),
                    new SqlParameter("@IdFornecedor", idFornecedor)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                List<Compras> compras = new List<Compras>();

                foreach (DataRow row in dataTable.Rows)
                {
                    Compras compra = CreateCompraFromDataRow(row);
                    compras.Add(compra);
                }

                return compras;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<Compras>();
            }
        }
        public Compras BuscarCompraPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            try
            {
                string sql = "SELECT * FROM tb_compras WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFC", numNFC),
                    new SqlParameter("@ModeloNFC", modeloNFC),
                    new SqlParameter("@SerieNFC", serieNFC),
                    new SqlParameter("@IdFornecedor", idFornecedor)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateCompraFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public bool ExisteCompraPorChave(int numNFC, int modeloNFC, int serieNFC, int idFornecedor)
        {
            try
            {
                string sql = "SELECT COUNT(*) FROM tb_compras WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@NumNFC", numNFC),
                    new SqlParameter("@ModeloNFC", modeloNFC),
                    new SqlParameter("@SerieNFC", serieNFC),
                    new SqlParameter("@IdFornecedor", idFornecedor)
                };
                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);

                if (dataTable.Rows.Count > 0)
                {
                    int count = Convert.ToInt32(dataTable.Rows[0][0]);
                    return count > 0;
                }

                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool CancelarCompra(Compras compra)
        {
            bool status = false;

            using (SqlConnection connection = banco.Abrir2())
            {
                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Obter os itens da compra
                        Ctrl_ItensCompra aCTLItensCompra = new Ctrl_ItensCompra();
                        List<ItensCompra> itensCompra = aCTLItensCompra.BuscarItemCompraPorChave2(compra.NumNFC, compra.ModeloNFC, compra.SerieNFC, compra.Fornecedor.ID);

                        // Verificar se a compra possui itens
                        if (itensCompra == null || itensCompra.Count == 0)
                        {
                            MessageBox.Show("Nenhum item encontrado para esta compra. Cancelamento abortado.");
                            return false;
                        }

                        // Atualiza a data de cancelamento da compra
                        string sql = "UPDATE tb_compras SET data_cancelamento = @DataCancelamento, status_compra =@Status WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                        SqlParameter[] parametros =
                        {
                            new SqlParameter("@DataCancelamento", DateTime.Now),
                            new SqlParameter("@NumNFC", compra.NumNFC),
                            new SqlParameter("@ModeloNFC", compra.ModeloNFC),
                            new SqlParameter("@SerieNFC", compra.SerieNFC),
                            new SqlParameter("@IdFornecedor", compra.Fornecedor.ID),
                            new SqlParameter("@Status", compra.StatusCompra)
                        };

                        banco.ExecutarComando(sql, parametros);

                        // Iterar sobre os itens da compra para ajustar o estoque
                        foreach (ItensCompra itemCompra in itensCompra)
                        {
                            if (itemCompra != null)
                            {
                                // Atualizar o estoque do produto
                                Ctrl_Produtos CTLProduto = new Ctrl_Produtos();
                                Produtos produto = CTLProduto.BuscarProdutoPorId(itemCompra.Produto.ID);
                                int estoqueAntigo = produto.QtdEstoque;
                                produto.QtdEstoque = estoqueAntigo - itemCompra.QtdProduto; // Remover a quantidade adicionada
                                status = CTLProduto.AtualizarEstoque(produto);
                                if (!status)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("Aconteceu um erro ao atualizar o estoque do produto.");
                                    return false;
                                }
                            }
                        }

                        // Atualizar as parcelas das contas a pagar para "CANCELADA"
                        Ctrl_ContasPagar aCTLConta = new Ctrl_ContasPagar();
                        List<ContasPagar> contas = aCTLConta.VerificarListaContasAPagar(compra.NumNFC, compra.ModeloNFC, compra.SerieNFC, compra.Fornecedor.ID);
                        foreach (ContasPagar conta in contas)
                        {
                            conta.Situacao = "CANCELADA"; // Definir a nova situação da parcela
                            status = aCTLConta.CancelarParcela(conta); // Chamar o método para cancelar a parcela
                            if (!status)
                            {
                                transaction.Rollback();
                                MessageBox.Show("Erro ao cancelar a parcela.");
                                return false;
                            }
                        }

                        transaction.Commit();
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }

            return status;
        }



        public bool CancelarCompra2(Compras compra)
        {
            bool status = false;

            using (SqlConnection connection = banco.Abrir2())
            {
                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Atualiza a data de cancelamento da compra
                        string sql = "UPDATE tb_compras SET data_cancelamento = @DataCancelamento WHERE num_nfc = @NumNFC AND modelo_nfc = @ModeloNFC AND serie_nfc = @SerieNFC AND id_fornecedor = @IdFornecedor";
                        SqlParameter[] parametros =
                        {
                            new SqlParameter("@DataCancelamento", DateTime.Today),
                            new SqlParameter("@NumNFC", compra.NumNFC),
                            new SqlParameter("@ModeloNFC", compra.ModeloNFC),
                            new SqlParameter("@SerieNFC", compra.SerieNFC),
                            new SqlParameter("@IdFornecedor", compra.Fornecedor.ID)
                        };

                        banco.ExecutarComando(sql, parametros);
                        transaction.Commit();
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }

            return status;
        }
        public List<Compras> ListarCompras(DateTime? dataInicio, DateTime? dataFim, bool? cancelada, string nomeFornecedor, string tipoData)
        {
            try
            {
                string sql = "SELECT * FROM tb_compras WHERE 1 = 1";

                // Adiciona filtros de data, se fornecidos, com base no tipo de data selecionado
                if (!string.IsNullOrEmpty(tipoData))
                {
                    if (tipoData == "CHEGADA")
                    {
                        if (dataInicio != null && dataFim != null)
                        {
                            sql += " AND data_chegada >= @DataInicio AND data_chegada <= @DataFim";
                        }
                    }
                    else if (tipoData == "EMISSAO")
                    {
                        if (dataInicio != null && dataFim != null)
                        {
                            sql += " AND data_emissao >= @DataInicio AND data_emissao <= @DataFim";
                        }
                    }
                    else if (tipoData == "CANCELAMENTO")
                    {
                        if (dataInicio != null && dataFim != null)
                        {
                            sql += " AND data_cancelamento >= @DataInicio AND data_cancelamento <= @DataFim";
                        }
                    }
                }

                // Adiciona filtro de compra cancelada, se fornecido
                if (cancelada != null)
                {
                    if (cancelada == true)
                    {
                        sql += " AND data_cancelamento IS NOT NULL";
                    }
                    else
                    {
                        sql += " AND data_cancelamento IS NULL";
                    }
                }

                // Adiciona filtro de nome do fornecedor, se fornecido e não vazio
                if (!string.IsNullOrEmpty(nomeFornecedor))
                {
                    sql += " AND id_fornecedor IN (SELECT id_fornecedor FROM tb_fornecedores WHERE nome_fantasia LIKE @NomeFornecedor)";
                }

                SqlParameter[] parametros =
                {
                    new SqlParameter("@DataInicio", dataInicio),
                    new SqlParameter("@DataFim", dataFim),
                    new SqlParameter("@NomeFornecedor", "%" + nomeFornecedor + "%")
                };

                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);
                return CreateComprasListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<Compras>();
            }
        }



        public List<Compras> ListarCompras(bool? statusCancelada)
        {
            try
            {
                string sql = "SELECT * FROM tb_compras WHERE 1 = 1";

                // Adiciona filtro de status cancelada, se fornecido
                if (statusCancelada != null)
                {
                    if (statusCancelada == true)
                    {
                        sql += " AND data_cancelamento IS NOT NULL";
                    }
                    else
                    {
                        sql += " AND data_cancelamento IS NULL";
                    }
                }

                DataTable dataTable = banco.ExecutarConsulta(sql, null);
                return CreateComprasListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<Compras>();
            }
        }

        public List<Compras> ListarComprasPorFornecedor(int CodFornecedor)
        {
            try
            {
                string sql = "SELECT * FROM tb_compras WHERE id_fornecedor = @CodFornecedor AND status_compra <> 'FINALIZADO' AND data_cancelamento IS NULL";

                SqlParameter[] parametros = new SqlParameter[]
                {
            new SqlParameter("@CodFornecedor", CodFornecedor)
                };

                DataTable dataTable = banco.ExecutarConsulta(sql, parametros);
                return CreateComprasListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao listar compras: " + ex.Message);
                return new List<Compras>();
            }
        }



        private Compras CreateCompraFromDataRow(DataRow row)
        {
            Ctrl_Fornecedores aCTLForn = new Ctrl_Fornecedores();
            DadosCadastro fornecedor = aCTLForn.BuscarFornecedorPorId(Convert.ToInt32(row["id_fornecedor"]));
            Ctrl_CondPagamento aCTLCond = new Ctrl_CondPagamento();
            CondicaoPagamento condicao = aCTLCond.BuscarCondicaoPagamentoPorId((Convert.ToInt32(row["id_condicao"])));


            return new Compras
            {
                NumNFC = Convert.ToInt32(row["num_nfc"]),
                ModeloNFC = Convert.ToInt32(row["modelo_nfc"]),
                SerieNFC = Convert.ToInt32(row["serie_nfc"]),
                Fornecedor = fornecedor,
                Condicao = condicao,
                ValorTotal = Convert.ToDecimal(row["valor_total"]),
                ValorFrete = Convert.ToDecimal(row["valor_frete"]),
                ValorSeguro = Convert.ToDecimal(row["valor_seguro"]),
                ValorOutrasDespesas = Convert.ToDecimal(row["valor_outras_despesas"]),
                DataChegada = Convert.ToDateTime(row["data_chegada"]),
                DataEmissao = Convert.ToDateTime(row["data_emissao"]),
                DataCancelamento = row["data_cancelamento"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(row["data_cancelamento"]),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                StatusCompra = row["status_compra"].ToString(),
            };
        }

        private List<Compras> CreateComprasListFromDataTable(DataTable dataTable)
        {
            List<Compras> compras = new List<Compras>();
            foreach (DataRow row in dataTable.Rows)
            {
                compras.Add(CreateCompraFromDataRow(row));
            }
            return compras;
        }
    }
}
