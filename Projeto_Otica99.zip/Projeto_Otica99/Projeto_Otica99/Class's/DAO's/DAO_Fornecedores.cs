﻿
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Fornecedores : DAO
    {
        DB oDB;
        Verificacao verificacao;
        public DAO_Fornecedores() 
        {
            oDB = new DB();
            verificacao = new Verificacao();
        }
        public override string CarregaObj(object obj)
        {
            DadosCadastro oFornecedor = (DadosCadastro)obj;
            string ok = "";

            try
            {
                string sql = "select * from Fornecedor where ID_Fornecedor = '" + Convert.ToString(oFornecedor.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    oFornecedor.ID                  = Convert.ToInt32(dr.GetValue(0));
                    oFornecedor.HistoricoID         = Convert.ToInt32(dr.GetValue(1));
                    oFornecedor.CidadeID            = Convert.ToInt32(dr.GetValue(2));
                
                    oFornecedor.NomeOuNomeFantasia  = dr.GetString(3);
                    oFornecedor.SobrenomeOuRSocial  = dr.GetString(4);
                    oFornecedor.Endereco            = dr.GetString(5);
                    oFornecedor.Complemento         = dr.GetString(6);
                    oFornecedor.Numero              = dr.GetString(7);
                    oFornecedor.Bairro              = dr.GetString(8);
                    oFornecedor.CEP                 = dr.GetString(9);
                    oFornecedor.Telefone            = dr.GetString(10);
                    oFornecedor.Email               = dr.GetString(11);
                    oFornecedor.CPFouCNPJ           = dr.GetString(12);
                    oFornecedor.RGouIE              = dr.GetString(13);
                    oFornecedor.Sexo                = dr.GetString(14);
                    oFornecedor.Ativo               = dr.GetString(15);
                   
                    oFornecedor.DataCriacao         = dr.GetDateTime(16);
                    oFornecedor.DataUltimaAlteracao = dr.GetDateTime(17);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            DadosCadastro oFornecedor = (DadosCadastro)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Fornecedor (HistoricoID, CidadeID, NomeOuNomeFantasia, SobrenomeOuRSocial, Endereco, Complemento, Numero, Bairro, CEP, Telefone, Email, CPFouCNPJ, RGouIE, Sexo, Ativo, DataEntrada, DataUltimaAlteracao) " +
        "VALUES (@HistoricoID, @CidadeID, @NomeOuNomeFantasia, @SobrenomeOuRSocial, @Endereco, @Complemento, @Numero, @Bairro, @CEP, @Telefone, @Email, @CPFouCNPJ, @RGouIE, @Sexo, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oFornecedor.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Fornecedor SET HistoricoID = @HistoricoID, CidadeID = @CidadeID, NomeOuNomeFantasia = @NomeOuNomeFantasia, SobrenomeOuRSocial = @SobrenomeOuRSocial, Endereco = @Endereco, Complemento = @Complemento, Numero = @Numero, Bairro = @Bairro, CEP = @CEP, Telefone = @Telefone, Email = @Email, CPFouCNPJ = @CPFouCNPJ,RGouIE =@RGouIE ,Sexo = @Sexo ,Ativo =@Ativo ,DataUltimaAlteracao=@DataUltimaAlteracao WHERE ID_Fornecedor =@ID_Fornecedor";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oFornecedor.ID != 0)
            {
                cnn.Parameters.AddWithValue("@ID_Fornecedor",      oFornecedor.ID);
            }                                                   
            cnn.Parameters.AddWithValue("@HistoricoID",         oFornecedor.HistoricoID);
            cnn.Parameters.AddWithValue("@CidadeID",            oFornecedor.CidadeID);
            cnn.Parameters.AddWithValue("@NomeOuNomeFantasia",  oFornecedor.NomeOuNomeFantasia);
            cnn.Parameters.AddWithValue("@SobrenomeOuRSocial",  oFornecedor.SobrenomeOuRSocial);
            cnn.Parameters.AddWithValue("@Endereco",            oFornecedor.Endereco);
            cnn.Parameters.AddWithValue("@Complemento",         oFornecedor.Complemento);
            cnn.Parameters.AddWithValue("@Numero",              oFornecedor.Numero);
            cnn.Parameters.AddWithValue("@Bairro",              oFornecedor.Bairro);
            cnn.Parameters.AddWithValue("@CEP",                 oFornecedor.CEP);
            cnn.Parameters.AddWithValue("@Telefone",            oFornecedor.Telefone);
            cnn.Parameters.AddWithValue("@Email",               oFornecedor.Email);
            cnn.Parameters.AddWithValue("@CPFouCNPJ",           oFornecedor.CPFouCNPJ);
            cnn.Parameters.AddWithValue("@RGouIE",              oFornecedor.RGouIE);
            cnn.Parameters.AddWithValue("@Sexo",                oFornecedor.Sexo);
            cnn.Parameters.AddWithValue("@Ativo",               oFornecedor.Ativo);
                                                               
            cnn.Parameters.AddWithValue("@DataEntrada",         oFornecedor.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", oFornecedor.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();

            cnn.Connection.Close();

            return ok;
        }
        //public List<DadosCadastro> Pesquisar(string nome)
        //{
        //    List<DadosCadastro> lista = new List<DadosCadastro>();
        //    SqlCommand cnn = new SqlCommand();
        //    cnn.Connection = DB.Abrir();
        //    cnn.CommandType = System.Data.CommandType.Text;
        //
        //    cnn.CommandText = "select * from Fornecedor where SobrenomeOuRSocial = '" + nome + "'";
        //    var dr = cnn.ExecuteReader();
        //    while (dr.Read())
        //    {
        //        lista.Add(new DadosCadastro(
        //        Convert.ToInt32(dr.GetValue(0)), //ID
        //        Convert.ToInt32(dr.GetValue(1)), //HistoricoID
        //        Convert.ToInt32(dr.GetValue(2)), //CidadeID
        //
        //        dr.GetString(3),                 // NomeOuNFantasia
        //        dr.GetString(4),                 // SobrenomeOURSocial
        //        dr.GetString(5),                 // Endereço
        //        dr.GetString(6),                 // Complemento
        //        dr.GetString(7),                 // Numero
        //        dr.GetString(8),                 // Bairro
        //        dr.GetString(9),                 // CEP
        //        dr.GetString(10),                // Telefone
        //        dr.GetString(11),                // Email
        //        dr.GetString(12),                // CPFouCNPJ
        //        dr.GetString(13),                // RGouIE
        //        dr.GetString(15),                // Sexo 
        //        dr.GetString(14),                // Ativo                       
        //
        //        dr.GetDateTime(16),
        //        dr.GetDateTime(17)
        //        ));
        //    }
        //    return lista;
        //}

        public override string Excluir(string item)
        {           
            string ok = "";
            
            try
            {
                string sql = "UPDATE Fornecedor SET Ativo = 'I' WHERE ID_Fornecedor = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        
        public int BuscarIDCidade(string nome)
        {
            int IDCidade = 0;
            try
            {
                string sql = "select ID_Cidade from Cidade where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDCidade = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {

            }
            if (IDCidade == 0)
            {
                MessageBox.Show("Cidade não encontrada!");
            }
            return IDCidade;
        }
        public string BuscarCidadePorId(int id)
        {

            string ok = "";
            try
            {
                string sql = "select Nome from Cidade where ID_Cidade = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }

        public List<DadosCadastro> ListarFornecedores(string status)
        {
            try
            {
                string sql = "SELECT * FROM Fornecedor";
                List<SqlParameter> parametros = new List<SqlParameter>();

                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE Ativo = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateFornecedoresListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao listar fornecedores", ex);
                return new List<DadosCadastro>();
            }
        }

        private List<DadosCadastro> CreateFornecedoresListFromDataTable(DataTable dataTable)
        {
            List<DadosCadastro> fornecedores = new List<DadosCadastro>();

            foreach (DataRow row in dataTable.Rows)
            {
                fornecedores.Add(CreateFornecedorFromDataRow(row));
            }
            return fornecedores;
        }
        public string BuscaUF(string cidade)
        {
            string uf = "";
            try
            {
                string sql = "SELECT e.UF FROM [dbo].[Cidade] c JOIN [dbo].[Estado] e ON c.EstadoID = e.ID_Estado WHERE c.Nome = @NomeCidade";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = DB.Abrir();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@NomeCidade", cidade);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    uf = dr.GetString(0);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                uf = "Erro";
            }
            return uf;
        }
        public DadosCadastro BuscarFornecedorPorNome(string nomeFantasia)
        {
            try
            {
                string query = "SELECT * FROM Fornecedor WHERE nome_fantasia LIKE @nomeFantasia";
                SqlParameter parametro = new SqlParameter("@nomeFantasia", $"%{nomeFantasia}%");
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateFornecedorFromDataRow(row);
                }

                return null; // Retorna null se nenhum fornecedor for encontrado
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar fornecedor por nome fantasia", ex);
                return null; // Retorna null em caso de erro
            }
        }
        private DadosCadastro CreateFornecedorFromDataRow(DataRow row)
        {
            Ctrl_CondPagamento aCTLCond = new Ctrl_CondPagamento();
            Ctrl_Cidades aCTLCidades = new Ctrl_Cidades();
            var condicao = aCTLCond.BuscarCondicaoPagamentoPorId(Convert.ToInt32(row["id_condicao_pagamento"]));
            return new DadosCadastro
            {
                ID = Convert.ToInt32(row["id_fornecedor"]),
                Ativo = row["Ativo"].ToString(),
                NomeOuNomeFantasia = row["NomeOuNomeFantasia"].ToString(),
                SobrenomeOuRSocial = row["SobrenomeOuRSocial"].ToString(),
                RGouIE = row["RGouIE"].ToString(),
                CPFouCNPJ = row["CPFouCNPJ"].ToString(),
                Email = row["email"].ToString(),
                Telefone = row["telefone"].ToString(),
                CEP = row["cep"].ToString(),
                Endereco = row["endereco"].ToString(),
                Numero = row["numero"].ToString(),
                Complemento = row["complemento"].ToString(),
                Bairro = row["bairro"].ToString(),
                CidadeID = Convert.ToInt32(row["id_cidade"]),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["data_ult_alteracao"]),
                condicao_Pagamento = condicao,
            };
        }
        public DadosCadastro BuscarFornecedorPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM tb_fornecedores WHERE id_fornecedor = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateFornecedorFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                // Trate exceções genéricas, se aplicável
                verificacao.HandleException("Erro ao buscar fornecedor por ID", ex);
                return null;
            }
        }
    }
}
