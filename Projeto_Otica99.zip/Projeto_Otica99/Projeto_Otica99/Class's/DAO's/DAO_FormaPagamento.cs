﻿using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_FormaPagamento : DAO
    {
        private DB oDB;
        private Verificacao aVerificacao;
        public DAO_FormaPagamento()
        {
            oDB = new DB();
            aVerificacao = new Verificacao();
        }
        public override string Salvar(object obj)
        {
            FormaPagamento aFormaPag = (FormaPagamento)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Forma_Pagamento (Status_Forma, Forma, DataEntrada, DataUltimaAlteracao) " +
                         "VALUES (@Status_Forma, @Forma, @DataEntrada, @DataUltimaAlteracao)";

            if (aFormaPag.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Forma_Pagamento SET Status_Forma = @Status_Forma, Forma = @Forma, " +
                      "DataUltimaAlteracao = @DataUltimaAlteracao WHERE ID_Forma = @ID_Forma";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;

            if (aFormaPag.ID != 0)
            {
                cnn.Parameters.AddWithValue("@ID_Forma",        aFormaPag.ID);
            }

            cnn.Parameters.AddWithValue("@Status_Forma",        aFormaPag.StatusForma);
            cnn.Parameters.AddWithValue("@Forma",               aFormaPag.Forma);
            cnn.Parameters.AddWithValue("@DataEntrada",         aFormaPag.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao", aFormaPag.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();

            cnn.Connection.Close();

            return ok;
        }
        public override string Excluir(string item)
        {
            string ok = "";
            try
            {
                string sql = "UPDATE Forma_Pagamento SET Status_Forma = 'I' WHERE ID_Forma = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public List<FormaPagamento> Pesquisar(string nome)
        {
            List<FormaPagamento> lista = new List<FormaPagamento>();
            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandType = System.Data.CommandType.Text;

            cnn.CommandText = "select * from Forma_Pagamento where Forma = '" + nome + "'";
            var dr = cnn.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new FormaPagamento(
                Convert.ToInt32(dr.GetValue(0)),
                dr.GetString(1),
                dr.GetString(2),
                dr.GetDateTime(3),
                dr.GetDateTime(4)
                ));
            }
            return lista;
        }
        public List<FormaPagamento> ListarFormasPag()
        {
            List<FormaPagamento> lista = new List<FormaPagamento>();
            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandType = System.Data.CommandType.Text;

            cnn.CommandText = "Select * from Forma_Pagamento";
            var dr = cnn.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new FormaPagamento(
                Convert.ToInt32(dr.GetValue(0)), 
                dr.GetString(1),
                dr.GetString(2),                                     
                dr.GetDateTime(3),
                dr.GetDateTime(4)
                ));
            }
            return lista;
        }
        public override string CarregaObj(object obj)
        {
            FormaPagamento aForma = (FormaPagamento)obj;
            string ok = "";

            try
            {
                string sql = "select * from Forma_Pagamento where ID_Forma = '" + Convert.ToString(aForma.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    aForma.ID = Convert.ToInt32(dr.GetValue(0));

                    aForma.StatusForma = dr.GetString(1);
                    aForma.Forma       = dr.GetString(2);

                    aForma.DataCriacao = dr.GetDateTime(3);
                    aForma.DataUltimaAlteracao = dr.GetDateTime(4);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public FormaPagamento BuscarFormaPagamentoPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Forma_Pagamento WHERE id_Forma = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateFormaPagamentoFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                // Trate exceções genéricas, se aplicável
                aVerificacao.HandleException("Erro ao buscar forma de pagamento por ID", ex);
                return null;
            }
        }
        private FormaPagamento CreateFormaPagamentoFromDataRow(DataRow row)
        {
            // Crie um novo objeto FormaPagamento e preencha suas propriedades com os dados da linha fornecida
            return new FormaPagamento
            {
                ID = Convert.ToInt32(row["id_Forma"]),
                StatusForma = row["Status_Forma"].ToString(),
                Forma = row["Forma"].ToString(),
                DataCriacao = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["DataUltimaAlteracao"])
            };
        }
    }
}