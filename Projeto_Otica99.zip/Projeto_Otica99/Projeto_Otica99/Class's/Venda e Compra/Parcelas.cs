﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Venda_e_Compra
{
    public class Parcelas : Pai
    {
        private CondicaoPagamento _condicao;
        private FormaPagamento    _forma;
        private int               _numParcela;
        private int               _diasTotais;
        private decimal           _porcentagem;

        public Parcelas()
        {
            _condicao    = new CondicaoPagamento();
            _forma       = new FormaPagamento();
            _numParcela  = 0;
            _diasTotais  = 0;
            _porcentagem = 0;
        }
        public Parcelas(int id, CondicaoPagamento condicao, int numParcela, FormaPagamento forma, int diasTotais, decimal porcentagem,
            DateTime dataCriacao, DateTime dataUltAlteracao) : base(id, dataCriacao, dataUltAlteracao)
        {
            Condicao    = condicao;
            NumParcela  = numParcela;
            Forma       = forma;
            DiasTotais  = diasTotais;
            Porcentagem = porcentagem;
        }
        public CondicaoPagamento Condicao
        {
            get => _condicao;
            set => _condicao = value;
        }

        public int NumParcela
        {
            get => _numParcela;
            set => _numParcela = value;
        }

        public FormaPagamento Forma
        {
            get => _forma;
            set => _forma = value;
        }

        public int DiasTotais
        {
            get => _diasTotais;
            set => _diasTotais = value;
        }

        public decimal Porcentagem
        {
            get => _porcentagem;
            set => _porcentagem = value;
        }
    }
}
