﻿using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    public class DadosCadastro : Pai
    {
        protected int _HistoricoID;
        protected int _CidadeID;
        private CondicaoPagamento _condicaoPagamento;

        protected string _NomeOuNomeFantasia;

        protected string _SobrenomeOuRSocial;

        protected string _Endereco;
        protected string _Complemento;
        protected string _Numero;
        protected string _Bairro;
        protected string _CEP;
        protected string _Telefone;
        protected string _Email;

        protected string _CPFouCNPJ;

        protected string _RGouIE;

        protected string _Sexo;

        protected string _Ativo;

        public DadosCadastro() : base()
        {
            _HistoricoID = 0;
            _CidadeID = 0;
            _condicaoPagamento = new CondicaoPagamento();

            _NomeOuNomeFantasia = "";

            _SobrenomeOuRSocial = "";

            _Endereco = "";
            _Complemento = "";
            _Numero = "";
            _Bairro = "";
            _CEP = "";
            _Telefone = "";
            _Email = "";

            _CPFouCNPJ = "";

            _RGouIE = "";

            _Sexo = "";

            _Ativo = "";


        }

        public DadosCadastro(int id, int historicoID, CondicaoPagamento condicaoPagamento, int cidadeID, string nomeOuNomeFantasia, string sobrenomeOuRSocial, string endereco, string complemento, string numero, string bairro, string cep, string telefone, string rGouIE, string cPFouCNPJ, string email, string ativo, string sexo, DateTime dataCriacao, DateTime dataUltAlteracao) : base(id, dataCriacao, dataUltAlteracao)
        {
            HistoricoID = historicoID;
            CidadeID = cidadeID;
            condicao_Pagamento = condicaoPagamento;
            NomeOuNomeFantasia = nomeOuNomeFantasia;
            SobrenomeOuRSocial = sobrenomeOuRSocial;
            Endereco = endereco;
            Complemento = complemento;
            Numero = numero;
            Bairro = bairro;
            CEP = cep;
            Telefone = telefone;
            Email = email;
            CPFouCNPJ = cPFouCNPJ;
            RGouIE = rGouIE;
            Sexo = sexo;
            Ativo = ativo;
        }
        public int HistoricoID
        {
            get => _HistoricoID;
            set => _HistoricoID = value;
        }
        public int CidadeID
        {
            get => _CidadeID;
            set => _CidadeID = value;
        }
        public CondicaoPagamento condicao_Pagamento
        {
            get => _condicaoPagamento;
            set => _condicaoPagamento = value;
        }
        public string NomeOuNomeFantasia
        {
            get => _NomeOuNomeFantasia;
            set => _NomeOuNomeFantasia = value;
        }
        public string SobrenomeOuRSocial
        {
            get => _SobrenomeOuRSocial;
            set => _SobrenomeOuRSocial = value;
        }
        public string Endereco
        {
            get => _Endereco;
            set => _Endereco = value;
        }
        public string Complemento
        {
            get => _Complemento;
            set => _Complemento = value;
        }
        public string Numero
        {
            get => _Numero;
            set => _Numero = value;
        }
        public string Bairro
        {
            get => _Bairro;
            set => _Bairro = value;
        }
        public string CEP
        {
            get => _CEP;
            set => _CEP = value;
        }
        public string Telefone
        {
            get => _Telefone;
            set => _Telefone = value;
        }
        public string Email
        {
            get => _Email;
            set => _Email = value;
        }
        public string CPFouCNPJ
        {
            get => _CPFouCNPJ;
            set => _CPFouCNPJ = value;
        }
        public string RGouIE
        {
            get => _RGouIE;
            set => _RGouIE = value;
        }

        public string Sexo
        {
            get => _Sexo;
            set => _Sexo = value;
        }
        public string Ativo
        {
            get => _Ativo;
            set => _Ativo = value;
        }

    }
}
