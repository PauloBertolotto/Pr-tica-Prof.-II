﻿namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento
{
    partial class FrmCadFormaPag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_StatusForma = new System.Windows.Forms.Label();
            this.lbl_Forma = new System.Windows.Forms.Label();
            this.CB_Status = new System.Windows.Forms.ComboBox();
            this.txt_FormaPag = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(86, 69);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(9, 27);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(158, 69);
            // 
            // lbl_StatusForma
            // 
            this.lbl_StatusForma.AutoSize = true;
            this.lbl_StatusForma.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_StatusForma.ForeColor = System.Drawing.Color.Gold;
            this.lbl_StatusForma.Location = new System.Drawing.Point(89, 7);
            this.lbl_StatusForma.Name = "lbl_StatusForma";
            this.lbl_StatusForma.Size = new System.Drawing.Size(50, 18);
            this.lbl_StatusForma.TabIndex = 4;
            this.lbl_StatusForma.Text = "Status";
            // 
            // lbl_Forma
            // 
            this.lbl_Forma.AutoSize = true;
            this.lbl_Forma.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Forma.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Forma.Location = new System.Drawing.Point(158, 7);
            this.lbl_Forma.Name = "lbl_Forma";
            this.lbl_Forma.Size = new System.Drawing.Size(52, 18);
            this.lbl_Forma.TabIndex = 5;
            this.lbl_Forma.Text = "Forma";
            // 
            // CB_Status
            // 
            this.CB_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Status.FormattingEnabled = true;
            this.CB_Status.Items.AddRange(new object[] {
            "A",
            "I"});
            this.CB_Status.Location = new System.Drawing.Point(92, 25);
            this.CB_Status.Name = "CB_Status";
            this.CB_Status.Size = new System.Drawing.Size(60, 26);
            this.CB_Status.TabIndex = 6;
            // 
            // txt_FormaPag
            // 
            this.txt_FormaPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FormaPag.Location = new System.Drawing.Point(158, 27);
            this.txt_FormaPag.Name = "txt_FormaPag";
            this.txt_FormaPag.Size = new System.Drawing.Size(185, 22);
            this.txt_FormaPag.TabIndex = 7;
            this.txt_FormaPag.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // FrmCadFormaPag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(349, 103);
            this.Controls.Add(this.txt_FormaPag);
            this.Controls.Add(this.CB_Status);
            this.Controls.Add(this.lbl_Forma);
            this.Controls.Add(this.lbl_StatusForma);
            this.Name = "FrmCadFormaPag";
            this.Text = "Cadastro Formas de Pagamento";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_StatusForma, 0);
            this.Controls.SetChildIndex(this.lbl_Forma, 0);
            this.Controls.SetChildIndex(this.CB_Status, 0);
            this.Controls.SetChildIndex(this.txt_FormaPag, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lbl_StatusForma;
        public System.Windows.Forms.Label lbl_Forma;
        public System.Windows.Forms.ComboBox CB_Status;
        public System.Windows.Forms.TextBox txt_FormaPag;
    }
}
