﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BuscarCliente = new System.Windows.Forms.Button();
            this.txt_CPFeCNPJ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Cliente = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CB_ServProd = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Qntd = new System.Windows.Forms.TextBox();
            this.txt_CodProd = new System.Windows.Forms.TextBox();
            this.lbl_CodProd = new System.Windows.Forms.Label();
            this.txt_Prod = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_BuscarProd = new System.Windows.Forms.Button();
            this.txt_Desc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_CustoUnit = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_CustoTotal = new System.Windows.Forms.TextBox();
            this.btn_NovoProd = new System.Windows.Forms.Button();
            this.DgItensVenda = new System.Windows.Forms.DataGridView();
            this.btn_FVenda = new System.Windows.Forms.Button();
            this.lvParcelas = new System.Windows.Forms.ListView();
            this.clParcelas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDias = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clIdForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPercentTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPreco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txt_CodCond = new System.Windows.Forms.TextBox();
            this.txt_Condicao = new System.Windows.Forms.TextBox();
            this.txt_ValorFrete = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_ValorSeg = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_Outros = new System.Windows.Forms.TextBox();
            this.btn_FCond = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.lbl_TotNota = new System.Windows.Forms.Label();
            this.Panel_Prod = new System.Windows.Forms.Panel();
            this.btn_ExcluirItem = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_CondicaoPag = new System.Windows.Forms.TextBox();
            this.btn_BuscarCondPag = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DgItensVenda)).BeginInit();
            this.Panel_Prod.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(1070, 556);
            // 
            // lbl_Código
            // 
            this.lbl_Código.Location = new System.Drawing.Point(6, 55);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(9, 74);
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1142, 556);
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // btn_BuscarCliente
            // 
            this.btn_BuscarCliente.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarCliente.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarCliente.Location = new System.Drawing.Point(285, 23);
            this.btn_BuscarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscarCliente.Name = "btn_BuscarCliente";
            this.btn_BuscarCliente.Size = new System.Drawing.Size(68, 26);
            this.btn_BuscarCliente.TabIndex = 576;
            this.btn_BuscarCliente.Text = "Buscar";
            this.btn_BuscarCliente.UseVisualStyleBackColor = false;
            this.btn_BuscarCliente.Click += new System.EventHandler(this.btn_BuscarCliente_Click);
            // 
            // txt_CPFeCNPJ
            // 
            this.txt_CPFeCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CPFeCNPJ.Location = new System.Drawing.Point(9, 24);
            this.txt_CPFeCNPJ.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CPFeCNPJ.MaxLength = 100;
            this.txt_CPFeCNPJ.Name = "txt_CPFeCNPJ";
            this.txt_CPFeCNPJ.Size = new System.Drawing.Size(268, 27);
            this.txt_CPFeCNPJ.TabIndex = 575;
            this.txt_CPFeCNPJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CPFeCNPJ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_CPFeCNPJ_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(11, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 18);
            this.label6.TabIndex = 577;
            this.label6.Text = "CPF / CNPJ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(89, 52);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 18);
            this.label1.TabIndex = 578;
            this.label1.Text = "Cliente";
            // 
            // txt_Cliente
            // 
            this.txt_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cliente.Location = new System.Drawing.Point(92, 74);
            this.txt_Cliente.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Cliente.MaxLength = 100;
            this.txt_Cliente.Name = "txt_Cliente";
            this.txt_Cliente.Size = new System.Drawing.Size(261, 27);
            this.txt_Cliente.TabIndex = 579;
            this.txt_Cliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(6, 105);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 18);
            this.label2.TabIndex = 580;
            this.label2.Text = "Serviço / Produto";
            // 
            // CB_ServProd
            // 
            this.CB_ServProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_ServProd.FormattingEnabled = true;
            this.CB_ServProd.Items.AddRange(new object[] {
            "Produtos",
            "Serviços"});
            this.CB_ServProd.Location = new System.Drawing.Point(9, 126);
            this.CB_ServProd.Name = "CB_ServProd";
            this.CB_ServProd.Size = new System.Drawing.Size(344, 28);
            this.CB_ServProd.TabIndex = 581;
            this.CB_ServProd.SelectedIndexChanged += new System.EventHandler(this.CB_ServProd_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(2, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 582;
            this.label3.Text = "Qntd.";
            // 
            // txt_Qntd
            // 
            this.txt_Qntd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Qntd.Location = new System.Drawing.Point(5, 31);
            this.txt_Qntd.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Qntd.MaxLength = 100;
            this.txt_Qntd.Name = "txt_Qntd";
            this.txt_Qntd.Size = new System.Drawing.Size(96, 27);
            this.txt_Qntd.TabIndex = 583;
            this.txt_Qntd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Qntd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Qntd_KeyPress);
            this.txt_Qntd.Leave += new System.EventHandler(this.txt_Qntd_Leave);
            // 
            // txt_CodProd
            // 
            this.txt_CodProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodProd.Location = new System.Drawing.Point(109, 31);
            this.txt_CodProd.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CodProd.MaxLength = 100;
            this.txt_CodProd.Name = "txt_CodProd";
            this.txt_CodProd.Size = new System.Drawing.Size(90, 27);
            this.txt_CodProd.TabIndex = 584;
            this.txt_CodProd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodProd.Leave += new System.EventHandler(this.txt_CodProd_Leave);
            // 
            // lbl_CodProd
            // 
            this.lbl_CodProd.AutoSize = true;
            this.lbl_CodProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodProd.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodProd.Location = new System.Drawing.Point(106, 9);
            this.lbl_CodProd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_CodProd.Name = "lbl_CodProd";
            this.lbl_CodProd.Size = new System.Drawing.Size(80, 18);
            this.lbl_CodProd.TabIndex = 585;
            this.lbl_CodProd.Text = "Cód. Prod.";
            // 
            // txt_Prod
            // 
            this.txt_Prod.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Prod.Location = new System.Drawing.Point(5, 84);
            this.txt_Prod.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Prod.MaxLength = 100;
            this.txt_Prod.Name = "txt_Prod";
            this.txt_Prod.Size = new System.Drawing.Size(211, 27);
            this.txt_Prod.TabIndex = 586;
            this.txt_Prod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(4, 62);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 18);
            this.label5.TabIndex = 587;
            this.label5.Text = "Produto";
            // 
            // btn_BuscarProd
            // 
            this.btn_BuscarProd.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarProd.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarProd.Location = new System.Drawing.Point(249, 31);
            this.btn_BuscarProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscarProd.Name = "btn_BuscarProd";
            this.btn_BuscarProd.Size = new System.Drawing.Size(104, 26);
            this.btn_BuscarProd.TabIndex = 588;
            this.btn_BuscarProd.Text = "Buscar";
            this.btn_BuscarProd.UseVisualStyleBackColor = false;
            this.btn_BuscarProd.Click += new System.EventHandler(this.btn_BuscarProd_Click);
            // 
            // txt_Desc
            // 
            this.txt_Desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Desc.Location = new System.Drawing.Point(224, 84);
            this.txt_Desc.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Desc.MaxLength = 100;
            this.txt_Desc.Name = "txt_Desc";
            this.txt_Desc.Size = new System.Drawing.Size(129, 27);
            this.txt_Desc.TabIndex = 589;
            this.txt_Desc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Desc.Leave += new System.EventHandler(this.txt_Desc_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(221, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 18);
            this.label7.TabIndex = 590;
            this.label7.Text = "Desconto";
            // 
            // txt_CustoUnit
            // 
            this.txt_CustoUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustoUnit.Location = new System.Drawing.Point(7, 509);
            this.txt_CustoUnit.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CustoUnit.MaxLength = 100;
            this.txt_CustoUnit.Name = "txt_CustoUnit";
            this.txt_CustoUnit.Size = new System.Drawing.Size(170, 27);
            this.txt_CustoUnit.TabIndex = 591;
            this.txt_CustoUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(6, 487);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 18);
            this.label8.TabIndex = 592;
            this.label8.Text = "R$ p/ Unidade";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(184, 487);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 18);
            this.label9.TabIndex = 593;
            this.label9.Text = "R$ Total";
            // 
            // txt_CustoTotal
            // 
            this.txt_CustoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustoTotal.Location = new System.Drawing.Point(185, 509);
            this.txt_CustoTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CustoTotal.MaxLength = 100;
            this.txt_CustoTotal.Name = "txt_CustoTotal";
            this.txt_CustoTotal.Size = new System.Drawing.Size(168, 27);
            this.txt_CustoTotal.TabIndex = 594;
            this.txt_CustoTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_NovoProd
            // 
            this.btn_NovoProd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_NovoProd.BackColor = System.Drawing.Color.Gold;
            this.btn_NovoProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_NovoProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_NovoProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NovoProd.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_NovoProd.Location = new System.Drawing.Point(7, 557);
            this.btn_NovoProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_NovoProd.Name = "btn_NovoProd";
            this.btn_NovoProd.Size = new System.Drawing.Size(172, 26);
            this.btn_NovoProd.TabIndex = 595;
            this.btn_NovoProd.Text = "Novo Produto";
            this.btn_NovoProd.UseVisualStyleBackColor = false;
            this.btn_NovoProd.Click += new System.EventHandler(this.btn_NovoProd_Click);
            // 
            // DgItensVenda
            // 
            this.DgItensVenda.AllowUserToAddRows = false;
            this.DgItensVenda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DgItensVenda.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.DgItensVenda.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.DgItensVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgItensVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DgItensVenda.Location = new System.Drawing.Point(375, 23);
            this.DgItensVenda.Margin = new System.Windows.Forms.Padding(2);
            this.DgItensVenda.MultiSelect = false;
            this.DgItensVenda.Name = "DgItensVenda";
            this.DgItensVenda.ReadOnly = true;
            this.DgItensVenda.RowHeadersWidth = 51;
            this.DgItensVenda.RowTemplate.Height = 24;
            this.DgItensVenda.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgItensVenda.Size = new System.Drawing.Size(835, 341);
            this.DgItensVenda.TabIndex = 596;
            this.DgItensVenda.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgItensVenda_CellContentClick);
            this.DgItensVenda.SelectionChanged += new System.EventHandler(this.DgItensVenda_SelectionChanged);
            // 
            // btn_FVenda
            // 
            this.btn_FVenda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_FVenda.BackColor = System.Drawing.Color.Gold;
            this.btn_FVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_FVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FVenda.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_FVenda.Location = new System.Drawing.Point(1116, 370);
            this.btn_FVenda.Margin = new System.Windows.Forms.Padding(4);
            this.btn_FVenda.Name = "btn_FVenda";
            this.btn_FVenda.Size = new System.Drawing.Size(94, 26);
            this.btn_FVenda.TabIndex = 597;
            this.btn_FVenda.Text = "Finalizar";
            this.btn_FVenda.UseVisualStyleBackColor = false;
            this.btn_FVenda.Click += new System.EventHandler(this.btn_FVenda_Click);
            // 
            // lvParcelas
            // 
            this.lvParcelas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lvParcelas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clParcelas,
            this.clDias,
            this.clIdForma,
            this.clForma,
            this.clPercentTotal,
            this.clPreco});
            this.lvParcelas.FullRowSelect = true;
            this.lvParcelas.GridLines = true;
            this.lvParcelas.HideSelection = false;
            this.lvParcelas.Location = new System.Drawing.Point(375, 427);
            this.lvParcelas.Margin = new System.Windows.Forms.Padding(4);
            this.lvParcelas.Name = "lvParcelas";
            this.lvParcelas.Size = new System.Drawing.Size(555, 150);
            this.lvParcelas.TabIndex = 598;
            this.lvParcelas.UseCompatibleStateImageBehavior = false;
            this.lvParcelas.View = System.Windows.Forms.View.Details;
            // 
            // clParcelas
            // 
            this.clParcelas.Text = "Nº";
            this.clParcelas.Width = 40;
            // 
            // clDias
            // 
            this.clDias.Text = "Dias";
            this.clDias.Width = 100;
            // 
            // clIdForma
            // 
            this.clIdForma.Text = "ID.F";
            // 
            // clForma
            // 
            this.clForma.Text = "Forma PG";
            this.clForma.Width = 240;
            // 
            // clPercentTotal
            // 
            this.clPercentTotal.Text = "%  sob Total";
            this.clPercentTotal.Width = 120;
            // 
            // clPreco
            // 
            this.clPreco.Text = "Valor da parcela";
            this.clPreco.Width = 150;
            // 
            // txt_CodCond
            // 
            this.txt_CodCond.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCond.Location = new System.Drawing.Point(375, 388);
            this.txt_CodCond.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CodCond.MaxLength = 100;
            this.txt_CodCond.Name = "txt_CodCond";
            this.txt_CodCond.Size = new System.Drawing.Size(53, 27);
            this.txt_CodCond.TabIndex = 599;
            this.txt_CodCond.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_Condicao
            // 
            this.txt_Condicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Condicao.Location = new System.Drawing.Point(436, 388);
            this.txt_Condicao.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Condicao.MaxLength = 100;
            this.txt_Condicao.Name = "txt_Condicao";
            this.txt_Condicao.Size = new System.Drawing.Size(168, 27);
            this.txt_Condicao.TabIndex = 600;
            this.txt_Condicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_ValorFrete
            // 
            this.txt_ValorFrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ValorFrete.Location = new System.Drawing.Point(612, 388);
            this.txt_ValorFrete.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ValorFrete.MaxLength = 100;
            this.txt_ValorFrete.Name = "txt_ValorFrete";
            this.txt_ValorFrete.Size = new System.Drawing.Size(77, 27);
            this.txt_ValorFrete.TabIndex = 601;
            this.txt_ValorFrete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_ValorFrete.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ValorFrete_KeyPress);
            this.txt_ValorFrete.Leave += new System.EventHandler(this.txt_ValorFrete_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gold;
            this.label10.Location = new System.Drawing.Point(372, 366);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 18);
            this.label10.TabIndex = 602;
            this.label10.Text = "Código";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(433, 366);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(172, 18);
            this.label11.TabIndex = 603;
            this.label11.Text = "Condição de Pagamento";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gold;
            this.label12.Location = new System.Drawing.Point(609, 366);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 18);
            this.label12.TabIndex = 604;
            this.label12.Text = "Valor Frete";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gold;
            this.label13.Location = new System.Drawing.Point(694, 366);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 18);
            this.label13.TabIndex = 606;
            this.label13.Text = "Valor Seguro";
            // 
            // txt_ValorSeg
            // 
            this.txt_ValorSeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ValorSeg.Location = new System.Drawing.Point(697, 388);
            this.txt_ValorSeg.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ValorSeg.MaxLength = 100;
            this.txt_ValorSeg.Name = "txt_ValorSeg";
            this.txt_ValorSeg.Size = new System.Drawing.Size(91, 27);
            this.txt_ValorSeg.TabIndex = 605;
            this.txt_ValorSeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gold;
            this.label14.Location = new System.Drawing.Point(793, 366);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 18);
            this.label14.TabIndex = 608;
            this.label14.Text = "Outros";
            // 
            // txt_Outros
            // 
            this.txt_Outros.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Outros.Location = new System.Drawing.Point(796, 388);
            this.txt_Outros.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Outros.MaxLength = 100;
            this.txt_Outros.Name = "txt_Outros";
            this.txt_Outros.Size = new System.Drawing.Size(77, 27);
            this.txt_Outros.TabIndex = 607;
            this.txt_Outros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_FCond
            // 
            this.btn_FCond.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_FCond.BackColor = System.Drawing.Color.Gold;
            this.btn_FCond.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FCond.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_FCond.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FCond.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_FCond.Location = new System.Drawing.Point(938, 427);
            this.btn_FCond.Margin = new System.Windows.Forms.Padding(4);
            this.btn_FCond.Name = "btn_FCond";
            this.btn_FCond.Size = new System.Drawing.Size(133, 26);
            this.btn_FCond.TabIndex = 609;
            this.btn_FCond.Text = "Finalizar Condição";
            this.btn_FCond.UseVisualStyleBackColor = false;
            this.btn_FCond.Click += new System.EventHandler(this.btn_FCond_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gold;
            this.label15.Location = new System.Drawing.Point(931, 468);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 39);
            this.label15.TabIndex = 610;
            this.label15.Text = "R$";
            // 
            // lbl_TotNota
            // 
            this.lbl_TotNota.AutoSize = true;
            this.lbl_TotNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotNota.ForeColor = System.Drawing.Color.Gold;
            this.lbl_TotNota.Location = new System.Drawing.Point(1088, 468);
            this.lbl_TotNota.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TotNota.Name = "lbl_TotNota";
            this.lbl_TotNota.Size = new System.Drawing.Size(122, 39);
            this.lbl_TotNota.TabIndex = 611;
            this.lbl_TotNota.Text = "000,00";
            // 
            // Panel_Prod
            // 
            this.Panel_Prod.Controls.Add(this.lbl_CodProd);
            this.Panel_Prod.Controls.Add(this.txt_Qntd);
            this.Panel_Prod.Controls.Add(this.label7);
            this.Panel_Prod.Controls.Add(this.label3);
            this.Panel_Prod.Controls.Add(this.txt_Desc);
            this.Panel_Prod.Controls.Add(this.btn_BuscarProd);
            this.Panel_Prod.Controls.Add(this.label5);
            this.Panel_Prod.Controls.Add(this.txt_Prod);
            this.Panel_Prod.Controls.Add(this.txt_CodProd);
            this.Panel_Prod.Location = new System.Drawing.Point(7, 160);
            this.Panel_Prod.Name = "Panel_Prod";
            this.Panel_Prod.Size = new System.Drawing.Size(360, 123);
            this.Panel_Prod.TabIndex = 612;
            // 
            // btn_ExcluirItem
            // 
            this.btn_ExcluirItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ExcluirItem.BackColor = System.Drawing.Color.Gold;
            this.btn_ExcluirItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ExcluirItem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_ExcluirItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExcluirItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_ExcluirItem.Location = new System.Drawing.Point(1014, 370);
            this.btn_ExcluirItem.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ExcluirItem.Name = "btn_ExcluirItem";
            this.btn_ExcluirItem.Size = new System.Drawing.Size(94, 26);
            this.btn_ExcluirItem.TabIndex = 613;
            this.btn_ExcluirItem.Text = "Excluir Item";
            this.btn_ExcluirItem.UseVisualStyleBackColor = false;
            this.btn_ExcluirItem.Click += new System.EventHandler(this.btn_ExcluirItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 318);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.MaxLength = 100;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(114, 27);
            this.textBox1.TabIndex = 591;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(12, 296);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 18);
            this.label4.TabIndex = 591;
            this.label4.Text = "Cód. Cond Pag.";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gold;
            this.label16.Location = new System.Drawing.Point(129, 296);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(172, 18);
            this.label16.TabIndex = 592;
            this.label16.Text = "Condição de Pagamento";
            // 
            // txt_CondicaoPag
            // 
            this.txt_CondicaoPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CondicaoPag.Location = new System.Drawing.Point(132, 318);
            this.txt_CondicaoPag.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CondicaoPag.MaxLength = 100;
            this.txt_CondicaoPag.Name = "txt_CondicaoPag";
            this.txt_CondicaoPag.Size = new System.Drawing.Size(161, 27);
            this.txt_CondicaoPag.TabIndex = 591;
            this.txt_CondicaoPag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_BuscarCondPag
            // 
            this.btn_BuscarCondPag.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarCondPag.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarCondPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarCondPag.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarCondPag.Location = new System.Drawing.Point(301, 318);
            this.btn_BuscarCondPag.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscarCondPag.Name = "btn_BuscarCondPag";
            this.btn_BuscarCondPag.Size = new System.Drawing.Size(62, 26);
            this.btn_BuscarCondPag.TabIndex = 591;
            this.btn_BuscarCondPag.Text = "Buscar";
            this.btn_BuscarCondPag.UseVisualStyleBackColor = false;
            // 
            // FrmCadVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1221, 590);
            this.Controls.Add(this.btn_BuscarCondPag);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_CondicaoPag);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_ExcluirItem);
            this.Controls.Add(this.Panel_Prod);
            this.Controls.Add(this.lbl_TotNota);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btn_FCond);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_Outros);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_ValorSeg);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_ValorFrete);
            this.Controls.Add(this.txt_Condicao);
            this.Controls.Add(this.txt_CodCond);
            this.Controls.Add(this.lvParcelas);
            this.Controls.Add(this.btn_FVenda);
            this.Controls.Add(this.DgItensVenda);
            this.Controls.Add(this.btn_NovoProd);
            this.Controls.Add(this.txt_CustoTotal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_CustoUnit);
            this.Controls.Add(this.CB_ServProd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Cliente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_BuscarCliente);
            this.Controls.Add(this.txt_CPFeCNPJ);
            this.Controls.Add(this.label6);
            this.Name = "FrmCadVenda";
            this.Text = "Cadastro: Venda";
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.txt_CPFeCNPJ, 0);
            this.Controls.SetChildIndex(this.btn_BuscarCliente, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.txt_Cliente, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.CB_ServProd, 0);
            this.Controls.SetChildIndex(this.txt_CustoUnit, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.txt_CustoTotal, 0);
            this.Controls.SetChildIndex(this.btn_NovoProd, 0);
            this.Controls.SetChildIndex(this.DgItensVenda, 0);
            this.Controls.SetChildIndex(this.btn_FVenda, 0);
            this.Controls.SetChildIndex(this.lvParcelas, 0);
            this.Controls.SetChildIndex(this.txt_CodCond, 0);
            this.Controls.SetChildIndex(this.txt_Condicao, 0);
            this.Controls.SetChildIndex(this.txt_ValorFrete, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.txt_ValorSeg, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.txt_Outros, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.btn_FCond, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.lbl_TotNota, 0);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.Panel_Prod, 0);
            this.Controls.SetChildIndex(this.btn_ExcluirItem, 0);
            this.Controls.SetChildIndex(this.textBox1, 0);
            this.Controls.SetChildIndex(this.txt_CondicaoPag, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.btn_BuscarCondPag, 0);
            ((System.ComponentModel.ISupportInitialize)(this.DgItensVenda)).EndInit();
            this.Panel_Prod.ResumeLayout(false);
            this.Panel_Prod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Button btn_BuscarCliente;
        protected System.Windows.Forms.TextBox txt_CPFeCNPJ;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.Label label1;
        protected System.Windows.Forms.TextBox txt_Cliente;
        protected System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CB_ServProd;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.TextBox txt_Qntd;
        protected System.Windows.Forms.TextBox txt_CodProd;
        protected System.Windows.Forms.Label lbl_CodProd;
        protected System.Windows.Forms.TextBox txt_Prod;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.Button btn_BuscarProd;
        protected System.Windows.Forms.TextBox txt_Desc;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.TextBox txt_CustoUnit;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.Label label9;
        protected System.Windows.Forms.TextBox txt_CustoTotal;
        protected System.Windows.Forms.Button btn_NovoProd;
        protected System.Windows.Forms.DataGridView DgItensVenda;
        protected System.Windows.Forms.Button btn_FVenda;
        protected System.Windows.Forms.ListView lvParcelas;
        private System.Windows.Forms.ColumnHeader clParcelas;
        private System.Windows.Forms.ColumnHeader clDias;
        private System.Windows.Forms.ColumnHeader clIdForma;
        private System.Windows.Forms.ColumnHeader clForma;
        private System.Windows.Forms.ColumnHeader clPercentTotal;
        private System.Windows.Forms.ColumnHeader clPreco;
        protected System.Windows.Forms.TextBox txt_CodCond;
        protected System.Windows.Forms.TextBox txt_Condicao;
        protected System.Windows.Forms.TextBox txt_ValorFrete;
        protected System.Windows.Forms.Label label10;
        protected System.Windows.Forms.Label label11;
        protected System.Windows.Forms.Label label12;
        protected System.Windows.Forms.Label label13;
        protected System.Windows.Forms.TextBox txt_ValorSeg;
        protected System.Windows.Forms.Label label14;
        protected System.Windows.Forms.TextBox txt_Outros;
        protected System.Windows.Forms.Button btn_FCond;
        protected System.Windows.Forms.Label label15;
        protected System.Windows.Forms.Label lbl_TotNota;
        private System.Windows.Forms.Panel Panel_Prod;
        protected System.Windows.Forms.Button btn_ExcluirItem;
        protected System.Windows.Forms.TextBox textBox1;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.Label label16;
        protected System.Windows.Forms.TextBox txt_CondicaoPag;
        protected System.Windows.Forms.Button btn_BuscarCondPag;
    }
}
