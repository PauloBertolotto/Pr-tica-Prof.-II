﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadServicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Status = new System.Windows.Forms.Label();
            this.CB_Status = new System.Windows.Forms.ComboBox();
            this.lbl_Descricao = new System.Windows.Forms.Label();
            this.txt_Descricao = new System.Windows.Forms.TextBox();
            this.lbl_Valor = new System.Windows.Forms.Label();
            this.txt_Valor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(298, 77);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(370, 77);
            // 
            // lbl_Status
            // 
            this.lbl_Status.AutoSize = true;
            this.lbl_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Status.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Status.Location = new System.Drawing.Point(347, 7);
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(50, 18);
            this.lbl_Status.TabIndex = 561;
            this.lbl_Status.Text = "Status";
            // 
            // CB_Status
            // 
            this.CB_Status.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CB_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Status.FormattingEnabled = true;
            this.CB_Status.Items.AddRange(new object[] {
            "ATIVO",
            "INATIVO"});
            this.CB_Status.Location = new System.Drawing.Point(350, 26);
            this.CB_Status.Name = "CB_Status";
            this.CB_Status.Size = new System.Drawing.Size(88, 28);
            this.CB_Status.TabIndex = 559;
            // 
            // lbl_Descricao
            // 
            this.lbl_Descricao.AutoSize = true;
            this.lbl_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Descricao.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Descricao.Location = new System.Drawing.Point(89, 6);
            this.lbl_Descricao.Name = "lbl_Descricao";
            this.lbl_Descricao.Size = new System.Drawing.Size(76, 18);
            this.lbl_Descricao.TabIndex = 560;
            this.lbl_Descricao.Text = "Descrição";
            // 
            // txt_Descricao
            // 
            this.txt_Descricao.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Descricao.Location = new System.Drawing.Point(92, 26);
            this.txt_Descricao.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Descricao.MaxLength = 100;
            this.txt_Descricao.Name = "txt_Descricao";
            this.txt_Descricao.Size = new System.Drawing.Size(252, 27);
            this.txt_Descricao.TabIndex = 558;
            // 
            // lbl_Valor
            // 
            this.lbl_Valor.AutoSize = true;
            this.lbl_Valor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Valor.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Valor.Location = new System.Drawing.Point(6, 57);
            this.lbl_Valor.Name = "lbl_Valor";
            this.lbl_Valor.Size = new System.Drawing.Size(42, 18);
            this.lbl_Valor.TabIndex = 563;
            this.lbl_Valor.Text = "Valor";
            // 
            // txt_Valor
            // 
            this.txt_Valor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Valor.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Valor.Location = new System.Drawing.Point(9, 77);
            this.txt_Valor.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Valor.MaxLength = 100;
            this.txt_Valor.Name = "txt_Valor";
            this.txt_Valor.Size = new System.Drawing.Size(252, 27);
            this.txt_Valor.TabIndex = 562;
            this.txt_Valor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Valor_KeyPress);
            // 
            // FrmCadServicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(453, 119);
            this.Controls.Add(this.lbl_Valor);
            this.Controls.Add(this.txt_Valor);
            this.Controls.Add(this.lbl_Status);
            this.Controls.Add(this.CB_Status);
            this.Controls.Add(this.lbl_Descricao);
            this.Controls.Add(this.txt_Descricao);
            this.Name = "FrmCadServicos";
            this.Text = "Cadastro: Serviços";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.txt_Descricao, 0);
            this.Controls.SetChildIndex(this.lbl_Descricao, 0);
            this.Controls.SetChildIndex(this.CB_Status, 0);
            this.Controls.SetChildIndex(this.lbl_Status, 0);
            this.Controls.SetChildIndex(this.txt_Valor, 0);
            this.Controls.SetChildIndex(this.lbl_Valor, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_Status;
        public System.Windows.Forms.ComboBox CB_Status;
        private System.Windows.Forms.Label lbl_Descricao;
        private System.Windows.Forms.TextBox txt_Descricao;
        private System.Windows.Forms.Label lbl_Valor;
        private System.Windows.Forms.TextBox txt_Valor;
    }
}
