﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadCompra : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        public FrmCadCompra()
        {
            InitializeComponent();
        }
    }
}
