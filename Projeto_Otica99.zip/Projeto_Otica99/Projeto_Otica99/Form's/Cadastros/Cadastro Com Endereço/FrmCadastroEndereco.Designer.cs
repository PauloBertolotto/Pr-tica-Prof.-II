﻿namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço
{
    partial class FrmCadastroEndereco
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CEP = new System.Windows.Forms.Label();
            this.lbl_Endereco = new System.Windows.Forms.Label();
            this.lbl_Bairro = new System.Windows.Forms.Label();
            this.lbl_Numero = new System.Windows.Forms.Label();
            this.lbl_Cidade = new System.Windows.Forms.Label();
            this.lbl_CodCidade = new System.Windows.Forms.Label();
            this.mtb_CEP = new System.Windows.Forms.MaskedTextBox();
            this.txt_Endereco = new System.Windows.Forms.TextBox();
            this.txt_Bairro = new System.Windows.Forms.TextBox();
            this.txt_Numero = new System.Windows.Forms.TextBox();
            this.txt_Cidade = new System.Windows.Forms.TextBox();
            this.txt_CodCidade = new System.Windows.Forms.TextBox();
            this.btn_BuscarPorCidade = new System.Windows.Forms.Button();
            this.lbl_Complemento = new System.Windows.Forms.Label();
            this.txt_Complemento = new System.Windows.Forms.TextBox();
            this.CB_Tipo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(286, 314);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(3);
            // 
            // lbl_Código
            // 
            this.lbl_Código.Location = new System.Drawing.Point(9, 7);
            this.lbl_Código.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(9, 27);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(358, 314);
            this.btn_Sair.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            // 
            // lbl_CEP
            // 
            this.lbl_CEP.AutoSize = true;
            this.lbl_CEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CEP.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CEP.Location = new System.Drawing.Point(530, 53);
            this.lbl_CEP.Name = "lbl_CEP";
            this.lbl_CEP.Size = new System.Drawing.Size(39, 18);
            this.lbl_CEP.TabIndex = 4;
            this.lbl_CEP.Text = "CEP";
            // 
            // lbl_Endereco
            // 
            this.lbl_Endereco.AutoSize = true;
            this.lbl_Endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Endereco.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Endereco.Location = new System.Drawing.Point(9, 53);
            this.lbl_Endereco.Name = "lbl_Endereco";
            this.lbl_Endereco.Size = new System.Drawing.Size(72, 18);
            this.lbl_Endereco.TabIndex = 5;
            this.lbl_Endereco.Text = "Endereço";
            // 
            // lbl_Bairro
            // 
            this.lbl_Bairro.AutoSize = true;
            this.lbl_Bairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bairro.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Bairro.Location = new System.Drawing.Point(433, 53);
            this.lbl_Bairro.Name = "lbl_Bairro";
            this.lbl_Bairro.Size = new System.Drawing.Size(48, 18);
            this.lbl_Bairro.TabIndex = 6;
            this.lbl_Bairro.Text = "Bairro";
            // 
            // lbl_Numero
            // 
            this.lbl_Numero.AutoSize = true;
            this.lbl_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Numero.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Numero.Location = new System.Drawing.Point(368, 53);
            this.lbl_Numero.Name = "lbl_Numero";
            this.lbl_Numero.Size = new System.Drawing.Size(62, 18);
            this.lbl_Numero.TabIndex = 7;
            this.lbl_Numero.Text = "Número";
            // 
            // lbl_Cidade
            // 
            this.lbl_Cidade.AutoSize = true;
            this.lbl_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cidade.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Cidade.Location = new System.Drawing.Point(90, 106);
            this.lbl_Cidade.Name = "lbl_Cidade";
            this.lbl_Cidade.Size = new System.Drawing.Size(54, 18);
            this.lbl_Cidade.TabIndex = 8;
            this.lbl_Cidade.Text = "Cidade";
            // 
            // lbl_CodCidade
            // 
            this.lbl_CodCidade.AutoSize = true;
            this.lbl_CodCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodCidade.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodCidade.Location = new System.Drawing.Point(9, 106);
            this.lbl_CodCidade.Name = "lbl_CodCidade";
            this.lbl_CodCidade.Size = new System.Drawing.Size(56, 18);
            this.lbl_CodCidade.TabIndex = 9;
            this.lbl_CodCidade.Text = "Código";
            // 
            // mtb_CEP
            // 
            this.mtb_CEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_CEP.Location = new System.Drawing.Point(530, 73);
            this.mtb_CEP.Mask = "00000-000";
            this.mtb_CEP.Name = "mtb_CEP";
            this.mtb_CEP.Size = new System.Drawing.Size(100, 22);
            this.mtb_CEP.TabIndex = 10;
            // 
            // txt_Endereco
            // 
            this.txt_Endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Endereco.Location = new System.Drawing.Point(9, 73);
            this.txt_Endereco.Name = "txt_Endereco";
            this.txt_Endereco.Size = new System.Drawing.Size(174, 22);
            this.txt_Endereco.TabIndex = 12;
            // 
            // txt_Bairro
            // 
            this.txt_Bairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Bairro.Location = new System.Drawing.Point(433, 73);
            this.txt_Bairro.Name = "txt_Bairro";
            this.txt_Bairro.Size = new System.Drawing.Size(92, 22);
            this.txt_Bairro.TabIndex = 13;
            // 
            // txt_Numero
            // 
            this.txt_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero.Location = new System.Drawing.Point(368, 73);
            this.txt_Numero.Name = "txt_Numero";
            this.txt_Numero.Size = new System.Drawing.Size(60, 22);
            this.txt_Numero.TabIndex = 14;
            // 
            // txt_Cidade
            // 
            this.txt_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cidade.Location = new System.Drawing.Point(90, 128);
            this.txt_Cidade.Name = "txt_Cidade";
            this.txt_Cidade.Size = new System.Drawing.Size(174, 22);
            this.txt_Cidade.TabIndex = 15;
            // 
            // txt_CodCidade
            // 
            this.txt_CodCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCidade.Location = new System.Drawing.Point(9, 128);
            this.txt_CodCidade.Name = "txt_CodCidade";
            this.txt_CodCidade.Size = new System.Drawing.Size(76, 22);
            this.txt_CodCidade.TabIndex = 16;
            this.txt_CodCidade.Text = "0";
            this.txt_CodCidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_BuscarPorCidade
            // 
            this.btn_BuscarPorCidade.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarPorCidade.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarPorCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarPorCidade.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarPorCidade.Location = new System.Drawing.Point(269, 124);
            this.btn_BuscarPorCidade.Name = "btn_BuscarPorCidade";
            this.btn_BuscarPorCidade.Size = new System.Drawing.Size(68, 26);
            this.btn_BuscarPorCidade.TabIndex = 17;
            this.btn_BuscarPorCidade.Text = "Buscar";
            this.btn_BuscarPorCidade.UseVisualStyleBackColor = false;
            this.btn_BuscarPorCidade.Click += new System.EventHandler(this.btn_BuscarPorCidade_Click);
            // 
            // lbl_Complemento
            // 
            this.lbl_Complemento.AutoSize = true;
            this.lbl_Complemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complemento.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Complemento.Location = new System.Drawing.Point(188, 53);
            this.lbl_Complemento.Name = "lbl_Complemento";
            this.lbl_Complemento.Size = new System.Drawing.Size(102, 18);
            this.lbl_Complemento.TabIndex = 18;
            this.lbl_Complemento.Text = "Complemento";
            // 
            // txt_Complemento
            // 
            this.txt_Complemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Complemento.Location = new System.Drawing.Point(188, 73);
            this.txt_Complemento.Name = "txt_Complemento";
            this.txt_Complemento.Size = new System.Drawing.Size(174, 22);
            this.txt_Complemento.TabIndex = 19;
            // 
            // CB_Tipo
            // 
            this.CB_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Tipo.FormattingEnabled = true;
            this.CB_Tipo.Location = new System.Drawing.Point(89, 26);
            this.CB_Tipo.Margin = new System.Windows.Forms.Padding(2);
            this.CB_Tipo.Name = "CB_Tipo";
            this.CB_Tipo.Size = new System.Drawing.Size(62, 25);
            this.CB_Tipo.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(86, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 18);
            this.label1.TabIndex = 21;
            this.label1.Text = "F/J";
            // 
            // FrmCadastroEndereco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(637, 356);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CB_Tipo);
            this.Controls.Add(this.txt_Complemento);
            this.Controls.Add(this.lbl_Complemento);
            this.Controls.Add(this.btn_BuscarPorCidade);
            this.Controls.Add(this.txt_CodCidade);
            this.Controls.Add(this.txt_Cidade);
            this.Controls.Add(this.txt_Numero);
            this.Controls.Add(this.txt_Bairro);
            this.Controls.Add(this.txt_Endereco);
            this.Controls.Add(this.mtb_CEP);
            this.Controls.Add(this.lbl_CodCidade);
            this.Controls.Add(this.lbl_Cidade);
            this.Controls.Add(this.lbl_Numero);
            this.Controls.Add(this.lbl_Bairro);
            this.Controls.Add(this.lbl_Endereco);
            this.Controls.Add(this.lbl_CEP);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FrmCadastroEndereco";
            this.Text = "FrmCadastroEnderecoPai";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_CEP, 0);
            this.Controls.SetChildIndex(this.lbl_Endereco, 0);
            this.Controls.SetChildIndex(this.lbl_Bairro, 0);
            this.Controls.SetChildIndex(this.lbl_Numero, 0);
            this.Controls.SetChildIndex(this.lbl_Cidade, 0);
            this.Controls.SetChildIndex(this.lbl_CodCidade, 0);
            this.Controls.SetChildIndex(this.mtb_CEP, 0);
            this.Controls.SetChildIndex(this.txt_Endereco, 0);
            this.Controls.SetChildIndex(this.txt_Bairro, 0);
            this.Controls.SetChildIndex(this.txt_Numero, 0);
            this.Controls.SetChildIndex(this.txt_Cidade, 0);
            this.Controls.SetChildIndex(this.txt_CodCidade, 0);
            this.Controls.SetChildIndex(this.btn_BuscarPorCidade, 0);
            this.Controls.SetChildIndex(this.lbl_Complemento, 0);
            this.Controls.SetChildIndex(this.txt_Complemento, 0);
            this.Controls.SetChildIndex(this.CB_Tipo, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lbl_CEP;
        public System.Windows.Forms.Label lbl_Endereco;
        public System.Windows.Forms.Label lbl_Bairro;
        public System.Windows.Forms.Label lbl_Numero;
        public System.Windows.Forms.Label lbl_Cidade;
        public System.Windows.Forms.Label lbl_CodCidade;
        public System.Windows.Forms.MaskedTextBox mtb_CEP;
        public System.Windows.Forms.TextBox txt_Endereco;
        public System.Windows.Forms.TextBox txt_Bairro;
        public System.Windows.Forms.TextBox txt_Numero;
        public System.Windows.Forms.TextBox txt_Cidade;
        public System.Windows.Forms.TextBox txt_CodCidade;
        public System.Windows.Forms.Button btn_BuscarPorCidade;
        public System.Windows.Forms.Label lbl_Complemento;
        public System.Windows.Forms.TextBox txt_Complemento;
        public System.Windows.Forms.ComboBox CB_Tipo;
        public System.Windows.Forms.Label label1;
    }
}
