﻿namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço
{
    partial class FrmCadPFePJ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_NomeOuNFantasia = new System.Windows.Forms.TextBox();
            this.txt_SobrenomeOuRSocial = new System.Windows.Forms.TextBox();
            this.lbl_CNPJeCPF = new System.Windows.Forms.Label();
            this.lbl_NomeOuNFantasia = new System.Windows.Forms.Label();
            this.lbl_SobrenomeOuRSocial = new System.Windows.Forms.Label();
            this.txt_Telefone = new System.Windows.Forms.MaskedTextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.lbl_Telefone = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_RGeIE = new System.Windows.Forms.Label();
            this.mtb_CPFeCNPJ = new System.Windows.Forms.MaskedTextBox();
            this.mtb_RGeIE = new System.Windows.Forms.MaskedTextBox();
            this.CB_Sexo = new System.Windows.Forms.ComboBox();
            this.lbl_Sexo = new System.Windows.Forms.Label();
            this.lbl_TelaCadastroDe = new System.Windows.Forms.Label();
            this.lbl_Generica = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_CodCondicaoPag = new System.Windows.Forms.TextBox();
            this.txt_CondPag = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_BuscarCondPag = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CEP
            // 
            this.lbl_CEP.Location = new System.Drawing.Point(529, 74);
            // 
            // lbl_Endereco
            // 
            this.lbl_Endereco.Location = new System.Drawing.Point(8, 74);
            // 
            // lbl_Bairro
            // 
            this.lbl_Bairro.Location = new System.Drawing.Point(432, 74);
            // 
            // lbl_Numero
            // 
            this.lbl_Numero.Location = new System.Drawing.Point(367, 74);
            // 
            // lbl_Cidade
            // 
            this.lbl_Cidade.Location = new System.Drawing.Point(89, 121);
            // 
            // lbl_CodCidade
            // 
            this.lbl_CodCidade.Location = new System.Drawing.Point(8, 121);
            // 
            // mtb_CEP
            // 
            this.mtb_CEP.Location = new System.Drawing.Point(529, 94);
            this.mtb_CEP.TabIndex = 8;
            this.mtb_CEP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // txt_Endereco
            // 
            this.txt_Endereco.Location = new System.Drawing.Point(8, 94);
            this.txt_Endereco.TabIndex = 4;
            this.txt_Endereco.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_Bairro
            // 
            this.txt_Bairro.Location = new System.Drawing.Point(432, 94);
            this.txt_Bairro.TabIndex = 7;
            this.txt_Bairro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_Numero
            // 
            this.txt_Numero.Location = new System.Drawing.Point(367, 94);
            this.txt_Numero.TabIndex = 6;
            this.txt_Numero.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // txt_Cidade
            // 
            this.txt_Cidade.Location = new System.Drawing.Point(89, 141);
            // 
            // txt_CodCidade
            // 
            this.txt_CodCidade.Location = new System.Drawing.Point(8, 141);
            this.txt_CodCidade.TabIndex = 9;
            // 
            // btn_BuscarPorCidade
            // 
            this.btn_BuscarPorCidade.Location = new System.Drawing.Point(268, 139);
            this.btn_BuscarPorCidade.TabIndex = 10;
            // 
            // lbl_Complemento
            // 
            this.lbl_Complemento.Location = new System.Drawing.Point(187, 74);
            // 
            // txt_Complemento
            // 
            this.txt_Complemento.Location = new System.Drawing.Point(187, 94);
            this.txt_Complemento.TabIndex = 5;
            this.txt_Complemento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // CB_Tipo
            // 
            this.CB_Tipo.ItemHeight = 17;
            this.CB_Tipo.Items.AddRange(new object[] {
            "PF",
            "PJ"});
            this.CB_Tipo.Location = new System.Drawing.Point(88, 48);
            this.CB_Tipo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(85, 29);
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(489, 256);
            this.btn_Salvar.TabIndex = 16;
            // 
            // lbl_Código
            // 
            this.lbl_Código.Location = new System.Drawing.Point(8, 29);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(8, 49);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(561, 256);
            this.btn_Sair.TabIndex = 17;
            // 
            // txt_NomeOuNFantasia
            // 
            this.txt_NomeOuNFantasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NomeOuNFantasia.Location = new System.Drawing.Point(155, 49);
            this.txt_NomeOuNFantasia.Name = "txt_NomeOuNFantasia";
            this.txt_NomeOuNFantasia.Size = new System.Drawing.Size(181, 22);
            this.txt_NomeOuNFantasia.TabIndex = 2;
            this.txt_NomeOuNFantasia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_SobrenomeOuRSocial
            // 
            this.txt_SobrenomeOuRSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SobrenomeOuRSocial.Location = new System.Drawing.Point(346, 49);
            this.txt_SobrenomeOuRSocial.Name = "txt_SobrenomeOuRSocial";
            this.txt_SobrenomeOuRSocial.Size = new System.Drawing.Size(283, 22);
            this.txt_SobrenomeOuRSocial.TabIndex = 3;
            this.txt_SobrenomeOuRSocial.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // lbl_CNPJeCPF
            // 
            this.lbl_CNPJeCPF.AutoSize = true;
            this.lbl_CNPJeCPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CNPJeCPF.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CNPJeCPF.Location = new System.Drawing.Point(8, 166);
            this.lbl_CNPJeCPF.Name = "lbl_CNPJeCPF";
            this.lbl_CNPJeCPF.Size = new System.Drawing.Size(38, 18);
            this.lbl_CNPJeCPF.TabIndex = 31;
            this.lbl_CNPJeCPF.Text = "CPF";
            // 
            // lbl_NomeOuNFantasia
            // 
            this.lbl_NomeOuNFantasia.AutoSize = true;
            this.lbl_NomeOuNFantasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NomeOuNFantasia.ForeColor = System.Drawing.Color.Gold;
            this.lbl_NomeOuNFantasia.Location = new System.Drawing.Point(152, 29);
            this.lbl_NomeOuNFantasia.Name = "lbl_NomeOuNFantasia";
            this.lbl_NomeOuNFantasia.Size = new System.Drawing.Size(49, 18);
            this.lbl_NomeOuNFantasia.TabIndex = 22;
            this.lbl_NomeOuNFantasia.Text = "Nome";
            // 
            // lbl_SobrenomeOuRSocial
            // 
            this.lbl_SobrenomeOuRSocial.AutoSize = true;
            this.lbl_SobrenomeOuRSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SobrenomeOuRSocial.ForeColor = System.Drawing.Color.Gold;
            this.lbl_SobrenomeOuRSocial.Location = new System.Drawing.Point(343, 29);
            this.lbl_SobrenomeOuRSocial.Name = "lbl_SobrenomeOuRSocial";
            this.lbl_SobrenomeOuRSocial.Size = new System.Drawing.Size(86, 18);
            this.lbl_SobrenomeOuRSocial.TabIndex = 24;
            this.lbl_SobrenomeOuRSocial.Text = "Sobrenome";
            // 
            // txt_Telefone
            // 
            this.txt_Telefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Telefone.Location = new System.Drawing.Point(341, 141);
            this.txt_Telefone.Mask = "00000-0000";
            this.txt_Telefone.Name = "txt_Telefone";
            this.txt_Telefone.Size = new System.Drawing.Size(82, 22);
            this.txt_Telefone.TabIndex = 11;
            // 
            // txt_Email
            // 
            this.txt_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Email.Location = new System.Drawing.Point(429, 141);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(200, 22);
            this.txt_Email.TabIndex = 12;
            // 
            // lbl_Telefone
            // 
            this.lbl_Telefone.AutoSize = true;
            this.lbl_Telefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Telefone.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Telefone.Location = new System.Drawing.Point(341, 121);
            this.lbl_Telefone.Name = "lbl_Telefone";
            this.lbl_Telefone.Size = new System.Drawing.Size(65, 18);
            this.lbl_Telefone.TabIndex = 29;
            this.lbl_Telefone.Text = "Telefone";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Email.Location = new System.Drawing.Point(429, 121);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(50, 18);
            this.lbl_Email.TabIndex = 28;
            this.lbl_Email.Text = "E-mail";
            // 
            // lbl_RGeIE
            // 
            this.lbl_RGeIE.AutoSize = true;
            this.lbl_RGeIE.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RGeIE.ForeColor = System.Drawing.Color.Gold;
            this.lbl_RGeIE.Location = new System.Drawing.Point(137, 166);
            this.lbl_RGeIE.Name = "lbl_RGeIE";
            this.lbl_RGeIE.Size = new System.Drawing.Size(31, 18);
            this.lbl_RGeIE.TabIndex = 30;
            this.lbl_RGeIE.Text = "RG";
            // 
            // mtb_CPFeCNPJ
            // 
            this.mtb_CPFeCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_CPFeCNPJ.Location = new System.Drawing.Point(8, 186);
            this.mtb_CPFeCNPJ.Name = "mtb_CPFeCNPJ";
            this.mtb_CPFeCNPJ.Size = new System.Drawing.Size(126, 22);
            this.mtb_CPFeCNPJ.TabIndex = 13;
            this.mtb_CPFeCNPJ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // mtb_RGeIE
            // 
            this.mtb_RGeIE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_RGeIE.Location = new System.Drawing.Point(140, 186);
            this.mtb_RGeIE.Name = "mtb_RGeIE";
            this.mtb_RGeIE.Size = new System.Drawing.Size(123, 22);
            this.mtb_RGeIE.TabIndex = 14;
            this.mtb_RGeIE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // CB_Sexo
            // 
            this.CB_Sexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Sexo.FormattingEnabled = true;
            this.CB_Sexo.Items.AddRange(new object[] {
            "M",
            "F"});
            this.CB_Sexo.Location = new System.Drawing.Point(269, 184);
            this.CB_Sexo.Name = "CB_Sexo";
            this.CB_Sexo.Size = new System.Drawing.Size(62, 24);
            this.CB_Sexo.TabIndex = 15;
            // 
            // lbl_Sexo
            // 
            this.lbl_Sexo.AutoSize = true;
            this.lbl_Sexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sexo.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Sexo.Location = new System.Drawing.Point(266, 165);
            this.lbl_Sexo.Name = "lbl_Sexo";
            this.lbl_Sexo.Size = new System.Drawing.Size(42, 18);
            this.lbl_Sexo.TabIndex = 36;
            this.lbl_Sexo.Text = "Sexo";
            // 
            // lbl_TelaCadastroDe
            // 
            this.lbl_TelaCadastroDe.AutoSize = true;
            this.lbl_TelaCadastroDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TelaCadastroDe.ForeColor = System.Drawing.Color.Gold;
            this.lbl_TelaCadastroDe.Location = new System.Drawing.Point(7, 5);
            this.lbl_TelaCadastroDe.Name = "lbl_TelaCadastroDe";
            this.lbl_TelaCadastroDe.Size = new System.Drawing.Size(111, 24);
            this.lbl_TelaCadastroDe.TabIndex = 37;
            this.lbl_TelaCadastroDe.Text = "Cadastro de";
            // 
            // lbl_Generica
            // 
            this.lbl_Generica.AutoSize = true;
            this.lbl_Generica.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Generica.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Generica.Location = new System.Drawing.Point(119, 5);
            this.lbl_Generica.Name = "lbl_Generica";
            this.lbl_Generica.Size = new System.Drawing.Size(88, 24);
            this.lbl_Generica.TabIndex = 38;
            this.lbl_Generica.Text = "Genérico";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(343, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 18);
            this.label2.TabIndex = 40;
            this.label2.Text = "Código";
            // 
            // txt_CodCondicaoPag
            // 
            this.txt_CodCondicaoPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCondicaoPag.Location = new System.Drawing.Point(341, 186);
            this.txt_CodCondicaoPag.Name = "txt_CodCondicaoPag";
            this.txt_CodCondicaoPag.Size = new System.Drawing.Size(82, 22);
            this.txt_CodCondicaoPag.TabIndex = 41;
            this.txt_CodCondicaoPag.Text = "0";
            this.txt_CodCondicaoPag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodCondicaoPag.Leave += new System.EventHandler(this.txt_CodCondicaoPag_Leave);
            // 
            // txt_CondPag
            // 
            this.txt_CondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CondPag.Location = new System.Drawing.Point(429, 186);
            this.txt_CondPag.Name = "txt_CondPag";
            this.txt_CondPag.Size = new System.Drawing.Size(200, 22);
            this.txt_CondPag.TabIndex = 42;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(429, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 18);
            this.label3.TabIndex = 43;
            this.label3.Text = "Condição de Pagamento";
            // 
            // btn_BuscarCondPag
            // 
            this.btn_BuscarCondPag.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarCondPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarCondPag.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarCondPag.Location = new System.Drawing.Point(561, 214);
            this.btn_BuscarCondPag.Name = "btn_BuscarCondPag";
            this.btn_BuscarCondPag.Size = new System.Drawing.Size(68, 26);
            this.btn_BuscarCondPag.TabIndex = 44;
            this.btn_BuscarCondPag.Text = "Buscar";
            this.btn_BuscarCondPag.UseVisualStyleBackColor = false;
            this.btn_BuscarCondPag.Click += new System.EventHandler(this.btn_BuscarCondPag_Click);
            // 
            // FrmCadPFePJ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(640, 293);
            this.Controls.Add(this.btn_BuscarCondPag);
            this.Controls.Add(this.txt_CondPag);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_CodCondicaoPag);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Generica);
            this.Controls.Add(this.lbl_TelaCadastroDe);
            this.Controls.Add(this.lbl_Sexo);
            this.Controls.Add(this.CB_Sexo);
            this.Controls.Add(this.mtb_RGeIE);
            this.Controls.Add(this.mtb_CPFeCNPJ);
            this.Controls.Add(this.lbl_CNPJeCPF);
            this.Controls.Add(this.lbl_RGeIE);
            this.Controls.Add(this.txt_Telefone);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.lbl_Telefone);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.txt_SobrenomeOuRSocial);
            this.Controls.Add(this.lbl_SobrenomeOuRSocial);
            this.Controls.Add(this.txt_NomeOuNFantasia);
            this.Controls.Add(this.lbl_NomeOuNFantasia);
            this.Name = "FrmCadPFePJ";
            this.Text = "Cadastro de Pessoa Física e jurídica";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_CEP, 0);
            this.Controls.SetChildIndex(this.lbl_Endereco, 0);
            this.Controls.SetChildIndex(this.lbl_Bairro, 0);
            this.Controls.SetChildIndex(this.lbl_Numero, 0);
            this.Controls.SetChildIndex(this.lbl_Cidade, 0);
            this.Controls.SetChildIndex(this.lbl_CodCidade, 0);
            this.Controls.SetChildIndex(this.mtb_CEP, 0);
            this.Controls.SetChildIndex(this.txt_Endereco, 0);
            this.Controls.SetChildIndex(this.txt_Bairro, 0);
            this.Controls.SetChildIndex(this.txt_Numero, 0);
            this.Controls.SetChildIndex(this.txt_Cidade, 0);
            this.Controls.SetChildIndex(this.txt_CodCidade, 0);
            this.Controls.SetChildIndex(this.btn_BuscarPorCidade, 0);
            this.Controls.SetChildIndex(this.lbl_Complemento, 0);
            this.Controls.SetChildIndex(this.txt_Complemento, 0);
            this.Controls.SetChildIndex(this.CB_Tipo, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.lbl_NomeOuNFantasia, 0);
            this.Controls.SetChildIndex(this.txt_NomeOuNFantasia, 0);
            this.Controls.SetChildIndex(this.lbl_SobrenomeOuRSocial, 0);
            this.Controls.SetChildIndex(this.txt_SobrenomeOuRSocial, 0);
            this.Controls.SetChildIndex(this.lbl_Email, 0);
            this.Controls.SetChildIndex(this.lbl_Telefone, 0);
            this.Controls.SetChildIndex(this.txt_Email, 0);
            this.Controls.SetChildIndex(this.txt_Telefone, 0);
            this.Controls.SetChildIndex(this.lbl_RGeIE, 0);
            this.Controls.SetChildIndex(this.lbl_CNPJeCPF, 0);
            this.Controls.SetChildIndex(this.mtb_CPFeCNPJ, 0);
            this.Controls.SetChildIndex(this.mtb_RGeIE, 0);
            this.Controls.SetChildIndex(this.CB_Sexo, 0);
            this.Controls.SetChildIndex(this.lbl_Sexo, 0);
            this.Controls.SetChildIndex(this.lbl_TelaCadastroDe, 0);
            this.Controls.SetChildIndex(this.lbl_Generica, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.txt_CodCondicaoPag, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txt_CondPag, 0);
            this.Controls.SetChildIndex(this.btn_BuscarCondPag, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.MaskedTextBox txt_Telefone;
        public System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label lbl_Telefone;
        private System.Windows.Forms.Label lbl_Email;
        protected System.Windows.Forms.Label lbl_RGeIE;
        protected System.Windows.Forms.Label lbl_CNPJeCPF;
        protected System.Windows.Forms.Label lbl_Sexo;
        public System.Windows.Forms.Label lbl_NomeOuNFantasia;
        public System.Windows.Forms.Label lbl_SobrenomeOuRSocial;
        public System.Windows.Forms.MaskedTextBox mtb_CPFeCNPJ;
        public System.Windows.Forms.MaskedTextBox mtb_RGeIE;
        public System.Windows.Forms.ComboBox CB_Sexo;
        public System.Windows.Forms.TextBox txt_SobrenomeOuRSocial;
        public System.Windows.Forms.TextBox txt_NomeOuNFantasia;
        private System.Windows.Forms.Label lbl_TelaCadastroDe;
        public System.Windows.Forms.Label lbl_Generica;
        protected System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txt_CodCondicaoPag;
        public System.Windows.Forms.TextBox txt_CondPag;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_BuscarCondPag;
    }
}
