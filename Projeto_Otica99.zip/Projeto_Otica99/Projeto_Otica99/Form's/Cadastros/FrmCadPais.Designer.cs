﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadPais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CadPais = new System.Windows.Forms.Label();
            this.lbl_CadDDI = new System.Windows.Forms.Label();
            this.lbl_CadSigla = new System.Windows.Forms.Label();
            this.txt_CadPais = new System.Windows.Forms.TextBox();
            this.txt_CadDDI = new System.Windows.Forms.TextBox();
            this.txt_CadSigla = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(200, 101);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(296, 101);
            this.btn_Sair.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // lbl_CadPais
            // 
            this.lbl_CadPais.AutoSize = true;
            this.lbl_CadPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CadPais.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CadPais.Location = new System.Drawing.Point(128, 9);
            this.lbl_CadPais.Name = "lbl_CadPais";
            this.lbl_CadPais.Size = new System.Drawing.Size(42, 20);
            this.lbl_CadPais.TabIndex = 4;
            this.lbl_CadPais.Text = "País";
            // 
            // lbl_CadDDI
            // 
            this.lbl_CadDDI.AutoSize = true;
            this.lbl_CadDDI.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CadDDI.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CadDDI.Location = new System.Drawing.Point(447, 9);
            this.lbl_CadDDI.Name = "lbl_CadDDI";
            this.lbl_CadDDI.Size = new System.Drawing.Size(39, 20);
            this.lbl_CadDDI.TabIndex = 5;
            this.lbl_CadDDI.Text = "DDI";
            // 
            // lbl_CadSigla
            // 
            this.lbl_CadSigla.AutoSize = true;
            this.lbl_CadSigla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CadSigla.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CadSigla.Location = new System.Drawing.Point(525, 9);
            this.lbl_CadSigla.Name = "lbl_CadSigla";
            this.lbl_CadSigla.Size = new System.Drawing.Size(46, 20);
            this.lbl_CadSigla.TabIndex = 6;
            this.lbl_CadSigla.Text = "Sigla";
            // 
            // txt_CadPais
            // 
            this.txt_CadPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CadPais.Location = new System.Drawing.Point(132, 32);
            this.txt_CadPais.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_CadPais.MaxLength = 255;
            this.txt_CadPais.Name = "txt_CadPais";
            this.txt_CadPais.Size = new System.Drawing.Size(300, 27);
            this.txt_CadPais.TabIndex = 7;
            this.txt_CadPais.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_CadDDI
            // 
            this.txt_CadDDI.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CadDDI.Location = new System.Drawing.Point(451, 32);
            this.txt_CadDDI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_CadDDI.MaxLength = 5;
            this.txt_CadDDI.Name = "txt_CadDDI";
            this.txt_CadDDI.Size = new System.Drawing.Size(61, 27);
            this.txt_CadDDI.TabIndex = 8;
            this.txt_CadDDI.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // txt_CadSigla
            // 
            this.txt_CadSigla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CadSigla.Location = new System.Drawing.Point(531, 32);
            this.txt_CadSigla.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_CadSigla.MaxLength = 3;
            this.txt_CadSigla.Name = "txt_CadSigla";
            this.txt_CadSigla.Size = new System.Drawing.Size(41, 27);
            this.txt_CadSigla.TabIndex = 9;
            this.txt_CadSigla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // FrmCadPais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(599, 144);
            this.Controls.Add(this.txt_CadSigla);
            this.Controls.Add(this.txt_CadDDI);
            this.Controls.Add(this.txt_CadPais);
            this.Controls.Add(this.lbl_CadSigla);
            this.Controls.Add(this.lbl_CadDDI);
            this.Controls.Add(this.lbl_CadPais);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmCadPais";
            this.Text = "Cadastro de País";
            this.Load += new System.EventHandler(this.FrmCadPais_Load);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_CadPais, 0);
            this.Controls.SetChildIndex(this.lbl_CadDDI, 0);
            this.Controls.SetChildIndex(this.lbl_CadSigla, 0);
            this.Controls.SetChildIndex(this.txt_CadPais, 0);
            this.Controls.SetChildIndex(this.txt_CadDDI, 0);
            this.Controls.SetChildIndex(this.txt_CadSigla, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected System.Windows.Forms.Label lbl_CadPais;
        protected System.Windows.Forms.Label lbl_CadDDI;
        protected System.Windows.Forms.Label lbl_CadSigla;
        public System.Windows.Forms.TextBox txt_CadPais;
        public System.Windows.Forms.TextBox txt_CadDDI;
        public System.Windows.Forms.TextBox txt_CadSigla;
    }
}
