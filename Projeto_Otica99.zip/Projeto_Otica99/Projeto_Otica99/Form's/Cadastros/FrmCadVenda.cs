﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System.Globalization;
using System.IO;
using Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço;
using Projeto_Otica99.Form_s.Consultas;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadVenda : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        DadosCadastro oCliente;
        Vendas aVenda;
        ItensVenda oItemVenda;
        Ctrl_Vendas aCTRLVenda;
        Ctrl_Produtos aCTRLProdutos;
        Ctrl_Clientes aCTRLClientes;
        int estoqueItens = 0;
        string tipoProdServ = "P";
        int ID_CONDICAO = 0;
        int IdSelecionado = 0;
        string NomeSelecionado = "";
        decimal valorUnit = 0m;
        int NumNFe;
        int SerieNFe;
        int ModeloNFe;
        bool permiteExclusao = true;
        private bool AutorizadoSalvar = false;
        Dictionary<int, Image> imagensProdutos = new Dictionary<int, Image>();  
        DateTime dtCriacao;
        DateTime dtEmissao;
        DateTime dtCancelamento;

        public FrmCadVenda()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            InicializarDataGridView();
            aVenda = new Vendas();
            oItemVenda = new ItensVenda();
            oCliente = new DadosCadastro();
            aCTRLProdutos = new Ctrl_Produtos();
            aCTRLVenda = new Ctrl_Vendas();
            aCTRLClientes = new Ctrl_Clientes();
        }
        public void BuscarNFE()
        {
            NumNFe = aCTRLVenda.BuscarNFE("NUMERO") + 1;
            SerieNFe = aCTRLVenda.BuscarNFE("SERIE");
            ModeloNFe = aCTRLVenda.BuscarNFE("MODELO"); 
        }

        private void InicializarDataGridView()
        {
            DgItensVenda.AutoGenerateColumns = false;

            DataGridViewImageColumn deleteColumn = new DataGridViewImageColumn();
            deleteColumn.Name = "DeleteColumn";
            deleteColumn.HeaderText = "Excluir";
            deleteColumn.Width = 80; 
            deleteColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
            DgItensVenda.Columns.Add(deleteColumn);

            DataGridViewTextBoxColumn numeroItemColumn = new DataGridViewTextBoxColumn();
            numeroItemColumn.Name = "numero_item";
            numeroItemColumn.HeaderText = "Item";
            numeroItemColumn.Width = 50;
            DgItensVenda.Columns.Add(numeroItemColumn);

            DataGridViewTextBoxColumn codigoColumn = new DataGridViewTextBoxColumn();
            codigoColumn.Name = "codigo";
            codigoColumn.HeaderText = "Código";
            codigoColumn.Width = 60;
            DgItensVenda.Columns.Add(codigoColumn);

            DataGridViewTextBoxColumn descricaoColumn = new DataGridViewTextBoxColumn();
            descricaoColumn.Name = "descricao";
            descricaoColumn.HeaderText = "Descrição";
            descricaoColumn.Width = 250;
            DgItensVenda.Columns.Add(descricaoColumn);

            DataGridViewTextBoxColumn quantidadeColumn = new DataGridViewTextBoxColumn();
            quantidadeColumn.Name = "quantidade";
            quantidadeColumn.HeaderText = "QTD";
            quantidadeColumn.Width = 50;
            DgItensVenda.Columns.Add(quantidadeColumn);

            DataGridViewTextBoxColumn descontoColumn = new DataGridViewTextBoxColumn();
            descontoColumn.Name = "desconto";
            descontoColumn.HeaderText = "Desconto";
            descontoColumn.Width = 100; 
            DgItensVenda.Columns.Add(descontoColumn);

            DataGridViewTextBoxColumn valorUnitarioColumn = new DataGridViewTextBoxColumn();
            valorUnitarioColumn.Name = "valor_unitario";
            valorUnitarioColumn.HeaderText = "R$ Unit.";
            valorUnitarioColumn.Width = 130;
            DgItensVenda.Columns.Add(valorUnitarioColumn);

            DataGridViewTextBoxColumn subTotalColumn = new DataGridViewTextBoxColumn();
            subTotalColumn.Name = "sub_total";
            subTotalColumn.HeaderText = "Subtotal";
            subTotalColumn.Width = 130;
            DgItensVenda.Columns.Add(subTotalColumn);

            DataGridViewTextBoxColumn tipoColumn = new DataGridViewTextBoxColumn();
            tipoColumn.Name = "tipo";
            tipoColumn.HeaderText = "Tipo";
            tipoColumn.Width = 30;
            DgItensVenda.Columns.Add(tipoColumn);
        }
        public void LimparCampos()
        {
            txt_Codigo.Clear();
            txt_Cliente.Clear();
            txt_CodProd.Clear();
            txt_CPFeCNPJ.Clear();
            txt_Prod.Clear();
            txt_Qntd.Text = "1";
            txt_CustoUnit.Clear();
            txt_CustoTotal.Clear();
            txt_Desc.Text = "0";         
            CB_ServProd.SelectedIndex = 0;
        }
        public virtual void Popular(Vendas aVenda)
        {

            CultureInfo cultura = CultureInfo.InvariantCulture;
            NumNFe = aVenda.NumNfv;
            ModeloNFe = aVenda.ModeloNfv;
            SerieNFe = aVenda.SerieNfv;
            txt_Codigo.Text = aVenda.Cliente.ID.ToString();
            txt_Cliente.Text = aVenda.Cliente.NomeOuNomeFantasia;
            dtCriacao = aVenda.DataCriacao;
            dtEmissao = aVenda.DataEmissao;
            txt_ValorFrete.Text = aVenda.ValorFrete.ToString("0.##", cultura);
            txt_ValorSeg.Text = aVenda.ValorSeguro.ToString("0.##", cultura);
            txt_Outros.Text = aVenda.ValorOutrasDespesas.ToString("0.##", cultura);
            lbl_TotNota.Text = aVenda.ValorTotal.ToString("0.##", cultura);
            txt_CodCond.Text = aVenda.CondicaoPagamento.ID.ToString();
            txt_Condicao.Text = aVenda.CondicaoPagamento.Condicao;
            string documento = "";
            oCliente = aVenda.Cliente;
            //if (oCliente.TipoCliente == "F")
            //    if (oCliente.CPFouCNPJ != null)
            //        documento = oCliente.CPFouCNPJ.ToString();              
            //else if (oCliente.TipoCliente == "J")
            //    documento = oCliente.CPFouCNPJ.ToString();


            txt_CPFeCNPJ.Text = Verificacao.FormatarDocumento(documento);

            int codigo = Convert.ToInt32(NumNFe);
            int modelo = Convert.ToInt32(ModeloNFe);
            int serie = Convert.ToInt32(SerieNFe);
            int cliente = Convert.ToInt32(txt_Codigo.Text);

            Ctrl_ItensVenda aCTLItensVenda = new Ctrl_ItensVenda();
            List<ItensVenda> ItemVenda = aCTLItensVenda.BuscarItensVendaPorChave2(codigo, modelo, serie);

            PopularItens(ItemVenda);
            CarregaLV();
        }
        public void PopularItens(List<ItensVenda> List)
        {
            if (List == null)
            {
                throw new ArgumentNullException(nameof(List), "A lista de itens não pode ser null.");
            }

            DgItensVenda.Rows.Clear();
            int itemNumber = DgItensVenda.Rows.Count + 1;
            foreach (ItensVenda Item in List)
            {
                DgItensVenda.Rows.Add(
                itemNumber,
                Item.IdItem.ToString(),
                Item.Descricao.ToString(),
                Item.QtdItem.ToString(),
                Item.Desconto.ToString(),
                Item.PrecoUnitario.ToString("F2"),
                Item.TotalItem.ToString("F2"),
                Item.TipoItem.ToString());
            }
        }

        private void Salvar()
        {
            if (AutorizadoSalvar)
            {
                if (DgItensVenda.Rows.Count > 0)
                {
                    if (VerificarCamposVazios())
                    {
                        Vendas venda = new Vendas();
                        venda.Cliente = new DadosCadastro();
                        List<ContasReceber> listaContasReceber = new List<ContasReceber>();
                        venda.CondicaoPagamento = new CondicaoPagamento();
                        venda.Cliente.ID = Convert.ToInt32(txt_Codigo.Text);
                        venda.CondicaoPagamento.ID = oCliente.condicao_Pagamento.ID;
                        venda.NumNfv = NumNFe;
                        venda.ModeloNfv = ModeloNFe;
                        venda.SerieNfv = SerieNFe;
                        venda.ValorTotal = Convert.ToDecimal(lbl_TotNota.Text);
                        venda.ValorFrete = decimal.Parse(txt_ValorFrete.Text);
                        venda.ValorSeguro = decimal.Parse(txt_ValorSeg.Text);
                        venda.ValorOutrasDespesas = decimal.Parse(txt_Outros.Text);
                        venda.DataCriacao = DateTime.Now;
                        venda.DataEmissao = DateTime.Now;
                        venda.DataSaida = DateTime.Now;
                        venda.ItensVenda = ItensListView(venda.NumNfv, venda.ModeloNfv, venda.SerieNfv, venda.Cliente.ID);


                        foreach (ListViewItem item in lvParcelas.Items)
                        {
                            ContasReceber aContareceber = new ContasReceber();
                            aContareceber.NumNFC = venda.NumNfv;
                            aContareceber.ModeloNFC = venda.ModeloNfv;
                            aContareceber.SerieNFC = venda.SerieNfv;
                            aContareceber.NumParcela = Convert.ToInt32(item.SubItems[0].Text);
                            aContareceber.Cliente.ID = venda.Cliente.ID;
                            aContareceber.Condicao.ID = venda.CondicaoPagamento.ID;
                            aContareceber.Valor = Convert.ToDecimal(item.SubItems[5].Text);
                            aContareceber.Situacao = "A RECEBER";
                            aContareceber.DataCriacao = DateTime.Now;
                            aContareceber.DataVencimento = DateTime.Now.AddDays(Convert.ToInt32(item.SubItems[1].Text));
                            aContareceber.DataUltAlteracao = DateTime.Now;
                            aContareceber.FormaPagamento.ID = Convert.ToInt32(item.SubItems[2].Text);
                            
                            listaContasReceber.Add(aContareceber);
                        }
                        venda.ContasReceber = listaContasReceber;

                        bool result = aCTRLVenda.AdicionarVenda(venda);

                        if (!result)
                        {
                            MessageBox.Show("Erro ao salvar a venda.");
                        }
                        else
                        {
                            MessageBox.Show("venda salva com sucesso!");
                        }
                        this.Close();
                    }

                }
                return;
            }
        }
        public List<ItensVenda> ItensListView(int Num_nfc, int Modelo_nfc, int Serie_nfc, int Id_cliente)
        {
            var vLista = new List<ItensVenda>();
            foreach (DataGridViewRow vLinha in DgItensVenda.Rows)
            {
                ItensVenda ItensVenda = new ItensVenda();
                ItensVenda.NumNfv = Num_nfc;
                ItensVenda.ModeloNfv = Modelo_nfc;
                ItensVenda.SerieNfv = Serie_nfc;
                ItensVenda.Cliente.ID = Id_cliente;
                ItensVenda.TipoItem = Convert.ToString(vLinha.Cells["tipo"].Value);
                ItensVenda.IdItem = Convert.ToInt32(vLinha.Cells["codigo"].Value);
                ItensVenda.QtdItem = Convert.ToInt32(vLinha.Cells["quantidade"].Value);
                ItensVenda.PrecoUnitario = Convert.ToDecimal(vLinha.Cells["valor_unitario"].Value);
                ItensVenda.Desconto = Convert.ToDecimal(vLinha.Cells["desconto"].Value);
                ItensVenda.TotalItem = Convert.ToDecimal(lbl_TotNota.Text);
                ItensVenda.DataCriacao = DateTime.Now;
                vLista.Add(ItensVenda);
            }
            return vLista;
        }

        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txt_Codigo.Text))
            {
                camposFaltantes.Add("Código do Cliente");
            }
            if (string.IsNullOrWhiteSpace(txt_ValorFrete.Text))
            {
                camposFaltantes.Add("Frete");
            }
            if (string.IsNullOrWhiteSpace(txt_Outros.Text))
            {
                camposFaltantes.Add("Outras taxas");
            }
            if (string.IsNullOrWhiteSpace(txt_ValorSeg.Text))
            {
                camposFaltantes.Add("Seguro");
            }
            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void CB_ServProd_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_CodProd.Enabled = true;


            if (CB_ServProd.Text == "Produtos") 
            {
                tipoProdServ = "P"; 
                lbl_CodProd.Text = "Cód Produto";

            }
            else 
            {
                tipoProdServ = "S"; 
                lbl_CodProd.Text = "Cód Serviço";
            }

            Panel_Prod.Enabled = true;
            txt_CodProd.Clear();
            txt_Qntd.Focus();
            txt_Qntd.Select();
            limparItens();
        }
        private void limparItens()
        {
            txt_Desc.Text = "0";
            txt_CodProd.Clear();
            txt_Prod.Clear();
            txt_Qntd.Text = "1";
            txt_CustoTotal.Clear();
            txt_CustoUnit.Clear();          
        }

        private void btn_BuscarProd_Click(object sender, EventArgs e)
        {
            txt_CustoTotal.Clear();
            if (!string.IsNullOrWhiteSpace(CB_ServProd.Text))
            {
                if (tipoProdServ == "P") 
                {
                    using (FrmConProdutos frm = new FrmConProdutos())
                    {
                        frm.btn_Sair.Text = "Selecionar";
                        frm.ShowDialog();
                    
                        IdSelecionado = frm.IdSelecionado;
                        NomeSelecionado = frm.NomeSelecionado;
                        estoqueItens = Convert.ToInt32(frm.Und);

                        txt_CodProd.Text = IdSelecionado.ToString();
                        txt_Prod.Text = NomeSelecionado;
                        BuscarProdutoOuServicoPorId(IdSelecionado); 
                        CalculoDescontos(); 
                    }
                }
                else if (tipoProdServ == "S") 
                {
                    using (FrmConServicos frm = new FrmConServicos())
                    {
                        frm.btn_Sair.Text = "Selecionar";
                        frm.ShowDialog();
                       
                        IdSelecionado = frm.IdSelecionado;
                        NomeSelecionado = frm.NomeSelecionado;

                        txt_CodProd.Text = IdSelecionado.ToString();
                        txt_Prod.Text = NomeSelecionado; 
                        BuscarProdutoOuServicoPorId(IdSelecionado);
                        CalculoDescontos(); 
                    }
                }
            }
        }

        private void txt_CodProd_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_CodProd.Text))
            {
                txt_CodProd.Clear();
            }
            else if (int.TryParse(txt_CodProd.Text, out int cod) && cod > 0)
            {
                BuscarProdutoOuServicoPorId(cod);
                CalculoDescontos(); 
            }
            else
            {
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                txt_CodProd.Clear();
            }
        }

        private void BuscarProdutoOuServicoPorId(int id)
        {
            if (CB_ServProd.Text == "Produtos")
            {
                Produtos produto = aCTRLProdutos.BuscarProdutoPorId(id);

                if (produto == null)
                {
                    MessageBox.Show("Produto não encontrado para o código especificado.");
                    limparItens();
                }
                else if (produto.Status == "I")
                {
                    MessageBox.Show("O produto associado a este código está inativo.");
                    limparItens();
                }
                else
                {
                    txt_Prod.Text = produto.Nome;
                    estoqueItens = produto.QtdEstoque;
                    valorUnit = produto.PrecoVenda;
                    txt_CustoUnit.Text = produto.PrecoVenda.ToString();
                    
                }
            }
            else if (CB_ServProd.Text == "Serviços")
            {
                Ctrl_Servicos aCTLServ = new Ctrl_Servicos();
                Servicos servico = aCTLServ.BuscarServicoPorId(id);

                if (servico == null)
                {
                    MessageBox.Show("Serviço não encontrado para o código especificado.");
                    txt_CodProd.Clear();
                    txt_CustoUnit.Clear();
                    txt_Prod.Clear();
                }
                else if (servico.Status == "I")
                {
                    MessageBox.Show("O serviço associado a este código está inativo.");
                    txt_CodProd.Clear();
                    txt_Prod.Clear();
                    txt_CustoUnit.Clear();
                }
                else
                {
                    txt_Prod.Text = servico.Descricao;
                    valorUnit = servico.Valor;
                    txt_CustoUnit.Text = servico.Valor.ToString();
                    
                }

            }
        }

        private void btn_BuscarCliente_Click(object sender, EventArgs e)
        {
            BuscarClientePorDocumento(txt_CPFeCNPJ.Text.Trim());
        }
        private void BuscarClientePorDocumento(string documento)
        {
            if (string.IsNullOrWhiteSpace(documento)) 
            {

                using (FrmConClientes frm = new FrmConClientes())
                {
                    frm.btn_Sair.Text = "Selecionar";
                    frm.ShowDialog();

                    int IdSelecionado = frm.IdSelecionado;
                    txt_Codigo.Text = IdSelecionado.ToString();

                    oCliente = aCTRLClientes.BuscarClientePorId(IdSelecionado);
                    if (oCliente != null) 
                    {
                        FuncoesCliente();
                    }
                    else
                    {
                        MessageBox.Show("Documento não encontrado.");
                    }
                }
            }
            else
            {
                oCliente = aCTRLClientes.BuscarClientePorDocumento2(documento);
                if (oCliente != null)
                {
                    FuncoesCliente();
                }
                else
                {
                    MessageBox.Show("Documento não encontrado.");
                }
            }
        }
        private void FuncoesCliente()
        {
            txt_Codigo.Text = oCliente.ID.ToString();
            txt_Cliente.Text = oCliente.NomeOuNomeFantasia;
            
            string documentoCliente = string.IsNullOrWhiteSpace(oCliente.CPFouCNPJ) ? oCliente.RGouIE : oCliente.CPFouCNPJ;
            txt_CPFeCNPJ.Text = Verificacao.FormatarDocumento(documentoCliente);
            CB_ServProd.Focus();
            CB_ServProd.Select();
        }

        private void txt_Qntd_KeyPress(object sender, KeyPressEventArgs e)
        {
     
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }

        private void btn_NovoProd_Click(object sender, EventArgs e)
        {

            string tipoItemOriginal = CB_ServProd.Text;

            if (string.IsNullOrWhiteSpace(CB_ServProd.Text))
            {
                MessageBox.Show("Por favor, selecione um tipo de item (Produto ou Serviço).");
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_CodProd.Text))
            {
                MessageBox.Show("Por favor, insira o código do produto ou serviço.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Qntd.Text) || !int.TryParse(txt_Qntd.Text, out int quantidade) || quantidade <= 0)
            {
                MessageBox.Show("Por favor, insira uma quantidade válida.");
                return;
            }

            int id = int.Parse(txt_CodProd.Text);
            string tipo = CB_ServProd.Text == "Produtos" ? "P" : "S";

            if (VerificarItemDuplicado(id, tipo))
            {
                MessageBox.Show("Item com o mesmo código e tipo já foi adicionado.");
                limparItens();
                return;
            }
            decimal desconto = string.IsNullOrWhiteSpace(txt_Desc.Text) ? 0 : Convert.ToDecimal(txt_Desc.Text);
            decimal valorUnitario = valorUnit;

            if (tipo == "P")
            {
                if (quantidade > estoqueItens)
                {
                    MessageBox.Show($"Quantidade de Produtos excede o estoque disponível ({estoqueItens}).", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }


            decimal subtotalSemDesconto = valorUnitario * quantidade;
            decimal subtotalComDesconto = subtotalSemDesconto - desconto;
            btn_FVenda.Enabled = true;
            int itemNumber = DgItensVenda.Rows.Count + 1;
            DgItensVenda.Rows.Add(
                
                itemNumber,
                id.ToString(),
                txt_Prod.Text,
                quantidade,
                desconto,
                valorUnitario.ToString("F2"),
                subtotalComDesconto.ToString("F2"),
                tipo

            );

            AtualizarTotalNota();
            limparItens();
            valorUnit = 0;
            estoqueItens = 0;
            CB_ServProd.Text = tipoItemOriginal;
        }

        private void AtualizarTotalNota()
        {
            decimal totalNota = 0;

            foreach (DataGridViewRow row in DgItensVenda.Rows)
            {
                if (row.Cells["sub_total"].Value != null)
                {

                    if (decimal.TryParse(row.Cells["sub_total"].Value.ToString(), out decimal subTotal))
                    {
                        totalNota += subTotal;
                    }
                    else
                    {

                        MessageBox.Show("Erro ao converter o valor do subtotal para decimal.", "Erro de Conversão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            decimal frete = 0;
            decimal seguro = 0;
            decimal outras = 0;

            if (decimal.TryParse(txt_ValorFrete.Text.ToString(), out decimal freteValue))
            {
                frete = freteValue;
            }
            if (decimal.TryParse(txt_ValorSeg.Text.ToString(), out decimal seguroValue))
            {
                seguro = seguroValue;
            }
            if (decimal.TryParse(txt_Outros.Text.ToString(), out decimal outrasValue))
            {
                outras = outrasValue;
            }

            decimal custoTotal = frete + seguro + outras + totalNota;
            lbl_TotNota.Text = custoTotal.ToString("F2");
        }

        private bool VerificarItemDuplicado(int id, string tipo)
        {
            foreach (DataGridViewRow row in DgItensVenda.Rows)
            {
                if (row.Cells["codigo"].Value != null && row.Cells["Tipo"].Value != null)
                {
                    if (Convert.ToInt32(row.Cells["codigo"].Value) == id && row.Cells["Tipo"].Value.ToString() == tipo)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private void DgItensVenda_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.Text != "Consultar uma Venda")
            {
                if (e.ColumnIndex == DgItensVenda.Columns["DeleteColumn"].Index && e.RowIndex >= 0 && permiteExclusao)
                {
                
                    DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este item?", "Confirmar Exclusão",
                                                           MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        DgItensVenda.Rows.RemoveAt(e.RowIndex);

                        AtualizarNumerosItens();

                        AtualizarTotalNota();
                        if (DgItensVenda.Rows.Count == 0)
                        {
                            btn_FVenda.Enabled = false;
                        }
                    }
                }
            }
        }

        private void AtualizarNumerosItens()
        {
            for (int i = 0; i < DgItensVenda.Rows.Count; i++)
            {
                DgItensVenda.Rows[i].Cells["numero_item"].Value = i + 1;
            }
        }

        private void Sair()
        {
            if (DgItensVenda.Rows.Count > 0)
            {
        
                DialogResult result = MessageBox.Show("Tem certeza que deseja cancelar esta venda e sair?", "Cancelar Venda ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    Close();
                }
            }
            else
            {
                if (txt_Codigo.Text.Length > 0)
                {
                    DialogResult result = MessageBox.Show("Tem certeza que deseja cancelar esta venda e sair?", "Cancelar Venda", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        Close();
                    }
                }
                else
                    Close();
            }

        }

        private void btn_ExcluirItem_Click(object sender, EventArgs e)
        {
            if (DgItensVenda.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecione um item para excluir.");
                return;
            }

            DialogResult result = MessageBox.Show("Tem certeza que deseja excluir o item selecionado?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                foreach (DataGridViewRow row in DgItensVenda.SelectedRows)
                {
                    DgItensVenda.Rows.Remove(row);
                }

                AtualizarTotalNota();
            }
        }

        private void txt_CPFeCNPJ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                BuscarClientePorDocumento(txt_CPFeCNPJ.Text.Trim());
            }
        }

        private void DgItensVenda_SelectionChanged(object sender, EventArgs e)
        {
            if (DgItensVenda.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = DgItensVenda.SelectedRows[0];
                int idSelecionado = Convert.ToInt32(selectedRow.Cells["codigo"].Value);                
            }
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            if (btn_Sair.Text == "Sair")
                Close();
            else
                Sair();
        }
        public void DesabilitarBotoes()
        {
            txt_ValorFrete.Enabled = false;
            txt_ValorSeg.Enabled = false;
            txt_Outros.Enabled = false;
            btn_Salvar.Enabled = false;
            
        }

        private void txt_Qntd_Leave(object sender, EventArgs e)
        {
            CalculoDescontos();
        }

        private void CalculoDescontos()
        {
            if (!string.IsNullOrWhiteSpace(txt_Qntd.Text) && !string.IsNullOrWhiteSpace(txt_CustoUnit.Text))
            {
                decimal valorUnitario;
                if (decimal.TryParse(txt_CustoUnit.Text.Replace("R$", "").Trim(), out valorUnitario))
                {
                    int quantidade;
                    if (int.TryParse(txt_Qntd.Text, out quantidade))
                    {
                        decimal valorTotal = quantidade * valorUnitario;

                        decimal desconto = 0;
                        if (!string.IsNullOrWhiteSpace(txt_Desc.Text))
                        {
                            if (decimal.TryParse(txt_Desc.Text.Replace("R$", "").Trim(), out desconto))
                            {
                         
                                if (valorTotal - desconto >= 0)
                                {
                                    valorTotal -= desconto;
                                }
                                else
                                {
                                    MessageBox.Show("O desconto não pode resultar em um valor total negativo.", "Erro de Desconto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    txt_Desc.Text = "0";
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Valor de desconto inválido.", "Erro de Desconto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txt_Desc.Text = "0";
                                return;
                            }
                        }
                  
                        txt_CustoUnit.Text = valorUnitario.ToString("0.00");
                
                        txt_CustoTotal.Text = valorTotal.ToString("0.00");
                    }
                    else
                    {
                        MessageBox.Show("Quantidade inválida.", "Erro de Quantidade", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txt_Qntd.Text = "1";
                        txt_CustoTotal.Text = "0.00";
                    }
                }
                else
                {
                    MessageBox.Show("Valor unitário inválido.", "Erro de Valor Unitário", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_CustoUnit.Text = "";
                    txt_CustoTotal.Text = "0.00";
                }
            }
            else
            {
                txt_CustoTotal.Text = "0.00";
            }
        }

        private void txt_Desc_Leave(object sender, EventArgs e)
        {
            CalculoDescontos();
        }

        private void btn_FVenda_Click(object sender, EventArgs e)
        {
            if (btn_FVenda.Text == "FINALIZAR VENDA")
            {
                permiteExclusao = false;
               
                btn_FVenda.Text = "LIBERAR PRODUTOS";
                btn_FVenda.BackColor = Color.DarkGreen;
            }
            else
            {         
                DgItensVenda.ReadOnly = false;         
                permiteExclusao = true;
                lvParcelas.Items.Clear();
                txt_ValorFrete.Clear();
                txt_Outros.Clear();
                txt_ValorSeg.Clear();
                btn_FVenda.Text = "FINALIZAR VENDA";
                btn_FVenda.BackColor = Color.DarkRed;

            }
            AtualizarTotalNota();
        }

        private void btn_FCond_Click(object sender, EventArgs e)
        {
            if (btn_FCond.Text == "FINALIZAR CONDIÇÃO")
            {
                LiberarFrete(false);
                btn_FCond.Text = "LIBERAR CONDIÇÃO"; 
                btn_FCond.BackColor = Color.DarkGreen;
                btn_FCond.Enabled = true; 
                lbl_TotNota.Enabled = true; 
                AtualizarTotalNota();
                LiberarCondicaoPagamento();
                AutorizadoSalvar = true;

            }
            else if (btn_FCond.Text == "LIBERAR CONDIÇÃO")
            {
                LiberarFrete(true);
                btn_FCond.Text = "FINALIZAR CONDIÇÃO";
                btn_FCond.BackColor = Color.DarkRed;
                btn_FCond.Enabled = true;
                AtualizarTotalNota();
                LiberarCondicaoPagamento();
                AutorizadoSalvar = false;

            }
        }
        private void LiberarCondicaoPagamento()
        {
            if (DgItensVenda.Rows.Count > 0)
            {

                int cod = oCliente.condicao_Pagamento.ID;
                Ctrl_CondPagamento aCTLcon = new Ctrl_CondPagamento();
                CondicaoPagamento condicao = aCTLcon.BuscarCondicaoPagamentoPorId(cod);
                if (condicao != null)
                {
                    txt_CodCond.Text = condicao.ID.ToString();
                    txt_Condicao.Text = condicao.Condicao;
                    CarregaLV();
                }
            }
            else
            {           
                txt_CodCond.Text = "";
                txt_Condicao.Text = "";
            }
        }

        private void CarregaLV()
        {
            int cod = Convert.ToInt32(txt_CodCond.Text);
            Ctrl_Parcelas aCTLParcela = new Ctrl_Parcelas();
            List<Parcelas> dados = aCTLParcela.BuscarParcelasPorIDCondicao(cod); ;
            PreencherListView(dados);
        }

        private void PreencherListView(IEnumerable<Parcelas> dados)
        {
            lvParcelas.Items.Clear();

            // Calcula o custo total com os adicionais uma vez para uso em todas as parcelas
            decimal custoTotalComAdicionais = CalcularCustoTotalComAdicionais();

            foreach (var parcela in dados)
            {
                ListViewItem item = new ListViewItem(parcela.NumParcela.ToString());
                item.SubItems.Add(parcela.DiasTotais.ToString());
                item.SubItems.Add(parcela.Forma.ID.ToString());
                item.SubItems.Add(parcela.Forma.Forma);
                item.SubItems.Add(parcela.Porcentagem.ToString());

                // Calcula o valor da parcela com base na porcentagem e no custo total com adicionais
                decimal valorParcela = (parcela.Porcentagem / 100) * custoTotalComAdicionais;
                item.SubItems.Add(valorParcela.ToString("F2")); // Adiciona o valor da parcela na posição correta

                item.Tag = parcela;
                lvParcelas.Items.Add(item);
            }

        }
        private void LiberarFrete(bool valor)
        {
            txt_ValorFrete.Enabled = valor;
            txt_Outros.Enabled = valor;
            txt_ValorSeg.Enabled = valor;
        }
        private decimal CalcularCustoTotalComAdicionais()
        {
            decimal total = CustoTotal(); // Chama o método existente para obter o custo total atual

            // Somar os custos de frete, seguro e outros se não forem nulos ou vazios
            decimal frete = 0;
            decimal seguro = 0;
            decimal outrosCustos = 0;

            if (!string.IsNullOrEmpty(txt_ValorFrete.Text)) frete = Convert.ToDecimal(txt_ValorFrete.Text);
            if (!string.IsNullOrEmpty(txt_ValorSeg.Text)) seguro = Convert.ToDecimal(txt_ValorSeg.Text);
            if (!string.IsNullOrEmpty(txt_Outros.Text)) outrosCustos = Convert.ToDecimal(txt_Outros.Text);

            total += frete + seguro + outrosCustos;

            return total;
        }
        private decimal CustoTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow vLinha in DgItensVenda.Rows)
            {
                total += Convert.ToDecimal(vLinha.Cells["quantidade"].Value) * Convert.ToDecimal(vLinha.Cells["valor_unitario"].Value);
            }
            return total;
        }

        private void txt_ValorFrete_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }

        private void txt_ValorFrete_Leave(object sender, EventArgs e)
        {
            AtualizarTotalNota();
        }
    }
}
