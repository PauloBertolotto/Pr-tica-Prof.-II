﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConServicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.CB_Descricao = new System.Windows.Forms.CheckBox();
            this.CB_Codigo = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(273, 22);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(683, 520);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(755, 520);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(827, 520);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 79);
            this.LV_Con_Pai.Size = new System.Drawing.Size(958, 439);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(899, 21);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Size = new System.Drawing.Size(259, 23);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(899, 520);
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(191, 52);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(77, 22);
            this.CB_Inativos.TabIndex = 17;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            this.CB_Inativos.CheckedChanged += new System.EventHandler(this.CB_Inativos_CheckedChanged);
            // 
            // CB_Descricao
            // 
            this.CB_Descricao.AutoSize = true;
            this.CB_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Descricao.ForeColor = System.Drawing.Color.Gold;
            this.CB_Descricao.Location = new System.Drawing.Point(90, 52);
            this.CB_Descricao.Name = "CB_Descricao";
            this.CB_Descricao.Size = new System.Drawing.Size(95, 22);
            this.CB_Descricao.TabIndex = 15;
            this.CB_Descricao.Text = "Descrição";
            this.CB_Descricao.UseVisualStyleBackColor = true;
            // 
            // CB_Codigo
            // 
            this.CB_Codigo.AutoSize = true;
            this.CB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.CB_Codigo.Location = new System.Drawing.Point(9, 52);
            this.CB_Codigo.Name = "CB_Codigo";
            this.CB_Codigo.Size = new System.Drawing.Size(75, 22);
            this.CB_Codigo.TabIndex = 14;
            this.CB_Codigo.Text = "Código";
            this.CB_Codigo.UseVisualStyleBackColor = true;
            // 
            // FrmConServicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(975, 555);
            this.Controls.Add(this.CB_Inativos);
            this.Controls.Add(this.CB_Descricao);
            this.Controls.Add(this.CB_Codigo);
            this.Name = "FrmConServicos";
            this.Text = "Consulta: Serviços";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Codigo, 0);
            this.Controls.SetChildIndex(this.CB_Descricao, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox CB_Inativos;
        private System.Windows.Forms.CheckBox CB_Descricao;
        private System.Windows.Forms.CheckBox CB_Codigo;
    }
}
