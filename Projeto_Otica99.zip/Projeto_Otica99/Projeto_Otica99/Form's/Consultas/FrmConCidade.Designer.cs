﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConCidade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CH_Cidade = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DDD = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Estado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCadastro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(602, 21);
            this.btn_ConBuscar.Size = new System.Drawing.Size(64, 27);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Cidade,
            this.CH_DDD,
            this.CH_Estado,
            this.CH_DataCadastro,
            this.CH_DataUltAlt});
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(9, 23);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txt_Codigo.Size = new System.Drawing.Size(587, 23);
            // 
            // CH_Cidade
            // 
            this.CH_Cidade.Text = "Cidade";
            this.CH_Cidade.Width = 130;
            // 
            // CH_DDD
            // 
            this.CH_DDD.Text = "DDD";
            // 
            // CH_Estado
            // 
            this.CH_Estado.Text = "Estado";
            this.CH_Estado.Width = 150;
            // 
            // CH_DataCadastro
            // 
            this.CH_DataCadastro.Text = "Data de Cadastro";
            this.CH_DataCadastro.Width = 150;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 150;
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(671, 23);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(77, 22);
            this.CB_Inativos.TabIndex = 15;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            // 
            // FrmConCidade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(846, 488);
            this.Controls.Add(this.CB_Inativos);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "FrmConCidade";
            this.Text = "Consulta de Cidades";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColumnHeader CH_Cidade;
        private System.Windows.Forms.ColumnHeader CH_DDD;
        private System.Windows.Forms.ColumnHeader CH_Estado;
        private System.Windows.Forms.ColumnHeader CH_DataCadastro;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
        private System.Windows.Forms.CheckBox CB_Inativos;
    }
}
