﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RB_Codigo = new System.Windows.Forms.RadioButton();
            this.RB_Categoria = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 83);
            this.LV_Con_Pai.Size = new System.Drawing.Size(811, 368);
            // 
            // RB_Codigo
            // 
            this.RB_Codigo.AutoSize = true;
            this.RB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.RB_Codigo.Location = new System.Drawing.Point(9, 52);
            this.RB_Codigo.Name = "RB_Codigo";
            this.RB_Codigo.Size = new System.Drawing.Size(74, 22);
            this.RB_Codigo.TabIndex = 10;
            this.RB_Codigo.TabStop = true;
            this.RB_Codigo.Text = "Código";
            this.RB_Codigo.UseVisualStyleBackColor = true;
            // 
            // RB_Categoria
            // 
            this.RB_Categoria.AutoSize = true;
            this.RB_Categoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RB_Categoria.ForeColor = System.Drawing.Color.Gold;
            this.RB_Categoria.Location = new System.Drawing.Point(89, 52);
            this.RB_Categoria.Name = "RB_Categoria";
            this.RB_Categoria.Size = new System.Drawing.Size(90, 22);
            this.RB_Categoria.TabIndex = 11;
            this.RB_Categoria.TabStop = true;
            this.RB_Categoria.Text = "Categoria";
            this.RB_Categoria.UseVisualStyleBackColor = true;
            // 
            // FrmConCategoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(828, 488);
            this.Controls.Add(this.RB_Categoria);
            this.Controls.Add(this.RB_Codigo);
            this.Name = "FrmConCategoria";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.RB_Codigo, 0);
            this.Controls.SetChildIndex(this.RB_Categoria, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton RB_Codigo;
        private System.Windows.Forms.RadioButton RB_Categoria;
    }
}
