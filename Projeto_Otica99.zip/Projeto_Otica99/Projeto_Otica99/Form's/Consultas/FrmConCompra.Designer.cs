﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(972, 21);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(829, 537);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(901, 537);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(973, 537);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Size = new System.Drawing.Size(1104, 480);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(1045, 21);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Size = new System.Drawing.Size(959, 23);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1045, 537);
            // 
            // FrmConCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1121, 572);
            this.Name = "FrmConCompra";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}
