﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using Projeto_Otica99.Class_s.Outros;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmConContas_a_Pagar : Projeto_Otica99.FrmPai
    {
        FrmCadContasPagar frmContaPagar;
        ContasPagar aContaPagar;
        protected Dictionary<string, double> _colunasProporcao = new Dictionary<string, double>();
        Ctrl_ContasPagar aCTRLContaPagar;
        public FrmConContas_a_Pagar()
        {
            InitializeComponent();
            this.Resize += FrmConContas_a_Pagar_Resize;
            aCTRLContaPagar = new Ctrl_ContasPagar();
            Verificacao.DisableCopyPaste(this);
            DataGrid();
            CarregaLV();
        }
        protected void CalcularProporcoesColunas(DataGridView dgv)
        {
            _colunasProporcao.Clear();
            double larguraTotal = dgv.Width;

            foreach (DataGridViewColumn coluna in dgv.Columns)
            {
                if (coluna.Visible)
                {
                    _colunasProporcao[coluna.Name] = (double)coluna.Width / larguraTotal;
                }
            }
        }
        
       
        protected void RedimensionarColunas(DataGridView dgv)
        {
            double larguraTotal = dgv.Width;

            foreach (DataGridViewColumn coluna in dgv.Columns)
            {
                if (coluna.Visible && _colunasProporcao.ContainsKey(coluna.Name))
                {
                    coluna.Width = (int)(_colunasProporcao[coluna.Name] * larguraTotal);
                }
            }
        }

        public void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmContaPagar = (FrmCadContasPagar)obj;
            }
        }
        public void ConhecaObj(object obj)
        {
            aContaPagar = (ContasPagar)obj;
        }
        protected void Incluir()
        {
            aCTRLContaPagar.Incluir();
            CarregaLV();
        }

        protected int ObterIdSelecionado(string columnName)
        {
            if (dgvContas.SelectedRows.Count > 0)
            {
                return int.Parse(dgvContas.SelectedRows[0].Cells[columnName].Value.ToString());
            }
            return 0;
        }
        protected string ObterNomeSelecionado(string columnName)
        {
            if (dgvContas.SelectedRows.Count > 0)
            {
                return dgvContas.SelectedRows[0].Cells[columnName].Value.ToString();
            }
            return string.Empty; // Retorna uma string vazia como valor padrão caso não haja linha selecionada
        }
        public void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (dgvContas.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvContas.SelectedRows[0];
                ContasPagar conta = selectedRow.Tag as ContasPagar;
                if (conta != null)
                {
                    aCTRLContaPagar.Visualizar(conta);
                    CarregaLV();
                }
            }
        }

        public void CarregaLV()
        {
            string valor = CB_Status.Text;
            if (string.IsNullOrEmpty(valor))
                valor = "A PAGAR"; // Define o valor padrão como "A PAGAR" se o ComboBox estiver vazio
            List<ContasPagar> dados = aCTRLContaPagar.ListarContasPagar(valor);
            PreencherDataGridView(dados);
        }

        // Método para preencher o DataGridView com os dados de ContasPagar
        protected virtual void PreencherDataGridView(IEnumerable<ContasPagar> dados)
        {
            dgvContas.Rows.Clear();

            foreach (var conta in dados)
            {
                int rowIndex = dgvContas.Rows.Add();
                DataGridViewRow row = dgvContas.Rows[rowIndex];

                row.Cells["num_nfc"].Value = conta.NumNFC;
                row.Cells["modelo_nfc"].Value = conta.ModeloNFC;
                row.Cells["serie_nfc"].Value = conta.SerieNFC;
                row.Cells["num_parcela"].Value = conta.NumParcela;
                row.Cells["id_fornecedor"].Value = conta.Fornecedor.ID;
                row.Cells["fornecedor"].Value = conta.Fornecedor.NomeOuNomeFantasia;
                row.Cells["Forma_pagamento"].Value = conta.FormaPagamento.Forma;
                row.Cells["Data_emissao"].Value = conta.DataCriacao == DateTime.MinValue ? string.Empty : conta.DataCriacao.ToString("dd/MM/yyyy");
                row.Cells["data_vencimento"].Value = conta.DataVencimento == DateTime.MinValue ? string.Empty : conta.DataVencimento.ToString("dd/MM/yyyy");
                row.Cells["Valor"].Value = conta.Valor == 0 ? string.Empty : conta.Valor.ToString("C");
                row.Cells["data_baixa"].Value = conta.DataBaixa == DateTime.MinValue ? string.Empty : conta.DataBaixa.ToString("dd/MM/yyyy");
                row.Cells["Pagamento"].Value = conta.Pagamento == 0 ? string.Empty : conta.Pagamento.ToString("C");
                row.Cells["Juros"].Value = conta.Condicao.Taxa;
                row.Cells["Multa"].Value = conta.Condicao.Multa;
                row.Cells["Desconto"].Value = conta.Condicao.Desconto;
                row.Cells["situacao"].Value = conta.Situacao;
                row.Tag = conta;
            }

            AplicarFormatacao();
        }

        protected void DataGrid()
        {
            // Configurações iniciais do DataGridView
            dgvContas.AutoGenerateColumns = false;
            dgvContas.Columns.Clear(); // Limpa as colunas existentes
            dgvContas.Columns.AddRange(new DataGridViewTextBoxColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "num_nfc", HeaderText = "Nº NFC", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "modelo_nfc", HeaderText = "Modelo", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "serie_nfc", HeaderText = "Série", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "num_parcela", HeaderText = "Parcela", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "id_fornecedor", HeaderText = "Cód Forn.", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "fornecedor", HeaderText = "Fornecedor", Width = 200 },
                new DataGridViewTextBoxColumn { Name = "Forma_pagamento", HeaderText = "Forma Pgt", Width = 155 },
                new DataGridViewTextBoxColumn { Name = "Data_emissao", HeaderText = "Data Emissão", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "data_vencimento", HeaderText = "Data Vencimento", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Valor", HeaderText = "Parcela VR (R$)", Width = 120 },
                new DataGridViewTextBoxColumn { Name = "data_baixa", HeaderText = "Data Baixa", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Pagamento", HeaderText = "Valor PG (R$)", Width = 120 },
                new DataGridViewTextBoxColumn { Name = "Juros", HeaderText = "Juros", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "Multa", HeaderText = "Multa", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "Desconto", HeaderText = "Desconto", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "situacao", HeaderText = "Status", Width = 110 },
            });

            dgvContas.RowTemplate.Height = 40; // Altura das linhas em pixels

            dgvContas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvContas.MultiSelect = false;
            CalcularProporcoesColunas(dgvContas);
        }



        protected void AplicarFormatacao() // Aplica a formatação das cores no DataGridView
        {
            // Itera sobre cada linha do DataGridView
            foreach (DataGridViewRow row in dgvContas.Rows)
            {
                // Garante que nenhuma célula está selecionada
                dgvContas.CurrentCell = null;

                // Obtém o valor da célula "situacao"
                string situacao = row.Cells["situacao"].Value as string;

                // Formata a linha com fundo verde se a situação for "PAGO"
                if (situacao == "PAGO")
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        cell.Style.BackColor = Color.LightGreen;
                        cell.Style.ForeColor = Color.Black;
                    }
                }
                else if (situacao == "CANCELADA")
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        cell.Style.BackColor = Color.Gray;
                        cell.Style.ForeColor = Color.Black;
                    }
                }
                else
                {
                    // Verifica e formata com base na data de vencimento
                    if (row.Cells["data_vencimento"].Value != null && DateTime.TryParse(row.Cells["data_vencimento"].Value.ToString(), out DateTime dataVencimento))
                    {
                        TimeSpan diasParaVencimento = dataVencimento - DateTime.Now;

                        Color backColor;
                        Color foreColor;

                        if (diasParaVencimento.TotalDays < 0)
                        {
                            backColor = Color.DarkRed; // Vencida
                            foreColor = Color.White;  // Texto em branco para vencidas
                        }
                        else if (diasParaVencimento.TotalDays <= 3)
                        {
                            backColor = Color.Orange; // Entre 0 e 3 dias
                            foreColor = Color.Black;  // Texto padrão
                        }
                        else
                        {
                            backColor = Color.Yellow; // Mais de 3 dias
                            foreColor = Color.Black;  // Texto padrão
                        }

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            cell.Style.BackColor = backColor;
                            cell.Style.ForeColor = foreColor;
                        }
                    }
                }
            }
        }
        protected void PesquisarContasPagar()
        {
            // Obtém os parâmetros de filtragem
            DateTime? dataInicio = null;
            DateTime? dataFim    = null;

            if (dtData1.Value.Date > DateTime.MinValue.Date)
            {
                dataInicio = dtData1.Value.Date;
            }

            if (dtData2.Value.Date > DateTime.MinValue.Date)
            {
                dataFim = dtData2.Value.Date;
            }
            if (string.IsNullOrEmpty(CB_Datas.Text))
            {
                return;
            }           
            DateTime dataInicioValue = dataInicio ?? DateTime.MinValue;
            DateTime dataFimValue    = dataFim ?? DateTime.MinValue;
           
            List<ContasPagar> contas = aCTRLContaPagar.ListarContasPagarComData(CB_Status.Text, dataInicioValue, dataFimValue, CB_Datas.Text);
            PreencherDataGridView(contas);
        }
        private void btn_BuscarData_Click(object sender, EventArgs e)
        {
            if (dtData1.Value > dtData2.Value)
            {
                MessageBox.Show("O periodo de busca não pode conter uma data inicial maior que a data final.");
            }
            else
                PesquisarContasPagar();
        }

        private void txt_Fornecedor_TextChanged(object sender, EventArgs e)
        {
            List<ContasPagar> dados = aCTRLContaPagar.BuscarContasPorNomeFornecedor(txt_Fornecedor.Text);
            PreencherDataGridView(dados);
        }

        private void btn_Pagar_Click(object sender, EventArgs e)
        {
            if (dgvContas.SelectedCells.Count > 0)
            {
                int numero = ObterIdSelecionado("num_nfc");
                int modelo = ObterIdSelecionado("modelo_nfc");
                int serie = ObterIdSelecionado("serie_nfc");
                int fornecedor = ObterIdSelecionado("id_fornecedor");
                int parcela = ObterIdSelecionado("num_parcela");
                string status = ObterNomeSelecionado("situacao");

                if (status != "CANCELADA")
                {
                    ContasPagar conta = aCTRLContaPagar.BuscarContaPagar(numero, modelo, serie, fornecedor, parcela);
                    if (conta != null)
                    {
                        aCTRLContaPagar.Alterar(conta);
                        CarregaLV();
                    }
                }
                else
                {
                    MessageBox.Show(
                        "A operação não pode ser realizada porque a nota fiscal selecionada foi cancelada.",
                        "Ação não permitida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
            }
        }

        private void FrmConContas_a_Pagar_Load(object sender, EventArgs e)
        {
            this.Resize += FrmConContas_a_Pagar_Resize;
        }

        private void dgvContas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvContas.EndEdit();
        }

        private void dgvContas_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Visualizar();
        }

        private void FrmConContas_a_Pagar_Resize(object sender, EventArgs e)
        {
            if (this.Controls.OfType<DataGridView>().Any())
            {
                DataGridView dgv = this.Controls.OfType<DataGridView>().First();
                RedimensionarColunas(dgv);
            }
        }

        private void btn_BuscarDados_Click(object sender, EventArgs e)
        {
            int NumNFC = Convert.ToInt32(txt_Numero.Text);
            int ModeloNFC = Convert.ToInt32(txt_Modelo.Text);
            int SerieNFC = Convert.ToInt32(txt_Serie.Text);
            int FornNFC = Convert.ToInt32(txt_CFornecedor.Text);
            int ParcelaNFC = Convert.ToInt32(txt_NParcelas.Text);

            List<ContasPagar> dados = aCTRLContaPagar.BuscarContas(NumNFC, ModeloNFC, SerieNFC, FornNFC, ParcelaNFC);
            PreencherDataGridView(dados);
        }

        private void btn_BuscarFornecedor_Click(object sender, EventArgs e)
        {
            CarregaLV();
        }
    }
}
