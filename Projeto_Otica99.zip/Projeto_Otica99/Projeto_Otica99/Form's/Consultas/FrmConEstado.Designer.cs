﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConEstado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CH_Estado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_UF = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCadastro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Pais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(597, 24);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Estado,
            this.CH_UF,
            this.CH_Pais,
            this.CH_DataCadastro,
            this.CH_DataUltAlt});
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(752, 24);
            this.btn_Att.Margin = new System.Windows.Forms.Padding(2);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(10, 26);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txt_Codigo.Size = new System.Drawing.Size(581, 23);
            // 
            // CH_Estado
            // 
            this.CH_Estado.Text = "Estado";
            this.CH_Estado.Width = 130;
            // 
            // CH_UF
            // 
            this.CH_UF.Text = "UF";
            // 
            // CH_DataCadastro
            // 
            this.CH_DataCadastro.Text = "Data de Cadastro";
            this.CH_DataCadastro.Width = 150;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 150;
            // 
            // CH_Pais
            // 
            this.CH_Pais.Text = "País";
            this.CH_Pais.Width = 130;
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(670, 26);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(77, 22);
            this.CB_Inativos.TabIndex = 15;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            // 
            // FrmConEstado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(846, 488);
            this.Controls.Add(this.CB_Inativos);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "FrmConEstado";
            this.Text = "Consulta de Estados";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColumnHeader CH_Estado;
        private System.Windows.Forms.ColumnHeader CH_UF;
        private System.Windows.Forms.ColumnHeader CH_Pais;
        private System.Windows.Forms.ColumnHeader CH_DataCadastro;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
        private System.Windows.Forms.CheckBox CB_Inativos;
    }
}
