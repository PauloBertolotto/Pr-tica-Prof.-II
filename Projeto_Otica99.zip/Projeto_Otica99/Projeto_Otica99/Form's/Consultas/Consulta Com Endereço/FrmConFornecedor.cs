﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using System.Linq;

namespace Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço
{
    public partial class FrmConFornecedor : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        DadosCadastro     oFornecedor;
        FrmCadPFePJ       oCadFornecedor;
        Ctrl_Fornecedores aCtrl_Fornecedor;
        
        public FrmConFornecedor()
        {
            InitializeComponent();
            oFornecedor      = new DadosCadastro();
            aCtrl_Fornecedor = new Ctrl_Fornecedores();
        }
        public int id = 0;
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadFornecedor = (FrmCadPFePJ)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Fornecedor = (Ctrl_Fornecedores)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadFornecedor.ConhecaObj(oFornecedor);
            oCadFornecedor.lbl_Generica.Text = "Fornecedor";
            oCadFornecedor.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {             
            string aux                        = oCadFornecedor.btn_Salvar.Text;
            oCadFornecedor.txt_Codigo.Enabled = false;
            oCadFornecedor.btn_Salvar.Text    = "Alterar";
            oCadFornecedor.lbl_Generica.Text  = "Fornecedor";
            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                // Crie uma instância da tela de destino

                // Preencha os campos ou propriedades da tela de destino com os dados do item selecionado
                oCadFornecedor.txt_Codigo.Text = itemSelecionado.SubItems[0].Text;
                oCadFornecedor.txt_NomeOuNFantasia.Text = itemSelecionado.SubItems[1].Text;
                oCadFornecedor.txt_SobrenomeOuRSocial.Text = itemSelecionado.SubItems[2].Text;
                if (itemSelecionado.SubItems[3].Text.Length < 18)
                {
                    oCadFornecedor.CB_Tipo.Text = "PF";
                    oCadFornecedor.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFornecedor.CB_Tipo.Enabled = false;
                }
                else
                {
                    oCadFornecedor.CB_Tipo.Text = "PJ";
                    oCadFornecedor.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFornecedor.CB_Sexo.Text = null;
                    oCadFornecedor.CB_Tipo.Enabled = false;
                }
                oCadFornecedor.mtb_RGeIE.Text = itemSelecionado.SubItems[4].Text;
                oCadFornecedor.txt_Email.Text = itemSelecionado.SubItems[5].Text;
                oCadFornecedor.txt_Telefone.Text = itemSelecionado.SubItems[6].Text;
                oCadFornecedor.txt_Numero.Text = itemSelecionado.SubItems[9].Text;
                oCadFornecedor.txt_Endereco.Text = itemSelecionado.SubItems[7].Text;
                oCadFornecedor.txt_Complemento.Text = itemSelecionado.SubItems[8].Text;
                oCadFornecedor.mtb_CEP.Text = itemSelecionado.SubItems[11].Text;
                oCadFornecedor.txt_Bairro.Text = itemSelecionado.SubItems[10].Text;
                oCadFornecedor.txt_Cidade.Text = itemSelecionado.SubItems[12].Text;
                oCadFornecedor.CB_Sexo.Text = itemSelecionado.SubItems[14].Text;
                oCadFornecedor.txt_CodCidade.Text = Convert.ToInt32(aCtrl_Fornecedor.BuscarIDCidade(oCadFornecedor.txt_Cidade.Text)).ToString();

                // Exiba a tela de destino
                oCadFornecedor.ShowDialog();
                oCadFornecedor.btn_Salvar.Text = aux;
                oCadFornecedor.CB_Tipo.Enabled = true;
                oCadFornecedor.CB_Sexo.Enabled = true;
                oCadFornecedor.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        //protected override void Buscar()
        //{
        //    base.Buscar();
        //    string valorPesquisa = txt_Codigo.Text;
        //
        //    if (!string.IsNullOrEmpty(valorPesquisa))
        //    {
        //        // Execute uma pesquisa na camada de controle com base no critério
        //        LV_Con_Pai.Items.Clear();
        //        var lista = aCtrl_Fornecedor.Pesquisar(valorPesquisa);
        //
        //        if (lista != null)
        //        {
        //            foreach (var oFornecedor in lista)
        //            {
        //                ListViewItem item = new ListViewItem(Convert.ToString(oFornecedor.ID));
        //                if (oFornecedor.Ativo == "A")
        //                {
        //                    item.SubItems.Add(oFornecedor.NomeOuNomeFantasia);
        //                    item.SubItems.Add(oFornecedor.SobrenomeOuRSocial);
        //                    item.SubItems.Add(oFornecedor.CPFouCNPJ);
        //                    item.SubItems.Add(oFornecedor.Email);
        //                    item.SubItems.Add(oFornecedor.Telefone);
        //                    item.SubItems.Add(oFornecedor.RGouIE);
        //                    item.SubItems.Add(Convert.ToString(aCtrl_Fornecedor.BuscarCidadePorId(oFornecedor.CidadeID)));
        //                    item.SubItems.Add(aCtrl_Fornecedor.BuscaUF(Convert.ToString(aCtrl_Fornecedor.BuscarCidadePorId(oFornecedor.CidadeID))));
        //                    item.SubItems.Add(oFornecedor.Endereco);
        //                    item.SubItems.Add(oFornecedor.Complemento);
        //                    item.SubItems.Add(oFornecedor.Numero);
        //                    item.SubItems.Add(oFornecedor.Bairro);
        //                    item.SubItems.Add(oFornecedor.CEP);
        //
        //                    item.SubItems.Add(Convert.ToString(oFornecedor.DataCriacao));
        //                    item.SubItems.Add(Convert.ToString(oFornecedor.DataUltimaAlteracao));
        //
        //
        //                    LV_Con_Pai.Items.Add(item);
        //                }
        //            }
        //        }
        //        else
        //        {
        //            // Caso não haja resultados, limpe a ListView ou mostre uma mensagem adequada
        //            // Exemplo: LV_Con_Pai.Items.Clear();
        //        }
        //    }
        //}
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Fornecedor.Excluir(aux);
                    
                }
                this.CarregaLV();
            }
        }
        //public override void CarregaLV()
        //{
        //    base.CarregaLV();
        //    LV_Con_Pai.Items.Clear();
        //    var lista = aCtrl_Fornecedor.ListarFornecedores();
        //
        //    foreach (var oFornecedor in lista)
        //    {
        //        // Verifica se ambos ou nenhum dos checkboxes estão marcados
        //        bool ambosOuNenhum = (CB_PF.Checked && CB_PJ.Checked) || (!CB_PF.Checked && !CB_PJ.Checked);
        //
        //        // Verifica se o fornecedor deve ser incluído com base nos checkboxes e na condição acima
        //        bool incluirFornecedor = ambosOuNenhum ||
        //                              (CB_PF.Checked && oFornecedor.CPFouCNPJ.Length < 15) ||
        //                              (CB_PJ.Checked && oFornecedor.CPFouCNPJ.Length > 15);
        //
        //        if (incluirFornecedor)
        //        {
        //            ListViewItem item = new ListViewItem(Convert.ToString(oFornecedor.ID));
        //            if ((oFornecedor.Ativo == "I" && CB_Inativos.Checked) || (oFornecedor.Ativo == "A" && !CB_Inativos.Checked))
        //            {
        //                item.SubItems.Add(oFornecedor.NomeOuNomeFantasia);
        //                item.SubItems.Add(oFornecedor.SobrenomeOuRSocial);
        //                item.SubItems.Add(oFornecedor.CPFouCNPJ);
        //                item.SubItems.Add(oFornecedor.Email);
        //                item.SubItems.Add(oFornecedor.RGouIE);
        //                item.SubItems.Add(oFornecedor.Telefone);
        //                item.SubItems.Add(oFornecedor.Endereco);
        //                item.SubItems.Add(oFornecedor.Complemento);
        //                item.SubItems.Add(oFornecedor.Numero);
        //                item.SubItems.Add(oFornecedor.Bairro);
        //                item.SubItems.Add(oFornecedor.CEP);
        //                item.SubItems.Add(Convert.ToString(aCtrl_Fornecedor.BuscarCidadePorId(oFornecedor.CidadeID)));
        //                item.SubItems.Add(aCtrl_Fornecedor.BuscaUF(Convert.ToString(aCtrl_Fornecedor.BuscarCidadePorId(oFornecedor.CidadeID))));
        //                item.SubItems.Add(oFornecedor.Sexo);
        //                item.SubItems.Add(Convert.ToString(oFornecedor.DataCriacao));
        //                item.SubItems.Add(Convert.ToString(oFornecedor.DataUltimaAlteracao));
        //
        //                LV_Con_Pai.Items.Add(item);
        //            }
        //        }
        //    }
        //}    
    }
}
