﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço
{
    public partial class FrmConFuncionarios : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        DadosCadastro     oFuncionario;
        FrmCadPFePJ       oCadFuncionario;
        Ctrl_Funcionarios aCtrl_Funcionarios;
        public FrmConFuncionarios()
        {
            InitializeComponent();
            oFuncionario       = new DadosCadastro();
            aCtrl_Funcionarios = new Ctrl_Funcionarios();
        }
        public int id = 0;
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadFuncionario = (FrmCadPFePJ)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Funcionarios = (Ctrl_Funcionarios)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadFuncionario.ConhecaObj(oFuncionario);
            oCadFuncionario.lbl_Generica.Text = "Funcionário";
            oCadFuncionario.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            string aux = oCadFuncionario.btn_Salvar.Text;
            oCadFuncionario.btn_Salvar.Text = "Alterar";
            oCadFuncionario.lbl_Generica.Text = "Funcionário";
            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                // Crie uma instância da tela de destino

                // Preencha os campos ou propriedades da tela de destino com os dados do item selecionado
                oCadFuncionario.txt_Codigo.Text             = itemSelecionado.SubItems[0].Text;
                oCadFuncionario.txt_NomeOuNFantasia.Text    = itemSelecionado.SubItems[1].Text;
                oCadFuncionario.txt_SobrenomeOuRSocial.Text = itemSelecionado.SubItems[2].Text;
                if (itemSelecionado.SubItems[3].Text.Length < 18)
                {
                    oCadFuncionario.CB_Tipo.Text      = "PF";
                    oCadFuncionario.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFuncionario.CB_Tipo.Enabled   = false;
                }
                else
                {
                    oCadFuncionario.CB_Tipo.Text      = "PJ";
                    oCadFuncionario.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFuncionario.CB_Sexo.Text      = null;
                    oCadFuncionario.CB_Tipo.Enabled   = false;
                }
                oCadFuncionario.mtb_RGeIE.Text        = itemSelecionado.SubItems[4].Text;
                oCadFuncionario.txt_Email.Text        = itemSelecionado.SubItems[5].Text;
                oCadFuncionario.txt_Telefone.Text     = itemSelecionado.SubItems[6].Text;
                oCadFuncionario.txt_Numero.Text       = itemSelecionado.SubItems[9].Text;
                oCadFuncionario.txt_Endereco.Text     = itemSelecionado.SubItems[7].Text;
                oCadFuncionario.txt_Complemento.Text  = itemSelecionado.SubItems[8].Text;
                oCadFuncionario.mtb_CEP.Text          = itemSelecionado.SubItems[11].Text;
                oCadFuncionario.txt_Bairro.Text       = itemSelecionado.SubItems[10].Text;
                oCadFuncionario.txt_Cidade.Text       = itemSelecionado.SubItems[12].Text;
                oCadFuncionario.CB_Sexo.Text          = itemSelecionado.SubItems[14].Text;
                oCadFuncionario.txt_CodCidade.Text    = Convert.ToInt32(aCtrl_Funcionarios.BuscarIDCidade(oCadFuncionario.txt_Cidade.Text)).ToString();

                // Exiba a tela de destino
                oCadFuncionario.ShowDialog();
                oCadFuncionario.btn_Salvar.Text = aux;
                oCadFuncionario.CB_Tipo.Enabled = true;
                oCadFuncionario.CB_Sexo.Enabled = true;
                oCadFuncionario.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        //public override void CarregaLV()
        //{
        //    base.CarregaLV();
        //    LV_Con_Pai.Items.Clear();
        //    var lista = aCtrl_Funcionarios.ListarFuncionarios();
        //
        //    foreach (var oFuncionario in lista)
        //    {
        //        // Verifica se ambos ou nenhum dos checkboxes estão marcados
        //        bool ambosOuNenhum = (CB_PF.Checked && CB_PJ.Checked) || (!CB_PF.Checked && !CB_PJ.Checked);
        //
        //        // Verifica se o funcionario deve ser incluído com base nos checkboxes e na condição acima
        //        bool incluirFuncionarios = ambosOuNenhum ||
        //                              (CB_PF.Checked && oFuncionario.CPFouCNPJ.Length < 15) ||
        //                              (CB_PJ.Checked && oFuncionario.CPFouCNPJ.Length > 15);
        //
        //        if (incluirFuncionarios)
        //        {
        //            ListViewItem item = new ListViewItem(Convert.ToString(oFuncionario.ID));
        //            if ((oFuncionario.Ativo == "I" && CB_Inativos.Checked) || (oFuncionario.Ativo == "A" && !CB_Inativos.Checked))
        //            {
        //                item.SubItems.Add(oFuncionario.NomeOuNomeFantasia);
        //                item.SubItems.Add(oFuncionario.SobrenomeOuRSocial);
        //                item.SubItems.Add(oFuncionario.CPFouCNPJ);
        //                item.SubItems.Add(oFuncionario.Email);
        //                item.SubItems.Add(oFuncionario.RGouIE);
        //                item.SubItems.Add(oFuncionario.Telefone);
        //                item.SubItems.Add(oFuncionario.Endereco);
        //                item.SubItems.Add(oFuncionario.Complemento);
        //                item.SubItems.Add(oFuncionario.Numero);
        //                item.SubItems.Add(oFuncionario.Bairro);
        //                item.SubItems.Add(oFuncionario.CEP);
        //                item.SubItems.Add(Convert.ToString(aCtrl_Funcionarios.BuscarCidadePorId(oFuncionario.CidadeID)));
        //                item.SubItems.Add(aCtrl_Funcionarios.BuscaUF(Convert.ToString(aCtrl_Funcionarios.BuscarCidadePorId(oFuncionario.CidadeID))));
        //                item.SubItems.Add(oFuncionario.Sexo);
        //                item.SubItems.Add(Convert.ToString(oFuncionario.DataCriacao));
        //                item.SubItems.Add(Convert.ToString(oFuncionario.DataUltimaAlteracao));
        //
        //                LV_Con_Pai.Items.Add(item);
        //            }
        //        }
        //    }
        //}

        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Funcionarios.Excluir(aux);

                }
                this.CarregaLV();
            }
        }
        //protected override void Buscar()
        //{
        //    base.Buscar();
        //    string valorPesquisa = txt_Codigo.Text;
        //
        //    if (!string.IsNullOrEmpty(valorPesquisa))
        //    {
        //        // Execute uma pesquisa na camada de controle com base no critério
        //        LV_Con_Pai.Items.Clear();
        //        var lista = aCtrl_Funcionarios.Pesquisar(valorPesquisa);
        //
        //        if (lista != null)
        //        {
        //            foreach (var oFuncionario in lista)
        //            {
        //                ListViewItem item = new ListViewItem(Convert.ToString(oFuncionario.ID));
        //                if (oFuncionario.Ativo == "A")
        //                {
        //                    item.SubItems.Add(oFuncionario.NomeOuNomeFantasia);
        //                    item.SubItems.Add(oFuncionario.SobrenomeOuRSocial);
        //                    item.SubItems.Add(oFuncionario.CPFouCNPJ);
        //                    item.SubItems.Add(oFuncionario.Email);
        //                    item.SubItems.Add(oFuncionario.Telefone);
        //                    item.SubItems.Add(oFuncionario.RGouIE);
        //                    item.SubItems.Add(Convert.ToString(aCtrl_Funcionarios.BuscarCidadePorId(oFuncionario.CidadeID)));
        //                    item.SubItems.Add(aCtrl_Funcionarios.BuscaUF(Convert.ToString(aCtrl_Funcionarios.BuscarCidadePorId(oFuncionario.CidadeID))));
        //                    item.SubItems.Add(oFuncionario.Endereco);
        //                    item.SubItems.Add(oFuncionario.Complemento);
        //                    item.SubItems.Add(oFuncionario.Numero);
        //                    item.SubItems.Add(oFuncionario.Bairro);
        //                    item.SubItems.Add(oFuncionario.CEP);
        //
        //                    item.SubItems.Add(Convert.ToString(oFuncionario.DataCriacao));
        //                    item.SubItems.Add(Convert.ToString(oFuncionario.DataUltimaAlteracao));
        //
        //
        //                    LV_Con_Pai.Items.Add(item);
        //                }
        //            }
        //        }
        //        else
        //        {
        //            // Caso não haja resultados, limpe a ListView ou mostre uma mensagem adequada
        //            // Exemplo: LV_Con_Pai.Items.Clear();
        //        }
        //    }
        //}
        public override void Atualizar()
        {
            CarregaLV();
        }
    }
}
