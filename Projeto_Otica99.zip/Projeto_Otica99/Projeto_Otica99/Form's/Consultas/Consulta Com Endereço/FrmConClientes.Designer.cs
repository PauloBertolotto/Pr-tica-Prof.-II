﻿namespace Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço
{
    partial class FrmConClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CH_NomeOuNFantasia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_SobrenomeOuRSocial = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_CNPJouCPF = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_RGouIE = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Telefone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Complemento = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Numero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Bairro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_CEP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Cidade = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_UF = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCadastro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.CH_Endereco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CB_PF = new System.Windows.Forms.CheckBox();
            this.CB_PJ = new System.Windows.Forms.CheckBox();
            this.CH_Sexo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(466, 22);
            this.btn_ConBuscar.Size = new System.Drawing.Size(67, 27);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(605, 453);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(677, 453);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(749, 453);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_NomeOuNFantasia,
            this.CH_SobrenomeOuRSocial,
            this.CH_CNPJouCPF,
            this.CH_RGouIE,
            this.CH_Email,
            this.CH_Telefone,
            this.CH_Endereco,
            this.CH_Complemento,
            this.CH_Numero,
            this.CH_Bairro,
            this.CH_CEP,
            this.CH_Cidade,
            this.CH_UF,
            this.CH_Sexo,
            this.CH_DataCadastro,
            this.CH_DataUltAlt});
            this.LV_Con_Pai.Size = new System.Drawing.Size(880, 396);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(821, 22);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(10, 24);
            this.txt_Codigo.Size = new System.Drawing.Size(451, 23);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(821, 453);
            // 
            // CH_NomeOuNFantasia
            // 
            this.CH_NomeOuNFantasia.Text = "Nome/Nome Fantasia";
            this.CH_NomeOuNFantasia.Width = 150;
            // 
            // CH_SobrenomeOuRSocial
            // 
            this.CH_SobrenomeOuRSocial.Text = "Sobrenome/R.Social";
            this.CH_SobrenomeOuRSocial.Width = 150;
            // 
            // CH_CNPJouCPF
            // 
            this.CH_CNPJouCPF.Text = "CPF/CNPJ";
            this.CH_CNPJouCPF.Width = 150;
            // 
            // CH_RGouIE
            // 
            this.CH_RGouIE.Text = "RG/IE";
            this.CH_RGouIE.Width = 120;
            // 
            // CH_Email
            // 
            this.CH_Email.Text = "Email";
            this.CH_Email.Width = 150;
            // 
            // CH_Telefone
            // 
            this.CH_Telefone.Text = "Telefone";
            this.CH_Telefone.Width = 90;
            // 
            // CH_Complemento
            // 
            this.CH_Complemento.Text = "Complemento";
            this.CH_Complemento.Width = 120;
            // 
            // CH_Numero
            // 
            this.CH_Numero.Text = "Número";
            this.CH_Numero.Width = 80;
            // 
            // CH_Bairro
            // 
            this.CH_Bairro.Text = "Bairro";
            this.CH_Bairro.Width = 90;
            // 
            // CH_CEP
            // 
            this.CH_CEP.Text = "CEP";
            this.CH_CEP.Width = 90;
            // 
            // CH_Cidade
            // 
            this.CH_Cidade.Text = "Cidade";
            this.CH_Cidade.Width = 150;
            // 
            // CH_UF
            // 
            this.CH_UF.Text = "UF";
            // 
            // CH_DataCadastro
            // 
            this.CH_DataCadastro.Text = "Data de Cadastro";
            this.CH_DataCadastro.Width = 150;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 150;
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(538, 24);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(77, 22);
            this.CB_Inativos.TabIndex = 10;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            // 
            // CH_Endereco
            // 
            this.CH_Endereco.Text = "Endereço";
            this.CH_Endereco.Width = 150;
            // 
            // CB_PF
            // 
            this.CB_PF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_PF.AutoSize = true;
            this.CB_PF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_PF.ForeColor = System.Drawing.Color.Gold;
            this.CB_PF.Location = new System.Drawing.Point(620, 24);
            this.CB_PF.Name = "CB_PF";
            this.CB_PF.Size = new System.Drawing.Size(95, 22);
            this.CB_PF.TabIndex = 11;
            this.CB_PF.Text = "Pessoa F.";
            this.CB_PF.UseVisualStyleBackColor = true;
            // 
            // CB_PJ
            // 
            this.CB_PJ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CB_PJ.AutoSize = true;
            this.CB_PJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_PJ.ForeColor = System.Drawing.Color.Gold;
            this.CB_PJ.Location = new System.Drawing.Point(721, 24);
            this.CB_PJ.Name = "CB_PJ";
            this.CB_PJ.Size = new System.Drawing.Size(94, 22);
            this.CB_PJ.TabIndex = 12;
            this.CB_PJ.Text = "Pessoa J.";
            this.CB_PJ.UseVisualStyleBackColor = true;
            // 
            // CH_Sexo
            // 
            this.CH_Sexo.Text = "Sexo";
            // 
            // FrmConClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(897, 488);
            this.Controls.Add(this.CB_PJ);
            this.Controls.Add(this.CB_PF);
            this.Controls.Add(this.CB_Inativos);
            this.Name = "FrmConClientes";
            this.Text = "Consulta de Clientes";
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_PF, 0);
            this.Controls.SetChildIndex(this.CB_PJ, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColumnHeader CH_NomeOuNFantasia;
        private System.Windows.Forms.ColumnHeader CH_SobrenomeOuRSocial;
        private System.Windows.Forms.ColumnHeader CH_CNPJouCPF;
        private System.Windows.Forms.ColumnHeader CH_RGouIE;
        private System.Windows.Forms.ColumnHeader CH_Email;
        private System.Windows.Forms.ColumnHeader CH_Telefone;
        private System.Windows.Forms.ColumnHeader CH_Complemento;
        private System.Windows.Forms.ColumnHeader CH_Numero;
        private System.Windows.Forms.ColumnHeader CH_Bairro;
        private System.Windows.Forms.ColumnHeader CH_CEP;
        private System.Windows.Forms.ColumnHeader CH_Cidade;
        private System.Windows.Forms.ColumnHeader CH_UF;
        private System.Windows.Forms.ColumnHeader CH_DataCadastro;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
        private System.Windows.Forms.CheckBox CB_Inativos;
        private System.Windows.Forms.ColumnHeader CH_Endereco;
        private System.Windows.Forms.CheckBox CB_PF;
        private System.Windows.Forms.CheckBox CB_PJ;
        private System.Windows.Forms.ColumnHeader CH_Sexo;
    }
}
