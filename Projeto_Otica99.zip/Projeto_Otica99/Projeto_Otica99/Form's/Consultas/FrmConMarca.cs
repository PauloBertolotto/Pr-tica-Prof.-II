﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Class_s.Outros;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConMarca : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FrmCadMarca frmCadMarcas;
        Marca aMarca;
        Ctrl_Marca aCTRLMarcas;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }

        public FrmConMarca()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            aCTRLMarcas = new Ctrl_Marca();
        }
        public override void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmCadMarcas = (FrmCadMarca)obj;
            }
        }

        public virtual void ConhecaObj(object obj)
        {
            aMarca = (Marca)obj;
        }
        protected override void Incluir()
        {
            base.Incluir();
            aCTRLMarcas.Incluir();
            CarregaLV();
        }

        protected override void Alterar()
        {
            base.Alterar();
            int idMarca = ObterIdSelecionado();
            if (idMarca > 0)
            {
                Marca marca = aCTRLMarcas.BuscarMarcaPorId(idMarca);
                if (marca != null)
                {
                    aCTRLMarcas.Alterar(marca);
                    CarregaLV();
                }
            }
        }

        public override void Excluir()
        {
            base.Excluir();
            int idMarca = ObterIdSelecionado();
            if (idMarca > 0)
            {
                Marca marca = aCTRLMarcas.BuscarMarcaPorId(idMarca);
                if (marca != null)
                {
                    aCTRLMarcas.Excluir(marca);
                    CarregaLV();
                }
            }
        }

        public virtual void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                Marca marca = selectedItem.Tag as Marca;
                if (marca != null)
                {
                    aCTRLMarcas.Visualizar(marca);
                    CarregaLV();
                }
            }
        }

        public override void CarregaLV()
        {
            base.CarregaLV();
            List<Marca> dados = aCTRLMarcas.ListarMarcas();
            PreencherListView(dados);
        }

        private void PreencherListView(IEnumerable<Marca> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var marca in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(marca.ID));
                item.SubItems.Add(marca.Nome);
                item.SubItems.Add(marca.Descricao);
                item.SubItems.Add(marca.DataCriacao.ToString());
                item.SubItems.Add(marca.DataUltimaAlteracao.ToString());
                item.Tag = marca;
                LV_Con_Pai.Items.Add(item);
            }
        }

        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }

        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }

        private string ObterCriterioPesquisa()
        {
            if (RB_Codigo.Checked)
            {
                return "ID";
            }
            else if (RB_Nome.Checked)
            {
                return "NOME";
            }
            else if (RB_Descricao.Checked)
            {
                return "DESCRICAO";
            }

            return string.Empty; // Nenhum critério selecionado
        }

        public virtual void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCriterioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                var resultados = aCTRLMarcas.PesquisarMarcasPorCriterio(criterioPesquisa, valorPesquisa);

                // Use o método de preenchimento para atualizar a ListView
                PreencherListView(resultados);
            }
        }
    }
}
