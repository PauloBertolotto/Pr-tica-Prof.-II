﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.CB_Datas = new System.Windows.Forms.ComboBox();
            this.btn_BuscarData = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.dtData2 = new System.Windows.Forms.DateTimePicker();
            this.dtData1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.CB_Canceladas = new System.Windows.Forms.CheckBox();
            this.txt_Serie = new System.Windows.Forms.TextBox();
            this.txt_Modelo = new System.Windows.Forms.TextBox();
            this.txt_Numero = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_BuscarDados = new System.Windows.Forms.Button();
            this.btn_CancelarV = new System.Windows.Forms.Button();
            this.btn_NovaVenda = new System.Windows.Forms.Button();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // lbl_Código
            // 
            this.lbl_Código.Size = new System.Drawing.Size(71, 17);
            this.lbl_Código.Text = "Pesquisar";
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(9, 24);
            this.txt_Codigo.Size = new System.Drawing.Size(135, 23);
            this.txt_Codigo.Text = "";
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1138, 500);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(146, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 16);
            this.label8.TabIndex = 592;
            this.label8.Text = "Tipo de Data";
            // 
            // CB_Datas
            // 
            this.CB_Datas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Datas.FormattingEnabled = true;
            this.CB_Datas.Items.AddRange(new object[] {
            "EMISSAO",
            "VENCIMENTO",
            "BAIXA"});
            this.CB_Datas.Location = new System.Drawing.Point(149, 22);
            this.CB_Datas.Name = "CB_Datas";
            this.CB_Datas.Size = new System.Drawing.Size(83, 26);
            this.CB_Datas.TabIndex = 591;
            // 
            // btn_BuscarData
            // 
            this.btn_BuscarData.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarData.Location = new System.Drawing.Point(685, 53);
            this.btn_BuscarData.Name = "btn_BuscarData";
            this.btn_BuscarData.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarData.TabIndex = 590;
            this.btn_BuscarData.Text = "Buscar";
            this.btn_BuscarData.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(394, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 16);
            this.label7.TabIndex = 589;
            this.label7.Text = "até";
            // 
            // dtData2
            // 
            this.dtData2.Location = new System.Drawing.Point(426, 57);
            this.dtData2.Name = "dtData2";
            this.dtData2.Size = new System.Drawing.Size(253, 20);
            this.dtData2.TabIndex = 588;
            // 
            // dtData1
            // 
            this.dtData1.Location = new System.Drawing.Point(137, 57);
            this.dtData1.Name = "dtData1";
            this.dtData1.Size = new System.Drawing.Size(251, 20);
            this.dtData1.TabIndex = 587;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(13, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 16);
            this.label6.TabIndex = 586;
            this.label6.Text = "Período de Busca:";
            // 
            // CB_Canceladas
            // 
            this.CB_Canceladas.AutoSize = true;
            this.CB_Canceladas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Canceladas.ForeColor = System.Drawing.Color.Gold;
            this.CB_Canceladas.Location = new System.Drawing.Point(555, 24);
            this.CB_Canceladas.Name = "CB_Canceladas";
            this.CB_Canceladas.Size = new System.Drawing.Size(105, 22);
            this.CB_Canceladas.TabIndex = 593;
            this.CB_Canceladas.Text = "Canceladas";
            this.CB_Canceladas.UseVisualStyleBackColor = true;
            this.CB_Canceladas.CheckedChanged += new System.EventHandler(this.CB_Canceladas_CheckedChanged);
            // 
            // txt_Serie
            // 
            this.txt_Serie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Serie.Location = new System.Drawing.Point(400, 23);
            this.txt_Serie.Name = "txt_Serie";
            this.txt_Serie.Size = new System.Drawing.Size(75, 24);
            this.txt_Serie.TabIndex = 600;
            // 
            // txt_Modelo
            // 
            this.txt_Modelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Modelo.Location = new System.Drawing.Point(319, 23);
            this.txt_Modelo.Name = "txt_Modelo";
            this.txt_Modelo.Size = new System.Drawing.Size(75, 24);
            this.txt_Modelo.TabIndex = 599;
            // 
            // txt_Numero
            // 
            this.txt_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero.Location = new System.Drawing.Point(238, 23);
            this.txt_Numero.Name = "txt_Numero";
            this.txt_Numero.Size = new System.Drawing.Size(75, 24);
            this.txt_Numero.TabIndex = 598;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(397, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 597;
            this.label3.Text = "Série";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(316, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 596;
            this.label2.Text = "Modelo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(235, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 595;
            this.label1.Text = "Número";
            // 
            // btn_BuscarDados
            // 
            this.btn_BuscarDados.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarDados.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarDados.Location = new System.Drawing.Point(481, 22);
            this.btn_BuscarDados.Name = "btn_BuscarDados";
            this.btn_BuscarDados.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarDados.TabIndex = 601;
            this.btn_BuscarDados.Text = "Buscar";
            this.btn_BuscarDados.UseVisualStyleBackColor = false;
            // 
            // btn_CancelarV
            // 
            this.btn_CancelarV.BackColor = System.Drawing.Color.Gold;
            this.btn_CancelarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_CancelarV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarV.Location = new System.Drawing.Point(1006, 501);
            this.btn_CancelarV.Name = "btn_CancelarV";
            this.btn_CancelarV.Size = new System.Drawing.Size(127, 27);
            this.btn_CancelarV.TabIndex = 602;
            this.btn_CancelarV.Text = "Cancelar Venda";
            this.btn_CancelarV.UseVisualStyleBackColor = false;
            // 
            // btn_NovaVenda
            // 
            this.btn_NovaVenda.BackColor = System.Drawing.Color.Gold;
            this.btn_NovaVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_NovaVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NovaVenda.Location = new System.Drawing.Point(900, 502);
            this.btn_NovaVenda.Name = "btn_NovaVenda";
            this.btn_NovaVenda.Size = new System.Drawing.Size(100, 27);
            this.btn_NovaVenda.TabIndex = 603;
            this.btn_NovaVenda.Text = "Nova Venda";
            this.btn_NovaVenda.UseVisualStyleBackColor = false;
            this.btn_NovaVenda.Click += new System.EventHandler(this.btn_NovaVenda_Click);
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.BackColor = System.Drawing.Color.Gold;
            this.btn_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Excluir.Location = new System.Drawing.Point(9, 502);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(100, 27);
            this.btn_Excluir.TabIndex = 604;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = false;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(9, 77);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1196, 419);
            this.listView1.TabIndex = 605;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // FrmConVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1217, 541);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.btn_NovaVenda);
            this.Controls.Add(this.btn_CancelarV);
            this.Controls.Add(this.btn_BuscarDados);
            this.Controls.Add(this.txt_Serie);
            this.Controls.Add(this.txt_Modelo);
            this.Controls.Add(this.txt_Numero);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CB_Canceladas);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CB_Datas);
            this.Controls.Add(this.btn_BuscarData);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtData2);
            this.Controls.Add(this.dtData1);
            this.Controls.Add(this.label6);
            this.Name = "FrmConVendas";
            this.Text = "Consulta: Vendas";
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.dtData1, 0);
            this.Controls.SetChildIndex(this.dtData2, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.btn_BuscarData, 0);
            this.Controls.SetChildIndex(this.CB_Datas, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.CB_Canceladas, 0);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txt_Numero, 0);
            this.Controls.SetChildIndex(this.txt_Modelo, 0);
            this.Controls.SetChildIndex(this.txt_Serie, 0);
            this.Controls.SetChildIndex(this.btn_BuscarDados, 0);
            this.Controls.SetChildIndex(this.btn_CancelarV, 0);
            this.Controls.SetChildIndex(this.btn_NovaVenda, 0);
            this.Controls.SetChildIndex(this.btn_Excluir, 0);
            this.Controls.SetChildIndex(this.listView1, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CB_Datas;
        private System.Windows.Forms.Button btn_BuscarData;
        private System.Windows.Forms.Label label7;
        protected System.Windows.Forms.DateTimePicker dtData2;
        protected System.Windows.Forms.DateTimePicker dtData1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox CB_Canceladas;
        private System.Windows.Forms.TextBox txt_Serie;
        private System.Windows.Forms.TextBox txt_Modelo;
        private System.Windows.Forms.TextBox txt_Numero;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_BuscarDados;
        private System.Windows.Forms.Button btn_CancelarV;
        private System.Windows.Forms.Button btn_NovaVenda;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.ListView listView1;
    }
}
