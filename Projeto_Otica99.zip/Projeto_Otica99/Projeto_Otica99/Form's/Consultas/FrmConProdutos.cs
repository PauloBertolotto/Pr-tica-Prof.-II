﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Class_s.Outros;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConProdutos : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FrmCadProdutos frmcadProduto;
        Produtos oProduto;
        Ctrl_Produtos aCTRLProduto; // Alteração de CTLProduto para CTLProduto
        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        public string ValorVenda { get; private set; }
        public string Und { get; private set; }
        string status = "A";

        public FrmConProdutos()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            aCTRLProduto = new Ctrl_Produtos();
        }

        public override void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmcadProduto = (FrmCadProdutos)obj;
            }
        }

        public virtual void ConhecaObj(object obj)
        {         

            if (obj is Produtos)
            {
                oProduto = (Produtos)obj;
            }
        }
        protected override void Incluir()
        {
            base.Incluir();
            aCTRLProduto.Incluir(); // Alteração de CTLProduto para CTLProduto
            CarregaLV();
        }
        protected override void Alterar()
        {
            base.Alterar();
            int idProduto = ObterIdSelecionado(); // Alteração de idProduto para idProduto
            if (idProduto > 0)
            {
                Produtos Produto = aCTRLProduto.BuscarProdutoPorId(idProduto); // Alteração de Produto para Produto, CTLProduto para CTLProduto
                if (Produto != null)
                {
                    aCTRLProduto.Alterar(Produto); // Alteração de Produto para Produto, CTLProduto para CTLProduto
                    CarregaLV();
                }
            }
        }
        public override void Excluir()
        {
            base.Excluir();
            int idProduto = ObterIdSelecionado(); // Alteração de idProduto para idProduto
            if (idProduto > 0)
            {
                Produtos Produto = aCTRLProduto.BuscarProdutoPorId(idProduto); // Alteração de Produto para Produto, CTLProduto para CTLProduto
                if (Produto != null)
                {
                    aCTRLProduto.Excluir(Produto); // Alteração de Produto para Produto, CTLProduto para CTLProduto
                    CarregaLV();
                }
            }
        }
        public virtual void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                Produtos Produto = selectedItem.Tag as Produtos; // Alteração de Produto para Produto

                if (Produto != null)
                {
                    aCTRLProduto.Visualizar(Produto); // Alteração de Produto para Produto, CTLProduto para CTLProduto
                }
            }
        }
        private void PreencherListView(IEnumerable<Produtos> Produtos) // Alteração de IEnumerable<Produto> para IEnumerable<Produto>
        {
            LV_Con_Pai.Items.Clear();

            foreach (var Produto in Produtos) // Alteração de var Produto em Produtos para var Produto em Produtos
            {
                ListViewItem item = new ListViewItem(Convert.ToString(Produto.ID));
                item.SubItems.Add(Produto.Categoria.Nome);
                item.SubItems.Add(Produto.Nome);
                item.SubItems.Add(Produto.DescricaoProduto);
                item.SubItems.Add(Produto.Marca.Nome);
                item.SubItems.Add(Produto.PrecoCusto.ToString("C"));
                item.SubItems.Add(Produto.PrecoVenda.ToString("C"));
                item.SubItems.Add(Produto.UnidadeMedida);
                item.SubItems.Add(Produto.QtdEstoque.ToString());
                item.SubItems.Add(Produto.DataCriacao.ToString());
                item.SubItems.Add(Produto.DataUltimaAlteracao.ToString());
                item.SubItems.Add(Produto.Status == "I" ? "Inativo" : Produto.Status == "A" ? "Ativo" : Produto.Status);
                item.SubItems.Add(Produto.Referencia);
                item.Tag = Produto;
                LV_Con_Pai.Items.Add(item);
            }
        }
        public override void CarregaLV()
        {

            base.CarregaLV();
            List<Produtos> Produtos = aCTRLProduto.ListarProdutos(status); // Alteração de List<Produto> para List<Produto>, CTLProduto para CTLProduto
            PreencherListView(Produtos); // Alteração de IEnumerable<Produto> para IEnumerable<Produto>

        }
        public virtual void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCritérioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                var resultados = aCTRLProduto.PesquisarProdutosPorCriterio(criterioPesquisa, valorPesquisa, status);

                // Use o método de preenchimento para atualizar a ListView
                PreencherListView(resultados);
            }
        }
        public override void Atualizar()
        {
            base.Atualizar();
            CarregaLV();
        }
        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }
        private string ObterCritérioPesquisa()
        {
            if (CB_Codigo.Checked)
            {
                return "ID"; // Pesquisar pelo ID
            }
            else if (CB_Categoria.Checked)
            {
                return "CATEGORIA"; // Pesquisar pela Produto
            }
            else if (CB_Produto.Checked)
            {
                return "PRODUTO"; // Pesquisar pela Produto
            }
            return string.Empty; // Nenhum critério selecionado
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                    Und = LV_Con_Pai.SelectedItems[0].SubItems[8].Text;
                    ValorVenda = LV_Con_Pai.SelectedItems[0].SubItems[6].Text;
                }
                this.Close();
            }
        }

        private void CB_Inativos_CheckedChanged(object sender, EventArgs e)
        {
            if (CB_Inativos.Checked)
            {
                status = "I";
                btn_Status.Text = "Ativar";
            }
            else
            {
                status = "A";
                btn_Status.Text = "Desativar";
                btn_Con_Incluir.Enabled = btn_Con_Alterar.Enabled = true;
            }

            btn_Con_Incluir.Enabled = btn_Con_Alterar.Enabled = !CB_Inativos.Checked;
            CarregaLV();
        }

        private void btn_Status_Click(object sender, EventArgs e)
        {
            int idCondicao = ObterIdSelecionado();
            if (idCondicao > 0)
            {
                Produtos produto = aCTRLProduto.BuscarProdutoPorId(idCondicao);
                if (produto != null)
                {
                    aCTRLProduto.Desativar(produto);
                    CarregaLV();
                }
            }
        }
    }
}
