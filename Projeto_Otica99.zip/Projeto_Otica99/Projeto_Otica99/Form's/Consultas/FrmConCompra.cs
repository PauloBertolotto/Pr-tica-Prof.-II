﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConCompra : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        public FrmConCompra()
        {
            InitializeComponent();
        }
    }
}
