﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConCidade : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        Cidades      aCidade;
        FrmCadCidade oCadCidade;
        Ctrl_Cidades aCtrl_Cidade;
        FrmConEstado frmConEstado; 
        public int    IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        public FrmConCidade()
        {
            InitializeComponent();
            oCadCidade   = new FrmCadCidade();
            frmConEstado = new FrmConEstado();
            aCtrl_Cidade = new Ctrl_Cidades();
            aCidade = new Cidades();
        }
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadCidade = (FrmCadCidade)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Cidade = (Ctrl_Cidades)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadCidade.ConhecaObj(aCidade);
            oCadCidade.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            string aux = oCadCidade.btn_Salvar.Text;
            oCadCidade.btn_Salvar.Text = "Alterar";
            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                // Preencha os campos ou propriedades da tela de destino com os dados do item selecionado
                oCadCidade.txt_Codigo.Text    = itemSelecionado.SubItems[0].Text;
                oCadCidade.txt_Cidade.Text    = itemSelecionado.SubItems[1].Text;
                oCadCidade.txt_DDD.Text       = itemSelecionado.SubItems[2].Text;
                oCadCidade.txt_Estado.Text    = itemSelecionado.SubItems[3].Text;
                oCadCidade.txt_CodEstado.Text = Convert.ToInt32(aCtrl_Cidade.BuscarIDEstado(oCadCidade.txt_Estado.Text)).ToString();

                // Exiba a tela de destino
                oCadCidade.ShowDialog();
                oCadCidade.btn_Salvar.Text = aux;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Cidade.Excluir(aux);

                }
                this.CarregaLV();
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            LV_Con_Pai.Items.Clear();
            var lista = aCtrl_Cidade.ListarCidades();

            foreach (var aCidade in lista)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(aCidade.ID));
                if ((aCidade.Ativo == "I" && CB_Inativos.Checked) || (aCidade.Ativo == "A" && !CB_Inativos.Checked))
                {
                    item.SubItems.Add(aCidade.Cidade);
                    item.SubItems.Add(aCidade.DDD);
                    item.SubItems.Add(Convert.ToString(aCtrl_Cidade.BuscarEstadoPorId((Convert.ToInt32(aCidade.EstadoID)))));
                    item.SubItems.Add(Convert.ToString(aCidade.DataUltimaAlteracao));
                    item.SubItems.Add(Convert.ToString(aCidade.DataCriacao));
                    LV_Con_Pai.Items.Add(item);
                }
            }
        }
        private void LV_Con_Pai_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem linha = LV_Con_Pai.SelectedItems[0];

                aCidade.ID                  = Convert.ToInt16(linha.SubItems[0].Text);
                aCidade.Cidade              = linha.SubItems[1].Text;
                aCidade.DDD                 = linha.SubItems[2].Text;
                aCidade.EstadoID            = Convert.ToInt16(linha.SubItems[3].Text);
                aCidade.DataCriacao         = Convert.ToDateTime(linha.SubItems[4].Text);
                aCidade.DataUltimaAlteracao = Convert.ToDateTime(linha.SubItems[5].Text);
            }
        }
        protected override void Buscar()
        {
            base.Buscar();
            string valorPesquisa = txt_Codigo.Text;

            if (!string.IsNullOrEmpty(valorPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                LV_Con_Pai.Items.Clear();
                var lista = aCtrl_Cidade.Pesquisar(valorPesquisa);

                if (lista != null)
                {
                    foreach (var aCidade in lista)
                    {
                        ListViewItem item = new ListViewItem(Convert.ToString(aCidade.ID));
                        item.SubItems.Add(aCidade.Cidade);
                        item.SubItems.Add(aCidade.DDD);
                        item.SubItems.Add(Convert.ToString(aCtrl_Cidade.BuscarEstadoPorId((Convert.ToInt32(aCidade.EstadoID)))));
                        item.SubItems.Add(Convert.ToString(aCidade.DataUltimaAlteracao));
                        item.SubItems.Add(Convert.ToString(aCidade.DataCriacao));
                        LV_Con_Pai.Items.Add(item);
                    }
                }
                else
                {
                    // Caso não haja resultados, limpe a ListView ou mostre uma mensagem adequada
                    // Exemplo: LV_Con_Pai.Items.Clear();
                }
            }
        }
        public override void Atualizar()
        {
            CarregaLV();
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
    }
}
