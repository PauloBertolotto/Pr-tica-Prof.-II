﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas.Consula_Pagamento
{
    public partial class FrmConCondPagamento : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FrmCadCondicaoPag  oCadCondPag;
        CondicaoPagamento  aCondicaoPG;
        Ctrl_CondPagamento aCTLCondicaoPG;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }

        private string status = "A";
        public FrmConCondPagamento()
        {
            InitializeComponent();
            aCTLCondicaoPG = new Ctrl_CondPagamento();
        }
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadCondPag = (FrmCadCondicaoPag)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCTLCondicaoPG = (Ctrl_CondPagamento)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadCondPag.ConhecaObj(aCondicaoPG);
            oCadCondPag.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            string aux = oCadCondPag.btn_Salvar.Text;
            oCadCondPag.txt_Codigo.Enabled = false;
            oCadCondPag.btn_Salvar.Text = "Alterar";

            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                // Preencha os campos ou propriedades da tela de destino com os dados do item selecionado
                oCadCondPag.txt_Codigo.Text = itemSelecionado.SubItems[0].Text;
                oCadCondPag.txt_Condicao.Text = itemSelecionado.SubItems[1].Text;
                oCadCondPag.txt_Parcelas.Text = itemSelecionado.SubItems[2].Text;
                oCadCondPag.txt_Taxa.Text = itemSelecionado.SubItems[3].Text;
                oCadCondPag.txt_Multa.Text = itemSelecionado.SubItems[4].Text;
                oCadCondPag.txt_Desconto.Text = itemSelecionado.SubItems[5].Text;
                oCadCondPag.txt_DataCadastro.Text = itemSelecionado.SubItems[6].Text;
                oCadCondPag.txt_DataUltAlteracao.Text = itemSelecionado.SubItems[7].Text;

                // Exiba a tela de destino
                oCadCondPag.ShowDialog();
                oCadCondPag.btn_Salvar.Text = aux;
                oCadCondPag.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCTLCondicaoPG.Excluir(aux);

                }
                this.CarregaLV();
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            List<CondicaoPagamento> dados = aCTLCondicaoPG.ListarCondicoesPagamento(status);
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<CondicaoPagamento> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var Condicao in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(Condicao.ID));
                item.SubItems.Add(Condicao.Condicao);
                item.SubItems.Add(Condicao.Parcelas.ToString());
                item.SubItems.Add(Condicao.Taxa.ToString());
                item.SubItems.Add(Condicao.Multa.ToString());
                item.SubItems.Add(Condicao.Desconto.ToString());
                item.SubItems.Add(Condicao.DataCriacao.ToString());
                item.SubItems.Add(Condicao.DataUltimaAlteracao.ToString());
                item.SubItems.Add(Condicao.Status == "I" ? "Inativo" : Condicao.Status == "A" ? "Ativo" : Condicao.Status);
                item.Tag = Condicao;
                LV_Con_Pai.Items.Add(item);
            }
        }
        protected void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;

            if (!string.IsNullOrEmpty(valorPesquisa))
            {
                var resultados = aCTLCondicaoPG.PesquisarCondicaoPorCriterio(valorPesquisa, status);
                PreencherListView(resultados);
            }
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }
    }
}
