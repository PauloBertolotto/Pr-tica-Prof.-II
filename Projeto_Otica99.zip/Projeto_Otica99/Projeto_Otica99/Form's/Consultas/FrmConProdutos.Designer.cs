﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_Codigo = new System.Windows.Forms.CheckBox();
            this.CB_Categoria = new System.Windows.Forms.CheckBox();
            this.CB_Produto = new System.Windows.Forms.CheckBox();
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.btn_Desativar = new System.Windows.Forms.Button();
            this.btn_Status = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(359, 21);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(856, 453);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(928, 453);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(1000, 453);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 85);
            this.LV_Con_Pai.Size = new System.Drawing.Size(1131, 366);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(1072, 21);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Size = new System.Drawing.Size(345, 23);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1072, 453);
            // 
            // CB_Codigo
            // 
            this.CB_Codigo.AutoSize = true;
            this.CB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.CB_Codigo.Location = new System.Drawing.Point(13, 53);
            this.CB_Codigo.Name = "CB_Codigo";
            this.CB_Codigo.Size = new System.Drawing.Size(75, 22);
            this.CB_Codigo.TabIndex = 10;
            this.CB_Codigo.Text = "Código";
            this.CB_Codigo.UseVisualStyleBackColor = true;
            // 
            // CB_Categoria
            // 
            this.CB_Categoria.AutoSize = true;
            this.CB_Categoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Categoria.ForeColor = System.Drawing.Color.Gold;
            this.CB_Categoria.Location = new System.Drawing.Point(94, 53);
            this.CB_Categoria.Name = "CB_Categoria";
            this.CB_Categoria.Size = new System.Drawing.Size(91, 22);
            this.CB_Categoria.TabIndex = 11;
            this.CB_Categoria.Text = "Categoria";
            this.CB_Categoria.UseVisualStyleBackColor = true;
            // 
            // CB_Produto
            // 
            this.CB_Produto.AutoSize = true;
            this.CB_Produto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Produto.ForeColor = System.Drawing.Color.Gold;
            this.CB_Produto.Location = new System.Drawing.Point(191, 53);
            this.CB_Produto.Name = "CB_Produto";
            this.CB_Produto.Size = new System.Drawing.Size(80, 22);
            this.CB_Produto.TabIndex = 12;
            this.CB_Produto.Text = "Produto";
            this.CB_Produto.UseVisualStyleBackColor = true;
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(277, 53);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(77, 22);
            this.CB_Inativos.TabIndex = 13;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            this.CB_Inativos.CheckedChanged += new System.EventHandler(this.CB_Inativos_CheckedChanged);
            // 
            // btn_Desativar
            // 
            this.btn_Desativar.BackColor = System.Drawing.Color.Gold;
            this.btn_Desativar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Desativar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Desativar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Desativar.Location = new System.Drawing.Point(764, 453);
            this.btn_Desativar.Name = "btn_Desativar";
            this.btn_Desativar.Size = new System.Drawing.Size(87, 26);
            this.btn_Desativar.TabIndex = 14;
            this.btn_Desativar.Text = "Desativar";
            this.btn_Desativar.UseVisualStyleBackColor = false;
            // 
            // btn_Status
            // 
            this.btn_Status.BackColor = System.Drawing.Color.Gold;
            this.btn_Status.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Status.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Status.Location = new System.Drawing.Point(681, 453);
            this.btn_Status.Name = "btn_Status";
            this.btn_Status.Size = new System.Drawing.Size(77, 26);
            this.btn_Status.TabIndex = 15;
            this.btn_Status.Text = "Status";
            this.btn_Status.UseVisualStyleBackColor = false;
            this.btn_Status.Click += new System.EventHandler(this.btn_Status_Click);
            // 
            // FrmConProdutos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1148, 488);
            this.Controls.Add(this.btn_Status);
            this.Controls.Add(this.btn_Desativar);
            this.Controls.Add(this.CB_Inativos);
            this.Controls.Add(this.CB_Produto);
            this.Controls.Add(this.CB_Categoria);
            this.Controls.Add(this.CB_Codigo);
            this.Name = "FrmConProdutos";
            this.Text = "Consulta: Produtos";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Codigo, 0);
            this.Controls.SetChildIndex(this.CB_Categoria, 0);
            this.Controls.SetChildIndex(this.CB_Produto, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.Controls.SetChildIndex(this.btn_Desativar, 0);
            this.Controls.SetChildIndex(this.btn_Status, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox CB_Codigo;
        private System.Windows.Forms.CheckBox CB_Categoria;
        private System.Windows.Forms.CheckBox CB_Produto;
        private System.Windows.Forms.CheckBox CB_Inativos;
        private System.Windows.Forms.Button btn_Desativar;
        private System.Windows.Forms.Button btn_Status;
    }
}
