﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Form_s.Cadastros;
using Projeto_Otica99.Class_s.Outros;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConServicos : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        FrmCadServicos frmcadServico;
        Servicos oServico;
        Ctrl_Servicos aCTRLServicos;
        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        private string status = "A";

        public FrmConServicos()
        {
            InitializeComponent();
            Verificacao.DisableCopyPaste(this);
            aCTRLServicos = new Ctrl_Servicos();
        }

        public override void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmcadServico = (FrmCadServicos)obj;
            }
        }

        public virtual void ConhecaObj(object obj)
        {
            oServico = (Servicos)obj;
        }

        protected override void Incluir()
        {
            base.Incluir();
            aCTRLServicos.Incluir();
            CarregaLV();
        }

        protected override void Alterar()
        {
            base.Alterar();
            int idServico = ObterIdSelecionado();
            if (idServico > 0)
            {
                Servicos servico = aCTRLServicos.BuscarServicoPorId(idServico);
                if (servico != null)
                {
                    aCTRLServicos.Alterar(servico);
                    CarregaLV();
                }
            }
        }

        public override void Excluir()
        {
            base.Excluir();
            int idServico = ObterIdSelecionado();
            if (idServico > 0)
            {
                Servicos servico = aCTRLServicos.BuscarServicoPorId(idServico);
                if (servico != null)
                {
                    aCTRLServicos.Excluir(servico);
                    CarregaLV();
                }
            }
        }

        public virtual void Visualizar()
        {
            if (btn_Sair.Text == "Selecionar")
            {
                btn_Sair.PerformClick();
            }
            else if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                Servicos servico = selectedItem.Tag as Servicos;
                if (servico != null)
                {
                    aCTRLServicos.Visualizar(servico);
                    CarregaLV();
                }
            }
        }

        public override void CarregaLV()
        {
            base.CarregaLV();
            List<Servicos> dados = aCTRLServicos.ListarServicos(status);
            PreencherListView(dados);
        }

        private void PreencherListView(IEnumerable<Servicos> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var servico in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(servico.ID));
                item.SubItems.Add(servico.Descricao);
                item.SubItems.Add(servico.Valor.ToString());
                item.SubItems.Add(servico.Status == "I" ? "Inativo" : servico.Status == "A" ? "Ativo" : servico.Status);
                item.SubItems.Add(servico.DataCriacao.ToString());
                item.SubItems.Add(servico.DataUltimaAlteracao.ToString());
                item.Tag = servico;
                LV_Con_Pai.Items.Add(item);
            }
        }

        private int ObterIdSelecionado()
        {
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                return int.Parse(LV_Con_Pai.SelectedItems[0].Text);
            }
            return 0;
        }

        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }

        private string ObterCriterioPesquisa()
        {
            if (CB_Codigo.Checked)
            {
                return "ID";
            }
            else if (CB_Descricao.Checked)
            {
                return "DESCRICAO";
            }

            return string.Empty;
        }

        public virtual void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCriterioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                var resultados = aCTRLServicos.PesquisarServicosPorCriterio(criterioPesquisa, valorPesquisa, status);
                PreencherListView(resultados);
            }
        }

        private void CB_Inativos_CheckedChanged(object sender, EventArgs e)
        {
            if (CB_Inativos.Checked)
                status = "I";
            else
                status = "A";
            CarregaLV();
        }


    }
}
