﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99
{
    public partial class Principal : Form
    {
        Paises              oPais;
        Ctrl_Paises         aCtrlPais;
                            
        Estados             oEstado;
        Ctrl_Estados        aCtrlEstado;
                            
        Cidades             aCidade;
        Ctrl_Cidades        aCtrlCidade;
                            
        DadosCadastro       oCliente;
        Ctrl_Clientes       aCtrlClientes;
                            
        DadosCadastro       oFuncionario;
        Ctrl_Funcionarios   aCtrlFuncionarios;
                            
        DadosCadastro       oFornecedor;
        Ctrl_Fornecedores   aCtrlFornecedor;

        FormaPagamento      aFormaPag;
        Ctrl_FormaPagamento aCtrlFormaPag;

        CondicaoPagamento   aCondPag;
        Ctrl_CondPagamento  aCtrlCondPag;

        ContasPagar         aContasPagar;
        Ctrl_ContasPagar    aCtrlContasPagar;

        ContasReceber       aContasReceber;
        Ctrl_ContasReceber  aCtrlContasReceber;

        Vendas              aVendas;
        Ctrl_Vendas         aCtrlVendas;

        Interfaces  aInter;
        public Principal()
        {
            InitializeComponent();
            
            aInter            = new Interfaces();
            aCtrlPais         = new Ctrl_Paises();
            aCtrlEstado       = new Ctrl_Estados();
            aCtrlCidade       = new Ctrl_Cidades();
            aCtrlClientes     = new Ctrl_Clientes();
            aCtrlFuncionarios = new Ctrl_Funcionarios();
            aCtrlFornecedor   = new Ctrl_Fornecedores();
            aCtrlFormaPag     = new Ctrl_FormaPagamento();
            aCtrlCondPag      = new Ctrl_CondPagamento();
        }
        private void MostrarConsultas()
        {
            PanelConsultas.Visible   = true;
            btn_Paises.Visible       = true;
            btn_Estados.Visible      = true;
            btn_Cidades.Visible      = true;
            btn_Clientes.Visible     = true;
            btn_Funcionarios.Visible = true;
            btn_Fornecedores.Visible = true;
            btn_Produtos.Visible     = false;

        }
        private void MostarPagamento()
        {
            Panel_Pag.Visible         = true;
            btn_CondPag.Visible       = true;
            btn_FormaPag.Visible      = true;
            btn_ContasPagar.Visible   = true;
            btn_ContasReceber.Visible = true;
        }
     
        private void OcultarConsultas()
        {
            PanelConsultas.Visible   = false;
            btn_Paises.Visible       = false;
            btn_Estados.Visible      = false;
            btn_Cidades.Visible      = false;
            btn_Clientes.Visible     = false;
            btn_Funcionarios.Visible = false;
            btn_Fornecedores.Visible = false;
            btn_Produtos.Visible     = false;
        }
        private void OcultarPagamento()
        {
            Panel_Pag.Visible         = false;
            btn_CondPag.Visible       = false;
            btn_FormaPag.Visible      = false;
            btn_ContasPagar.Visible   = false;
            btn_ContasReceber.Visible = false;
        }
        
        private void Principal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                // Feche o formulário
                this.Close();
            }
        }
        private void btn_Consultas_Click(object sender, EventArgs e)
        {
            OcultarPagamento();
            MostrarConsultas();
        }
        private void btn_Contas_Click(object sender, EventArgs e)
        {
            OcultarConsultas();
            MostarPagamento();
           
        }

        private void btn_Paises_Click(object sender, EventArgs e)
        {
            aInter.PecaPais(oPais, aCtrlPais);
        }

        private void btn_Estados_Click(object sender, EventArgs e)
        {
            aInter.PecaEstado(oEstado, aCtrlEstado);
        }

        private void btn_Cidades_Click(object sender, EventArgs e)
        {
            aInter.PecaCidade(aCidade, aCtrlCidade);
        }

        private void btn_Fornecedores_Click(object sender, EventArgs e)
        {
            aInter.PecaFornecedor(oFornecedor, aCtrlFornecedor);
        }

        private void btn_Clientes_Click(object sender, EventArgs e)
        {
            aInter.PecaCliente(oCliente, aCtrlClientes);
        }

        private void btn_Funcionarios_Click(object sender, EventArgs e)
        {
            aInter.PecaFuncionario(oFornecedor, aCtrlFuncionarios);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            aInter.PecaFormaPag(aFormaPag, aCtrlFormaPag);
        }

        private void btn_CondPag_Click(object sender, EventArgs e)
        {
            aInter.PecaCondPag(aCondPag, aCtrlCondPag);
        }

        private void btn_FormaPag_Click(object sender, EventArgs e)
        {
            aInter.PecaFormaPag(aFormaPag, aCtrlFormaPag);
        }

        private void btn_ContasPagar_Click(object sender, EventArgs e)
        {
            aInter.PecaContasPagar(aContasPagar);
        }

        private void btn_ContasReceber_Click(object sender, EventArgs e)
        {
            aInter.PecaContasReceber(aContasReceber);
        }

        private void btn_Venda_Click(object sender, EventArgs e)
        {
            aInter.PecaVendas(aVendas);
        }

    }
}
