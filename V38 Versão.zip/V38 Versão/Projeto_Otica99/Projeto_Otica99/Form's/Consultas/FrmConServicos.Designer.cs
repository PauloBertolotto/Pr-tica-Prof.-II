﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConServicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_Inativos = new System.Windows.Forms.CheckBox();
            this.CB_Descricao = new System.Windows.Forms.CheckBox();
            this.CB_Codigo = new System.Windows.Forms.CheckBox();
            this.CH_Descricao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_Valor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataCriacao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH_DataUltAlt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Location = new System.Drawing.Point(506, 22);
            this.btn_ConBuscar.Click += new System.EventHandler(this.btn_ConBuscar_Click);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Location = new System.Drawing.Point(916, 668);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Location = new System.Drawing.Point(988, 668);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Location = new System.Drawing.Point(1060, 668);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Descricao,
            this.CH_Status,
            this.CH_Valor,
            this.CH_DataCriacao,
            this.CH_DataUltAlt});
            this.LV_Con_Pai.Size = new System.Drawing.Size(1191, 609);
            // 
            // btn_Att
            // 
            this.btn_Att.Location = new System.Drawing.Point(1113, 21);
            this.btn_Att.Size = new System.Drawing.Size(87, 27);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Size = new System.Drawing.Size(492, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(1132, 668);
            // 
            // CB_Inativos
            // 
            this.CB_Inativos.AutoSize = true;
            this.CB_Inativos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Inativos.ForeColor = System.Drawing.Color.Gold;
            this.CB_Inativos.Location = new System.Drawing.Point(761, 26);
            this.CB_Inativos.Name = "CB_Inativos";
            this.CB_Inativos.Size = new System.Drawing.Size(83, 24);
            this.CB_Inativos.TabIndex = 17;
            this.CB_Inativos.Text = "Inativos";
            this.CB_Inativos.UseVisualStyleBackColor = true;
            this.CB_Inativos.CheckedChanged += new System.EventHandler(this.CB_Inativos_CheckedChanged);
            // 
            // CB_Descricao
            // 
            this.CB_Descricao.AutoSize = true;
            this.CB_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Descricao.ForeColor = System.Drawing.Color.Gold;
            this.CB_Descricao.Location = new System.Drawing.Point(660, 26);
            this.CB_Descricao.Name = "CB_Descricao";
            this.CB_Descricao.Size = new System.Drawing.Size(99, 24);
            this.CB_Descricao.TabIndex = 15;
            this.CB_Descricao.Text = "Descrição";
            this.CB_Descricao.UseVisualStyleBackColor = true;
            // 
            // CB_Codigo
            // 
            this.CB_Codigo.AutoSize = true;
            this.CB_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Codigo.ForeColor = System.Drawing.Color.Gold;
            this.CB_Codigo.Location = new System.Drawing.Point(579, 26);
            this.CB_Codigo.Name = "CB_Codigo";
            this.CB_Codigo.Size = new System.Drawing.Size(78, 24);
            this.CB_Codigo.TabIndex = 14;
            this.CB_Codigo.Text = "Código";
            this.CB_Codigo.UseVisualStyleBackColor = true;
            // 
            // CH_Descricao
            // 
            this.CH_Descricao.Text = "Descrição";
            this.CH_Descricao.Width = 300;
            // 
            // CH_Status
            // 
            this.CH_Status.Text = "Status";
            this.CH_Status.Width = 120;
            // 
            // CH_Valor
            // 
            this.CH_Valor.Text = "Valor";
            this.CH_Valor.Width = 150;
            // 
            // CH_DataCriacao
            // 
            this.CH_DataCriacao.Text = "Data de Cadastro";
            this.CH_DataCriacao.Width = 200;
            // 
            // CH_DataUltAlt
            // 
            this.CH_DataUltAlt.Text = "Última Alteração";
            this.CH_DataUltAlt.Width = 200;
            // 
            // FrmConServicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1208, 703);
            this.Controls.Add(this.CB_Inativos);
            this.Controls.Add(this.CB_Descricao);
            this.Controls.Add(this.CB_Codigo);
            this.Name = "FrmConServicos";
            this.Text = "Consulta: Serviços";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.Controls.SetChildIndex(this.CB_Codigo, 0);
            this.Controls.SetChildIndex(this.CB_Descricao, 0);
            this.Controls.SetChildIndex(this.CB_Inativos, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox CB_Inativos;
        private System.Windows.Forms.CheckBox CB_Descricao;
        private System.Windows.Forms.CheckBox CB_Codigo;
        private System.Windows.Forms.ColumnHeader CH_Descricao;
        private System.Windows.Forms.ColumnHeader CH_Status;
        private System.Windows.Forms.ColumnHeader CH_Valor;
        private System.Windows.Forms.ColumnHeader CH_DataCriacao;
        private System.Windows.Forms.ColumnHeader CH_DataUltAlt;
    }
}
