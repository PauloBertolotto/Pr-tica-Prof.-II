﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Otica99.Form_s.Consultas
{
    public partial class FrmConPais : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        Paises      oPais;
        FrmCadPais  oCadPais;
        Ctrl_Paises aCtrl_Pais;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        public FrmConPais()
        {
            InitializeComponent();

            oCadPais = new FrmCadPais();
            aCtrl_Pais = new Ctrl_Paises();
            oPais = new Paises();
            CarregaLV();
        }
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadPais = (FrmCadPais)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
           base.ConhecaObj(obj, ctrl);
         
           aCtrl_Pais = (Ctrl_Paises)ctrl;
           this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadPais.ConhecaObj(oPais);
            oCadPais.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            string aux = oCadPais.btn_Salvar.Text;
            oCadPais.btn_Salvar.Text = "Alterar";

            if (LV_Con_Pai.SelectedItems.Count > 0)
            {

                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                oCadPais.txt_Codigo.Text   = itemSelecionado.SubItems[0].Text;
                oCadPais.txt_CadPais.Text  = itemSelecionado.SubItems[1].Text;
                oCadPais.txt_CadDDI.Text   = itemSelecionado.SubItems[2].Text;
                oCadPais.txt_CadSigla.Text = itemSelecionado.SubItems[3].Text;
      
                oCadPais.ShowDialog();
                oCadPais.btn_Salvar.Text = aux;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Pais.Excluir(aux);
                }
                this.CarregaLV();
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            LV_Con_Pai.Items.Clear();
            var lista = aCtrl_Pais.ListarPaises();

            foreach (var oPais in lista)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(oPais.ID));
                if ((oPais.Ativo == "I" && CB_Inativos.Checked) || (oPais.Ativo == "A" && !CB_Inativos.Checked))
                {
                    item.SubItems.Add(oPais.Ddi);
                    item.SubItems.Add(oPais.Pais);
                    item.SubItems.Add(oPais.Sigla);
                    item.SubItems.Add(Convert.ToString(oPais.DataUltimaAlteracao));
                    item.SubItems.Add(Convert.ToString(oPais.DataCriacao));
                    LV_Con_Pai.Items.Add(item);
                }
            }
        }
        private void LV_Con_Pai_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.LV_Con_Pai.SelectedItems.Count > 0)
            {
                ListViewItem linha = LV_Con_Pai.SelectedItems[0];

                oPais.ID                  = Convert.ToInt16(linha.SubItems[0].Text);
                oPais.Pais                = linha.SubItems[1].Text;
                oPais.Ddi                 = linha.SubItems[2].Text;
                oPais.Sigla               = linha.SubItems[3].Text;
                oPais.DataCriacao         = Convert.ToDateTime(linha.SubItems[4].Text);
                oPais.DataUltimaAlteracao = Convert.ToDateTime(linha.SubItems[5].Text);
            }
        }
        protected override void Buscar()
        {
            base.Buscar();
            string valorPesquisa = txt_Codigo.Text;

            if (!string.IsNullOrEmpty(valorPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                LV_Con_Pai.Items.Clear();
                var lista = aCtrl_Pais.Pesquisar(valorPesquisa);

                if (lista != null)
                {
                    foreach (var oPais in lista)
                    {
                        ListViewItem item = new ListViewItem(Convert.ToString(oPais.ID));
                        item.SubItems.Add(oPais.Ddi);
                        item.SubItems.Add(oPais.Pais);
                        item.SubItems.Add(oPais.Sigla);
                        item.SubItems.Add(Convert.ToString(oPais.DataUltimaAlteracao));
                        item.SubItems.Add(Convert.ToString(oPais.DataCriacao));
                        LV_Con_Pai.Items.Add(item);
                    }
                }
                else
                {
                    // Caso não haja resultados, limpe a ListView ou mostre uma mensagem adequada
                    // Exemplo: LV_Con_Pai.Items.Clear();
                }
            }
        }

        public override void Atualizar()
        {
            CarregaLV();           
        }
        public override void Sair()
        {
            if (btn_Sair.Text == "Sair")
            {
                base.Sair();
            }
            else if (btn_Sair.Text == "Selecionar")
            {
                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    IdSelecionado = int.Parse(LV_Con_Pai.SelectedItems[0].SubItems[0].Text);
                    NomeSelecionado = LV_Con_Pai.SelectedItems[0].SubItems[1].Text;
                }
                this.Close();
            }
        }

        private void FrmConPais_Load(object sender, EventArgs e)
        {

        }
    }
}
