﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmConContas_a_Pagar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_Status = new System.Windows.Forms.ComboBox();
            this.lbl_Status = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_CFornecedor = new System.Windows.Forms.TextBox();
            this.txt_NParcelas = new System.Windows.Forms.TextBox();
            this.txt_Serie = new System.Windows.Forms.TextBox();
            this.txt_Modelo = new System.Windows.Forms.TextBox();
            this.txt_Numero = new System.Windows.Forms.TextBox();
            this.btn_BuscarData = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.dtData2 = new System.Windows.Forms.DateTimePicker();
            this.dtData1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_BuscarDados = new System.Windows.Forms.Button();
            this.btn_BuscarFornecedor = new System.Windows.Forms.Button();
            this.dgvContas = new System.Windows.Forms.DataGridView();
            this.btn_Pagar = new System.Windows.Forms.Button();
            this.CB_Datas = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Fornecedor = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContas)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Código
            // 
            this.lbl_Código.Size = new System.Drawing.Size(81, 17);
            this.lbl_Código.Text = "Fornecedor";
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_Codigo.Location = new System.Drawing.Point(9, 666);
            this.txt_Codigo.Size = new System.Drawing.Size(83, 23);
            this.txt_Codigo.Text = "";
            // 
            // btn_Sair
            // 
            this.btn_Sair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Sair.Location = new System.Drawing.Point(1140, 666);
            // 
            // CB_Status
            // 
            this.CB_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Status.FormattingEnabled = true;
            this.CB_Status.Items.AddRange(new object[] {
            "A PAGAR",
            "PAGO",
            "CANCELADA",
            "TODOS"});
            this.CB_Status.Location = new System.Drawing.Point(206, 26);
            this.CB_Status.Name = "CB_Status";
            this.CB_Status.Size = new System.Drawing.Size(117, 26);
            this.CB_Status.TabIndex = 14;
            // 
            // lbl_Status
            // 
            this.lbl_Status.AutoSize = true;
            this.lbl_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Status.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Status.Location = new System.Drawing.Point(203, 9);
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(47, 16);
            this.lbl_Status.TabIndex = 13;
            this.lbl_Status.Text = " Status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(727, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "C. Fornecedor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(646, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Nº Parcelas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(565, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Série";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(484, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Modelo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(403, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "Número";
            // 
            // txt_CFornecedor
            // 
            this.txt_CFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CFornecedor.Location = new System.Drawing.Point(730, 28);
            this.txt_CFornecedor.Name = "txt_CFornecedor";
            this.txt_CFornecedor.Size = new System.Drawing.Size(89, 24);
            this.txt_CFornecedor.TabIndex = 27;
            this.txt_CFornecedor.Text = "0";
            this.txt_CFornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_NParcelas
            // 
            this.txt_NParcelas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NParcelas.Location = new System.Drawing.Point(649, 28);
            this.txt_NParcelas.Name = "txt_NParcelas";
            this.txt_NParcelas.Size = new System.Drawing.Size(75, 24);
            this.txt_NParcelas.TabIndex = 26;
            this.txt_NParcelas.Text = "0";
            this.txt_NParcelas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_Serie
            // 
            this.txt_Serie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Serie.Location = new System.Drawing.Point(568, 28);
            this.txt_Serie.Name = "txt_Serie";
            this.txt_Serie.Size = new System.Drawing.Size(75, 24);
            this.txt_Serie.TabIndex = 25;
            this.txt_Serie.Text = "0";
            this.txt_Serie.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_Modelo
            // 
            this.txt_Modelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Modelo.Location = new System.Drawing.Point(487, 28);
            this.txt_Modelo.Name = "txt_Modelo";
            this.txt_Modelo.Size = new System.Drawing.Size(75, 24);
            this.txt_Modelo.TabIndex = 24;
            this.txt_Modelo.Text = "0";
            this.txt_Modelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_Numero
            // 
            this.txt_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero.Location = new System.Drawing.Point(406, 28);
            this.txt_Numero.Name = "txt_Numero";
            this.txt_Numero.Size = new System.Drawing.Size(75, 24);
            this.txt_Numero.TabIndex = 23;
            this.txt_Numero.Text = "0";
            this.txt_Numero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_BuscarData
            // 
            this.btn_BuscarData.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarData.Location = new System.Drawing.Point(767, 72);
            this.btn_BuscarData.Name = "btn_BuscarData";
            this.btn_BuscarData.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarData.TabIndex = 32;
            this.btn_BuscarData.Text = "Buscar";
            this.btn_BuscarData.UseVisualStyleBackColor = false;
            this.btn_BuscarData.Click += new System.EventHandler(this.btn_BuscarData_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(476, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 16);
            this.label7.TabIndex = 31;
            this.label7.Text = "até";
            // 
            // dtData2
            // 
            this.dtData2.Location = new System.Drawing.Point(508, 76);
            this.dtData2.Name = "dtData2";
            this.dtData2.Size = new System.Drawing.Size(253, 20);
            this.dtData2.TabIndex = 30;
            // 
            // dtData1
            // 
            this.dtData1.Location = new System.Drawing.Point(219, 76);
            this.dtData1.Name = "dtData1";
            this.dtData1.Size = new System.Drawing.Size(251, 20);
            this.dtData1.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(95, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 16);
            this.label6.TabIndex = 28;
            this.label6.Text = "Período de Busca:";
            // 
            // btn_BuscarDados
            // 
            this.btn_BuscarDados.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarDados.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarDados.Location = new System.Drawing.Point(825, 25);
            this.btn_BuscarDados.Name = "btn_BuscarDados";
            this.btn_BuscarDados.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarDados.TabIndex = 33;
            this.btn_BuscarDados.Text = "Buscar";
            this.btn_BuscarDados.UseVisualStyleBackColor = false;
            this.btn_BuscarDados.Click += new System.EventHandler(this.btn_BuscarDados_Click);
            // 
            // btn_BuscarFornecedor
            // 
            this.btn_BuscarFornecedor.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarFornecedor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarFornecedor.Location = new System.Drawing.Point(329, 25);
            this.btn_BuscarFornecedor.Name = "btn_BuscarFornecedor";
            this.btn_BuscarFornecedor.Size = new System.Drawing.Size(68, 27);
            this.btn_BuscarFornecedor.TabIndex = 34;
            this.btn_BuscarFornecedor.Text = "Buscar";
            this.btn_BuscarFornecedor.UseVisualStyleBackColor = false;
            this.btn_BuscarFornecedor.Click += new System.EventHandler(this.btn_BuscarFornecedor_Click);
            // 
            // dgvContas
            // 
            this.dgvContas.AllowUserToAddRows = false;
            this.dgvContas.AllowUserToDeleteRows = false;
            this.dgvContas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvContas.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvContas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContas.Location = new System.Drawing.Point(9, 101);
            this.dgvContas.Margin = new System.Windows.Forms.Padding(2);
            this.dgvContas.Name = "dgvContas";
            this.dgvContas.ReadOnly = true;
            this.dgvContas.RowHeadersVisible = false;
            this.dgvContas.RowHeadersWidth = 51;
            this.dgvContas.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvContas.RowTemplate.Height = 24;
            this.dgvContas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContas.Size = new System.Drawing.Size(1199, 556);
            this.dgvContas.TabIndex = 582;
            this.dgvContas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContas_CellContentClick);
            this.dgvContas.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContas_CellContentDoubleClick);
            // 
            // btn_Pagar
            // 
            this.btn_Pagar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Pagar.BackColor = System.Drawing.Color.Gold;
            this.btn_Pagar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Pagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Pagar.Location = new System.Drawing.Point(1067, 666);
            this.btn_Pagar.Name = "btn_Pagar";
            this.btn_Pagar.Size = new System.Drawing.Size(68, 27);
            this.btn_Pagar.TabIndex = 583;
            this.btn_Pagar.Text = "Pagar";
            this.btn_Pagar.UseVisualStyleBackColor = false;
            this.btn_Pagar.Click += new System.EventHandler(this.btn_Pagar_Click);
            // 
            // CB_Datas
            // 
            this.CB_Datas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_Datas.FormattingEnabled = true;
            this.CB_Datas.Items.AddRange(new object[] {
            "EMISSAO",
            "VENCIMENTO",
            "BAIXA"});
            this.CB_Datas.Location = new System.Drawing.Point(9, 73);
            this.CB_Datas.Name = "CB_Datas";
            this.CB_Datas.Size = new System.Drawing.Size(83, 26);
            this.CB_Datas.TabIndex = 584;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(6, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 16);
            this.label8.TabIndex = 585;
            this.label8.Text = "Tipo de Data";
            // 
            // txt_Fornecedor
            // 
            this.txt_Fornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Fornecedor.Location = new System.Drawing.Point(9, 28);
            this.txt_Fornecedor.Name = "txt_Fornecedor";
            this.txt_Fornecedor.Size = new System.Drawing.Size(191, 24);
            this.txt_Fornecedor.TabIndex = 586;
            this.txt_Fornecedor.TextChanged += new System.EventHandler(this.txt_Fornecedor_TextChanged);
            // 
            // FrmConContas_a_Pagar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1213, 703);
            this.Controls.Add(this.txt_Fornecedor);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CB_Datas);
            this.Controls.Add(this.btn_Pagar);
            this.Controls.Add(this.dgvContas);
            this.Controls.Add(this.btn_BuscarFornecedor);
            this.Controls.Add(this.btn_BuscarDados);
            this.Controls.Add(this.btn_BuscarData);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtData2);
            this.Controls.Add(this.dtData1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_CFornecedor);
            this.Controls.Add(this.txt_NParcelas);
            this.Controls.Add(this.txt_Serie);
            this.Controls.Add(this.txt_Modelo);
            this.Controls.Add(this.txt_Numero);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CB_Status);
            this.Controls.Add(this.lbl_Status);
            this.Name = "FrmConContas_a_Pagar";
            this.Text = "Consulta: Contas a Pagar";
            this.Load += new System.EventHandler(this.FrmConContas_a_Pagar_Load);
            this.Resize += new System.EventHandler(this.FrmConContas_a_Pagar_Resize);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.lbl_Status, 0);
            this.Controls.SetChildIndex(this.CB_Status, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txt_Numero, 0);
            this.Controls.SetChildIndex(this.txt_Modelo, 0);
            this.Controls.SetChildIndex(this.txt_Serie, 0);
            this.Controls.SetChildIndex(this.txt_NParcelas, 0);
            this.Controls.SetChildIndex(this.txt_CFornecedor, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.dtData1, 0);
            this.Controls.SetChildIndex(this.dtData2, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.btn_BuscarData, 0);
            this.Controls.SetChildIndex(this.btn_BuscarDados, 0);
            this.Controls.SetChildIndex(this.btn_BuscarFornecedor, 0);
            this.Controls.SetChildIndex(this.dgvContas, 0);
            this.Controls.SetChildIndex(this.btn_Pagar, 0);
            this.Controls.SetChildIndex(this.CB_Datas, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.txt_Fornecedor, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CB_Status;
        private System.Windows.Forms.Label lbl_Status;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_CFornecedor;
        private System.Windows.Forms.TextBox txt_NParcelas;
        private System.Windows.Forms.TextBox txt_Serie;
        private System.Windows.Forms.TextBox txt_Modelo;
        private System.Windows.Forms.TextBox txt_Numero;
        private System.Windows.Forms.Button btn_BuscarData;
        private System.Windows.Forms.Label label7;
        protected System.Windows.Forms.DateTimePicker dtData2;
        protected System.Windows.Forms.DateTimePicker dtData1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_BuscarDados;
        private System.Windows.Forms.Button btn_BuscarFornecedor;
        private System.Windows.Forms.DataGridView dgvContas;
        private System.Windows.Forms.Button btn_Pagar;
        private System.Windows.Forms.ComboBox CB_Datas;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Fornecedor;
    }
}
