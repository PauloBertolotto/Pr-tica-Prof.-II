﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BuscarCliente = new System.Windows.Forms.Button();
            this.txt_CPFeCNPJ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Cliente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CB_ServProd = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Panel_Prod = new System.Windows.Forms.Panel();
            this.lbl_CodProd = new System.Windows.Forms.Label();
            this.txt_Qntd = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Desc = new System.Windows.Forms.TextBox();
            this.btn_BuscarProd = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Prod = new System.Windows.Forms.TextBox();
            this.txt_CodProd = new System.Windows.Forms.TextBox();
            this.btn_LimparDadosCliente = new System.Windows.Forms.Button();
            this.btn_AddItem = new System.Windows.Forms.Button();
            this.txt_CustoTotal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_CustoUnit = new System.Windows.Forms.TextBox();
            this.DgItensVenda = new System.Windows.Forms.DataGridView();
            this.btn_BuscarCondPag = new System.Windows.Forms.Button();
            this.btn_ExcluirItem = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_Outros = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_ValorSeg = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_ValorFrete = new System.Windows.Forms.TextBox();
            this.txt_Condicao = new System.Windows.Forms.TextBox();
            this.txt_CodCond = new System.Windows.Forms.TextBox();
            this.btn_FVenda = new System.Windows.Forms.Button();
            this.lbl_TotNota = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btn_FCond = new System.Windows.Forms.Button();
            this.lvParcelas = new System.Windows.Forms.ListView();
            this.clParcelas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDias = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clIdForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPercentTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPreco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.pbFoto = new System.Windows.Forms.PictureBox();
            this.btn_Limpar = new System.Windows.Forms.Button();
            this.Panel_Prod.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgItensVenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Código
            // 
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.Location = new System.Drawing.Point(10, 3);
            this.lbl_Código.Size = new System.Drawing.Size(59, 20);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Enabled = false;
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(14, 27);
            this.txt_Codigo.Size = new System.Drawing.Size(60, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sair.Location = new System.Drawing.Point(1130, 543);
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // btn_BuscarCliente
            // 
            this.btn_BuscarCliente.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarCliente.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarCliente.Location = new System.Drawing.Point(216, 27);
            this.btn_BuscarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscarCliente.Name = "btn_BuscarCliente";
            this.btn_BuscarCliente.Size = new System.Drawing.Size(68, 26);
            this.btn_BuscarCliente.TabIndex = 579;
            this.btn_BuscarCliente.Text = "Buscar";
            this.btn_BuscarCliente.UseVisualStyleBackColor = false;
            this.btn_BuscarCliente.Click += new System.EventHandler(this.btn_BuscarCliente_Click);
            // 
            // txt_CPFeCNPJ
            // 
            this.txt_CPFeCNPJ.Enabled = false;
            this.txt_CPFeCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CPFeCNPJ.Location = new System.Drawing.Point(14, 87);
            this.txt_CPFeCNPJ.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CPFeCNPJ.MaxLength = 100;
            this.txt_CPFeCNPJ.Name = "txt_CPFeCNPJ";
            this.txt_CPFeCNPJ.Size = new System.Drawing.Size(195, 27);
            this.txt_CPFeCNPJ.TabIndex = 578;
            this.txt_CPFeCNPJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CPFeCNPJ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_CPFeCNPJ_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(16, 65);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 20);
            this.label6.TabIndex = 580;
            this.label6.Text = "CPF / CNPJ";
            // 
            // txt_Cliente
            // 
            this.txt_Cliente.Enabled = false;
            this.txt_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cliente.Location = new System.Drawing.Point(79, 27);
            this.txt_Cliente.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Cliente.MaxLength = 100;
            this.txt_Cliente.Name = "txt_Cliente";
            this.txt_Cliente.Size = new System.Drawing.Size(129, 27);
            this.txt_Cliente.TabIndex = 582;
            this.txt_Cliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(75, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 20);
            this.label1.TabIndex = 581;
            this.label1.Text = "Cliente";
            // 
            // CB_ServProd
            // 
            this.CB_ServProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_ServProd.FormattingEnabled = true;
            this.CB_ServProd.Items.AddRange(new object[] {
            "Produtos",
            "Serviços"});
            this.CB_ServProd.Location = new System.Drawing.Point(13, 146);
            this.CB_ServProd.Name = "CB_ServProd";
            this.CB_ServProd.Size = new System.Drawing.Size(272, 28);
            this.CB_ServProd.TabIndex = 584;
            this.CB_ServProd.SelectedIndexChanged += new System.EventHandler(this.CB_ServProd_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(10, 118);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 583;
            this.label2.Text = "Serviço / Produto";
            // 
            // Panel_Prod
            // 
            this.Panel_Prod.Controls.Add(this.lbl_CodProd);
            this.Panel_Prod.Controls.Add(this.txt_Qntd);
            this.Panel_Prod.Controls.Add(this.label7);
            this.Panel_Prod.Controls.Add(this.label3);
            this.Panel_Prod.Controls.Add(this.txt_Desc);
            this.Panel_Prod.Controls.Add(this.btn_BuscarProd);
            this.Panel_Prod.Controls.Add(this.label5);
            this.Panel_Prod.Controls.Add(this.txt_Prod);
            this.Panel_Prod.Controls.Add(this.txt_CodProd);
            this.Panel_Prod.Location = new System.Drawing.Point(9, 180);
            this.Panel_Prod.Name = "Panel_Prod";
            this.Panel_Prod.Size = new System.Drawing.Size(283, 123);
            this.Panel_Prod.TabIndex = 613;
            // 
            // lbl_CodProd
            // 
            this.lbl_CodProd.AutoSize = true;
            this.lbl_CodProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodProd.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodProd.Location = new System.Drawing.Point(106, 9);
            this.lbl_CodProd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_CodProd.Name = "lbl_CodProd";
            this.lbl_CodProd.Size = new System.Drawing.Size(80, 18);
            this.lbl_CodProd.TabIndex = 585;
            this.lbl_CodProd.Text = "Cód. Prod.";
            // 
            // txt_Qntd
            // 
            this.txt_Qntd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Qntd.Location = new System.Drawing.Point(5, 31);
            this.txt_Qntd.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Qntd.MaxLength = 100;
            this.txt_Qntd.Name = "txt_Qntd";
            this.txt_Qntd.Size = new System.Drawing.Size(96, 27);
            this.txt_Qntd.TabIndex = 583;
            this.txt_Qntd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Qntd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Qntd_KeyPress);
            this.txt_Qntd.Leave += new System.EventHandler(this.txt_Qntd_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(189, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 18);
            this.label7.TabIndex = 590;
            this.label7.Text = "Desconto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(2, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 582;
            this.label3.Text = "Qntd.";
            // 
            // txt_Desc
            // 
            this.txt_Desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Desc.Location = new System.Drawing.Point(192, 84);
            this.txt_Desc.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Desc.MaxLength = 100;
            this.txt_Desc.Name = "txt_Desc";
            this.txt_Desc.Size = new System.Drawing.Size(85, 27);
            this.txt_Desc.TabIndex = 589;
            this.txt_Desc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Desc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Desc_KeyPress);
            this.txt_Desc.Leave += new System.EventHandler(this.txt_Desc_Leave);
            // 
            // btn_BuscarProd
            // 
            this.btn_BuscarProd.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarProd.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarProd.Location = new System.Drawing.Point(207, 30);
            this.btn_BuscarProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscarProd.Name = "btn_BuscarProd";
            this.btn_BuscarProd.Size = new System.Drawing.Size(68, 28);
            this.btn_BuscarProd.TabIndex = 588;
            this.btn_BuscarProd.Text = "Buscar";
            this.btn_BuscarProd.UseVisualStyleBackColor = false;
            this.btn_BuscarProd.Click += new System.EventHandler(this.btn_BuscarProd_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(4, 62);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 18);
            this.label5.TabIndex = 587;
            this.label5.Text = "Produto";
            // 
            // txt_Prod
            // 
            this.txt_Prod.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Prod.Location = new System.Drawing.Point(5, 84);
            this.txt_Prod.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Prod.MaxLength = 100;
            this.txt_Prod.Name = "txt_Prod";
            this.txt_Prod.Size = new System.Drawing.Size(181, 27);
            this.txt_Prod.TabIndex = 586;
            this.txt_Prod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_CodProd
            // 
            this.txt_CodProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodProd.Location = new System.Drawing.Point(109, 31);
            this.txt_CodProd.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CodProd.MaxLength = 100;
            this.txt_CodProd.Name = "txt_CodProd";
            this.txt_CodProd.Size = new System.Drawing.Size(90, 27);
            this.txt_CodProd.TabIndex = 584;
            this.txt_CodProd.Text = "0";
            this.txt_CodProd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodProd.Leave += new System.EventHandler(this.txt_CodProd_Leave);
            // 
            // btn_LimparDadosCliente
            // 
            this.btn_LimparDadosCliente.BackColor = System.Drawing.Color.Gold;
            this.btn_LimparDadosCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_LimparDadosCliente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_LimparDadosCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LimparDadosCliente.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_LimparDadosCliente.Location = new System.Drawing.Point(216, 86);
            this.btn_LimparDadosCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btn_LimparDadosCliente.Name = "btn_LimparDadosCliente";
            this.btn_LimparDadosCliente.Size = new System.Drawing.Size(69, 28);
            this.btn_LimparDadosCliente.TabIndex = 639;
            this.btn_LimparDadosCliente.Text = "Limpar";
            this.btn_LimparDadosCliente.UseVisualStyleBackColor = false;
            this.btn_LimparDadosCliente.Click += new System.EventHandler(this.btn_LimparDadosCliente_Click);
            // 
            // btn_AddItem
            // 
            this.btn_AddItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_AddItem.BackColor = System.Drawing.Color.Gold;
            this.btn_AddItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AddItem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_AddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_AddItem.Location = new System.Drawing.Point(9, 544);
            this.btn_AddItem.Margin = new System.Windows.Forms.Padding(4);
            this.btn_AddItem.Name = "btn_AddItem";
            this.btn_AddItem.Size = new System.Drawing.Size(277, 26);
            this.btn_AddItem.TabIndex = 618;
            this.btn_AddItem.Text = "Adicionar";
            this.btn_AddItem.UseVisualStyleBackColor = false;
            this.btn_AddItem.Click += new System.EventHandler(this.btn_AddItem_Click);
            // 
            // txt_CustoTotal
            // 
            this.txt_CustoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustoTotal.Location = new System.Drawing.Point(155, 509);
            this.txt_CustoTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CustoTotal.MaxLength = 100;
            this.txt_CustoTotal.Name = "txt_CustoTotal";
            this.txt_CustoTotal.Size = new System.Drawing.Size(131, 27);
            this.txt_CustoTotal.TabIndex = 617;
            this.txt_CustoTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(152, 487);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 18);
            this.label9.TabIndex = 616;
            this.label9.Text = "R$ Total";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(8, 487);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 18);
            this.label8.TabIndex = 615;
            this.label8.Text = "R$ p/ Unidade";
            // 
            // txt_CustoUnit
            // 
            this.txt_CustoUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustoUnit.Location = new System.Drawing.Point(9, 509);
            this.txt_CustoUnit.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CustoUnit.MaxLength = 100;
            this.txt_CustoUnit.Name = "txt_CustoUnit";
            this.txt_CustoUnit.Size = new System.Drawing.Size(138, 27);
            this.txt_CustoUnit.TabIndex = 614;
            this.txt_CustoUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // DgItensVenda
            // 
            this.DgItensVenda.AllowUserToAddRows = false;
            this.DgItensVenda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DgItensVenda.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.DgItensVenda.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.DgItensVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgItensVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DgItensVenda.Location = new System.Drawing.Point(297, 5);
            this.DgItensVenda.Margin = new System.Windows.Forms.Padding(2);
            this.DgItensVenda.MultiSelect = false;
            this.DgItensVenda.Name = "DgItensVenda";
            this.DgItensVenda.ReadOnly = true;
            this.DgItensVenda.RowHeadersWidth = 51;
            this.DgItensVenda.RowTemplate.Height = 24;
            this.DgItensVenda.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgItensVenda.Size = new System.Drawing.Size(901, 341);
            this.DgItensVenda.TabIndex = 619;
            this.DgItensVenda.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgItensVenda_CellContentClick);
            this.DgItensVenda.SelectionChanged += new System.EventHandler(this.DgItensVenda_SelectionChanged);
            // 
            // btn_BuscarCondPag
            // 
            this.btn_BuscarCondPag.BackColor = System.Drawing.Color.Gold;
            this.btn_BuscarCondPag.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarCondPag.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_BuscarCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BuscarCondPag.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_BuscarCondPag.Location = new System.Drawing.Point(534, 371);
            this.btn_BuscarCondPag.Margin = new System.Windows.Forms.Padding(4);
            this.btn_BuscarCondPag.Name = "btn_BuscarCondPag";
            this.btn_BuscarCondPag.Size = new System.Drawing.Size(62, 26);
            this.btn_BuscarCondPag.TabIndex = 620;
            this.btn_BuscarCondPag.Text = "Buscar";
            this.btn_BuscarCondPag.UseVisualStyleBackColor = false;
            this.btn_BuscarCondPag.Click += new System.EventHandler(this.btn_BuscarCondPag_Click);
            // 
            // btn_ExcluirItem
            // 
            this.btn_ExcluirItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ExcluirItem.BackColor = System.Drawing.Color.Gold;
            this.btn_ExcluirItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ExcluirItem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_ExcluirItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExcluirItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_ExcluirItem.Location = new System.Drawing.Point(1002, 352);
            this.btn_ExcluirItem.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ExcluirItem.Name = "btn_ExcluirItem";
            this.btn_ExcluirItem.Size = new System.Drawing.Size(94, 26);
            this.btn_ExcluirItem.TabIndex = 632;
            this.btn_ExcluirItem.Text = "Excluir Item";
            this.btn_ExcluirItem.UseVisualStyleBackColor = false;
            this.btn_ExcluirItem.Click += new System.EventHandler(this.btn_ExcluirItem_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gold;
            this.label14.Location = new System.Drawing.Point(785, 349);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 20);
            this.label14.TabIndex = 631;
            this.label14.Text = "Outros";
            this.label14.Visible = false;
            // 
            // txt_Outros
            // 
            this.txt_Outros.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Outros.Location = new System.Drawing.Point(788, 371);
            this.txt_Outros.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Outros.MaxLength = 100;
            this.txt_Outros.Name = "txt_Outros";
            this.txt_Outros.Size = new System.Drawing.Size(77, 27);
            this.txt_Outros.TabIndex = 630;
            this.txt_Outros.Text = "0";
            this.txt_Outros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Outros.Visible = false;
            this.txt_Outros.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ValorFrete_KeyPress);
            this.txt_Outros.Leave += new System.EventHandler(this.txt_ValorFrete_Leave);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gold;
            this.label13.Location = new System.Drawing.Point(686, 349);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 20);
            this.label13.TabIndex = 629;
            this.label13.Text = "Valor Seguro";
            this.label13.Visible = false;
            // 
            // txt_ValorSeg
            // 
            this.txt_ValorSeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ValorSeg.Location = new System.Drawing.Point(689, 371);
            this.txt_ValorSeg.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ValorSeg.MaxLength = 100;
            this.txt_ValorSeg.Name = "txt_ValorSeg";
            this.txt_ValorSeg.Size = new System.Drawing.Size(91, 27);
            this.txt_ValorSeg.TabIndex = 628;
            this.txt_ValorSeg.Text = "0";
            this.txt_ValorSeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_ValorSeg.Visible = false;
            this.txt_ValorSeg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ValorFrete_KeyPress);
            this.txt_ValorSeg.Leave += new System.EventHandler(this.txt_ValorFrete_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gold;
            this.label12.Location = new System.Drawing.Point(601, 349);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 20);
            this.label12.TabIndex = 627;
            this.label12.Text = "Valor Frete";
            this.label12.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(355, 349);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(184, 20);
            this.label11.TabIndex = 626;
            this.label11.Text = "Condição de Pagamento";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gold;
            this.label10.Location = new System.Drawing.Point(294, 349);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 20);
            this.label10.TabIndex = 625;
            this.label10.Text = "Código";
            // 
            // txt_ValorFrete
            // 
            this.txt_ValorFrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ValorFrete.Location = new System.Drawing.Point(604, 371);
            this.txt_ValorFrete.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ValorFrete.MaxLength = 100;
            this.txt_ValorFrete.Name = "txt_ValorFrete";
            this.txt_ValorFrete.Size = new System.Drawing.Size(77, 27);
            this.txt_ValorFrete.TabIndex = 624;
            this.txt_ValorFrete.Text = "0";
            this.txt_ValorFrete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_ValorFrete.Visible = false;
            this.txt_ValorFrete.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ValorFrete_KeyPress);
            this.txt_ValorFrete.Leave += new System.EventHandler(this.txt_ValorFrete_Leave);
            // 
            // txt_Condicao
            // 
            this.txt_Condicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Condicao.Location = new System.Drawing.Point(358, 371);
            this.txt_Condicao.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Condicao.MaxLength = 100;
            this.txt_Condicao.Name = "txt_Condicao";
            this.txt_Condicao.Size = new System.Drawing.Size(168, 27);
            this.txt_Condicao.TabIndex = 623;
            this.txt_Condicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_CodCond
            // 
            this.txt_CodCond.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodCond.Location = new System.Drawing.Point(297, 371);
            this.txt_CodCond.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CodCond.MaxLength = 100;
            this.txt_CodCond.Name = "txt_CodCond";
            this.txt_CodCond.Size = new System.Drawing.Size(53, 27);
            this.txt_CodCond.TabIndex = 622;
            this.txt_CodCond.Text = "0";
            this.txt_CodCond.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_FVenda
            // 
            this.btn_FVenda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_FVenda.BackColor = System.Drawing.Color.Gold;
            this.btn_FVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_FVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FVenda.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_FVenda.Location = new System.Drawing.Point(1104, 352);
            this.btn_FVenda.Margin = new System.Windows.Forms.Padding(4);
            this.btn_FVenda.Name = "btn_FVenda";
            this.btn_FVenda.Size = new System.Drawing.Size(94, 26);
            this.btn_FVenda.TabIndex = 621;
            this.btn_FVenda.Text = "Finalizar";
            this.btn_FVenda.UseVisualStyleBackColor = false;
            this.btn_FVenda.Click += new System.EventHandler(this.btn_FVenda_Click);
            // 
            // lbl_TotNota
            // 
            this.lbl_TotNota.AutoSize = true;
            this.lbl_TotNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotNota.ForeColor = System.Drawing.Color.Gold;
            this.lbl_TotNota.Location = new System.Drawing.Point(1076, 472);
            this.lbl_TotNota.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TotNota.Name = "lbl_TotNota";
            this.lbl_TotNota.Size = new System.Drawing.Size(122, 39);
            this.lbl_TotNota.TabIndex = 636;
            this.lbl_TotNota.Text = "000,00";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gold;
            this.label15.Location = new System.Drawing.Point(1011, 472);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 39);
            this.label15.TabIndex = 635;
            this.label15.Text = "R$";
            // 
            // btn_FCond
            // 
            this.btn_FCond.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_FCond.BackColor = System.Drawing.Color.Gold;
            this.btn_FCond.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FCond.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_FCond.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FCond.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_FCond.Location = new System.Drawing.Point(885, 371);
            this.btn_FCond.Margin = new System.Windows.Forms.Padding(4);
            this.btn_FCond.Name = "btn_FCond";
            this.btn_FCond.Size = new System.Drawing.Size(93, 26);
            this.btn_FCond.TabIndex = 634;
            this.btn_FCond.Text = "Finalizar Condição";
            this.btn_FCond.UseVisualStyleBackColor = false;
            this.btn_FCond.Click += new System.EventHandler(this.btn_FCond_Click);
            // 
            // lvParcelas
            // 
            this.lvParcelas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lvParcelas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clParcelas,
            this.clDias,
            this.clIdForma,
            this.clForma,
            this.clPercentTotal,
            this.clPreco});
            this.lvParcelas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvParcelas.FullRowSelect = true;
            this.lvParcelas.GridLines = true;
            this.lvParcelas.HideSelection = false;
            this.lvParcelas.Location = new System.Drawing.Point(297, 406);
            this.lvParcelas.Margin = new System.Windows.Forms.Padding(4);
            this.lvParcelas.Name = "lvParcelas";
            this.lvParcelas.Size = new System.Drawing.Size(681, 164);
            this.lvParcelas.TabIndex = 633;
            this.lvParcelas.UseCompatibleStateImageBehavior = false;
            this.lvParcelas.View = System.Windows.Forms.View.Details;
            // 
            // clParcelas
            // 
            this.clParcelas.Text = "Nº";
            this.clParcelas.Width = 40;
            // 
            // clDias
            // 
            this.clDias.Text = "Dias";
            this.clDias.Width = 100;
            // 
            // clIdForma
            // 
            this.clIdForma.Text = "ID.F";
            // 
            // clForma
            // 
            this.clForma.Text = "Forma PG";
            this.clForma.Width = 206;
            // 
            // clPercentTotal
            // 
            this.clPercentTotal.Text = "%  sob Total";
            this.clPercentTotal.Width = 120;
            // 
            // clPreco
            // 
            this.clPreco.Text = "Valor da parcela";
            this.clPreco.Width = 150;
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.BackColor = System.Drawing.Color.Gold;
            this.btn_Salvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Salvar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Salvar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Salvar.Location = new System.Drawing.Point(1056, 542);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(68, 28);
            this.btn_Salvar.TabIndex = 591;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = false;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // pbFoto
            // 
            this.pbFoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbFoto.Location = new System.Drawing.Point(12, 349);
            this.pbFoto.Name = "pbFoto";
            this.pbFoto.Size = new System.Drawing.Size(274, 112);
            this.pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFoto.TabIndex = 637;
            this.pbFoto.TabStop = false;
            // 
            // btn_Limpar
            // 
            this.btn_Limpar.BackColor = System.Drawing.Color.Gold;
            this.btn_Limpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Limpar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Limpar.Location = new System.Drawing.Point(978, 542);
            this.btn_Limpar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpar.Name = "btn_Limpar";
            this.btn_Limpar.Size = new System.Drawing.Size(70, 29);
            this.btn_Limpar.TabIndex = 638;
            this.btn_Limpar.Text = "Limpar";
            this.btn_Limpar.UseVisualStyleBackColor = false;
            this.btn_Limpar.Click += new System.EventHandler(this.btn_Limpar_Click);
            // 
            // FrmCadVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1207, 583);
            this.Controls.Add(this.btn_LimparDadosCliente);
            this.Controls.Add(this.btn_Limpar);
            this.Controls.Add(this.pbFoto);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.lbl_TotNota);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btn_FCond);
            this.Controls.Add(this.lvParcelas);
            this.Controls.Add(this.btn_BuscarCondPag);
            this.Controls.Add(this.btn_ExcluirItem);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_Outros);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_ValorSeg);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_ValorFrete);
            this.Controls.Add(this.txt_Condicao);
            this.Controls.Add(this.txt_CodCond);
            this.Controls.Add(this.btn_FVenda);
            this.Controls.Add(this.DgItensVenda);
            this.Controls.Add(this.btn_AddItem);
            this.Controls.Add(this.txt_CustoTotal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_CustoUnit);
            this.Controls.Add(this.Panel_Prod);
            this.Controls.Add(this.CB_ServProd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Cliente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_BuscarCliente);
            this.Controls.Add(this.txt_CPFeCNPJ);
            this.Controls.Add(this.label6);
            this.Name = "FrmCadVendas";
            this.Text = "Cadastro: Vendas";
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.txt_CPFeCNPJ, 0);
            this.Controls.SetChildIndex(this.btn_BuscarCliente, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.txt_Cliente, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.CB_ServProd, 0);
            this.Controls.SetChildIndex(this.Panel_Prod, 0);
            this.Controls.SetChildIndex(this.txt_CustoUnit, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.txt_CustoTotal, 0);
            this.Controls.SetChildIndex(this.btn_AddItem, 0);
            this.Controls.SetChildIndex(this.DgItensVenda, 0);
            this.Controls.SetChildIndex(this.btn_FVenda, 0);
            this.Controls.SetChildIndex(this.txt_CodCond, 0);
            this.Controls.SetChildIndex(this.txt_Condicao, 0);
            this.Controls.SetChildIndex(this.txt_ValorFrete, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.txt_ValorSeg, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.txt_Outros, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.btn_ExcluirItem, 0);
            this.Controls.SetChildIndex(this.btn_BuscarCondPag, 0);
            this.Controls.SetChildIndex(this.lvParcelas, 0);
            this.Controls.SetChildIndex(this.btn_FCond, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.lbl_TotNota, 0);
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.pbFoto, 0);
            this.Controls.SetChildIndex(this.btn_Limpar, 0);
            this.Controls.SetChildIndex(this.btn_LimparDadosCliente, 0);
            this.Panel_Prod.ResumeLayout(false);
            this.Panel_Prod.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgItensVenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Button btn_BuscarCliente;
        protected System.Windows.Forms.TextBox txt_CPFeCNPJ;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.TextBox txt_Cliente;
        protected System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CB_ServProd;
        protected System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel Panel_Prod;
        protected System.Windows.Forms.Label lbl_CodProd;
        protected System.Windows.Forms.TextBox txt_Qntd;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.TextBox txt_Desc;
        protected System.Windows.Forms.Button btn_BuscarProd;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.TextBox txt_Prod;
        protected System.Windows.Forms.TextBox txt_CodProd;
        protected System.Windows.Forms.Button btn_AddItem;
        protected System.Windows.Forms.TextBox txt_CustoTotal;
        protected System.Windows.Forms.Label label9;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.TextBox txt_CustoUnit;
        protected System.Windows.Forms.DataGridView DgItensVenda;
        protected System.Windows.Forms.Button btn_BuscarCondPag;
        protected System.Windows.Forms.Button btn_ExcluirItem;
        protected System.Windows.Forms.Label label14;
        protected System.Windows.Forms.TextBox txt_Outros;
        protected System.Windows.Forms.Label label13;
        protected System.Windows.Forms.TextBox txt_ValorSeg;
        protected System.Windows.Forms.Label label12;
        protected System.Windows.Forms.Label label11;
        protected System.Windows.Forms.Label label10;
        protected System.Windows.Forms.TextBox txt_ValorFrete;
        protected System.Windows.Forms.TextBox txt_Condicao;
        protected System.Windows.Forms.TextBox txt_CodCond;
        protected System.Windows.Forms.Button btn_FVenda;
        protected System.Windows.Forms.Label lbl_TotNota;
        protected System.Windows.Forms.Label label15;
        protected System.Windows.Forms.ListView lvParcelas;
        private System.Windows.Forms.ColumnHeader clParcelas;
        private System.Windows.Forms.ColumnHeader clDias;
        private System.Windows.Forms.ColumnHeader clIdForma;
        private System.Windows.Forms.ColumnHeader clForma;
        private System.Windows.Forms.ColumnHeader clPercentTotal;
        private System.Windows.Forms.ColumnHeader clPreco;
        public System.Windows.Forms.Button btn_Salvar;
        public System.Windows.Forms.Button btn_FCond;
        private System.Windows.Forms.PictureBox pbFoto;
        protected System.Windows.Forms.Button btn_Limpar;
        protected System.Windows.Forms.Button btn_LimparDadosCliente;
    }
}
