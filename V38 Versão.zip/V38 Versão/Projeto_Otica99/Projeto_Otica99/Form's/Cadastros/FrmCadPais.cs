﻿using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadPais : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Paises      oPais;
        FrmConPais  aConPais;
        Ctrl_Paises aCtrlPais;
        public FrmCadPais()
        {
            InitializeComponent();
            aCtrlPais = new Ctrl_Paises();
            oPais = new Paises();
        }
        private void Letras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }
        private void Numeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public void SetConsultaPais(object obj)
        {
            aConPais = (FrmConPais)obj;
        }
        public override void ConhecaObj(object obj)
        {
            this.oPais = (Paises)obj;
          //  aCtrlPais = (Ctrl_Paises)Ctrl;
        }
        public override void CarregarEdit()
        {
            this.txt_Codigo.Text   = txt_Codigo.ToString();
            this.txt_CadPais.Text  = txt_CadPais.ToString();
            this.txt_CadDDI.Text   = txt_CadDDI.ToString();
            this.txt_CadSigla.Text = txt_CadSigla.ToString();
        }
        //protected override void AlterarEdit()
        //{ 
        //    base.AlterarEdit();
        //
        //}
        protected override void LimparCampos()
        {
            this.txt_Codigo.Text = "0";
            this.txt_CadPais.Clear();
            this.txt_CadDDI.Clear();
            this.txt_CadSigla.Clear();
        }
        public override void DesbloquearEdit()
        {
            txt_Codigo.Enabled   = true;
            txt_CadPais.Enabled  = true;
            txt_CadDDI.Enabled   = true;
            txt_CadSigla.Enabled = true;
        }
        public override void BloquearEdit()
        {
            txt_Codigo.Enabled   = false;
            txt_CadPais.Enabled  = false;
            txt_CadDDI.Enabled   = false;
            txt_CadSigla.Enabled = false;
        }
        public bool CamposPreenchidos()
        {
            bool ok = false;
            if (string.IsNullOrEmpty(txt_CadPais.Text) ||
                string.IsNullOrEmpty(txt_CadDDI.Text) ||
                string.IsNullOrEmpty(txt_CadSigla.Text)              
                )
            {
                MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                ok = true;
            }

            return ok;
        }
        public override void Salvar()
        {
            string Salvo;
            string msg = "O Cadastro do País: " + txt_CadPais.Text + " foi realizado com o sucesso!";
            if (CamposPreenchidos())
            {
              
                oPais.ID    = Convert.ToInt16(txt_Codigo.Text);
                oPais.Pais  = txt_CadPais.Text;
                oPais.Ddi   = txt_CadDDI.Text;
                oPais.Sigla = txt_CadSigla.Text;
                oPais.Ativo = "A";


                if (btn_Salvar.Text == "Alterar")
                {
                    Salvo = aCtrlPais.Salvar(oPais);
                    oPais.DataUltimaAlteracao = DateTime.Now;
                    msg = "o Cadastro do País: " + oPais.Pais + " foi Alterado com sucesso!";
                    this.txt_Codigo.Text = "0";
                    LimparCampos();
                }
                
                Salvo = aCtrlPais.Salvar(oPais);
                this.txt_Codigo.Text = "0";
                LimparCampos();
                MessageBox.Show(msg);
                Close();
            }
        }

        private void FrmCadPais_Load(object sender, EventArgs e)
        {
            
        }
    }
}
