﻿using Projeto_Otica99.Class_s.Controller_s;

using Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Class_s.Outros;
using System.Text.RegularExpressions;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Consultas.Consula_Pagamento;

namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço
{
    public partial class FrmCadPFePJ : Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço.FrmCadastroEndereco
    {
        DadosCadastro  oCliente;
        DadosCadastro  oFornecedor;
        DadosCadastro2 oFuncionario;

        Ctrl_Clientes     aCtrlCliente;
        Ctrl_Funcionarios aCtrlFuncionarios;
        Ctrl_Fornecedores aCtrlFornecedor;

        FrmConCidade aConCidade;
        FrmConCargo  aConCargo;

        Verificacao verificacao;

        public FrmCadPFePJ()
        {
            InitializeComponent();

            oCliente           = new DadosCadastro();
            oFornecedor        = new DadosCadastro();
            oFuncionario       = new DadosCadastro2();

            aCtrlCliente       = new Ctrl_Clientes();
            aCtrlFuncionarios  = new Ctrl_Funcionarios();
            aCtrlFornecedor    = new Ctrl_Fornecedores();

            verificacao        = new Verificacao();
            CB_Tipo.SelectedIndexChanged += new EventHandler(CB_Tipo_SelectedIndexChanged);
            txt_Codigo.Enabled = false;
        }

        private void Letras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
            // Verifica se o primeiro caractere é um espaço
            if (txt_NomeOuRSocial.Text.Length == 0 && char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void Numeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public void SetConsultaCidade(object obj)
        {
            aConCidade = (FrmConCidade)obj;
        }
        public void SetConsultaCargo(object obj)
        {
            aConCargo = (FrmConCargo)obj;
        }
        public override void ConhecaObj(object obj)
        {
            if (lbl_Generica.Text == "Cliente")
            {
                this.oCliente     = (DadosCadastro)obj;
            }
            else if (lbl_Generica.Text == "Fornecedor")
            {
                this.oFornecedor  = (DadosCadastro)obj;
            }
            else if (lbl_Generica.Text == "Funcionário")
            {
                this.oFuncionario = (DadosCadastro2)obj;
            }
        }
        public bool CamposPreenchidos()
        {
            bool ok = false;

            if(CB_Tipo.Text == "Estrangeiro")
            {
                if (string.IsNullOrEmpty(txt_Endereco.Text) ||
                //string.IsNullOrEmpty(txt_Complemento.Text) ||
                string.IsNullOrEmpty(txt_Numero.Text) ||
                string.IsNullOrEmpty(txt_Bairro.Text) ||              
                string.IsNullOrEmpty(txt_CodCidade.Text) ||
                string.IsNullOrEmpty(CB_Tipo.Text) ||
                string.IsNullOrEmpty(txt_NomeOuRSocial.Text) ||
                string.IsNullOrEmpty(txt_SobrenomeOuNFantasia.Text) ||
                string.IsNullOrEmpty(txt_Telefone.Text) ||
                string.IsNullOrEmpty(txt_Email.Text))
                {
                    MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    ok = true;
                }
            }
            else if (CB_Tipo.Text == "PJ")
            {
                if (string.IsNullOrEmpty(txt_Endereco.Text) ||
                //string.IsNullOrEmpty(txt_Complemento.Text) ||
                string.IsNullOrEmpty(txt_Numero.Text) ||
                string.IsNullOrEmpty(txt_Bairro.Text) ||
                (mtb_CEP.Text == "00000-000") ||
                string.IsNullOrEmpty(txt_CodCidade.Text) ||
                string.IsNullOrEmpty(CB_Tipo.Text) ||
                string.IsNullOrEmpty(txt_NomeOuRSocial.Text) ||
                string.IsNullOrEmpty(txt_SobrenomeOuNFantasia.Text) ||
                string.IsNullOrEmpty(txt_Telefone.Text) ||
                string.IsNullOrEmpty(txt_Email.Text) ||
                (mtb_CPFeCNPJ.Text == "000.000.000-00" || mtb_CPFeCNPJ.Text == "00.000.000/0000-00") ||
                (string.IsNullOrEmpty(mtb_RGeIE.Text) || mtb_RGeIE.Text == "00.000.000-0"))
                {
                    MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    ok = true;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txt_Endereco.Text) ||
               //string.IsNullOrEmpty(txt_Complemento.Text) ||
               string.IsNullOrEmpty(txt_Numero.Text) ||
               string.IsNullOrEmpty(txt_Bairro.Text) ||
               (mtb_CEP.Text == "00000-000") ||
               string.IsNullOrEmpty(txt_CodCidade.Text) ||
               string.IsNullOrEmpty(CB_Tipo.Text) ||
               string.IsNullOrEmpty(txt_NomeOuRSocial.Text) ||
               string.IsNullOrEmpty(txt_SobrenomeOuNFantasia.Text) ||
               string.IsNullOrEmpty(txt_Telefone.Text) ||
               string.IsNullOrEmpty(txt_Email.Text) ||
               (mtb_CPFeCNPJ.Text == "000.000.000-00" || mtb_CPFeCNPJ.Text == "00.000.000/0000-00") ||
               (string.IsNullOrEmpty(mtb_RGeIE.Text) || mtb_RGeIE.Text == "00.000.000-0") ||
               ((string.IsNullOrEmpty(txt_DataNasc.Text) || (txt_DataNasc.Text == " / /    "))))
                {
                    MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    ok = true;
                }
            }
            return ok;
        }

        public override void CarregarEdit()
        {
            this.txt_Codigo.Text = txt_Codigo.ToString();

            this.mtb_CEP.Text = mtb_CEP.ToString();
            this.txt_Endereco.Text = txt_Endereco.ToString();
            this.txt_Complemento.Text = txt_Complemento.ToString();
            this.txt_Numero.Text = txt_Numero.ToString();
            this.txt_Bairro.Text = txt_Bairro.ToString();
            this.mtb_CEP.Text = mtb_CEP.ToString();
            this.txt_Cidade.Text = txt_Cidade.ToString();
            this.txt_CodCidade.Text = txt_CodCidade.ToString();
            this.txt_Complemento.Text = txt_Complemento.ToString();

            this.mtb_CPFeCNPJ.Text = mtb_CPFeCNPJ.ToString();
            this.txt_Email.Text = txt_Email.ToString();
            this.txt_Telefone.Text = txt_Telefone.ToString();
            this.txt_SobrenomeOuNFantasia.Text = txt_SobrenomeOuNFantasia.ToString();
            this.txt_NomeOuRSocial.Text = txt_NomeOuRSocial.ToString();
        }
        protected override void LimparCampos()
        {
            this.txt_Codigo.Text = "0";
            this.mtb_CEP.Clear();
            this.txt_Endereco.Clear();
            this.txt_Complemento.Clear();
            this.txt_Numero.Clear();
            this.txt_Bairro.Clear();
            this.txt_Cidade.Clear();
            this.txt_CodCidade.Clear();
            this.txt_Complemento.Clear();


            this.mtb_CPFeCNPJ.Clear();
            this.txt_Email.Clear();
            this.txt_Telefone.Clear();
            this.txt_SobrenomeOuNFantasia.Clear();
            this.txt_NomeOuRSocial.Clear();
            this.mtb_RGeIE.Clear();
            this.CB_Tipo.SelectedIndex = -1;
            this.CB_Sexo.SelectedIndex = -1;

            this.txt_CodCondicaoPag.Clear();
            this.txt_CondPag.Clear();
            this.txt_DataNasc.Clear();
            this.txt_CodCargo.Clear();
            this.txt_Cargo.Clear();


        }
        public override void DesbloquearEdit()
        {
            this.mtb_CEP.Enabled = false;
            this.txt_Endereco.Enabled = false;
            this.txt_Complemento.Enabled = false;
            this.txt_Numero.Enabled = false;
            this.txt_Bairro.Enabled = false;
            this.mtb_CEP.Enabled = false;
            this.txt_Cidade.Enabled = false;
            this.txt_CodCidade.Enabled = false;
            this.txt_Complemento.Enabled = false;


            this.mtb_CPFeCNPJ.Enabled = false;
            this.txt_Email.Enabled = false;
            this.txt_Telefone.Enabled = false;
            this.txt_SobrenomeOuNFantasia.Enabled = false;
            this.txt_NomeOuRSocial.Enabled = false;

        }
        public override void BloquearEdit()
        {
            this.mtb_CEP.Enabled = true;
            this.txt_Endereco.Enabled = true;
            this.txt_Complemento.Enabled = true;
            this.txt_Numero.Enabled = true;
            this.txt_Bairro.Enabled = true;
            this.mtb_CEP.Enabled = true;
            this.txt_Cidade.Enabled = true;
            this.txt_CodCidade.Enabled = true;
            this.txt_Complemento.Enabled = true;


            this.mtb_CPFeCNPJ.Enabled = true;
            this.txt_Email.Enabled = true;
            this.txt_Telefone.Enabled = true;
            this.txt_SobrenomeOuNFantasia.Enabled = true;
            this.txt_NomeOuRSocial.Enabled = true;
        }
        private void CB_Tipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CB_Tipo.Text == "PF")
            {
                PF();
            }
            else if (CB_Tipo.Text == "PJ")
            {
                PJ();
            }
            else
            {
                Estrangeiro();
            }
        }
        public void PF()
        {
            lbl_NomeOuRSocial.Text = "Nome";
            lbl_SobrenomeOuNFantasia.Text = "Sobrenome";
            lbl_CNPJeCPF.Text = "CPF";
            lbl_RGeIE.Text = "RG";
            mtb_CPFeCNPJ.Mask = "000\\.000\\.000\\-00";
            mtb_RGeIE.Mask = "00\\.000\\.000\\-0";

            lbl_Sexo.Visible = true;
            CB_Sexo.Visible = true;
            CB_Sexo.Enabled = true;

            lbl_DataNasc.Visible = true;
            txt_DataNasc.Visible = true;
            txt_DataNasc.Enabled = true;
            txt_DataNasc.Mask = "00\\/00\\/0000";

            if (lbl_Generica.Text == "Fornecedor")
            {
                lbl_DataNasc.Visible = false;
                txt_DataNasc.Visible = false;
                txt_DataNasc.Enabled = false;
                lbl_CodCargo.Visible = false;
                lbl_Cargo.Visible    = false;
                txt_CodCargo.Visible = false;
                txt_Cargo.Visible    = false;
                btn_Cargo.Visible    = false;

            }
            else if(lbl_Generica.Text == "Funcionário")
            {            
                lbl_CodCargo.Visible = true;
                lbl_Cargo.Visible    = true;
                txt_CodCargo.Visible = true;
                txt_Cargo.Visible    = true;
                btn_Cargo.Visible    = true;
                btn_BuscarCondPag.Visible = false;
            }
            else if(lbl_Generica.Text == "Cliente")
            {
                lbl_DataNasc.Visible = true;
                txt_DataNasc.Visible = true;
                txt_DataNasc.Enabled = true;
                txt_DataNasc.Mask    = "00\\/00\\/0000";
                lbl_CodCargo.Visible = false;
                lbl_Cargo.Visible    = false;
                txt_CodCargo.Visible = false;
                txt_Cargo.Visible    = false;
                btn_Cargo.Visible    = false;
                btn_BuscarCondPag.Visible = true;
            }
        }
        public void PJ()
        {
            lbl_NomeOuRSocial.Text = "Razão Social";
            lbl_SobrenomeOuNFantasia.Text = "Nome Fantasia";
            lbl_CNPJeCPF.Text = "CNPJ";
            lbl_RGeIE.Text = "IE";
            mtb_CPFeCNPJ.Mask = "00\\.000\\.000\\/0000\\-00";
            mtb_RGeIE.Mask = "";

            lbl_Sexo.Visible = false;
            CB_Sexo.Visible = false;
            CB_Sexo.Enabled = false;

            lbl_DataNasc.Visible = false;
            txt_DataNasc.Visible = false;
            txt_DataNasc.Enabled = false;
            lbl_CodCargo.Visible = false;
            lbl_Cargo.Visible    = false;
            txt_CodCargo.Visible = false;
            txt_Cargo.Visible    = false;
            btn_Cargo.Visible    = false;
           
            if (lbl_Generica.Text == "Cliente")
            {
                btn_BuscarCondPag.Visible = true;
            }
            else if (lbl_Generica.Text == "Fornecedor")
            {
                btn_BuscarCondPag.Visible = true;
            }
            else if (lbl_Generica.Text == "Funcionário")
            {
                lbl_CodCargo.Visible = true;
                lbl_Cargo.Visible    = true;
                txt_CodCargo.Visible = true;
                txt_Cargo.Visible    = true;
                btn_Cargo.Visible    = true;
            }
        }
        public void Estrangeiro()
        {
            lbl_NomeOuRSocial.Text = "Nome";
            lbl_SobrenomeOuNFantasia.Text = "Sobrenome";
            lbl_CNPJeCPF.Text = "CPF";
            lbl_RGeIE.Text = "RG";
            mtb_CPFeCNPJ.Mask = "000\\.000\\.000\\-00";
            mtb_RGeIE.Mask = "00\\.000\\.000\\-0";

            lbl_Sexo.Visible = true;
            CB_Sexo.Visible = true;
            CB_Sexo.Enabled = true;

            if (lbl_Generica.Text == "Fornecedor")
            {
                lbl_DataNasc.Visible = false;
                txt_DataNasc.Visible = false;
                txt_DataNasc.Enabled = false;
                lbl_CodCargo.Visible = false;
                txt_Cargo.Visible    = false;
            }         
            else
            {
                lbl_DataNasc.Visible = true;
                txt_DataNasc.Visible = true;
                txt_DataNasc.Enabled = true;
                txt_DataNasc.Mask = "00\\/00\\/0000";
                lbl_CodCargo.Visible = false;
                txt_Cargo.Visible = false;
            }
        }
        public bool VerificaCampos()
        {
            bool ok = false;
            if (verificacao.IsCep(mtb_CEP.Text))
            {
                ok = true;
            }
            else
            {
                mtb_CEP.Text = "00000-000";
            }

            if (verificacao.IsEmail(txt_Email.Text))
            {
                ok = true;
            }
            else
            {
                txt_Email.Clear();
            }

            return ok;
        }
        public bool VerificaCamposPF()
        {
            bool ok = false;

            if (verificacao.IsCpf(mtb_CPFeCNPJ.Text))
            {
                ok = true;
            }
            else
            {
                mtb_CPFeCNPJ.Text = "00.000.000/0000-00";
                return ok;
            }

            return ok;
        }
        public bool VerificaCamposPJ()
        {
            bool ok = true;
            if (verificacao.IsCnpj(mtb_CPFeCNPJ.Text))
            {
                ok = true;
            }
            else
            {
                //mtb_CPFeCNPJ.Clear();             
            }

            return ok;
        }
        public override void Salvar()
        {
            if (CamposPreenchidos())
            {
                if (lbl_Generica.Text == "Cliente")
                {
                    if (CB_Tipo.Text == "Estrangeiro")
                    {
                        string Salvo_Cliente;
                        string msg = "O Cadastro do cliente " + txt_NomeOuRSocial.Text + " foi realizado com o sucesso!";

                        oCliente.ID = Convert.ToInt16(txt_Codigo.Text);
                        oCliente.CidadeID.ID = Convert.ToInt16(txt_CodCidade.Text);
                        oCliente.condicao_Pagamento.ID = Convert.ToInt16(txt_CodCondicaoPag.Text);

                        oCliente.NomeOuRSocial = txt_NomeOuRSocial.Text;
                        oCliente.SobrenomeOuNomeFantasia = txt_SobrenomeOuNFantasia.Text;
                        oCliente.Endereco = txt_Endereco.Text;
                        oCliente.Complemento = txt_Complemento.Text;
                        oCliente.Numero = txt_Numero.Text;
                        oCliente.Bairro = txt_Bairro.Text;
                        oCliente.CEP = mtb_CEP.Text;

                        if (VerificaCampos())
                        {
                            oCliente.Email = txt_Email.Text;
                        }

                        oCliente.Telefone = txt_Telefone.Text;

                        if (CB_Tipo.Text == "PF")
                        {
                            if (mtb_CPFeCNPJ.Text != null)
                            {
                                if (VerificaCamposPF())
                                {
                                    oCliente.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                                    oCliente.RGouIE = mtb_RGeIE.Text;
                                }
                            }
                            else
                            {
                                oCliente.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                                oCliente.RGouIE = mtb_RGeIE.Text;
                            }
                        }
                        else
                        {
                            if (VerificaCamposPJ())
                            {
                                oCliente.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                            }
                            oCliente.RGouIE = mtb_RGeIE.Text;
                        }

                        oCliente.Sexo = CB_Sexo.Text;
                        oCliente.DataNasc = txt_DataNasc.Text;
                        oCliente.Ativo = "A";

                        if (btn_Salvar.Text == "Alterar")
                        {
                            oCliente.DataUltimaAlteracao = DateTime.Now;
                            msg = "o Cadastro do cliente foi Alterado com sucesso!";
                        }

                        if (CamposPreenchidos())
                        {
                            Salvo_Cliente = aCtrlCliente.Salvar(oCliente);
                            MessageBox.Show(msg);
                            LimparCampos();
                            this.txt_Codigo.Text = "0";
                            Close();
                        }
                    }
                    else
                    {
                        string Salvo_Cliente;
                        string msg = "O Cadastro do cliente " + txt_NomeOuRSocial.Text + " foi realizado com o sucesso!";

                        oCliente.ID = Convert.ToInt16(txt_Codigo.Text);
                        oCliente.CidadeID.ID = Convert.ToInt16(txt_CodCidade.Text);
                        oCliente.condicao_Pagamento.ID = Convert.ToInt16(txt_CodCondicaoPag.Text);

                        oCliente.NomeOuRSocial = txt_NomeOuRSocial.Text;
                        oCliente.SobrenomeOuNomeFantasia = txt_SobrenomeOuNFantasia.Text;
                        oCliente.Endereco = txt_Endereco.Text;
                        oCliente.Complemento = txt_Complemento.Text;
                        oCliente.Numero = txt_Numero.Text;
                        oCliente.Bairro = txt_Bairro.Text;

                        if (VerificaCampos())
                        {
                            oCliente.CEP = mtb_CEP.Text;
                            oCliente.Email = txt_Email.Text;
                        }

                        oCliente.Telefone = txt_Telefone.Text;

                        if (CB_Tipo.Text == "PF")
                        {
                            if (VerificaCamposPF())
                            {
                                oCliente.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                                oCliente.RGouIE = mtb_RGeIE.Text;
                            }
                        }
                        else
                        {
                            if (VerificaCamposPJ())
                            {
                                oCliente.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                            }
                            oCliente.RGouIE = mtb_RGeIE.Text;
                        }

                        oCliente.Sexo = CB_Sexo.Text;
                        oCliente.DataNasc = txt_DataNasc.Text;
                        oCliente.Ativo = "A";

                        if (btn_Salvar.Text == "Alterar")
                        {
                            oCliente.DataUltimaAlteracao = DateTime.Now;
                            msg = "o Cadastro do cliente foi Alterado com sucesso!";
                        }

                        if (CamposPreenchidos())
                        {
                            Salvo_Cliente = aCtrlCliente.Salvar(oCliente);
                            MessageBox.Show(msg);
                            LimparCampos();
                            this.txt_Codigo.Text = "0";
                            Close();
                        }
                    }

                }
                else if (lbl_Generica.Text == "Fornecedor")
                {

                    string Salvo_Fornecedor;
                    string msg = "O Cadastro do Fornecedor " + txt_NomeOuRSocial.Text + " foi realizado com o sucesso!";

                    oFornecedor.ID = Convert.ToInt16(txt_Codigo.Text);
                    oFornecedor.CidadeID.ID = Convert.ToInt16(txt_CodCidade.Text);
                    oFornecedor.condicao_Pagamento.ID = Convert.ToInt16(txt_CodCondicaoPag.Text);

                    oFornecedor.NomeOuRSocial = txt_NomeOuRSocial.Text;
                    oFornecedor.SobrenomeOuNomeFantasia = txt_SobrenomeOuNFantasia.Text;
                    oFornecedor.Endereco = txt_Endereco.Text;
                    oFornecedor.Complemento = txt_Complemento.Text;
                    oFornecedor.Numero = txt_Numero.Text;
                    oFornecedor.Bairro = txt_Bairro.Text;

                    if (VerificaCampos())
                    {
                        oFornecedor.CEP = mtb_CEP.Text;
                        oFornecedor.Email = txt_Email.Text;

                    }

                    oFornecedor.Telefone = txt_Telefone.Text;

                    if (CB_Tipo.Text == "PF")
                    {
                        if (VerificaCamposPF())
                        {
                            oFornecedor.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                        }
                        oFornecedor.RGouIE = mtb_RGeIE.Text;
                    }

                    else
                    {
                        if (VerificaCamposPJ())
                        {
                            oFornecedor.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                        }
                        oFornecedor.RGouIE = mtb_RGeIE.Text;
                    }

                    oFornecedor.Sexo = CB_Sexo.Text;
                    oFornecedor.Ativo = "A";

                    if (btn_Salvar.Text == "Alterar")
                    {
                        oFornecedor.DataUltimaAlteracao = DateTime.Now;
                        oFornecedor.Sexo = CB_Sexo.Text.Length > 0 ? CB_Sexo.Text.Substring(0, 1) : "";
                        msg = "o Cadastro do Fornecedor foi Alterado com sucesso!";

                    }
                    if (CamposPreenchidos())
                    {
                        Salvo_Fornecedor = aCtrlFornecedor.Salvar(oFornecedor);
                        MessageBox.Show(msg);
                        LimparCampos();
                        this.txt_Codigo.Text = "0";
                        Close();
                    }

                }
                else
                {
                    string Salvo_Funcionario;
                    string msg = "O Cadastro do Funcionário " + txt_NomeOuRSocial.Text + " foi realizado com o sucesso!";

                    oFuncionario.ID                      = Convert.ToInt16(txt_Codigo.Text);
                    oFuncionario.CidadeID.ID             = Convert.ToInt16(txt_CodCidade.Text);
                    oFuncionario.NomeOuRSocial           = txt_NomeOuRSocial.Text;
                    oFuncionario.SobrenomeOuNomeFantasia = txt_SobrenomeOuNFantasia.Text;
                    oFuncionario.Endereco                = txt_Endereco.Text;
                    oFuncionario.Complemento             = txt_Complemento.Text;
                    oFuncionario.Numero                  = txt_Numero.Text;
                    oFuncionario.Bairro                  = txt_Bairro.Text;

                    if (VerificaCampos())
                    {
                        oFuncionario.CEP   = mtb_CEP.Text;
                        oFuncionario.Email = txt_Email.Text;

                    }

                    oFuncionario.Telefone = txt_Telefone.Text;

                    if (CB_Tipo.Text == "PF")
                    {
                        if (VerificaCamposPF())
                        {
                            oFuncionario.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                            oFuncionario.RGouIE    = mtb_RGeIE.Text;
                        }
                    }

                    else
                    {
                        if (VerificaCamposPJ())
                        {
                            oFuncionario.CPFouCNPJ = mtb_CPFeCNPJ.Text;
                        }
                        oFuncionario.RGouIE = mtb_RGeIE.Text;
                    }
                    oFuncionario.Sexo     = CB_Sexo.Text;
                    oFuncionario.DataNasc = txt_DataNasc.Text;
                    oFuncionario.CargoID.ID = Convert.ToInt16(txt_CodCargo.Text);
                    oFuncionario.Ativo    = "A";

                    if (btn_Salvar.Text == "Alterar")
                    {
                        oFuncionario.DataUltimaAlteracao = DateTime.Now;
                        msg = "o Cadastro do Funcionário foi Alterado com sucesso!";
                    }

                    if (CamposPreenchidos())
                    {
                        Salvo_Funcionario = aCtrlFuncionarios.Salvar(oFuncionario);
                        MessageBox.Show(msg);
                        LimparCampos();
                        this.txt_Codigo.Text = "0";
                        Close();
                    }
                }

            }

        }

        private void btn_BuscarCondPag_Click(object sender, EventArgs e)
        {
            using (FrmConCondPagamento frm = new FrmConCondPagamento())
            {
                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txt_CodCondicaoPag.Text = IdSelecionado.ToString();
                txt_CondPag.Text = NomeSelecionado;
                txt_CodCondicaoPag_Leave(txt_CodCondicaoPag, EventArgs.Empty);

            }
        }

        private void txt_CodCondicaoPag_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_CodCondicaoPag.Text))
                LimparCondPg();
            else if (int.TryParse(txt_CodCondicaoPag.Text, out int cod) && cod > 0)
            {
                Ctrl_CondPagamento aCTRLcon = new Ctrl_CondPagamento();
                CondicaoPagamento condicao = aCTRLcon.BuscarCondicaoPagamentoPorId(cod);

                if (condicao == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparCondPg();
                }

                else
                {
                    txt_CondPag.Text = condicao.Condicao;
                }
            }
            else
            {
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparCondPg();
            }
            this.AcceptButton = btn_Salvar;
        }
        private void LimparCondPg()
        {
            txt_CondPag.Clear();
            txt_CodCondicaoPag.Clear();
        }

        private void mtb_CPFeCNPJ_Leave(object sender, EventArgs e)
        {
            if (CB_Tipo.Text == "PF")
            {
                if (!verificacao.IsCpf(mtb_CPFeCNPJ.Text))
                {
                    MessageBox.Show("CPF Inválido!");
                }
                
            }
            else
            {
                if (verificacao.IsCnpj(mtb_CPFeCNPJ.Text))
                {
                    MessageBox.Show("CNPJ Válido!");
                }
                else
                {
                    MessageBox.Show("CNPJ Inválido!");
                }
            }
        }

        private void txt_DataNasc_Leave(object sender, EventArgs e)
        {
            if (CB_Tipo.Text == "PF" || CB_Tipo.Text == "Estrangeiro")
            {
                if (!verificacao.Tem18AnosOuMais(txt_DataNasc.Text))
                {
                    MessageBox.Show("Menor de idade!");
                    txt_DataNasc.Mask = "00\\/00\\/0000";
                }
                
            }
            
        }

        private void FrmCadPFePJ_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_Cargo_Click(object sender, EventArgs e)
        {
            using (FrmConCargo frm = new FrmConCargo())
            {
                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                int    IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txt_CodCargo.Text = IdSelecionado.ToString();
                txt_Cargo.Text = NomeSelecionado;
            }
        }
    }
}
