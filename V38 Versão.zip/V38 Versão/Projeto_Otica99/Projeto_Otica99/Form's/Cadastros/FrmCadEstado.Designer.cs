﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadEstado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Estado = new System.Windows.Forms.Label();
            this.lbl_UF = new System.Windows.Forms.Label();
            this.lbl_Pais = new System.Windows.Forms.Label();
            this.txt_Estado = new System.Windows.Forms.TextBox();
            this.txt_UF = new System.Windows.Forms.TextBox();
            this.txt_Pais = new System.Windows.Forms.TextBox();
            this.btn_Buscar = new System.Windows.Forms.Button();
            this.lbl_CodPais = new System.Windows.Forms.Label();
            this.txt_CodPais = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(161, 126);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(3);
            // 
            // lbl_Código
            // 
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.Size = new System.Drawing.Size(71, 24);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(9, 33);
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(243, 126);
            this.btn_Sair.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            // 
            // lbl_Estado
            // 
            this.lbl_Estado.AutoSize = true;
            this.lbl_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estado.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Estado.Location = new System.Drawing.Point(111, 7);
            this.lbl_Estado.Name = "lbl_Estado";
            this.lbl_Estado.Size = new System.Drawing.Size(68, 24);
            this.lbl_Estado.TabIndex = 4;
            this.lbl_Estado.Text = "Estado";
            // 
            // lbl_UF
            // 
            this.lbl_UF.AutoSize = true;
            this.lbl_UF.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UF.ForeColor = System.Drawing.Color.Gold;
            this.lbl_UF.Location = new System.Drawing.Point(386, 7);
            this.lbl_UF.Name = "lbl_UF";
            this.lbl_UF.Size = new System.Drawing.Size(35, 24);
            this.lbl_UF.TabIndex = 5;
            this.lbl_UF.Text = "UF";
            // 
            // lbl_Pais
            // 
            this.lbl_Pais.AutoSize = true;
            this.lbl_Pais.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pais.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Pais.Location = new System.Drawing.Point(114, 65);
            this.lbl_Pais.Name = "lbl_Pais";
            this.lbl_Pais.Size = new System.Drawing.Size(45, 24);
            this.lbl_Pais.TabIndex = 6;
            this.lbl_Pais.Text = "País";
            // 
            // txt_Estado
            // 
            this.txt_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Estado.Location = new System.Drawing.Point(114, 33);
            this.txt_Estado.Name = "txt_Estado";
            this.txt_Estado.Size = new System.Drawing.Size(255, 26);
            this.txt_Estado.TabIndex = 7;
            this.txt_Estado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_UF
            // 
            this.txt_UF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_UF.Location = new System.Drawing.Point(389, 33);
            this.txt_UF.Name = "txt_UF";
            this.txt_UF.Size = new System.Drawing.Size(106, 26);
            this.txt_UF.TabIndex = 8;
            this.txt_UF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Letras_KeyPress);
            // 
            // txt_Pais
            // 
            this.txt_Pais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Pais.Location = new System.Drawing.Point(117, 92);
            this.txt_Pais.Name = "txt_Pais";
            this.txt_Pais.Size = new System.Drawing.Size(254, 26);
            this.txt_Pais.TabIndex = 9;
            // 
            // btn_Buscar
            // 
            this.btn_Buscar.BackColor = System.Drawing.Color.Gold;
            this.btn_Buscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Buscar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Buscar.Location = new System.Drawing.Point(389, 89);
            this.btn_Buscar.Name = "btn_Buscar";
            this.btn_Buscar.Size = new System.Drawing.Size(75, 26);
            this.btn_Buscar.TabIndex = 10;
            this.btn_Buscar.Text = "Buscar";
            this.btn_Buscar.UseVisualStyleBackColor = false;
            this.btn_Buscar.Click += new System.EventHandler(this.btn_Buscar_Click);
            // 
            // lbl_CodPais
            // 
            this.lbl_CodPais.AutoSize = true;
            this.lbl_CodPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodPais.ForeColor = System.Drawing.Color.Gold;
            this.lbl_CodPais.Location = new System.Drawing.Point(6, 65);
            this.lbl_CodPais.Name = "lbl_CodPais";
            this.lbl_CodPais.Size = new System.Drawing.Size(90, 24);
            this.lbl_CodPais.TabIndex = 11;
            this.lbl_CodPais.Text = "Cód. País";
            // 
            // txt_CodPais
            // 
            this.txt_CodPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CodPais.Location = new System.Drawing.Point(9, 92);
            this.txt_CodPais.Name = "txt_CodPais";
            this.txt_CodPais.Size = new System.Drawing.Size(87, 26);
            this.txt_CodPais.TabIndex = 12;
            this.txt_CodPais.Text = "0";
            this.txt_CodPais.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_CodPais.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Numeros_KeyPress);
            // 
            // FrmCadEstado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(507, 172);
            this.Controls.Add(this.txt_CodPais);
            this.Controls.Add(this.lbl_CodPais);
            this.Controls.Add(this.btn_Buscar);
            this.Controls.Add(this.txt_Pais);
            this.Controls.Add(this.txt_UF);
            this.Controls.Add(this.txt_Estado);
            this.Controls.Add(this.lbl_Pais);
            this.Controls.Add(this.lbl_UF);
            this.Controls.Add(this.lbl_Estado);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FrmCadEstado";
            this.Text = "Cadastro de Estado";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.lbl_Estado, 0);
            this.Controls.SetChildIndex(this.lbl_UF, 0);
            this.Controls.SetChildIndex(this.lbl_Pais, 0);
            this.Controls.SetChildIndex(this.txt_Estado, 0);
            this.Controls.SetChildIndex(this.txt_UF, 0);
            this.Controls.SetChildIndex(this.txt_Pais, 0);
            this.Controls.SetChildIndex(this.btn_Buscar, 0);
            this.Controls.SetChildIndex(this.lbl_CodPais, 0);
            this.Controls.SetChildIndex(this.txt_CodPais, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_Buscar;
        public System.Windows.Forms.Label lbl_Estado;
        public System.Windows.Forms.Label lbl_UF;
        public System.Windows.Forms.Label lbl_Pais;
        public System.Windows.Forms.TextBox txt_Estado;
        public System.Windows.Forms.TextBox txt_UF;
        public System.Windows.Forms.TextBox txt_Pais;
        private System.Windows.Forms.Label lbl_CodPais;
        public System.Windows.Forms.TextBox txt_CodPais;
    }
}
