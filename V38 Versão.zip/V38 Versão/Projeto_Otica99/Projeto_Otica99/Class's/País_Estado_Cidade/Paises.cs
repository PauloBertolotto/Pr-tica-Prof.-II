﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    public class Paises : Pai
    {
        protected string _pais;
        protected string _sigla;
        protected string _ddi;
        protected string _ativo;

        public Paises() : base()
        {
            _pais = "";
            _sigla = "";
            _ddi = "";
            _ativo = "";
        }

        public Paises(int id, string ddi, string pais, string sigla, string ativo, DateTime dataUltAlteracao, DateTime dataCriacao) : base(id, dataCriacao, dataUltAlteracao)
        {
            Ddi = ddi;
            Pais = pais;
            Sigla = sigla;
            Ativo = ativo;
        }

        public string Ddi
        {
            get => _ddi;
            set => _ddi = value;
        }

        public string Pais
        {
            get => _pais;
            set => _pais = value;
        }

        public string Sigla
        {
            get => _sigla;
            set => _sigla = value;
        }
        public string Ativo
        {
            get => _ativo;
            set => _ativo = value;
        }
    }
}
