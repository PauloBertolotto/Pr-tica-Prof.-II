﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    public class Estados : Pai
    {
        protected string _estado;
        protected string _uf;
        protected Paises _paisID;
        protected string _ativo;
        public Estados() : base()
        {
            ID      = 0;
            _estado = "";
            _uf     = "";
            _paisID = new Paises();
            _ativo = "";
        }

        public Estados(int id, string estado, string uf, Paises paisID, string ativo, DateTime dataultAlteracao, DateTime dataCriacao) : base(id, dataCriacao, dataultAlteracao)
        {
            this.ID = id;
            Estado = estado;
            UF = uf;
            Ativo = ativo;
        }
        public Paises PaisID
        {
            get => _paisID;
            set => _paisID = value;
        }
        public string Estado
        {
            get => _estado;
            set => _estado = value;
        }

        public string UF
        {
            get => _uf;
            set => _uf = value;
        }
        public string Ativo
        {
            get => _ativo;
            set => _ativo = value;
        }
    }
}
