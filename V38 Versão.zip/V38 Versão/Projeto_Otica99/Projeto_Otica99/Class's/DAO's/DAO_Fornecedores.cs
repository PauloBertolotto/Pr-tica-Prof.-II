﻿
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Fornecedores : DAO
    {
        DB oDB;
        Verificacao verificacao;
        public DAO_Fornecedores() 
        {
            oDB = new DB();
            verificacao = new Verificacao();
        }
        public override string CarregaObj(object obj)
        {
            DadosCadastro oFornecedor = (DadosCadastro)obj;
            string ok = "";

            try
            {
                string sql = "select * from Fornecedor where ID_Fornecedor = '" + Convert.ToString(oFornecedor.ID) + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    oFornecedor.ID                      = Convert.ToInt32(dr.GetValue(0));
                    oFornecedor.CidadeID.ID             = Convert.ToInt32(dr.GetValue(1));
                
                    oFornecedor.NomeOuRSocial           = dr.GetString(2);
                    oFornecedor.SobrenomeOuNomeFantasia = dr.GetString(3);
                    oFornecedor.Endereco                = dr.GetString(4);
                    oFornecedor.Complemento             = dr.GetString(5);
                    oFornecedor.Numero                  = dr.GetString(6);
                    oFornecedor.Bairro                  = dr.GetString(7);
                    oFornecedor.CEP                     = dr.GetString(8);
                    oFornecedor.Telefone                = dr.GetString(9);
                    oFornecedor.Email                   = dr.GetString(10);
                    oFornecedor.CPFouCNPJ               = dr.GetString(11);
                    oFornecedor.RGouIE                  = dr.GetString(12);
                    oFornecedor.Sexo                    = dr.GetString(13);
                    oFornecedor.Ativo                   = dr.GetString(14);
                                                        
                    oFornecedor.DataCriacao             = dr.GetDateTime(15);
                    oFornecedor.DataUltimaAlteracao     = dr.GetDateTime(16);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        public override string Salvar(object obj)
        {
            DadosCadastro oFornecedor = (DadosCadastro)obj;
            string ok = "";
            char op = 'I';
            string sql = "INSERT INTO Fornecedor (CidadeID, id_condicao_pagamento, NomeOuRSocial, SobrenomeOuNomeFantasia, Endereco, Complemento, Numero, Bairro, CEP, Telefone, Email, CPFouCNPJ, RGouIE, Sexo, Ativo, DataEntrada, DataUltimaAlteracao) " +
        "VALUES (@CidadeID, @id_condicao_pagamento, @NomeOuRSocial, @SobrenomeOuNomeFantasia, @Endereco, @Complemento, @Numero, @Bairro, @CEP, @Telefone, @Email, @CPFouCNPJ, @RGouIE, @Sexo, @Ativo, @DataEntrada, @DataUltimaAlteracao)";
            if (oFornecedor.ID != 0)
            {
                op = 'U';
                sql = "UPDATE Fornecedor SET CidadeID = @CidadeID, id_condicao_pagamento = @id_condicao_pagamento, NomeOuRSocial = @NomeOuRSocial, SobrenomeOuNomeFantasia = @SobrenomeOuNomeFantasia, Endereco = @Endereco, Complemento = @Complemento, Numero = @Numero, Bairro = @Bairro, CEP = @CEP, Telefone = @Telefone, Email = @Email, CPFouCNPJ = @CPFouCNPJ,RGouIE = @RGouIE ,Sexo = @Sexo ,Ativo = @Ativo ,DataUltimaAlteracao = @DataUltimaAlteracao WHERE ID_Fornecedor = @ID_Fornecedor";
            }

            SqlCommand cnn = new SqlCommand();
            cnn.Connection = DB.Abrir();
            cnn.CommandText = sql;
            if (oFornecedor.ID != 0)
            {
                cnn.Parameters.AddWithValue("@ID_Fornecedor",      oFornecedor.ID);
            }                                                   
            cnn.Parameters.AddWithValue("@CidadeID",               oFornecedor.CidadeID.ID);
            cnn.Parameters.AddWithValue("@id_condicao_pagamento",  oFornecedor.condicao_Pagamento.ID);
            cnn.Parameters.AddWithValue("@NomeOuRSocial",          oFornecedor.NomeOuRSocial);
            cnn.Parameters.AddWithValue("@SobrenomeOuNomeFantasia",oFornecedor.SobrenomeOuNomeFantasia);
            cnn.Parameters.AddWithValue("@Endereco",               oFornecedor.Endereco);
            cnn.Parameters.AddWithValue("@Complemento",            oFornecedor.Complemento);
            cnn.Parameters.AddWithValue("@Numero",                 oFornecedor.Numero);
            cnn.Parameters.AddWithValue("@Bairro",                 oFornecedor.Bairro);
            cnn.Parameters.AddWithValue("@CEP",                    oFornecedor.CEP);
            cnn.Parameters.AddWithValue("@Telefone",               oFornecedor.Telefone);
            cnn.Parameters.AddWithValue("@Email",                  oFornecedor.Email);
            cnn.Parameters.AddWithValue("@CPFouCNPJ",              oFornecedor.CPFouCNPJ);
            cnn.Parameters.AddWithValue("@RGouIE",                 oFornecedor.RGouIE);
            cnn.Parameters.AddWithValue("@Sexo",                   oFornecedor.Sexo);
            cnn.Parameters.AddWithValue("@Ativo",                  oFornecedor.Ativo);
                                                                   
            cnn.Parameters.AddWithValue("@DataEntrada",            oFornecedor.DataCriacao);
            cnn.Parameters.AddWithValue("@DataUltimaAlteracao",    oFornecedor.DataUltimaAlteracao);

            cnn.ExecuteNonQuery();

            cnn.Connection.Close();

            return ok;
        }
        public List<DadosCadastro> PesquisarFornecedoresPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<DadosCadastro> fornecedoresEncontrados = new List<DadosCadastro>();

            try
            {
                string query = string.Empty;
                SqlParameter parametro = new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%");

                // Verificando o critério de pesquisa
                if (criterio == "ID")
                {
                    query = "SELECT * FROM Fornecedor WHERE ID_Fornecedor LIKE @ValorPesquisa";
                }
                else if (criterio == "NOME")
                {
                    query = "SELECT * FROM Fornecedor WHERE SobrenomeOuNomeFantasia LIKE @ValorPesquisa";
                }
                else if (criterio == "CPF")
                {
                    query = "SELECT * FROM Fornecedor WHERE CPFouCNPJ LIKE @ValorPesquisa";
                }
                //else if (criterio == "CIDADE")
                //{
                //    query = "SELECT f.* FROM Fornecedor f JOIN Cidade cid ON f.ID_Cidade = cid.CidadeID WHERE cid.nome LIKE @ValorPesquisa";
                //}
                else if (criterio == "STATUS")
                {
                    query = "SELECT * FROM Fornecedor WHERE Ativo LIKE @Ativo";
                }

                if (!string.IsNullOrEmpty(status))
                {
                    if (!string.IsNullOrEmpty(query))
                    {
                        query += " AND Ativo = @Status";
                    }
                    else
                    {
                        query = "SELECT * FROM Fornecedor WHERE Ativo = @Status";
                    }
                }

                // Executar a consulta e preencher a lista de fornecedores encontrados
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro, new SqlParameter("@Status", status) });

                foreach (DataRow row in dataTable.Rows)
                {
                    DadosCadastro fornecedor = CreateFornecedorFromDataRow(row);
                    fornecedoresEncontrados.Add(fornecedor);
                }
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar fornecedores", ex);
                return null;
            }

            return fornecedoresEncontrados;
        }

        public override string Excluir(string item)
        {           
            string ok = "";
            
            try
            {
                string sql = "UPDATE Fornecedor SET Ativo = 'I' WHERE ID_Fornecedor = '" + item + "'";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                cnn.Connection.Close();
                ok = "Excluido!";
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }
        
        public int BuscarIDCidade(string nome)
        {
            int IDCidade = 0;
            try
            {
                string sql = "select ID_Cidade from Cidade where Nome = @Nome";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.Parameters.AddWithValue("@Nome", nome);
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    IDCidade = Convert.ToInt32(dr.GetValue(0));
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro!");
            }
            finally
            {

            }
            if (IDCidade == 0)
            {
                MessageBox.Show("Cidade não encontrada!");
            }
            return IDCidade;
        }
        public string BuscarCidadePorId(int id)
        {

            string ok = "";
            try
            {
                string sql = "select Nome from Cidade where ID_Cidade = " + id + "";
                SqlCommand cnn = new SqlCommand();
                cnn.Connection = DB.Abrir();
                cnn.CommandType = System.Data.CommandType.Text;
                cnn.CommandText = sql;
                cnn.ExecuteNonQuery();
                var dr = cnn.ExecuteReader();
                while (dr.Read())
                {
                    ok = dr.GetString(0);
                }
                cnn.Connection.Close();
            }
            catch (SqlException ex)
            {
                ok = "Erro";
            }
            finally
            {

            }
            return ok;
        }

        public List<DadosCadastro> ListarFornecedores(string status)
        {
            try
            {
                string sql = "SELECT * FROM Fornecedor";
                List<SqlParameter> parametros = new List<SqlParameter>();

                if (!string.IsNullOrEmpty(status))
                {
                    sql += " WHERE Ativo = @Status";
                    parametros.Add(new SqlParameter("@Status", status));
                }

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros.ToArray());
                return CreateFornecedoresListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao listar fornecedores", ex);
                return new List<DadosCadastro>();
            }
        }

        private List<DadosCadastro> CreateFornecedoresListFromDataTable(DataTable dataTable)
        {
            List<DadosCadastro> fornecedores = new List<DadosCadastro>();

            foreach (DataRow row in dataTable.Rows)
            {
                fornecedores.Add(CreateFornecedorFromDataRow(row));
            }
            return fornecedores;
        }
        public string BuscaUF(string cidade)
        {
            string uf = "";
            try
            {
                string sql = "SELECT e.UF FROM [dbo].[Cidade] c JOIN [dbo].[Estado] e ON c.EstadoID = e.ID_Estado WHERE c.Nome = @Nome";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = DB.Abrir();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@NomeCidade", cidade);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    uf = dr.GetString(0);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                uf = "Erro";
            }
            return uf;
        }
        public DadosCadastro BuscarFornecedorPorNome(string nomeFantasia)
        {
            try
            {
                string query = "SELECT * FROM Fornecedor WHERE NomeOuRSocial LIKE @NomeOuRSocial";
                SqlParameter parametro = new SqlParameter("@NomeOuRSocial", $"%{nomeFantasia}%");
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateFornecedorFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar fornecedor por nome fantasia", ex);
                return null; 
            }
        }
        private DadosCadastro CreateFornecedorFromDataRow(DataRow row)
        {
            Ctrl_CondPagamento aCTLCond = new Ctrl_CondPagamento();
            Ctrl_Cidades aCTLCidades = new Ctrl_Cidades();
            var condicao = aCTLCond.BuscarCondicaoPagamentoPorId(Convert.ToInt32(row["id_condicao_pagamento"]));
            return new DadosCadastro
            {
                ID = Convert.ToInt32(row["ID_Fornecedor"]),
                Ativo = row["Ativo"].ToString(),
                NomeOuRSocial = row["NomeOuRSocial"].ToString(),
                SobrenomeOuNomeFantasia = row["SobrenomeOuNomeFantasia"].ToString(),
                RGouIE = row["RGouIE"].ToString(),
                CPFouCNPJ = row["CPFouCNPJ"].ToString(),
                Email = row["email"].ToString(),
                Telefone = row["telefone"].ToString(),
                CEP = row["cep"].ToString(),
                Endereco = row["endereco"].ToString(),
                Numero = row["numero"].ToString(),
                Complemento = row["complemento"].ToString(),
                Bairro = row["bairro"].ToString(),
                CidadeID = new Cidades { ID = Convert.ToInt32(row["CidadeID"]) },
                DataCriacao = Convert.ToDateTime(row["DataEntrada"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["DataUltimaAlteracao"]),
                condicao_Pagamento = condicao,
            };
        }
        public DadosCadastro BuscarFornecedorPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Fornecedor WHERE ID_Fornecedor = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateFornecedorFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                // Trate exceções genéricas, se aplicável
                verificacao.HandleException("Erro ao buscar fornecedor por ID", ex);
                return null;
            }
        }
    }
}
