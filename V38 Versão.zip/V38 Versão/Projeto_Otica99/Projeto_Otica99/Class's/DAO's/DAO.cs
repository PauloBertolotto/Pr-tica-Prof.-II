﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO
    {
        public DAO() { }
        public virtual string CarregaObj(object obj)
        {
            return "";
        }
        public virtual string Salvar(object obj)
        {
            return "";
        }
        public virtual string Excluir(string item)
        {
            return "";
        }
        public virtual string Desativar(string ativo)
        {
            return "";
        }
    }
}
