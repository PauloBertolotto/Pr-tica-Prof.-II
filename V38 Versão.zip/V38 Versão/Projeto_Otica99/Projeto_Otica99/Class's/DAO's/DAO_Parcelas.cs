﻿using Projeto_Otica99.Class_s.Controller_s;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Class_s.Outros;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Parcelas : DAO
    {
        private DB banco = new DB();
        private Verificacao verificacao = new Verificacao();
        Ctrl_CondPagamento aCTLCondicao;
        Ctrl_FormaPagamento aCTLForma;

        public DAO_Parcelas()
        {
            aCTLCondicao = new Ctrl_CondPagamento();
            aCTLForma = new Ctrl_FormaPagamento();
        }
        public bool SalvarParcelas(Parcelas Obj)
        {
            try
            {
                string Sql = @"insert into Parcelas (ID_Condicao, Num_Parcela, ID_Forma, dias_totais, porcentagem,
            data_criacao, data_ult_alteracao) values (@IdCondicao, @NumParcela, @Id_Forma, @DiasTotais,
                @Porcentagem, @data_criacao, @data_ult_alteracao)";
                SqlParameter[] parametros =
                {
            new SqlParameter("@IdCondicao", Obj.ID),
            new SqlParameter("@NumParcela", Obj.NumParcela),
            new SqlParameter("@ID_Forma", Obj.Forma.ID),
            new SqlParameter("@DiasTotais", Obj.DiasTotais),
            new SqlParameter("@Porcentagem", Obj.Porcentagem),
            new SqlParameter("@data_criacao", Obj.DataCriacao),
            new SqlParameter("@data_ult_alteracao", Obj.DataUltimaAlteracao)
        };

                banco.ExecutarComando(Sql, parametros);
                return true;
            }
            catch (Exception Erro)
            {
                // Logger.Log("Aconteceu o Erro: " + Erro);
                return false;
            }
        }


        public string AdicionarParcela(Parcelas parcela)
        {
            try
            {
                string sql = "INSERT INTO tb_parcelas (id_condicao, num_parcela, id_forma, dias_totais, porcentagem, data_criacao, data_ult_alteracao) " +
                             "VALUES (@IdCondicao, @NumParcela, @IdForma, @DiasTotais, @Porcentagem, @data_criacao, @data_ult_alteracao)";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@IdCondicao",          parcela.Condicao.ID),
                    new SqlParameter("@NumParcela",          parcela.NumParcela),
                    new SqlParameter("@IdForma",             parcela.Forma.ID),
                    new SqlParameter("@DiasTotais",          parcela.DiasTotais),
                    new SqlParameter("@Porcentagem",         parcela.Porcentagem),
                    new SqlParameter("@data_criacao",         parcela.DataCriacao),
                    new SqlParameter("@data_ult_alteracao", parcela.DataUltimaAlteracao)
                };
                banco.ExecutarComando(sql, parametros);

                return "OK";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public bool AtualizarParcela(Parcelas parcela)
        {
            try
            {
                string sql = "UPDATE tb_parcelas SET dias_totais = @DiasTotais, porcentagem = @Porcentagem, " +
                             "data_ult_alteracao = @data_ult_alteracao WHERE id_condicao = @IdCondicao AND num_parcela = @NumParcela AND id_forma = @IdForma";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@DiasTotais", parcela.DiasTotais),
                    new SqlParameter("@Porcentagem", parcela.Porcentagem),
                    new SqlParameter("@data_ult_alteracao", parcela.DataUltimaAlteracao),
                    new SqlParameter("@IdCondicao", parcela.Condicao.ID),
                    new SqlParameter("@NumParcela", parcela.NumParcela),
                    new SqlParameter("@IdForma", parcela.Forma.ID)
                };
                banco.ExecutarComando(sql, parametros);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool ExcluirParcela(int idCondicao, int numParcela, int idForma)
        {
            try
            {
                string sql = "DELETE FROM tb_parcelas WHERE id_condicao = @IdCondicao AND num_parcela = @NumParcela AND id_forma = @IdForma";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@IdCondicao", idCondicao),
                    new SqlParameter("@NumParcela", numParcela),
                    new SqlParameter("@ID_Forma", idForma)
                };
                banco.ExecutarComando(sql, parametros);

                return true;
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao excluir parcela", ex);
                return false;
            }
        }

        public List<Parcelas> ListarParcelas()
        {
            try
            {
                string sql = "SELECT * FROM tb_parcelas";
                DataTable dataTable = banco.ExecutarConsulta(sql, null);
                return CreateParcelasListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao listar parcelas", ex);
                return new List<Parcelas>();
            }
        }
        private Parcelas CreateParcelaFromDataRow(DataRow row)
        {

            CondicaoPagamento condicao = aCTLCondicao.BuscarCondicaoPagamentoPorId(Convert.ToInt32(row["id_condicao"]));
            FormaPagamento forma = aCTLForma.BuscarFormaPagamentoPorId(Convert.ToInt32(row["id_forma"]));

            return new Parcelas
            {
                Condicao = condicao,
                NumParcela = Convert.ToInt32(row["num_parcela"]),
                Forma = forma,
                DiasTotais = Convert.ToInt32(row["dias_totais"]),
                Porcentagem = Convert.ToDecimal(row["porcentagem"]),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["data_ult_alteracao"])
            };
        }
        public Parcelas BuscarParcelaPorId(int idCondicao, int numParcela, int idForma)
        {
            try
            {
                string query = "SELECT * FROM Parcelas WHERE id_condicao = @IdCondicao AND num_parcela = @NumParcela AND id_forma = @IdForma";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@IdCondicao", idCondicao),
                    new SqlParameter("@NumParcela", numParcela),
                    new SqlParameter("@IdForma", idForma)
                };
                DataTable dataTable = banco.ExecutarConsulta(query, parametros);

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateParcelaFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                // Trate exceções
                verificacao.HandleException("Erro ao buscar parcela por ID", ex);
                return null;
            }
        }

        private List<Parcelas> CreateParcelasListFromDataTable(DataTable dataTable)
        {
            List<Parcelas> parcelas = new List<Parcelas>();
            // Para cada linha no DataTable, crie um objeto Parcela e adicione à lista de parcelas
            foreach (DataRow row in dataTable.Rows)
            {
                parcelas.Add(CreateParcelaFromDataRow(row));
            }
            return parcelas;
        }
        public List<Parcelas> BuscarParcelasPorIDCondicao(int idCondicao)
        {
            try
            {
                string query = "SELECT * FROM Parcelas WHERE id_condicao = @IdCondicao";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@IdCondicao", idCondicao)
                };
                DataTable dataTable = banco.ExecutarConsulta(query, parametros);

                return CreateParcelasListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                verificacao.HandleException("Erro ao buscar parcelas por ID de condição", ex);
                return new List<Parcelas>();
            }
        }
    }
}
