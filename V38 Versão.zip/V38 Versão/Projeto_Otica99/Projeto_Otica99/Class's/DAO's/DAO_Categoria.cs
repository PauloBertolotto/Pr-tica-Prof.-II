﻿using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Categoria
    {
        private DB banco = new DB();
        Verificacao operacao = new Verificacao();

        public void AdicionarCategoria(Categoria Categoria)
        {
            try
            {
                string sql = "INSERT INTO Categorias (Nome";
                List<string> colunas = new List<string>() { "@Nome" };
                List<object> valores = new List<object>() { Categoria.Nome };
                

                sql += ") VALUES (" + string.Join(", ", colunas) + ")";
                SqlParameter[] parametros = colunas.Zip(valores, (coluna, valor) => new SqlParameter(coluna, valor)).ToArray();
                banco.ExecutarComando(sql, parametros);
            }
            catch (SqlException ex)
            {
                operacao.HandleException("Erro ao adicionar Categoria", ex);
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao adicionar Categoria", ex);
            }
        }

        public void AtualizarCategoria(Categoria Categoria)
        {
            try
            {
                string sql = "UPDATE Categorias SET Nome = @Nome";
                List<SqlParameter> parametros = new List<SqlParameter>()
                 {
                     new SqlParameter("@Nome", Categoria.Nome),
                     new SqlParameter("@Id", Categoria.ID)
                 };

                sql += " WHERE Id = @Id";

                banco.ExecutarComando(sql, parametros.ToArray());
            }
            catch (SqlException ex)
            {
                operacao.HandleException("Erro ao atualizar Categoria", ex);
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao atualizar Categoria", ex);
            }
        }


        public Categoria BuscarCategoriaPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Categorias WHERE Id = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = banco.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return new Categoria
                    {
                        ID = Convert.ToInt32(row["Id"]),
                        Nome = row["Nome"].ToString(),
                        
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao buscar Categoria por ID", ex);
                return null;
            }
        }
        public List<Categoria> BuscarCategoriaPorNome(string valorPesquisa)
        {
            try
            {
                string query = "SELECT * FROM Categorias WHERE Nome LIKE @ValorPesquisa";
                SqlParameter parametro = new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%");
                DataTable dataTable = banco.ExecutarConsulta(query, new[] { parametro });

                List<Categoria> Categoria = new List<Categoria>();
                foreach (DataRow row in dataTable.Rows)
                {
                    Categoria.Add(new Categoria
                    {
                        ID = Convert.ToInt32(row["Id"]),
                        Nome = row["Nome"].ToString(),
                       
                    });
                }

                return Categoria;
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao buscar Categoria por nome", ex);
                return new List<Categoria>();
            }
        }
        public List<Categoria> ListarCategoria()
        {
            try
            {
                string sql = "SELECT * FROM Categorias ORDER BY Id ASC"; // Ordena os Categoria pelo ID em ordem ascendente
                DataTable dataTable = banco.ExecutarConsulta(sql, null);

                List<Categoria> Categoria = new List<Categoria>();
                foreach (DataRow row in dataTable.Rows)
                {
                    Categoria.Add(new Categoria
                    {
                        ID = Convert.ToInt32(row["Id"]),
                        Nome = row["Nome"].ToString(),
                        
                    });
                }

                return Categoria;
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao listar Categoria", ex);
                return new List<Categoria>();
            }
        }



        public bool ExcluirCategoria(int CategoriaId)
        {
            try
            {
                string sql = "DELETE FROM Categorias WHERE Id = @Id";
                SqlParameter[] parametros = { new SqlParameter("@Id", CategoriaId) };
                banco.ExecutarComando(sql, parametros);
                return true;
            }
            catch (SqlException ex)
            {

                if (operacao.IsForeignKeyViolation(ex))
                {
                    MessageBox.Show("Não foi possível excluir o Categoria selecionado, pois ele está sendo utilizado em outros registros." +
                        " Por favor, remova todas as referências deste Categoria em outros registros antes de tentar excluí-lo novamente.");
                }
                else
                {
                    operacao.HandleException("Erro ao excluir Categoria", ex);
                }
                return false;
            }
        }
    }
}
