﻿using Projeto_Otica99.Class_s.Outros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.DAO_s
{
    internal class DAO_Cargos
    {
        private DB oDB = new DB();
        private Verificacao operacao = new Verificacao();

        public string AdicionarCargo(Cargos cargo)
        {
            try
            {
                string sql = "INSERT INTO Cargos (status_cargo, cargo, data_criacao, data_ult_alteracao) " +
                             "VALUES (@StatusCargo, @Cargo, @DataCriacao, @DataUltimaAlteracao)";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@StatusCargo", cargo.StatusCargo),
                    new SqlParameter("@Cargo", cargo.Cargo),
                    new SqlParameter("@DataCriacao", cargo.DataCriacao),
                    new SqlParameter("@DataUltimaAlteracao", cargo.DataUltimaAlteracao)
                };
                var result = oDB.ExecutarComando(sql, parametros);
                if (result)
                    return "OK";
                else
                {
                    return "NOT";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public string AtualizarCargo(Cargos cargo)
        {
            try
            {
                string sql = "UPDATE tb_cargos SET status_cargo = @StatusCargo, cargo = @Cargo, " +
                             "data_ult_alteracao = @DataUltimaAlteracao WHERE id_cargo = @Id";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@StatusCargo", cargo.StatusCargo),
                    new SqlParameter("@Cargo", cargo.Cargo),
                    new SqlParameter("@DataUltimaAlteracao", cargo.DataUltimaAlteracao),
                    new SqlParameter("@Id", cargo.ID)
                };
                oDB.ExecutarComando(sql, parametros);
                return "OK";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public bool ExcluirCargo(int cargoId)
        {
            try
            {
                string sql = "DELETE FROM Cargos WHERE id_cargo = @Id";
                SqlParameter parametro = new SqlParameter("@Id", cargoId);
                oDB.ExecutarComando(sql, new[] { parametro });
                return true;
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao excluir cargo", ex);
                return false;
            }
        }

        public Cargos BuscarCargoPorId(int id)
        {
            try
            {
                string query = "SELECT * FROM Cargos WHERE id_cargo = @Id";
                SqlParameter parametro = new SqlParameter("@Id", id);
                DataTable dataTable = oDB.ExecutarConsulta(query, new[] { parametro });

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    return CreateCargoFromDataRow(row);
                }

                return null;
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao buscar cargo por ID", ex);
                return null;
            }
        }

        public List<Cargos> ListarCargos(string status)
        {
            try
            {
                if (status != "I" && status != "A")
                {
                    throw new ArgumentException("Status deve ser 'I' ou 'A'");
                }

                string sql = "SELECT * FROM Cargos WHERE status_cargo = @status";
                SqlParameter[] parametros = new SqlParameter[]
                {
            new SqlParameter("@status", SqlDbType.Char) { Value = status }
                };

                DataTable dataTable = oDB.ExecutarConsulta(sql, parametros);
                return CreateCargosListFromDataTable(dataTable);
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao listar cargos", ex);
                return new List<Cargos>();
            }
        }


        private Cargos CreateCargoFromDataRow(DataRow row)
        {
            return new Cargos
            {
                ID = Convert.ToInt32(row["id_cargo"]),
                StatusCargo = row["status_cargo"].ToString(),
                Cargo = row["cargo"].ToString(),
                DataCriacao = Convert.ToDateTime(row["data_criacao"]),
                DataUltimaAlteracao = Convert.ToDateTime(row["data_ult_alteracao"])
            };
        }

        private List<Cargos> CreateCargosListFromDataTable(DataTable dataTable)
        {
            List<Cargos> cargos = new List<Cargos>();
            foreach (DataRow row in dataTable.Rows)
            {
                cargos.Add(CreateCargoFromDataRow(row));
            }
            return cargos;
        }

        public List<Cargos> PesquisarCargosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Cargos> cargosEncontrados = new List<Cargos>();

            try
            {
                string query = string.Empty;
                SqlParameter parametro = new SqlParameter("@ValorPesquisa", "%" + valorPesquisa + "%");
                SqlParameter parametroStatus = new SqlParameter("@Status", status);

                if (criterio == "ID")
                {
                    query = "SELECT * FROM Cargos WHERE id_cargo LIKE @ValorPesquisa";
                }
                else if (criterio == "CARGO")
                {
                    query = "SELECT * FROM Cargos WHERE cargo LIKE @ValorPesquisa";
                }

                if (!string.IsNullOrEmpty(status))
                {
                    if (!string.IsNullOrEmpty(query))
                    {
                        query += " AND status_cargo = @Status";
                    }
                    else
                    {
                        query = "SELECT * FROM Cargos WHERE status_cargo = @Status";
                    }
                }

                DataTable dataTable;
                if (!string.IsNullOrEmpty(query))
                {
                    dataTable = oDB.ExecutarConsulta(query, new[] { parametro, parametroStatus });
                }
                else
                {
                    dataTable = oDB.ExecutarConsulta("SELECT * FROM Cargos WHERE status_cargo = @Status", new[] { parametroStatus });
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    Cargos cargo = CreateCargoFromDataRow(row);
                    cargosEncontrados.Add(cargo);
                }
            }
            catch (Exception ex)
            {
                operacao.HandleException("Erro ao buscar cargos", ex);
                return null;
            }

            return cargosEncontrados;
        }

    }
}
