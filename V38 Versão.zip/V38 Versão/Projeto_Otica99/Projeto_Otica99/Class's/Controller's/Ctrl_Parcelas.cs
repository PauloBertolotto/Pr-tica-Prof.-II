﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Parcelas : Controller
    {
        private Parcelas Parcelas = new Parcelas();
        private DAO_Parcelas parcelasDAO = new DAO_Parcelas();

        public string AdicionarParcela(Parcelas parcela)
        {
            return parcelasDAO.AdicionarParcela(parcela);
        }

        public bool AtualizarParcela(Parcelas parcela)
        {
            return parcelasDAO.AtualizarParcela(parcela);
        }

        public bool ExcluirParcela(int idCondicao, int numParcela, int idForma)
        {
            return parcelasDAO.ExcluirParcela(idCondicao, numParcela, idForma);
        }

        public List<Parcelas> ListarParcelas()
        {
            return parcelasDAO.ListarParcelas();
        }
        public Parcelas BuscarParcelaPorId(int idCondicao, int numParcela, int idForma)
        {
            return parcelasDAO.BuscarParcelaPorId(idCondicao, numParcela, idForma);
        }
        public bool SalvarParcelas(Parcelas parcelas)
        {
            Parcelas = parcelas;
            return parcelasDAO.SalvarParcelas(parcelas);
        }
        public List<Parcelas> BuscarParcelasPorIDCondicao(int idCondicao)
        {
            return parcelasDAO.BuscarParcelasPorIDCondicao(idCondicao);
        }
    }
}
