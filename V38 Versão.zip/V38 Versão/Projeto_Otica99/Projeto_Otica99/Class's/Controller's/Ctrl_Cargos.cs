﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Cargos
    {
        private DAO_Cargos cargosDAO = new DAO_Cargos();

        public string AdicionarCargo(Cargos cargo)
        {
            return cargosDAO.AdicionarCargo(cargo);
        }

        public string AtualizarCargo(Cargos cargo)
        {
            return cargosDAO.AtualizarCargo(cargo);
        }

        public bool ExcluirCargo(int cargoId)
        {
            return cargosDAO.ExcluirCargo(cargoId);
        }

        public Cargos BuscarCargoPorId(int id)
        {
            return cargosDAO.BuscarCargoPorId(id);
        }

        public List<Cargos> ListarCargos(string status)
        {
            return cargosDAO.ListarCargos(status);
        }

        public List<Cargos> PesquisarCargosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            return cargosDAO.PesquisarCargosPorCriterio(criterio, valorPesquisa, status);
        }

        public void Incluir()
        {
            FrmCadCargo frmCadastroCargo = new FrmCadCargo();
            frmCadastroCargo.Text = "Incluir Cargo";
            frmCadastroCargo.CB_Status.Text = "ATIVO";
            frmCadastroCargo.CB_Status.Enabled = false;
            frmCadastroCargo.btn_Salvar.Text = "Salvar dados";
            frmCadastroCargo.ShowDialog();
        }

        public void Alterar(Cargos cargo)
        {
            if (cargo != null)
            {
                FrmCadCargo frmCadastroCargo = new FrmCadCargo();
                frmCadastroCargo.ConhecaObj(cargo);
                frmCadastroCargo.Text = "Alterar Cargo";
                frmCadastroCargo.btn_Salvar.Text = "Alterar";
                frmCadastroCargo.btn_Salvar.BackColor = Color.BurlyWood;
                frmCadastroCargo.CarregarEdit();
                frmCadastroCargo.btn_Salvar.Text =  "Alterar dados.";
                frmCadastroCargo.ShowDialog();
            }
        }

        public void Excluir(Cargos cargo)
        {
            if (cargo != null)
            {
                FrmCadCargo frmCadastroCargo = new FrmCadCargo();
                frmCadastroCargo.ConhecaObj(cargo);
                frmCadastroCargo.Text = "Excluir Cargo";
                frmCadastroCargo.btn_Salvar.Text = "EXCLUIR";
                frmCadastroCargo.btn_Salvar.Text =  "Excluir Cargo";
                frmCadastroCargo.btn_Salvar.ForeColor = Color.White;
                frmCadastroCargo.btn_Salvar.BackColor = Color.DarkRed;
                frmCadastroCargo.CarregarEdit();
                frmCadastroCargo.BloquearEdit();

                frmCadastroCargo.ShowDialog();
            }
        }

        public void Visualizar(Cargos cargo)
        {
            if (cargo != null)
            {
                FrmCadCargo frmCadastroCargo = new FrmCadCargo();
                frmCadastroCargo.ConhecaObj(cargo);
                frmCadastroCargo.Text = "Consultar Cargo";
                frmCadastroCargo.CarregarEdit();
                frmCadastroCargo.BloquearEdit();
                frmCadastroCargo.btn_Salvar.Enabled = false;
                frmCadastroCargo.ShowDialog();
            }
        }
    }
}
