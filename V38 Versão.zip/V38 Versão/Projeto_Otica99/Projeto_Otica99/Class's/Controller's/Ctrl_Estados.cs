﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Estados : Controller
    {
        DAO_Estados aDAO_Estados;
        public Ctrl_Estados() 
        {
            aDAO_Estados = new DAO_Estados();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_Estados.CarregaObj(obj);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Estados.Salvar(obj);
        }
        public override string Excluir(string item)
        {
            return aDAO_Estados.Excluir(item);
        }
        public List<Estados> PesquisarEstadosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Estados> Encontrados = aDAO_Estados.PesquisarEstadosPorCriterio(criterio, valorPesquisa, status);
            return Encontrados;
        }
        public List<Estados> ListarEstados(string status)
        {
            return aDAO_Estados.ListarEstados(status);
        }
        public string BuscarPaisPorId(int id)
        {
            return aDAO_Estados.BuscarPaisPorId(id);
        }
        public int BuscarIDPais(string nome)
        {
            return aDAO_Estados.BuscarIDPais(nome);
        }
        public Estados BuscarEstadoPorId(int id)
        {
            return aDAO_Estados.BuscarEstadoPorId(id);
        }
    }
}
