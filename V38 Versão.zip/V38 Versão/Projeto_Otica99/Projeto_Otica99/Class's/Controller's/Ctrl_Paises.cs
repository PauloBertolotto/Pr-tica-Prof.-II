﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Paises : Controller
    {
        DAO_Paises aDAO_Paises;
        public Ctrl_Paises() 
        {
            aDAO_Paises = new DAO_Paises();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_Paises.CarregaObj(obj);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Paises.Salvar(obj);
        }
        public override string Excluir(string item)
        {
            return aDAO_Paises.Excluir(item);
        }
        public List<Paises> Pesquisar(string nome)
        {
            return aDAO_Paises.Pesquisar(nome);
        }
        public List<Paises> ListarPaises()
        {
            return aDAO_Paises.ListarPaises();
        }
        public Paises BuscarPaisPorId(int id)
        {
            return aDAO_Paises.BuscarPaisPorId(id);
        }
    }
}
