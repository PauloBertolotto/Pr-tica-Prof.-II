﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Marca
    {
        private DAO_Marca aDAO_Marca = new DAO_Marca();

        public string AdicionarMarca(Marca marca)
        {
            try
            {
                marca.DataCriacao = DateTime.Now;
                marca.DataUltAlteracao = DateTime.Now;
                aDAO_Marca.AdicionarMarca(marca);
                return "Marca adicionada com sucesso.";
            }
            catch (Exception ex)
            {
                return "Erro ao adicionar marca: " + ex.Message;
            }
        }

        public string AtualizarMarca(Marca marca)
        {
            try
            {
                marca.DataUltAlteracao = DateTime.Now;
                aDAO_Marca.AtualizarMarca(marca);
                return "Marca atualizada com sucesso.";
            }
            catch (Exception ex)
            {
                return "Erro ao atualizar marca: " + ex.Message;
            }
        }

        public bool ExcluirMarca(int marcaId)
        {
            try
            {
                return aDAO_Marca.ExcluirMarca(marcaId);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Marca BuscarMarcaPorId(int id)
        {
            try
            {
                return aDAO_Marca.BuscarMarcaPorId(id);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<Marca> ListarMarcas()
        {
            try
            {
                return aDAO_Marca.ListarMarcas();
            }
            catch (Exception)
            {
                return new List<Marca>();
            }
        }

        public List<Marca> PesquisarMarcasPorCriterio(string criterio, string valorPesquisa)
        {
            try
            {
                return aDAO_Marca.PesquisarMarcasPorCriterio(criterio, valorPesquisa);
            }
            catch (Exception)
            {
                return new List<Marca>();
            }
        }

        public void Incluir()
        {
            FrmCadMarca frmCadastroMarca = new FrmCadMarca();
            frmCadastroMarca.Text = "Incluir Marca";
          
            frmCadastroMarca.ShowDialog();
        }

        public void Alterar(Marca marca)
        {
            if (marca != null)
            {
                FrmCadMarca frmCadastroMarca = new FrmCadMarca();
                frmCadastroMarca.ConhecaObj(marca);
                frmCadastroMarca.Text = "Alterar Marca";
                frmCadastroMarca.btn_Salvar.Text = "Alterar";

                frmCadastroMarca.CarregarEdit();
               
                frmCadastroMarca.ShowDialog();
            }
        }

        public void Excluir(Marca marca)
        {
            if (marca != null)
            {
                FrmCadMarca frmCadastroMarca = new FrmCadMarca();
                frmCadastroMarca.ConhecaObj(marca);
                frmCadastroMarca.Text = "Excluir Marca";
                frmCadastroMarca.btn_Salvar.Text = "Excluir";
                frmCadastroMarca.CarregarEdit();
                frmCadastroMarca.BloquearEdit();
                frmCadastroMarca.ShowDialog();
            }
        }

        public void Visualizar(Marca marca)
        {
            if (marca != null)
            {
                FrmCadMarca frmCadastroMarca = new FrmCadMarca();
                frmCadastroMarca.ConhecaObj(marca);
                frmCadastroMarca.Text = "Consultar Marca";
                frmCadastroMarca.CarregarEdit();
                frmCadastroMarca.BloquearEdit();
                frmCadastroMarca.btn_Salvar.Enabled = false;
                frmCadastroMarca.ShowDialog();
            }
        }
    }
}
