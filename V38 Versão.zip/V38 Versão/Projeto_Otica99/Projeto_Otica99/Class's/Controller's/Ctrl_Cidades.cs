﻿using Projeto_Otica99.Class_s.DAO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Cidades : Controller
    {
        DAO_Cidades aDAO_Cidades;
        public Ctrl_Cidades()
        {
            aDAO_Cidades = new DAO_Cidades();
        }
        public virtual string CarregaObj(int id)
        {
            return aDAO_Cidades.CarregaObj(id);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Cidades.Salvar(obj);
        }
        public override string Excluir(string item)
        {
            return aDAO_Cidades.Excluir(item);
        }
        public List<Cidades> PesquisarCidadesPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Cidades> Encontrados = aDAO_Cidades.PesquisarCidadesPorCriterio(criterio, valorPesquisa, status);
            return Encontrados;
        }
        public List<Cidades> ListarCidades(string status)
        {
            return aDAO_Cidades.ListarCidades(status);
        }
        public string BuscarEstadoPorId(int id)
        {
            return aDAO_Cidades.BuscarEstadoPorId(id);
        }
        public string BuscarUFPorId(int id)
        {
            return aDAO_Cidades.BuscarUFPorId(id);
        }
        public int BuscarIDEstado(string nome)
        {
            return aDAO_Cidades.BuscarIDEstado(nome);
        }
        public Cidades BuscarCidadePorId(int id)
        {
            return aDAO_Cidades.BuscarCidadePorId(id);
        }
    }
}
