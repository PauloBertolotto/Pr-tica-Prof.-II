﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Produtos
    {
        private DAO_Produtos aDAO_Produtos = new DAO_Produtos();


        public bool AdicionarProduto(Produtos produto)
        {
            return aDAO_Produtos.AdicionarProduto(produto);
        }

        public bool AtualizarEstoque(Produtos produto)
        {
            return aDAO_Produtos.AtualizarProdutoEstoque(produto);
        }
        public string AtualizarProduto(Produtos produto)
        {
            return aDAO_Produtos.AtualizarProduto(produto);
        }

        public bool ExcluirProduto(int idProduto)
        {
            return aDAO_Produtos.ExcluirProduto(idProduto);
        }

        public List<Produtos> ListarProdutos(string status)
        {
            return aDAO_Produtos.ListarProdutos(status);
        }

        public Produtos BuscarProdutoPorId(int idProduto)
        {
            return aDAO_Produtos.BuscarProdutoPorId(idProduto);

        }
        public List<Produtos> ListarProdutoPorIDProduto(int id)
        {
            return aDAO_Produtos.ListarProdutoPorIDProduto(id);
        }
        public List<Produtos> PesquisarProdutosPorCriterio(string criterio, string valorPesquisa, string status)
        {
            if (criterio == "ID" && !int.TryParse(valorPesquisa, out _))
            {
                List<Produtos> lista = new List<Produtos>();// lista vazia.
                return lista;
            }
            else
            {
                return aDAO_Produtos.PesquisarProdutosPorCriterio(criterio, valorPesquisa, status);
            }
        }
        public bool AtivarOuDesativarProduto(Produtos produto)
        {
            return aDAO_Produtos.AtivarOuDesativarProdutos(produto);
        }

        public void Incluir()
        {
            FrmCadProdutos frmCadastroProduto = new FrmCadProdutos();
            frmCadastroProduto.Text = "Incluir Produto";
            
            frmCadastroProduto.ShowDialog();
        }

        public void Alterar(Produtos produto)
        {
            if (produto != null)
            {
                FrmCadProdutos frmCadastroProduto = new FrmCadProdutos();
                frmCadastroProduto.ConhecaObj(produto);
                frmCadastroProduto.Text = "Alterar Produto";
                frmCadastroProduto.CarregarEdit();
               
                frmCadastroProduto.ShowDialog();
            }
        }

        public void Excluir(Produtos produto)
        {
            if (produto != null)
            {
                FrmCadProdutos frmCadastroProduto = new FrmCadProdutos();
                frmCadastroProduto.ConhecaObj(produto);
                frmCadastroProduto.Text = "Excluir Produto";
                frmCadastroProduto.btn_Salvar.Text = "Excluir";
                
                frmCadastroProduto.btn_Salvar.ForeColor = Color.White;
                frmCadastroProduto.btn_Salvar.BackColor = Color.DarkRed;
                frmCadastroProduto.CarregarEdit();
                frmCadastroProduto.BloquearEdit();
                frmCadastroProduto.ShowDialog();
            }
        }
        public void Visualizar(Produtos produto)
        {
            if (produto != null)
            {
                FrmCadProdutos frmCadastroProduto = new FrmCadProdutos();
                frmCadastroProduto.ConhecaObj(produto);
                frmCadastroProduto.Text = "Consultar Produto";
                frmCadastroProduto.CarregarEdit();
                frmCadastroProduto.BloquearEdit();
                frmCadastroProduto.btn_Salvar.Enabled = false;
                frmCadastroProduto.ShowDialog();
            }
        }
        public void Desativar(Produtos oProduto)
        {
            {
                if (oProduto != null)
                {
                    FrmCadProdutos frmProdutos = new FrmCadProdutos();
                    frmProdutos.ConhecaObj(oProduto);
                    frmProdutos.Text = "Desativar Condição de Pagamento";

                    if (oProduto.Status == "A")
                        frmProdutos.btn_Salvar.Text = "Desativar";
                    else
                        frmProdutos.btn_Salvar.Text = "Ativar";

                    frmProdutos.btn_Salvar.BackColor = Color.DarkRed;
                    frmProdutos.btn_Salvar.ForeColor = Color.White;
                    frmProdutos.CarregarEdit();
                    frmProdutos.BloquearEdit();
                    frmProdutos.ShowDialog();
                }
            }


        }
    }
}
