﻿using Projeto_Otica99.Class_s.DAO_s;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Clientes : Controller
    {
        DAO_Clientes aDAO_Clientes;
        public Ctrl_Clientes() 
        {
            aDAO_Clientes = new DAO_Clientes();
        }
        public override string CarregaObj(object obj)
        {
            return aDAO_Clientes.CarregaObj(obj);
        }
        public override string Salvar(object obj)
        {
            return aDAO_Clientes.Salvar(obj);
        }

        public int BuscarIDCidade(string nome)
        {
            return aDAO_Clientes.BuscarIDCidade(nome);
        }
        public string BuscarCidadePorId(int id)
        {
            return aDAO_Clientes.BuscarCidadePorId(id);
        }
        public string BuscarUFPorId(int id)
        {
            return aDAO_Clientes.BuscarUFPorId(id);
        }
        public List<DadosCadastro> ListarClientes(string status)
        {
            return aDAO_Clientes.ListarClientes(status);
        }

        public virtual string Excluir(string item)
        {
            return aDAO_Clientes.Excluir(item);
        }
        public string BuscaUF(string cidade)
        {
            return aDAO_Clientes.BuscaUF(cidade);
        }
        public List<DadosCadastro> PesquisarClientesPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<DadosCadastro> Encontrados = aDAO_Clientes.PesquisarClientesPorCriterio(criterio, valorPesquisa, status);
            return Encontrados;
        }
        public DadosCadastro BuscarClientePorId(int id)
        {
            return aDAO_Clientes.BuscarClientePorId(id);
        }

        public DadosCadastro BuscarClientePorDocumento2(string nome)
        {
            return aDAO_Clientes.BuscarClientePorCPFouCNPJ2(nome);
        }
    }
}
