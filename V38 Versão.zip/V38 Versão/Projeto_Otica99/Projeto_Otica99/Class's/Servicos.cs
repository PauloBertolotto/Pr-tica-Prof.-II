﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s
{
    internal class Servicos : Pai
    {
        public string _descricao;
        public string _statusServico;
        public decimal _valor;

        public Servicos() : base()
        {
            _statusServico = "";
            _descricao = "";
            _valor = 0m;
        }
        public Servicos(int id, decimal valor, string descricao, string status, DateTime data_criacao, DateTime data_ult_alteracao) : base(id, data_criacao, data_ult_alteracao)
        {
            Status = status;
            Descricao = descricao;
            Valor = valor;
        }
        public string Descricao
        {
            get { return _descricao; }
            set { _descricao = value; }
        }
        public decimal Valor
        {
            get { return _valor; }
            set { _valor = value; }
        }

        public string Status
        {
            get { return _statusServico; }
            set { _statusServico = value; }
        }
    }
}
