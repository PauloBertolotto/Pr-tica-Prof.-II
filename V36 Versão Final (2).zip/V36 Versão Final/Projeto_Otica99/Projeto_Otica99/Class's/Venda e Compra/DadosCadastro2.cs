﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Venda_e_Compra
{
    public class DadosCadastro2 : Pai
    {
        protected Cidades _CidadeID;
        private   CondicaoPagamento _condicaoPagamento;

        protected string _NomeOuRSocial;
        protected string _SobrenomeOuNomeFantasia;

        protected string _Endereco;
        protected string _Complemento;
        protected string _Numero;
        protected string _Bairro;
        protected string _CEP;
        protected string _Telefone;
        protected string _Email;

        protected string _CPFouCNPJ;

        protected string _RGouIE;

        protected string _Sexo;
        protected string _DataNasc;

        private Cargos   _CargoID;

        protected string _Ativo;

        public DadosCadastro2() : base()
        {

            _CidadeID = new Cidades();
            _condicaoPagamento = new CondicaoPagamento();

            _NomeOuRSocial = "";

            _SobrenomeOuNomeFantasia = "";

            _Endereco = "";
            _Complemento = "";
            _Numero = "";
            _Bairro = "";
            _CEP = "";
            _Telefone = "";
            _Email = "";

            _CPFouCNPJ = "";

            _RGouIE = "";

            _Sexo = "";
            _DataNasc = "";

            _CargoID = new Cargos();

            _Ativo = "";


        }

        public DadosCadastro2(int id, CondicaoPagamento condicaoPagamento, Cidades cidadeID, string nomeOuRSocial, string sobrenomeOuNomeFantasia, string endereco, string complemento, string numero, string bairro, string cep, string telefone, string rGouIE, string cPFouCNPJ, string email, string ativo, Cargos cargoID, string sexo, string dataNasc, DateTime dataCriacao, DateTime dataUltAlteracao) : base(id, dataCriacao, dataUltAlteracao)
        {
            condicao_Pagamento = condicaoPagamento;
            NomeOuRSocial = nomeOuRSocial;
            SobrenomeOuNomeFantasia = sobrenomeOuNomeFantasia;
            Endereco = endereco;
            Complemento = complemento;
            Numero = numero;
            Bairro = bairro;
            CEP = cep;
            Telefone = telefone;
            Email = email;
            CPFouCNPJ = cPFouCNPJ;
            RGouIE = rGouIE;
            Sexo = sexo;
            DataNasc = dataNasc;           
            Ativo = ativo;
        }

        public Cidades CidadeID
        {
            get => _CidadeID;
            set => _CidadeID = value;
        }
        public CondicaoPagamento condicao_Pagamento
        {
            get => _condicaoPagamento;
            set => _condicaoPagamento = value;
        }
        public string NomeOuRSocial
        {
            get => _NomeOuRSocial;
            set => _NomeOuRSocial = value;
        }
        public string SobrenomeOuNomeFantasia
        {
            get => _SobrenomeOuNomeFantasia;
            set => _SobrenomeOuNomeFantasia = value;
        }
        public string Endereco
        {
            get => _Endereco;
            set => _Endereco = value;
        }
        public string Complemento
        {
            get => _Complemento;
            set => _Complemento = value;
        }
        public string Numero
        {
            get => _Numero;
            set => _Numero = value;
        }
        public string Bairro
        {
            get => _Bairro;
            set => _Bairro = value;
        }
        public string CEP
        {
            get => _CEP;
            set => _CEP = value;
        }
        public string Telefone
        {
            get => _Telefone;
            set => _Telefone = value;
        }
        public string Email
        {
            get => _Email;
            set => _Email = value;
        }
        public string CPFouCNPJ
        {
            get => _CPFouCNPJ;
            set => _CPFouCNPJ = value;
        }
        public string RGouIE
        {
            get => _RGouIE;
            set => _RGouIE = value;
        }

        public string Sexo
        {
            get => _Sexo;
            set => _Sexo = value;
        }
        public string DataNasc
        {
            get => _DataNasc;
            set => _DataNasc = value;
        }
        public Cargos CargoID
        {
            get => _CargoID;
            set => _CargoID = value;
        }
        public string Ativo
        {
            get => _Ativo;
            set => _Ativo = value;
        }
    }
}
