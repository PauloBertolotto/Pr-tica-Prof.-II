﻿using Projeto_Otica99.Class_s.DAO_s;
using Projeto_Otica99.Form_s.Cadastros;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Otica99.Class_s.Controller_s
{
    internal class Ctrl_Categoria
    {
        private DAO_Categoria aDAO_Categoria = new DAO_Categoria();

        public void AdicionarCategoria(Categoria Categoria)
        {
            aDAO_Categoria.AdicionarCategoria(Categoria);
        }

        public void AtualizarCategoria(Categoria Categoria)
        {
            aDAO_Categoria.AtualizarCategoria(Categoria);
        }

        public void ExcluirCategoria(int CategoriaId)
        {
            aDAO_Categoria.ExcluirCategoria(CategoriaId);
        }

        public Categoria BuscarCategoriaPorId(int id)
        {
            return aDAO_Categoria.BuscarCategoriaPorId(id);
        }
        public List<Categoria> ListarCategoria()
        {
            return aDAO_Categoria.ListarCategoria();
        }

        public void Incluir()
        {
            FrmCadCategoria frmCadastroCategoria = new FrmCadCategoria();
            frmCadastroCategoria.Text = "Incluir Categoria";
           
            frmCadastroCategoria.ShowDialog();
        }

        public void Alterar(Categoria Categoria)
        {
            if (Categoria != null)
            {
                FrmCadCategoria frmCadastroCategoria = new FrmCadCategoria();
                frmCadastroCategoria.ConhecaObj(Categoria);
                frmCadastroCategoria.Text = "Alterar Categoria";
                frmCadastroCategoria.btn_Salvar.Text = "Alterar";

                frmCadastroCategoria.CarregarEdit();
            
                frmCadastroCategoria.ShowDialog();
            }
        }

        public void Excluir(Categoria Categoria)
        {
            if (Categoria != null)
            {
                FrmCadCategoria frmCadastroCategoria = new FrmCadCategoria();
                frmCadastroCategoria.ConhecaObj(Categoria);
                frmCadastroCategoria.CarregarEdit();
                frmCadastroCategoria.BloquearEdit();
                frmCadastroCategoria.btn_Salvar.Text = "Excluir";
                frmCadastroCategoria.ShowDialog();
            }
        }

        public void Visualizar(Categoria Categoria)
        {
            if (Categoria != null)
            {
                FrmCadCategoria frmCadastroCategoria = new FrmCadCategoria();
                frmCadastroCategoria.ConhecaObj(Categoria);
                frmCadastroCategoria.CarregarEdit();
                frmCadastroCategoria.BloquearEdit();
                frmCadastroCategoria.btn_Salvar.Enabled = false;
                frmCadastroCategoria.Text = "Consultar Categoria";
                frmCadastroCategoria.ShowDialog();
            }
        }

        public List<Categoria> PesquisarCategoriaPorCriterio(string criterio, string valorPesquisa)
        {
            List<Categoria> CategoriaEncontrados = new List<Categoria>();

            if (criterio == "ID")
            {
                // Pesquisar por ID
                if (int.TryParse(valorPesquisa, out int id))
                {
                    Categoria Categoria = BuscarCategoriaPorId(id);
                    if (Categoria != null)
                    {
                        CategoriaEncontrados.Add(Categoria);
                    }
                }
            }
            else if (criterio == "Categoria")
            {
                CategoriaEncontrados = aDAO_Categoria.BuscarCategoriaPorNome(valorPesquisa);
            }

            return CategoriaEncontrados;
        }
    }
}
