﻿namespace Projeto_Otica99.Form_s.Cadastros
{
    partial class FrmCadCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbNumero = new System.Windows.Forms.Label();
            this.txt_Categoria = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(183, 58);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Size = new System.Drawing.Size(76, 26);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(263, 58);
            // 
            // lbNumero
            // 
            this.lbNumero.AutoSize = true;
            this.lbNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumero.ForeColor = System.Drawing.Color.Gold;
            this.lbNumero.Location = new System.Drawing.Point(89, 7);
            this.lbNumero.Name = "lbNumero";
            this.lbNumero.Size = new System.Drawing.Size(72, 18);
            this.lbNumero.TabIndex = 538;
            this.lbNumero.Text = "Categoria";
            // 
            // txt_Categoria
            // 
            this.txt_Categoria.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_Categoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txt_Categoria.Location = new System.Drawing.Point(92, 26);
            this.txt_Categoria.MaxLength = 20;
            this.txt_Categoria.Name = "txt_Categoria";
            this.txt_Categoria.Size = new System.Drawing.Size(239, 27);
            this.txt_Categoria.TabIndex = 537;
            this.txt_Categoria.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Categoria_KeyDown);
            this.txt_Categoria.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Categoria_KeyPress);
            // 
            // FrmCadCategoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(353, 99);
            this.Controls.Add(this.lbNumero);
            this.Controls.Add(this.txt_Categoria);
            this.Name = "FrmCadCategoria";
            this.Text = "Cadastro de Categoria";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_Salvar, 0);
            this.Controls.SetChildIndex(this.txt_Categoria, 0);
            this.Controls.SetChildIndex(this.lbNumero, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbNumero;
        private System.Windows.Forms.TextBox txt_Categoria;
    }
}
