﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadContasPagar : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        ContasPagar aConta;
        Ctrl_ContasPagar aCTRLConta;
        CultureInfo cultura = CultureInfo.InvariantCulture;
        public FrmCadContasPagar()
        {
            InitializeComponent();
            aConta = new ContasPagar();
            aCTRLConta = new Ctrl_ContasPagar();
        }
        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is ContasPagar conta)
            {
                aConta = conta;
                CarregarEdit();
            }
        }
        protected override void LimparCampos()
        {
            txt_Codigo.Clear();
            txtModelo.Clear();
            txtSerie.Clear();
            txtParcela.Clear();
            txtCodForn.Clear();
            txtCodCondPg.Clear();
            txtCodForma.Clear();
            txtForma.Clear();
            txtFornecedor.Clear();
            txtStatus.Clear();
            txtTaxa.Clear();
            txtMulta.Clear();
            txtDesconto.Clear();
            txtParcela.Clear();
            txtTotalPago.Clear();
            dtVencimento.Value = DateTime.Now;
            dtBaixa.Value = DateTime.Now;
        }
        public override void BloquearEdit()
        {
            base.BloquearEdit();
            txt_Codigo.Enabled = false;
            txtModelo.Enabled = false;
            txtSerie.Enabled = false;
            txtParcela.Enabled = false;
            txtCodForn.Enabled = false;
            txtCodCondPg.Enabled = false;
            txtCodForma.Enabled = false;
            txtForma.Enabled = false;
            txtFornecedor.Enabled = false;
            txtStatus.Enabled = false;
            txtTaxa.Enabled = false;
            txtMulta.Enabled = false;
            txtDesconto.Enabled = false;
            txtTotalPago.Enabled = false;
            dtVencimento.Enabled = false;
            dtBaixa.Enabled = false;
            btn_Salvar.Enabled = false;
        }
        public override void DesbloquearEdit()
        {
            base.DesbloquearEdit();
            txt_Codigo.Enabled = true;
            txtModelo.Enabled = true;
            txtSerie.Enabled = true;
            txtParcela.Enabled = true;
            txtCodForn.Enabled = true;
            txtCodCondPg.Enabled = true;
            txtCodForma.Enabled = true;
            txtForma.Enabled = true;
            txtFornecedor.Enabled = true;
            txtStatus.Enabled = true;
            txtTaxa.Enabled = true;
            txtMulta.Enabled = true;
            txtDesconto.Enabled = true;
            txtTotalPago.Enabled = true;
            dtVencimento.Enabled = true;
            dtBaixa.Enabled = true;
            btn_Salvar.Enabled = true;
        }
        public override void CarregarEdit()
        {
            base.CarregarEdit();

            txt_Codigo.Text = aConta.NumNFC.ToString();
            txtModelo.Text = aConta.ModeloNFC.ToString();
            txtSerie.Text = aConta.SerieNFC.ToString();
            txtParcela.Text = aConta.NumParcela.ToString();
            txtCodForn.Text = aConta.Fornecedor.ID.ToString();
            txtCodCondPg.Text = aConta.Condicao.ID.ToString();
            txtCodForma.Text = aConta.FormaPagamento.ID.ToString();
            txtForma.Text = aConta.FormaPagamento.Forma;
            txtFornecedor.Text = aConta.Fornecedor.NomeOuRSocial;
            txtStatus.Text = aConta.Situacao;
            txtTaxa.Text = aConta.Condicao.Taxa.ToString();
            txtMulta.Text = aConta.Condicao.Multa.ToString();
            txtDesconto.Text = aConta.Condicao.Desconto.ToString();
            txtValorParcela.Text = aConta.Valor.ToString("0.00", cultura);
            dtVencimento.Value = aConta.DataVencimento;
          
            dtBaixa.Value = aConta.DataBaixa != DateTime.MinValue ? aConta.DataBaixa : DateTime.Now;

            txtTotalPago.Text = aConta.Pagamento.ToString("0.00", cultura);
            if (txtStatus.Text == "PAGO")
                BloquearEdit();
        }

        protected bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txtTotalPago.Text) || !decimal.TryParse(txtTotalPago.Text.Replace('.', ','), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal totalPago) || totalPago <= 0)
            {
                camposFaltantes.Add("Valor total pago deve ser um número maior que zero.");
            }
            else
            {

                if (string.IsNullOrWhiteSpace(txtValorParcela.Text) || !decimal.TryParse(txtValorParcela.Text.Replace('.', ','), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal valorParcela) || valorParcela <= 0)
                {
                    camposFaltantes.Add("Valor da parcela deve ser um número maior que zero.");
                }
                else
                {

                    if (totalPago < valorParcela)
                    {
                        DialogResult result = MessageBox.Show(
                            "O valor pago é menor que o valor da parcela. Tem certeza que deseja prosseguir?",
                            "Valor Inferior",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (result == DialogResult.No)
                        {
                            return false;
                        }
                    }
                }

                if (!string.IsNullOrWhiteSpace(txtValorSugerido.Text) && decimal.TryParse(txtValorSugerido.Text.Replace('.', ','), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal valorSugerido) && valorSugerido > 0)
                {
         
                    if (totalPago < valorSugerido)
                    {
                        DialogResult result = MessageBox.Show(
                            "O valor pago é menor que o valor sugerido. Tem certeza que deseja prosseguir?",
                            "Valor Inferior",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (result == DialogResult.No)
                        {
                            return false; 
                        }
                    }
                }
            }

            if (dtBaixa.Value.Date > DateTime.Now.Date)
            {
                camposFaltantes.Add("Data de baixa não pode ser uma data futura.");
            }

          
            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos ou contêm valores inválidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        public override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                aConta.Pagamento = decimal.Parse(txtTotalPago.Text, cultura);
                aConta.DataBaixa = dtBaixa.Value;
                aConta.DataUltAlteracao = DateTime.Now;
                aConta.Situacao = "PAGO";
                var result = aCTRLConta.Quitar(aConta);
                if (result == "OK")
                {
                    MessageBox.Show("Operação realizada com sucesso ");
                    Close();
                }
                else
                    MessageBox.Show("Erro inesperado.");
            }
        }

        private void txtTotalPago_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

        
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

          
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }
        protected virtual void VerificarValor()
        {
            try
            {
              
                CultureInfo cultura = new CultureInfo("pt-BR");
                NumberFormatInfo formato = cultura.NumberFormat;
                formato.NumberDecimalSeparator = ",";
                formato.NumberGroupSeparator = ".";

            
                decimal valorParcela;
                decimal taxaJurosDiaria;
                decimal multaDiaria;
                decimal desconto;

              
                string valorParcelaStr = txtValorParcela.Text.Replace('.', ',');
                string taxaJurosStr = txtTaxa.Text.Replace('.', ',');
                string multaDiariaStr = txtMulta.Text.Replace('.', ',');
                string descontoStr = txtDesconto.Text.Replace('.', ',');

                if (!decimal.TryParse(valorParcelaStr, NumberStyles.Any, formato, out valorParcela))
                {
                    MessageBox.Show("Valor da parcela inválido. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!decimal.TryParse(taxaJurosStr, NumberStyles.Any, formato, out taxaJurosDiaria))
                {
                    MessageBox.Show("Taxa de juros inválida. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!decimal.TryParse(multaDiariaStr, NumberStyles.Any, formato, out multaDiaria))
                {
                    MessageBox.Show("Multa diária inválida. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!decimal.TryParse(descontoStr, NumberStyles.Any, formato, out desconto))
                {
                    MessageBox.Show("Desconto inválido. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

        
                taxaJurosDiaria /= 100;

             
                DateTime dataVencimento = dtVencimento.Value.Date;
                DateTime dataBaixa = dtBaixa.Value.Date;

                decimal totalPago = valorParcela; 

               
                if (dataBaixa > dataVencimento)
                {
                    int diasAtraso = (dataBaixa - dataVencimento).Days;
                    decimal juros = valorParcela * taxaJurosDiaria * diasAtraso;
                    decimal multa = multaDiaria * diasAtraso;

                    totalPago += juros + multa; 
                }
              
                else if (dataBaixa < dataVencimento)
                {
                    decimal descontoAplicado = valorParcela * (desconto / 100);
                    totalPago -= descontoAplicado; 
                }

             
                txtValorSugerido.Text = totalPago.ToString("F2", cultura); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao calcular o valor sugerido: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Verificar_Click(object sender, EventArgs e)
        {
            VerificarValor();
        }
    }
}
