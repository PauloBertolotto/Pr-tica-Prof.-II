﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;
using System.IO;
using System.Data.SqlClient;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadCategoria : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Ctrl_Categoria aCTRLCategoria;
        Categoria aCategoria;
        public string caminhoFoto = "";
        
        public FrmCadCategoria()
        {
            InitializeComponent();
            aCategoria = new Categoria();
            aCTRLCategoria = new Ctrl_Categoria();
            Verificacao.DisableCopyPaste(this);
        }

        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Categoria Produto)
            {
                aCategoria = Produto;
                CarregarEdit();
            }
        }

        public override void BloquearEdit()
        {
            base.BloquearEdit();
            txt_Codigo.Enabled = false;
            txt_Categoria.Enabled = false;
           
        }
        public override void DesbloquearEdit()
        {
            base.DesbloquearEdit();
            txt_Codigo.Enabled = true;
            txt_Categoria.Enabled = true;
           
        }
        public override void CarregarEdit()
        {
            base.CarregarEdit();
            txt_Codigo.Text = aCategoria.ID.ToString();
            txt_Codigo.Text = aCategoria.ID.ToString();
            txt_Categoria.Text = aCategoria.Nome;

            
        }


        public virtual void Verificar()
        {
            if (btn_Salvar.Text == "SALVAR" || btn_Salvar.Text == "ALTERAR")
            {
                Salvar();
            }
            else if (btn_Salvar.Text == "EXCLUIR")
            {
                ConfirmarExclusaaCategoria();
            }
        }

        public override void Salvar()
        {
            if (string.IsNullOrWhiteSpace(txt_Categoria.Text))
            {
                MessageBox.Show("Campo Produto não pode estar vazio.");
                txt_Categoria.Focus();
                return;
            }

            try
            {
                aCategoria.Nome = txt_Categoria.Text;

                if (aCategoria.ID == 0) // Produto de patrimônios
                {
                    aCTRLCategoria.AdicionarCategoria(aCategoria);
                }
                else
                {
                    aCTRLCategoria.AtualizarCategoria(aCategoria);
                }

                Close();
            }
            catch (System.Runtime.InteropServices.ExternalException ex)
            {
                MessageBox.Show("Erro de GDI+: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar os dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ConfirmarExclusaaCategoria()
        {
            DialogResult result = MessageBox.Show("Tem certeza que deseja excluir esta Produto?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ExcluirProduto();
            }
        }
        private void ExcluirProduto()
        {
            if (aCategoria != null)
            {
                try
                {
                    Ctrl_Categoria aCTLCategoria = new Ctrl_Categoria();
                    aCTLCategoria.ExcluirCategoria(aCategoria.ID);
                    Close();
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547)
                    {
                        MessageBox.Show("Não é possível excluir a Produto devido a outros registros estarem vinculados a esta Produto.");
                    }
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir a Produto. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }

        private void txt_Categoria_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarNomes(sender, e);
        }

        private void txt_Categoria_KeyDown(object sender, KeyEventArgs e)
        {
            Verificacao.BloquearKeyDowControlC(sender, e);
        }
    }
}
