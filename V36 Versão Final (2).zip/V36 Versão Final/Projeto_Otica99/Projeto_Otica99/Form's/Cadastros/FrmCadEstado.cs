﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadEstado : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        FrmConPais   aConPais;
        Estados      oEstado;
        FrmConEstado aConEstado;
        Ctrl_Estados aCtrlEstado;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }

        public FrmCadEstado()
        {
            InitializeComponent();
            aConPais    = new FrmConPais();
            oEstado     = new Estados();
            aCtrlEstado = new Ctrl_Estados();
        }
        private void Letras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }
        private void Numeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public void SetConsultaPaises(object obj)
        {
            aConPais = (FrmConPais)obj;
        }
        public override void ConhecaObj(object obj)
        {
            this.oEstado = (Estados)obj;
          //  aCtrlEstado = (Ctrl_Estados)Ctrl;
        }
        public override void CarregarEdit()
        {
            this.txt_Codigo.Text = txt_Codigo.ToString();
            this.txt_Estado.Text = txt_Estado.ToString();
            this.txt_UF.Text     = txt_UF.ToString();
            this.txt_Pais.Text   = txt_Pais.ToString();
        }
        //protected override void AlterarEdit()
        //{ 
        //    base.AlterarEdit();
        //
        //}
        protected override void LimparCampos()
        {
            this.txt_Codigo.Clear();
            this.txt_Estado.Clear();
            this.txt_UF.Clear();
            this.txt_Pais.Clear();
        }
        public override void DesbloquearEdit()
        {
            txt_Codigo.Enabled = true;
            txt_Estado.Enabled = true;
            txt_UF.Enabled     = true;
            txt_Pais.Enabled   = true;
        }
        public override void BloquearEdit()
        {
            txt_Codigo.Enabled = false;
            txt_Estado.Enabled = false;
            txt_UF.Enabled     = false;
            txt_Pais.Enabled   = false;
        }
        public bool CamposPreenchidos()
        {
            bool ok = false;
            if (string.IsNullOrEmpty(txt_Estado.Text) ||
                string.IsNullOrEmpty(txt_UF.Text) ||
                string.IsNullOrEmpty(txt_CodPais.Text)
                )
            {
                MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                ok = true;
            }

            return ok;
        }
        public override void Salvar()
        {
            string Salvo;
            string msg     = "O Cadastro do Estado: " + txt_Estado.Text + " foi realizado com o sucesso!";
            if (CamposPreenchidos())
            {

                oEstado.ID        = Convert.ToInt16(txt_Codigo.Text);
                oEstado.Estado    = txt_Estado.Text;
                oEstado.UF        = txt_UF.Text;
                oEstado.PaisID.ID = Convert.ToInt16(txt_CodPais.Text);
                oEstado.Ativo     = "A";


                if (btn_Salvar.Text == "Alterar")
                {
                    Salvo                       = aCtrlEstado.Salvar(oEstado);
                    oEstado.DataUltimaAlteracao = DateTime.Now;
                    msg                         = "o Cadastro do Estado: " + oEstado.Estado + " foi Alterado com sucesso!";
                    LimparCampos();
                    this.txt_Codigo.Text        = "0";
                }

                Salvo = aCtrlEstado.Salvar(oEstado);
                LimparCampos();
                this.txt_Codigo.Text = "0";          
                MessageBox.Show(msg);
                Close();
            }
        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {

            using (FrmConPais frm = new FrmConPais())
            {
                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                // Agora, defina os valores nos campos do seu formulário de cadastro
                txt_CodPais.Text = IdSelecionado.ToString();
                txt_Pais.Text = NomeSelecionado;
            }
        }
    }
}
