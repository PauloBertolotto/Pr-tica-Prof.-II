﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadCidade : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Cidades      aCidade;
        FrmConEstado aConEstado;
        FrmConCidade aConCidade;
        Ctrl_Cidades aCtrlCidade;

        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        public FrmCadCidade()
        {
            InitializeComponent();
            aConEstado  = new FrmConEstado();
            aCidade     = new Cidades();
            aCtrlCidade = new Ctrl_Cidades();
        }
        private void Letras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }
        private void Numeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public void SetConsultaEstado(object obj)
        {
            aConEstado = (FrmConEstado)obj;
        }
        public override void ConhecaObj(object obj)
        {
            this.aCidade = (Cidades)obj;
          //  aCtrlCidade  = (Ctrl_Cidades)Ctrl;
        }
        public override void CarregarEdit()
        {
            this.txt_Codigo.Text = txt_Codigo.ToString();
            this.txt_Cidade.Text = txt_Cidade.ToString();
            this.txt_DDD.Text    = txt_DDD.ToString();
            this.txt_Estado.Text = txt_Estado.ToString();
        }
        //protected override void AlterarEdit()
        //{ 
        //    base.AlterarEdit();
        //
        //}
        protected override void LimparCampos()
        {
            this.txt_Codigo.Clear();
            this.txt_Cidade.Clear();
            this.txt_DDD.Clear();
            this.txt_Estado.Clear();
        }
        public override void DesbloquearEdit()
        {
            txt_Codigo.Enabled = true;
            txt_Cidade.Enabled = true;
            txt_DDD.Enabled    = true;
            txt_Estado.Enabled = true;
        }
        public override void BloquearEdit()
        {
            txt_Codigo.Enabled = false;
            txt_Cidade.Enabled = false;
            txt_DDD.Enabled    = false;
            txt_Estado.Enabled = false;
        }
        public bool CamposPreenchidos()
        {
            bool ok = false;
            if (string.IsNullOrEmpty(txt_Cidade.Text) ||
                string.IsNullOrEmpty(txt_DDD.Text) ||
                string.IsNullOrEmpty(txt_CodEstado.Text)
                )
            {
                MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                ok = true;
            }

            return ok;
        }
        public override void Salvar()
        {
            string Salvo;
            string msg       = "O Cadastro de Cidade: " + txt_Cidade.Text + " foi realizado com o sucesso!";

            if(CamposPreenchidos()) 
            { 
                aCidade.ID          = Convert.ToInt16(txt_Codigo.Text);
                aCidade.Cidade      = txt_Cidade.Text;
                aCidade.DDD         = txt_DDD.Text;
                aCidade.EstadoID.ID = Convert.ToInt16(txt_CodEstado.Text);
                aCidade.Ativo       = "A";


                if (btn_Salvar.Text == "Alterar")
                {
                    Salvo = aCtrlCidade.Salvar(aCidade);
                    aCidade.DataUltimaAlteracao = DateTime.Now;
                    msg = "o Cadastro de Cidade: " + aCidade.Cidade + " foi Alterado com sucesso!";
                    LimparCampos();
                    this.txt_Codigo.Text = "0";              
                }

                Salvo = aCtrlCidade.Salvar(aCidade);
                LimparCampos();
                this.txt_Codigo.Text = "0";
                MessageBox.Show(msg);
                Close();
            }
        }

        private void btn_Buscar_Click_1(object sender, EventArgs e)
        {
            using (FrmConEstado frm = new FrmConEstado())
            {
                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                // Agora, defina os valores nos campos do seu formulário de cadastro
                txt_CodEstado.Text = IdSelecionado.ToString();
                txt_Estado.Text = NomeSelecionado;
            }
        }
    }
}
