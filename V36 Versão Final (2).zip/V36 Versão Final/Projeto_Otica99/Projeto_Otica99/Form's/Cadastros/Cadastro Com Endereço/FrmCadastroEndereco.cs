﻿using Newtonsoft.Json;
using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço
{
    public partial class FrmCadastroEndereco : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Ctrl_Fornecedores aCtrlFornecedor;

        Verificacao       aVerficacao;
        public int IdSelecionado { get; private set; }
        public string NomeSelecionado { get; private set; }
        public FrmCadastroEndereco()
        {
            InitializeComponent();
            aCtrlFornecedor = new Ctrl_Fornecedores();
            txt_Cidade.Enabled = false;
        }       

        private void btn_BuscarPorCidade_Click(object sender, EventArgs e)
        {
            using (FrmConCidade frm = new FrmConCidade())
            {

                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                // Agora, defina os valores nos campos do seu formulário de cadastro
                txt_CodCidade.Text = IdSelecionado.ToString();
                txt_Cidade.Text = NomeSelecionado;
            }
        }
    }
}
