﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;
using Projeto_Otica99.Form_s.Consultas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projeto_Otica99.Form_s.Cadastros.Cadastro_Pagamento
{
    public partial class FrmCadCondicaoPag : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Ctrl_CondPagamento aCTLCondicaoPG = new Ctrl_CondPagamento();
        
        private int ultimoDias = 30;
        private CondicaoPagamento aCondicao;
        Ctrl_Parcelas aCtrlParcela;
        List<Parcelas> parcelasAtual;
        FrmCadCondicaoPag oCadCondPag;
        public FrmCadCondicaoPag()
        {
            InitializeComponent();
            aCondicao = new CondicaoPagamento();
            aCtrlParcela = new Ctrl_Parcelas();
            parcelasAtual = new List<Parcelas>();
           
        }     
        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is CondicaoPagamento condicao)
            {
                aCondicao = condicao;
            }
        }
        protected override void LimparCampos()
        {
            txt_Condicao.Clear();
            txt_Parcelas.Clear();
            txt_Dias.Clear();
            txt_PercentagemTotal.Clear();
            txt_Taxa.Clear();
            txt_Multa.Clear();
            txt_Desconto.Clear();
            txt_CodForma.Clear();
            txt_FormaPagamento.Clear();
        }
        public override void BloquearEdit()
        {
            base.BloquearEdit();
            txt_Condicao.Enabled         = false;
            txt_Parcelas.Enabled         = false;
            txt_Dias.Enabled             = false;
            txt_PercentagemTotal.Enabled = false;
            txt_Taxa.Enabled             = false;
            txt_Multa.Enabled            = false;
            txt_Desconto.Enabled         = false;
            txt_CodForma.Enabled         = false;
            txt_FormaPagamento.Enabled   = false;
            btn_Adicionar.Enabled        = false;
            btn_Buscar.Enabled           = false;
            txt_Percentagem.Enabled      = false;

        }
        public override void DesbloquearEdit()
        {
            base.DesbloquearEdit();
            txt_Condicao.Enabled         = true;
            txt_Parcelas.Enabled         = true;
            txt_Dias.Enabled             = true;
            txt_PercentagemTotal.Enabled = true;
            txt_Taxa.Enabled             = true;
            txt_Multa.Enabled            = true;
            txt_Desconto.Enabled         = true;
            txt_CodForma.Enabled         = true;
            txt_FormaPagamento.Enabled   = true;
            btn_Adicionar.Enabled        = true;
            btn_Buscar.Enabled           = true;
            txt_Percentagem.Enabled      = true;
        }
        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txt_Parcelas.Text))
            {
                camposFaltantes.Add("Parcelas");
            }
            if (string.IsNullOrWhiteSpace(txt_Taxa.Text))
            {
                camposFaltantes.Add("Taxa");
            }
            if (string.IsNullOrWhiteSpace(txt_Multa.Text))
            {
                camposFaltantes.Add("Multa");
            }
            if (string.IsNullOrWhiteSpace(txt_Desconto.Text))
            {
                camposFaltantes.Add("Desconto");
            }
            if (string.IsNullOrWhiteSpace(txt_Condicao.Text))
            {
                camposFaltantes.Add("Condição de pagamento");
            }
            if (string.IsNullOrWhiteSpace(txt_CodForma.Text))
            {
                camposFaltantes.Add("Codigo de Forma de pagamento");
            }
            if (string.IsNullOrWhiteSpace(txt_PercentagemTotal.Text))
            {
                Console.WriteLine(txt_PercentagemTotal.Text);
                camposFaltantes.Add("Parcelas");
            }
            if (string.IsNullOrWhiteSpace(txt_Dias.Text))
            {
                camposFaltantes.Add("DiasTotais");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos: " + camposFaltantesStr, "Campos em Faltam", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        private void txtCodForma_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_CodForma.Text))
                LimparForma();
            else if (int.TryParse(txt_CodForma.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente
                Ctrl_FormaPagamento aCTLF = new Ctrl_FormaPagamento();
                FormaPagamento forma = aCTLF.BuscarFormaPagamentoPorId(cod);

                if (forma == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparForma();
                }
                else
                {
                    txt_FormaPagamento.Text = forma.Forma;
                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparForma();
            }
            this.AcceptButton = btn_Salvar; // Restaura o botão "Salvar" como botão padrão
        }
        private void LimparForma()
        {
            txt_FormaPagamento.Clear();
            txt_CodForma.Clear();
            //txtParcelas.
        }
        public void Verificar()
        {
            if (btn_Salvar.Text == "SALVAR" || btn_Salvar.Text == "ALTERAR")
            {
                if (dg1.Rows.Count > 0)
                    Salvar();
            }
            else if (btn_Salvar.Text == "EXCLUIR")
            {
                DialogResult resultado = MessageBox.Show("Tem certeza que deseja excluir a condição de pagamento?", "Confirmação de Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resultado == DialogResult.Yes)
                {
                    try
                    {
                        aCondicao.ID = Convert.ToInt32(txt_Codigo.Text);
                        aCTLCondicaoPG.Excluir(aCondicao.ID);
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir a condição de pagamento: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else if (btn_Salvar.Text == "DESATIVAR" || btn_Salvar.Text == "ATIVAR")
            {
                string acao = (btn_Salvar.Text == "DESATIVAR") ? "DESATIVAR" : "ATIVAR";
                string mensagem = $"Tem certeza que deseja {acao} a condição de pagamento?";

                DialogResult resultado = MessageBox.Show(mensagem, $"Confirmação de {acao}", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    try
                    {
                        aCondicao.ID = Convert.ToInt32(txt_Codigo.Text);

                        aCondicao.Status = (aCondicao.Status == "A") ? "I" : "A"; // Se o status atual for "A", o novo status será "I" (inativo); caso contrário, será "A" (ativo)

                        aCTLCondicaoPG.AtivarOuDesativarCondicaoPagamento(aCondicao);
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao {acao} a condição de pagamento: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        
        public override void Salvar()
        {
            base.Salvar();
            if (txt_PercentagemTotal.Text == "100.00")
            {
                if (btn_Salvar.Text == "Salvar")
                {
                    aCondicao.DataCriacao = DateTime.Now;
                    aCondicao.Status = "A";
                    var result = aCTLCondicaoPG.AdicionarCondicaoPagamento(AdicionarGrid());
                    if (result == true)
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    aCondicao.ID = Convert.ToInt32(txt_Codigo.Text);
                    var result = aCTLCondicaoPG.AlterarCondicaoPagamento(AdicionarGrid());               
                }
            }
            else
            {
                MessageBox.Show("Impossível salvar, o percentual não bate com 100%");
            }
        }

        public CondicaoPagamento AdicionarGrid()
        {
            Ctrl_FormaPagamento ControllerForma = new Ctrl_FormaPagamento();
            var pagamento = new CondicaoPagamento();
            List<Parcelas> Lista = new List<Parcelas>();
            Parcelas Parcelas = null;
            pagamento.ID = Convert.ToInt32(txt_Codigo.Text);
            CultureInfo cultura = CultureInfo.InvariantCulture;

            pagamento.Status = "A";
            pagamento.Condicao = Convert.ToString(txt_Condicao.Text);
            pagamento.Multa = decimal.Parse(txt_Multa.Text, cultura);
            pagamento.Taxa = decimal.Parse(txt_Taxa.Text, cultura);
            pagamento.Desconto = decimal.Parse(txt_Desconto.Text, cultura);
            pagamento.DataCriacao = DateTime.Now;
            pagamento.DataUltimaAlteracao = DateTime.Now;
            foreach (DataGridViewRow vLinha in dg1.Rows)
            {
                Parcelas = new Parcelas();
                Parcelas.ID = pagamento.ID;
                Parcelas.NumParcela = Convert.ToInt32(vLinha.Cells["num_parcela"].Value);
                Parcelas.DiasTotais = Convert.ToInt32(vLinha.Cells["dias_totais"].Value);
                Parcelas.Porcentagem = Convert.ToDecimal(vLinha.Cells["percentual"].Value);
                Parcelas.Forma = new FormaPagamento();
                Parcelas.Forma.ID = Convert.ToInt32(vLinha.Cells["idForma"].Value);
                Parcelas.DataCriacao = DateTime.Now;
                Parcelas.DataUltimaAlteracao = DateTime.Now;
                Lista.Add(Parcelas);
            }
            pagamento.uParcelas = Lista;
            pagamento.Parcelas = pagamento.uParcelas.Count();
            return pagamento;
        }
        public void DefinirProximoIdCondicaoPagamento()
        {
            try
            {
                int proximoId = aCTLCondicaoPG.ObterProximoIdCondicaoPagamento();
                txt_Codigo.Text = proximoId.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao definir o próximo ID: {ex.Message}");
            }
        }
        public void Popular(CondicaoPagamento CondicaoPagamento)
        {
            // Formata os valores de preço para exibição correta
            CultureInfo cultura = CultureInfo.InvariantCulture;
            txt_Codigo.Text = CondicaoPagamento.ID.ToString();
            txt_Condicao.Text = CondicaoPagamento.Condicao.ToString();
            txt_Multa.Text = CondicaoPagamento.Multa.ToString("0.00", cultura);
            txt_Desconto.Text = CondicaoPagamento.Desconto.ToString("0.00", cultura);
            txt_Taxa.Text = CondicaoPagamento.Taxa.ToString("0.00", cultura);
            txt_DataCadastro.Text = CondicaoPagamento.DataCriacao.ToShortDateString();
            txt_DataUltAlteracao.Text = CondicaoPagamento.DataUltimaAlteracao.ToShortDateString();
            int idCondicao = Convert.ToInt32(txt_Codigo.Text);
            List<Parcelas> parcelas = aCtrlParcela.BuscarParcelasPorIDCondicao(idCondicao);

            foreach (var Parc in parcelas)
            {
                dg1.Rows.Add(
                    Parc.NumParcela,
                    Parc.DiasTotais,
                    Parc.Forma.ID,
                    Parc.Forma.Forma,
                    Parc.Porcentagem
                );

                // Adiciona a parcela à lista parcelasAtual
                txt_CodForma.Text = Parc.Forma.ID.ToString();
                txt_FormaPagamento.Text = Parc.Forma.Forma;
                parcelasAtual.Add(Parc);
            }
            txt_PercentagemTotal.Text = "100.00";
        }
        public void Add()
        {
            try
            {
                int totalParcelas = dg1.Rows.Count + 1;
                int dias = Convert.ToInt32(txt_Dias.Text);
                decimal percentualTotal = 0;

                // Calcula o percentual total
                foreach (DataGridViewRow row in dg1.Rows)
                {
                    string valorCelula = row.Cells["clmPercentagemTotal"].Value.ToString().Replace(',', '.');
                    percentualTotal += Convert.ToDecimal(valorCelula, CultureInfo.InvariantCulture);
                }

                // Substitui vírgulas por pontos e converte para decimal
                string percentualTexto = txt_Percentagem.Text.Replace(',', '.');
                decimal percentualAtual = Convert.ToDecimal(percentualTexto, CultureInfo.InvariantCulture);

                // Verifica se o percentual atual + o percentual total não ultrapassa 100%
                if (percentualTotal + percentualAtual > 100)
                {
                    MessageBox.Show("A soma do percentual atual com o percentual total ultrapassa 100%.");
                    return;
                }

                // Adiciona a nova linha ao DataGridView
                AddDg(totalParcelas, dias, percentualAtual);

                // Atualiza o valor do txtParcelas e txtDias
                txt_Parcelas.Text = totalParcelas.ToString();
                txt_Dias.Text = (dias + 30).ToString();
                ultimoDias = dias + 30;

                // Atualiza o valor do txtPercentualTotal
                txt_PercentagemTotal.Text = (percentualTotal + percentualAtual).ToString("F2", CultureInfo.InvariantCulture);
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Formato de percentual inválido. Por favor, insira um número válido.");
            }
        }
        public void AddDg(int vLinha, int dias, decimal percentual)
        {
            dg1.Rows.Add(
                vLinha,
                dias,
                txt_CodForma.Text,
                txt_FormaPagamento.Text,
                percentual.ToString());
        }
        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            using (FrmConFormaPagamento frm = new FrmConFormaPagamento())
            {
                frm.btn_Sair.Text = "Selecionar";
                frm.ShowDialog();

                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                // Agora, defina os valores nos campos do seu formulário de cadastro
                txt_CodForma.Text = IdSelecionado.ToString();
                txt_FormaPagamento.Text = NomeSelecionado;
                // Chamando explicitamente o evento Leave de txtCodPais
                txtCodForma_Leave(txt_CodForma, EventArgs.Empty);

            }
        }
        private void RecalcularPercentualTotal()
        {
            decimal percentualTotal = 0;

            // Itera pelas linhas do DataGridView e soma os percentuais
            foreach (DataGridViewRow row in dg1.Rows)
            {
                decimal percentual;
                if (decimal.TryParse(row.Cells["percentual"].Value?.ToString(), out percentual))
                {
                    percentualTotal += percentual;
                }
            }

            // Atualiza o valor de txtPercentualTotal.Text com o novo valor calculado
            txt_PercentagemTotal.Text = percentualTotal.ToString("0.00", CultureInfo.InvariantCulture);
        }
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dg1.SelectedRows.Count > 0)
            {
                DataGridViewRow select = dg1.SelectedRows[0];
                dg1.Rows.Remove(select);
                RecalcularPercentualTotal();
            }
            else
            {
                MessageBox.Show("selecione  para excluir");
            }
        }

        private void btn_Adicionar_Click(object sender, EventArgs e)
        {
            if (VerificarCamposVazios())
            {
                Add();  
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            dg1.Rows.Clear();
            txt_PercentagemTotal.Text = "0";
            txt_Parcelas.Text = "1";
            txt_Dias.Text = "30";
            ultimoDias = 30;
        }

        private void btn_Salvar_Click(object sender, EventArgs e)
        {

        }

        private void txt_Percentagem_KeyPress(object sender, KeyPressEventArgs e)
        {
          Verificacao.ValidarDecimais((System.Windows.Forms.TextBox)sender, e);
     
        }
    }
}
