﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Projeto_Otica99.Class_s.Outros;
using System.Data.SqlClient;

namespace Projeto_Otica99.Form_s.Cadastros
{
    public partial class FrmCadCargo : Projeto_Otica99.Form_s.Cadastros.FrmCadastroPai
    {
        Cargos      oCargo;
        Ctrl_Cargos aCtrl_Cargo;

        public FrmCadCargo()
        {
            InitializeComponent();
            aCtrl_Cargo = new Ctrl_Cargos();
            oCargo = new Cargos()   ;
            Verificacao.DisableCopyPaste(this);
        }

        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Cargos cargo)
            {
                oCargo = cargo;
                CarregarEdit();
            }
        }
        protected override void LimparCampos()
        {
            txt_Codigo.Clear();
            txt_Cargo.Clear();
            CB_Status.SelectedIndex = 0;
        }
        public override void BloquearEdit()
        {
            base.BloquearEdit();
            txt_Cargo.Enabled = false;
            CB_Status.Enabled = false;
        }
        public override void DesbloquearEdit()
        {
            base.DesbloquearEdit();
            txt_Cargo.Enabled = true;
            CB_Status.Enabled = true;
        }
        public override void CarregarEdit()
        {
            base.CarregarEdit();
            txt_Codigo.Text = oCargo.ID.ToString();
            txt_Cargo.Text  = oCargo.Cargo;
            CB_Status.Text  = oCargo.StatusCargo == "I" ? "Inativo" : oCargo.StatusCargo == "A" ? "Ativo" : oCargo.StatusCargo;
        }
        public void Verificar()
        {
            if (btn_Salvar.Text == "Salvar" || btn_Salvar.Text == "Alterar")
                Salvar();
            else if (btn_Salvar.Text == "Excluir")
            {
                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este estado?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    ExcluirCargo();
                }
            }          
        }
        private void ExcluirCargo()
        {
            if (oCargo != null)
            {
                try
                {
                    var result = aCtrl_Cargo.ExcluirCargo(oCargo.ID);
                    if (result)
                        Close();
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir o cargo. Detalhes: " + result);
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547)
                    {
                        MessageBox.Show("Não é possível excluir cargo devido a outros registros estarem vinculados a este cargo.");
                    }
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir o cargo. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }
        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txt_Cargo.Text))
            {
                camposFaltantes.Add("Cargo");
            }
            if (string.IsNullOrWhiteSpace(CB_Status.Text))
            {
                camposFaltantes.Add("Status");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        public override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                oCargo.Cargo = txt_Cargo.Text;
                oCargo.StatusCargo = CB_Status.Text[0].ToString();
                if (oCargo.ID == 0)
                {
                    oCargo.DataCriacao = DateTime.Now;
                    var result = aCtrl_Cargo.AdicionarCargo(oCargo);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    oCargo.DataUltimaAlteracao = DateTime.Now;
                    var result = aCtrl_Cargo.AtualizarCargo(oCargo);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
            }
        }

        private void txt_Cargo_KeyPress(object sender, KeyPressEventArgs e)
        {
            Verificacao.ValidarNomes(sender, e);
        }
    }
}
