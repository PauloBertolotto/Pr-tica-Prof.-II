﻿using Projeto_Otica99.Class_s.Controller_s;
using Projeto_Otica99.Class_s;
using Projeto_Otica99.Form_s.Cadastros.Cadastro_Com_Endereço;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Projeto_Otica99.Class_s.Outros;
using Projeto_Otica99.Class_s.Venda_e_Compra;

namespace Projeto_Otica99.Form_s.Consultas.Consulta_Com_Endereço
{
    public partial class FrmConFuncionarios : Projeto_Otica99.Form_s.Consultas.FrmConsultaPai
    {
        DadosCadastro2     oFuncionario;
        FrmCadPFePJ       oCadFuncionario;
        Ctrl_Funcionarios aCtrl_Funcionarios;
        Ctrl_Cidades      aCtrl_Cidades;
        Ctrl_Cargos       aCtrl_Cargos;
        private string status = "A";
        public FrmConFuncionarios()
        {
            InitializeComponent();
            oFuncionario       = new DadosCadastro2();
            aCtrl_Funcionarios = new Ctrl_Funcionarios();
            aCtrl_Cidades      = new Ctrl_Cidades();
            aCtrl_Cargos       = new Ctrl_Cargos();
            CarregaLV();
        }
        public int id = 0;
        public override void SetFrmCadastro(object obj)
        {
            base.SetFrmCadastro(obj);
            if (obj != null)
            {
                oCadFuncionario = (FrmCadPFePJ)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            base.ConhecaObj(obj, ctrl);

            aCtrl_Funcionarios = (Ctrl_Funcionarios)ctrl;
            this.CarregaLV();
        }
        protected override void Incluir()
        {
            base.Incluir();
            oCadFuncionario.ConhecaObj(oFuncionario);
            oCadFuncionario.lbl_Generica.Text          = "Funcionário";
            oCadFuncionario.lbl_CodPagamento.Visible   = false;
            oCadFuncionario.txt_CodCondicaoPag.Visible = false;
            oCadFuncionario.lbl_CondPag.Visible        = false;
            oCadFuncionario.txt_CondPag.Visible        = false;

            oCadFuncionario.ShowDialog();
            this.CarregaLV();
        }
        protected override void Alterar()
        {
            string aux = oCadFuncionario.btn_Salvar.Text;
            oCadFuncionario.btn_Salvar.Text = "Alterar";
            oCadFuncionario.lbl_Generica.Text = "Funcionário";
            // Verifica se algum item está selecionado na ListView
            if (LV_Con_Pai.SelectedItems.Count > 0)
            {
                // Obtém o item selecionado
                ListViewItem itemSelecionado = LV_Con_Pai.SelectedItems[0];

                // Crie uma instância da tela de destino

                // Preencha os campos ou propriedades da tela de destino com os dados do item selecionado
                oCadFuncionario.txt_Codigo.Text             = itemSelecionado.SubItems[0].Text;
                oCadFuncionario.txt_NomeOuRSocial.Text    = itemSelecionado.SubItems[1].Text;
                oCadFuncionario.txt_SobrenomeOuNFantasia.Text = itemSelecionado.SubItems[2].Text;

                if (itemSelecionado.SubItems[3].Text.Length < 18)
                {
                    oCadFuncionario.CB_Tipo.Text      = "PF";
                    oCadFuncionario.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFuncionario.CB_Tipo.Enabled   = false;
                }
                else
                {
                    oCadFuncionario.CB_Tipo.Text      = "PJ";
                    oCadFuncionario.mtb_CPFeCNPJ.Text = itemSelecionado.SubItems[3].Text;
                    oCadFuncionario.CB_Sexo.Text      = null;
                    oCadFuncionario.CB_Tipo.Enabled   = false;
                }

                oCadFuncionario.mtb_RGeIE.Text        = itemSelecionado.SubItems[4].Text;
                oCadFuncionario.txt_Email.Text        = itemSelecionado.SubItems[5].Text;
                oCadFuncionario.txt_Telefone.Text     = itemSelecionado.SubItems[6].Text;
                oCadFuncionario.txt_Numero.Text       = itemSelecionado.SubItems[9].Text;
                oCadFuncionario.txt_Endereco.Text     = itemSelecionado.SubItems[7].Text;
                oCadFuncionario.txt_Complemento.Text  = itemSelecionado.SubItems[8].Text;
                oCadFuncionario.mtb_CEP.Text          = itemSelecionado.SubItems[11].Text;
                oCadFuncionario.txt_Bairro.Text       = itemSelecionado.SubItems[10].Text;
                oCadFuncionario.txt_Cidade.Text       = itemSelecionado.SubItems[12].Text;
                oCadFuncionario.CB_Sexo.Text          = itemSelecionado.SubItems[14].Text;
                oCadFuncionario.txt_CodCidade.Text    = Convert.ToInt32(aCtrl_Funcionarios.BuscarIDCidade(oCadFuncionario.txt_Cidade.Text)).ToString();

                // Exiba a tela de destino
                oCadFuncionario.ShowDialog();
                oCadFuncionario.btn_Salvar.Text = aux;
                oCadFuncionario.CB_Tipo.Enabled = true;
                oCadFuncionario.CB_Sexo.Enabled = true;
                oCadFuncionario.txt_Codigo.Enabled = true;
            }
            else
            {
                MessageBox.Show("Selecione um item na lista antes de pressionar o botão.");
            }
        }
        public override void CarregaLV()
        {
            base.CarregaLV();
            List<DadosCadastro2> dados = aCtrl_Funcionarios.ListarFuncionarios(status);
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<DadosCadastro2> dados)
        {
            LV_Con_Pai.Items.Clear();

            foreach (var funcionario in dados)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(funcionario.ID));
                string nomeFantasia = string.IsNullOrWhiteSpace(funcionario.NomeOuRSocial) ? "Não Cadastrado" : funcionario.NomeOuRSocial;
                item.SubItems.Add(nomeFantasia);

                string razaoSocial = string.IsNullOrWhiteSpace(funcionario.SobrenomeOuNomeFantasia) ? "Não Cadastrado" : funcionario.SobrenomeOuNomeFantasia;
                item.SubItems.Add(razaoSocial);

                string cnpj = string.IsNullOrWhiteSpace(funcionario.CPFouCNPJ) ? "Não Cadastrado" : Verificacao.FormatarDocumento(funcionario.CPFouCNPJ);
                item.SubItems.Add(cnpj);

                string inscricaoEstadual = string.IsNullOrWhiteSpace(funcionario.RGouIE) ? "Não Cadastrado" : Verificacao.FormatarDocumento(funcionario.RGouIE);
                item.SubItems.Add(inscricaoEstadual);

                item.SubItems.Add(funcionario.Email);

                string telefone = string.IsNullOrEmpty(funcionario.Telefone) ? "Não Cadastrado" : Verificacao.FormatarTelefone(funcionario.Telefone);
                item.SubItems.Add(telefone);

                string endereco = string.IsNullOrEmpty(funcionario.Endereco) ? "Não Cadastrado" : (funcionario.Endereco);
                item.SubItems.Add(endereco);

                string complemento = string.IsNullOrEmpty(funcionario.Complemento) ? "Não Cadastrado" : (funcionario.Complemento);
                item.SubItems.Add(complemento);

                string numero = string.IsNullOrEmpty(funcionario.Numero) ? "Não Cadastrado" : (funcionario.Numero);
                item.SubItems.Add(numero);

                string bairro = string.IsNullOrEmpty(funcionario.Bairro) ? "Não Cadastrado" : (funcionario.Bairro);
                item.SubItems.Add(bairro);

                string cep = string.IsNullOrEmpty(funcionario.CEP) ? "Não Cadastrado" : (funcionario.CEP);
                item.SubItems.Add(cep);

                string cidade = string.IsNullOrWhiteSpace(aCtrl_Funcionarios.BuscarCidadePorId(funcionario.CidadeID.ID)) ? "Não Cadastrado" : aCtrl_Funcionarios.BuscarCidadePorId(funcionario.CidadeID.ID);
                item.SubItems.Add(cidade);

                string uf = string.IsNullOrWhiteSpace(aCtrl_Cidades.BuscarUFPorId(funcionario.CidadeID.EstadoID.ID)) ? "Não Cadastrado" : aCtrl_Cidades.BuscarUFPorId(funcionario.CidadeID.EstadoID.ID);
                item.SubItems.Add(uf);

                string sexo = string.IsNullOrEmpty(funcionario.Sexo) ? "Não Cadastrado" : (funcionario.Sexo);
                item.SubItems.Add(sexo);

                string datacad = string.IsNullOrEmpty(funcionario.DataCriacao.ToString()) ? "Não Cadastrado" : (funcionario.DataCriacao.ToString());
                item.SubItems.Add(datacad);

                string dataalt = string.IsNullOrEmpty(funcionario.DataUltimaAlteracao.ToString()) ? "Não Cadastrado" : (funcionario.DataUltimaAlteracao.ToString());
                item.SubItems.Add(dataalt);

                string condpag = string.IsNullOrEmpty(funcionario.condicao_Pagamento.Condicao) ? "Não Cadastrado" : (funcionario.condicao_Pagamento.Condicao);
                item.SubItems.Add(condpag);
                
                string datanasc = string.IsNullOrEmpty(funcionario.DataNasc) ? "Não Cadastrado" : (funcionario.DataNasc);               
                item.SubItems.Add(datanasc);
                          
                item.SubItems.Add(funcionario.condicao_Pagamento.Condicao);
            
                item.Tag = funcionario;
                LV_Con_Pai.Items.Add(item);
            }
        }
        //string cargo = string.IsNullOrWhiteSpace(aCtrl_Cargos.BuscarCargoPorId(funcionario.CargoID.ID)) ? "Não Cadastrado" : aCtrl_Cargos.BuscarCargoPorId(funcionario.CargoID.ID);
        //item.SubItems.Add(cargo);
        public override void Excluir()
        {
            base.Excluir();
            if (MessageBox.Show("Tem certeza que deseja excluir este registro?", "Confirmação", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                if (LV_Con_Pai.SelectedItems.Count > 0)
                {
                    ListViewItem selectedItem = LV_Con_Pai.SelectedItems[0];
                    string aux = selectedItem.SubItems[0].Text;
                    aCtrl_Funcionarios.Excluir(aux);

                }
                this.CarregaLV();
            }
        }
        private string ObterCritérioPesquisa()
        {
            if (CB_Codigo.Checked)
            {
                return "ID";
            }

            else if (CB_Nome.Checked)
            {
                return "NOME";
            }
            else if (CB_CPF.Checked)
            {
                return "CPF";
            }
            else if (CB_RG.Checked)
            {
                return "RG";
            }
            else if (CB_Cidade.Checked)
            {
                return "CIDADE";
            }

            return string.Empty; // Nenhum critério selecionado
        }
        protected void Pesquisar()
        {
            string valorPesquisa = txt_Codigo.Text;
            string criterioPesquisa = ObterCritérioPesquisa();

            if (!string.IsNullOrEmpty(valorPesquisa) && !string.IsNullOrEmpty(criterioPesquisa))
            {
                // Execute uma pesquisa na camada de controle com base no critério
                var resultados = aCtrl_Funcionarios.PesquisarFuncionariosPorCriterio(criterioPesquisa, valorPesquisa, status);

                // Use o método de preenchimento para atualizar a ListView
                PreencherListView(resultados);
            }
        }
        public override void Atualizar()
        {
            CarregaLV();
        }

        private void btn_ConBuscar_Click(object sender, EventArgs e)
        {
            Pesquisar();
        }
    }
}
