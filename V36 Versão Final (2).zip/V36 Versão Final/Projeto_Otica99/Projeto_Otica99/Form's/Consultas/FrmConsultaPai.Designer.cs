﻿namespace Projeto_Otica99.Form_s.Consultas
{
    partial class FrmConsultaPai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ConBuscar = new System.Windows.Forms.Button();
            this.btn_Con_Incluir = new System.Windows.Forms.Button();
            this.btn_Con_Alterar = new System.Windows.Forms.Button();
            this.btn_Con_Excluir = new System.Windows.Forms.Button();
            this.LV_Con_Pai = new System.Windows.Forms.ListView();
            this.CH_Codigo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_Att = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Código
            // 
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.Location = new System.Drawing.Point(5, -2);
            this.lbl_Código.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.lbl_Código.Size = new System.Drawing.Size(93, 24);
            this.lbl_Código.Text = "Pesquisar";
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(9, 24);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Codigo.Size = new System.Drawing.Size(1047, 26);
            this.txt_Codigo.Text = "";
            this.txt_Codigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_Sair
            // 
            this.btn_Sair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sair.Location = new System.Drawing.Point(1133, 667);
            // 
            // btn_ConBuscar
            // 
            this.btn_ConBuscar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ConBuscar.BackColor = System.Drawing.Color.Gold;
            this.btn_ConBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_ConBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConBuscar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_ConBuscar.Location = new System.Drawing.Point(1060, 21);
            this.btn_ConBuscar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_ConBuscar.Name = "btn_ConBuscar";
            this.btn_ConBuscar.Size = new System.Drawing.Size(68, 27);
            this.btn_ConBuscar.TabIndex = 3;
            this.btn_ConBuscar.Text = "Buscar";
            this.btn_ConBuscar.UseVisualStyleBackColor = false;
            this.btn_ConBuscar.Click += new System.EventHandler(this.btn_ConBuscar_Click);
            // 
            // btn_Con_Incluir
            // 
            this.btn_Con_Incluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Con_Incluir.BackColor = System.Drawing.Color.Gold;
            this.btn_Con_Incluir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Con_Incluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Con_Incluir.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Con_Incluir.Location = new System.Drawing.Point(917, 667);
            this.btn_Con_Incluir.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Con_Incluir.Name = "btn_Con_Incluir";
            this.btn_Con_Incluir.Size = new System.Drawing.Size(68, 26);
            this.btn_Con_Incluir.TabIndex = 4;
            this.btn_Con_Incluir.Text = "Incluir";
            this.btn_Con_Incluir.UseVisualStyleBackColor = false;
            this.btn_Con_Incluir.Click += new System.EventHandler(this.btn_Con_Incluir_Click);
            // 
            // btn_Con_Alterar
            // 
            this.btn_Con_Alterar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Con_Alterar.BackColor = System.Drawing.Color.Gold;
            this.btn_Con_Alterar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Con_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Con_Alterar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Con_Alterar.Location = new System.Drawing.Point(989, 667);
            this.btn_Con_Alterar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Con_Alterar.Name = "btn_Con_Alterar";
            this.btn_Con_Alterar.Size = new System.Drawing.Size(68, 26);
            this.btn_Con_Alterar.TabIndex = 5;
            this.btn_Con_Alterar.Text = "Alterar";
            this.btn_Con_Alterar.UseVisualStyleBackColor = false;
            this.btn_Con_Alterar.Click += new System.EventHandler(this.btn_Con_Alterar_Click);
            // 
            // btn_Con_Excluir
            // 
            this.btn_Con_Excluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Con_Excluir.BackColor = System.Drawing.Color.Gold;
            this.btn_Con_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Con_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Con_Excluir.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Con_Excluir.Location = new System.Drawing.Point(1061, 667);
            this.btn_Con_Excluir.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Con_Excluir.Name = "btn_Con_Excluir";
            this.btn_Con_Excluir.Size = new System.Drawing.Size(68, 26);
            this.btn_Con_Excluir.TabIndex = 6;
            this.btn_Con_Excluir.Text = "Excluir";
            this.btn_Con_Excluir.UseVisualStyleBackColor = false;
            this.btn_Con_Excluir.Click += new System.EventHandler(this.btn_Con_Excluir_Click);
            // 
            // LV_Con_Pai
            // 
            this.LV_Con_Pai.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LV_Con_Pai.BackColor = System.Drawing.Color.DarkGray;
            this.LV_Con_Pai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH_Codigo});
            this.LV_Con_Pai.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LV_Con_Pai.ForeColor = System.Drawing.Color.Black;
            this.LV_Con_Pai.FullRowSelect = true;
            this.LV_Con_Pai.GridLines = true;
            this.LV_Con_Pai.HideSelection = false;
            this.LV_Con_Pai.Location = new System.Drawing.Point(9, 55);
            this.LV_Con_Pai.Margin = new System.Windows.Forms.Padding(2);
            this.LV_Con_Pai.Name = "LV_Con_Pai";
            this.LV_Con_Pai.Size = new System.Drawing.Size(1192, 610);
            this.LV_Con_Pai.TabIndex = 7;
            this.LV_Con_Pai.UseCompatibleStateImageBehavior = false;
            this.LV_Con_Pai.View = System.Windows.Forms.View.Details;
            // 
            // CH_Codigo
            // 
            this.CH_Codigo.Text = "Código";
            this.CH_Codigo.Width = 100;
            // 
            // btn_Att
            // 
            this.btn_Att.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Att.BackColor = System.Drawing.Color.Gold;
            this.btn_Att.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Att.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Att.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Att.Location = new System.Drawing.Point(1133, 21);
            this.btn_Att.Name = "btn_Att";
            this.btn_Att.Size = new System.Drawing.Size(68, 27);
            this.btn_Att.TabIndex = 9;
            this.btn_Att.Text = "Atualizar";
            this.btn_Att.UseVisualStyleBackColor = false;
            this.btn_Att.Click += new System.EventHandler(this.btn_Att_Click);
            // 
            // FrmConsultaPai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1209, 702);
            this.Controls.Add(this.btn_Att);
            this.Controls.Add(this.LV_Con_Pai);
            this.Controls.Add(this.btn_Con_Excluir);
            this.Controls.Add(this.btn_Con_Alterar);
            this.Controls.Add(this.btn_Con_Incluir);
            this.Controls.Add(this.btn_ConBuscar);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmConsultaPai";
            this.Text = "FrmConsultaPai";
            this.Controls.SetChildIndex(this.btn_Sair, 0);
            this.Controls.SetChildIndex(this.lbl_Código, 0);
            this.Controls.SetChildIndex(this.txt_Codigo, 0);
            this.Controls.SetChildIndex(this.btn_ConBuscar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Incluir, 0);
            this.Controls.SetChildIndex(this.btn_Con_Alterar, 0);
            this.Controls.SetChildIndex(this.btn_Con_Excluir, 0);
            this.Controls.SetChildIndex(this.LV_Con_Pai, 0);
            this.Controls.SetChildIndex(this.btn_Att, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected System.Windows.Forms.ColumnHeader CH_Codigo;
        protected System.Windows.Forms.Button btn_ConBuscar;
        protected System.Windows.Forms.Button btn_Con_Incluir;
        protected System.Windows.Forms.Button btn_Con_Alterar;
        protected System.Windows.Forms.Button btn_Con_Excluir;
        protected System.Windows.Forms.ListView LV_Con_Pai;
        protected System.Windows.Forms.Button btn_Att;
    }
}
