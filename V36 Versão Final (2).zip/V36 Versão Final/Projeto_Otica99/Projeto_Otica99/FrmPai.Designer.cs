﻿namespace Projeto_Otica99
{
    partial class FrmPai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPai));
            this.btn_Sair = new System.Windows.Forms.Button();
            this.lbl_Código = new System.Windows.Forms.Label();
            this.txt_Codigo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Sair
            // 
            this.btn_Sair.BackColor = System.Drawing.Color.Gold;
            this.btn_Sair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Sair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sair.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Sair.Location = new System.Drawing.Point(770, 453);
            this.btn_Sair.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Sair.Name = "btn_Sair";
            this.btn_Sair.Size = new System.Drawing.Size(68, 26);
            this.btn_Sair.TabIndex = 0;
            this.btn_Sair.Text = "Sair";
            this.btn_Sair.UseVisualStyleBackColor = false;
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // lbl_Código
            // 
            this.lbl_Código.AutoSize = true;
            this.lbl_Código.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Código.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Código.ForeColor = System.Drawing.Color.Gold;
            this.lbl_Código.Location = new System.Drawing.Point(6, 7);
            this.lbl_Código.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Código.Name = "lbl_Código";
            this.lbl_Código.Size = new System.Drawing.Size(52, 17);
            this.lbl_Código.TabIndex = 1;
            this.lbl_Código.Text = "Código";
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Codigo.Location = new System.Drawing.Point(9, 26);
            this.txt_Codigo.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Codigo.Name = "txt_Codigo";
            this.txt_Codigo.Size = new System.Drawing.Size(76, 23);
            this.txt_Codigo.TabIndex = 2;
            this.txt_Codigo.Text = "0";
            this.txt_Codigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FrmPai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(846, 488);
            this.Controls.Add(this.txt_Codigo);
            this.Controls.Add(this.lbl_Código);
            this.Controls.Add(this.btn_Sair);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FrmPai";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPai";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmPai_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label lbl_Código;
        public System.Windows.Forms.TextBox txt_Codigo;
        public System.Windows.Forms.Button btn_Sair;
    }
}